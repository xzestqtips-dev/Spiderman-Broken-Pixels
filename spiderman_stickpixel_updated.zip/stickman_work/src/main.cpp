// ============================================================================
//  STICKMAN: PIXEL CITY  -  mobile landscape pixel-art endless runner
//  C++17 + SDL2.  Single file.  World art, fonts, audio and the stickman player are all
//  generated in code, so there are no asset files to ship.  The stickman is drawn in the
//  style of Alan Becker's Animator vs. Animation.  Fan-made tribute, not affiliated.
// ============================================================================
#include <SDL.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <deque>
#include <string>
#include <vector>

#include "progression.h"

typedef uint32_t u32;
static const float PI = 3.14159265f;
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static int pmod(int a, int m) { a %= m; return a < 0 ? a + m : a; }
static u32 hash3(u32 a, u32 b, u32 c) {
    u32 h = a * 374761393u + b * 668265263u + c * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}
struct Rng {
    u32 s;
    explicit Rng(u32 seed = 1) : s(seed ? seed : 1) {}
    u32 next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float f() { return (next() & 0xFFFFFF) / 16777216.0f; }
    int range(int a, int b) { if (b < a) b = a; return a + (int)(f() * (b - a + 1)); }
};

// ============================================================================
//  DISPLAY  (pixel-perfect integer scaling, adapts to any phone resolution)
// ============================================================================
static SDL_Window* gWin = nullptr;
static SDL_Renderer* gRen = nullptr;
static SDL_Texture* gTarget = nullptr;
static int OUTW = 1280, OUTH = 720;   // real output pixels
static int W = 640, H = 360, SC = 3;  // internal resolution + integer scale
static int OFFX = 0, OFFY = 0;        // letterbox offset in output pixels
static bool portrait = false;
static float safeL = 14, safeR = 14, safeT = 8, safeB = 10;
static float minTouch = 40;           // >= ~48dp expressed in internal pixels

static void recalcDisplay() {
    SDL_GetRendererOutputSize(gRen, &OUTW, &OUTH);
    portrait = OUTH > OUTW;
    int minD = std::min(OUTW, OUTH);
    SC = std::max(1, (int)lroundf(minD / 360.0f));
    W = std::max(1, OUTW / SC);
    H = std::max(1, OUTH / SC);
    OFFX = (OUTW - W * SC) / 2;
    OFFY = (OUTH - H * SC) / 2;
    if (gTarget) SDL_DestroyTexture(gTarget);
    gTarget = SDL_CreateTexture(gRen, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, W, H);
    // mobile safe area (notches / rounded corners): conservative margins
    safeL = safeR = std::max(14.0f, W * 0.035f);
    safeT = 8; safeB = 10;
    float ddpi = 0;
    if (SDL_GetDisplayDPI(0, &ddpi, nullptr, nullptr) != 0 || ddpi < 80) ddpi = 400;
    minTouch = clampf(48.0f * ddpi / 160.0f / (float)SC, 36.0f, 56.0f);
}

// ============================================================================
//  DRAW HELPERS
// ============================================================================
static void col(u32 c, int a = 255) {
    SDL_SetRenderDrawColor(gRen, (c >> 16) & 255, (c >> 8) & 255, c & 255, (Uint8)a);
}
static void rect(int x, int y, int w, int h, u32 c, int a = 255) {
    if (w <= 0 || h <= 0) return;
    col(c, a);
    SDL_Rect r = {x, y, w, h};
    SDL_RenderFillRect(gRen, &r);
}
static void disc(int cx, int cy, int r, u32 c, int a = 255) {
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        rect(cx - dx, cy + dy, dx * 2 + 1, 1, c, a);
    }
}
static void line(float x0, float y0, float x1, float y1, u32 c, int a = 255) {
    col(c, a);
    SDL_RenderDrawLine(gRen, (int)x0, (int)y0, (int)x1, (int)y1);
}

// ---- 5x7 bitmap font ----
struct Glyph { char c; uint8_t r[7]; };
static const Glyph FONT[] = {
    {'A',{0x0E,0x11,0x11,0x1F,0x11,0x11,0x11}}, {'B',{0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E}},
    {'C',{0x0E,0x11,0x10,0x10,0x10,0x11,0x0E}}, {'D',{0x1E,0x11,0x11,0x11,0x11,0x11,0x1E}},
    {'E',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}}, {'F',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x10}},
    {'G',{0x0E,0x11,0x10,0x17,0x11,0x11,0x0F}}, {'H',{0x11,0x11,0x11,0x1F,0x11,0x11,0x11}},
    {'I',{0x0E,0x04,0x04,0x04,0x04,0x04,0x0E}}, {'J',{0x07,0x02,0x02,0x02,0x02,0x12,0x0C}},
    {'K',{0x11,0x12,0x14,0x18,0x14,0x12,0x11}}, {'L',{0x10,0x10,0x10,0x10,0x10,0x10,0x1F}},
    {'M',{0x11,0x1B,0x15,0x15,0x11,0x11,0x11}}, {'N',{0x11,0x11,0x19,0x15,0x13,0x11,0x11}},
    {'O',{0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'P',{0x1E,0x11,0x11,0x1E,0x10,0x10,0x10}},
    {'Q',{0x0E,0x11,0x11,0x11,0x15,0x12,0x0D}}, {'R',{0x1E,0x11,0x11,0x1E,0x14,0x12,0x11}},
    {'S',{0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E}}, {'T',{0x1F,0x04,0x04,0x04,0x04,0x04,0x04}},
    {'U',{0x11,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'V',{0x11,0x11,0x11,0x11,0x11,0x0A,0x04}},
    {'W',{0x11,0x11,0x11,0x15,0x15,0x15,0x0A}}, {'X',{0x11,0x11,0x0A,0x04,0x0A,0x11,0x11}},
    {'Y',{0x11,0x11,0x11,0x0A,0x04,0x04,0x04}}, {'Z',{0x1F,0x01,0x02,0x04,0x08,0x10,0x1F}},
    {'0',{0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}}, {'1',{0x04,0x0C,0x04,0x04,0x04,0x04,0x0E}},
    {'2',{0x0E,0x11,0x01,0x02,0x04,0x08,0x1F}}, {'3',{0x1F,0x02,0x04,0x02,0x01,0x11,0x0E}},
    {'4',{0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}}, {'5',{0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E}},
    {'6',{0x06,0x08,0x10,0x1E,0x11,0x11,0x0E}}, {'7',{0x1F,0x01,0x02,0x04,0x08,0x08,0x08}},
    {'8',{0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}}, {'9',{0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C}},
    {'.',{0,0,0,0,0,0x0C,0x0C}}, {':',{0,0x0C,0x0C,0,0x0C,0x0C,0}},
    {'-',{0,0,0,0x1F,0,0,0}}, {'/',{0x01,0x02,0x02,0x04,0x08,0x08,0x10}},
    {'!',{0x04,0x04,0x04,0x04,0x04,0,0x04}}, {'?',{0x0E,0x11,0x01,0x02,0x04,0,0x04}},
    {'+',{0,0x04,0x04,0x1F,0x04,0x04,0}}, {'%',{0x19,0x19,0x02,0x04,0x08,0x13,0x13}}, {',',{0,0,0,0,0x0C,0x04,0x08}},
    {'<',{0x02,0x04,0x08,0x10,0x08,0x04,0x02}}, {'>',{0x08,0x04,0x02,0x01,0x02,0x04,0x08}},
};
static uint8_t gGl[128][7];
static void initFont() {
    memset(gGl, 0, sizeof(gGl));
    for (const Glyph& g : FONT) memcpy(gGl[(int)g.c], g.r, 7);
}
static int textW(const char* s, int sc) { return (int)strlen(s) * 6 * sc - sc; }
static void text(const char* s, int x, int y, int sc, u32 c, int a = 255) {
    static std::vector<SDL_Rect> rs;
    rs.clear();
    int cx = x;
    for (; *s; ++s) {
        unsigned char ch = (unsigned char)toupper((unsigned char)*s);
        if (ch < 128) {
            for (int r = 0; r < 7; r++) {
                uint8_t bits = gGl[ch][r];
                for (int b = 0; b < 5; b++)
                    if (bits & (16 >> b)) rs.push_back({cx + b * sc, y + r * sc, sc, sc});
            }
        }
        cx += 6 * sc;
    }
    col(c, a);
    if (!rs.empty()) SDL_RenderFillRects(gRen, rs.data(), (int)rs.size());
}
static void textShadow(const char* s, int x, int y, int sc, u32 c, u32 sh = 0x05060F) {
    text(s, x + std::max(1, sc / 2), y + std::max(1, sc / 2), sc, sh, 220);
    text(s, x, y, sc, c);
}
static void textC(const char* s, int cx, int y, int sc, u32 c) { textShadow(s, cx - textW(s, sc) / 2, y, sc, c); }
static int fitScale(const char* s, int maxW, int maxSc) {
    int sc = maxSc;
    while (sc > 1 && textW(s, sc) > maxW) sc--;
    return sc;
}

// ============================================================================
//  PIXEL IMAGES / PROCEDURAL ART
// ============================================================================
struct Img {
    int w, h;
    std::vector<u32> p;
    Img(int w_, int h_) : w(w_), h(h_), p((size_t)w_ * h_, 0) {}
    void set(int x, int y, u32 c) { if (x >= 0 && y >= 0 && x < w && y < h) p[(size_t)y * w + x] = c; }
    u32 get(int x, int y) const { return (x >= 0 && y >= 0 && x < w && y < h) ? p[(size_t)y * w + x] : 0; }
    void fill(int x, int y, int ww, int hh, u32 c) {
        for (int yy = y; yy < y + hh; yy++) for (int xx = x; xx < x + ww; xx++) set(xx, yy, c);
    }
};
static SDL_Texture* mkTex(const Img& im) {
    SDL_Texture* t = SDL_CreateTexture(gRen, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC, im.w, im.h);
    SDL_UpdateTexture(t, nullptr, im.p.data(), im.w * 4);
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    return t;
}

// ---- facade tiles (6 architectural styles x 3 window-light variants) ----
static SDL_Texture* gTile[6][3];
static SDL_Texture* gFar[3];

static u32 litColor(Rng& r, u32 off) {
    float f = r.f();
    if (f < 0.28f) return 0xFFFFD98A;
    if (f < 0.36f) return 0xFF8FE3FF;
    if (f < 0.40f) return 0xFFFF9CB8;
    return off;
}
static void windowRect(Img& im, Rng& r, int x, int y, int w, int h, u32 off, u32 frame) {
    im.fill(x - 1, y - 1, w + 2, h + 2, frame);
    u32 c = litColor(r, off);
    im.fill(x, y, w, h, c);
    if (c != off) im.fill(x, y + h - 2, w, 2, 0xFFE0B060);  // warm floor glow
    else im.fill(x, y, w, 1, off + 0x00080808);
}
static Img makeTile(int st, int var) {
    Img im(64, 64);
    Rng r(1234u + st * 97u + var * 7919u);
    switch (st) {
        case 0:  // glass tower
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                u32 c = 0xFF23405E;
                if (((x + y) >> 3) % 7 == 0) c = 0xFF2C5070;
                if (x % 16 == 0 || y % 16 == 0) c = 0xFF111F32;
                im.set(x, y, c);
            }
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) {
                u32 l = litColor(r, 0);
                if (l) { im.fill(i * 16 + 1, j * 16 + 1, 15, 15, l); im.fill(i * 16 + 1, j * 16 + 12, 15, 4, 0xFFC89A50); }
            }
            break;
        case 1:  // office tower
            im.fill(0, 0, 64, 64, 0xFF3A3D4F);
            for (int x = 0; x < 64; x += 16) im.fill(x, 0, 1, 64, 0xFF2E3141);
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++)
                windowRect(im, r, 3 + i * 16, 3 + j * 16, 10, 12, 0xFF1B2030, 0xFF22242F);
            break;
        case 2:  // brick apartments
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                int row = y / 4; u32 c = 0xFF6B3A35;
                if (y % 4 == 3 || (x + (row % 2) * 4) % 8 == 7) c = 0xFF4A2826;
                else if ((x * 7 + y * 13) % 11 == 0) c = 0xFF7A433C;
                im.set(x, y, c);
            }
            for (int j = 0; j < 2; j++) for (int i = 0; i < 4; i++) {
                int x = i * 16 + 4, y = j * 32 + 6;
                im.fill(x - 1, y - 2, 10, 2, 0xFF9A8A7A);
                windowRect(im, r, x, y, 8, 16, 0xFF1A1620, 0xFF2A1A1A);
                im.fill(x - 1, y + 17, 10, 2, 0xFF9A8A7A);
            }
            break;
        case 3:  // residential high-rise
            im.fill(0, 0, 64, 64, 0xFF4F4866);
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) {
                windowRect(im, r, 4 + i * 16, 3 + j * 16, 8, 9, 0xFF221E30, 0xFF2B263A);
                im.fill(i * 16 + 1, j * 16 + 13, 14, 2, 0xFF2B263A);
                im.fill(i * 16 + 1, j * 16 + 12, 14, 1, 0xFF7A7298);
            }
            break;
        case 4:  // industrial
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                u32 c = (x % 4 < 2) ? 0xFF313745 : 0xFF2A2F3B;
                if (y >= 28 && y < 32) c = (((x + y) / 4) % 2) ? 0xFFB8872A : 0xFF1A1A1A;
                im.set(x, y, c);
            }
            windowRect(im, r, 6, 10, 12, 6, 0xFF14171F, 0xFF1E222C);
            windowRect(im, r, 38, 10, 12, 6, 0xFF14171F, 0xFF1E222C);
            windowRect(im, r, 6, 44, 12, 6, 0xFF14171F, 0xFF1E222C);
            windowRect(im, r, 38, 44, 12, 6, 0xFF14171F, 0xFF1E222C);
            break;
        default:  // construction frame
            im.fill(0, 0, 64, 64, 0xFF121828);
            for (int k = 0; k < 2; k++) {
                im.fill(k * 32 + 3, 3, 29, 3, 0xFF4A4E5C);
                for (int i = 0; i < 29; i++) { im.set(k * 32 + 3 + i, 6 + i, 0xFF7A4818); im.set(k * 32 + 31 - i, 6 + i, 0xFF7A4818); }
            }
            for (int x : {0, 32}) { im.fill(x, 0, 3, 64, 0xFF9A5B22); im.fill(x, 0, 1, 64, 0xFFC9822F); }
            for (int y : {0, 32}) { im.fill(0, y, 64, 3, 0xFF9A5B22); im.fill(0, y, 64, 1, 0xFFC9822F); }
            if (r.f() < 0.7f) { im.fill(12, 14, 3, 3, 0xFFFFE9A0); im.fill(11, 17, 5, 1, 0xFF8A7430); }
            if (r.f() < 0.5f) { im.fill(46, 46, 3, 3, 0xFFFFE9A0); im.fill(45, 49, 5, 1, 0xFF8A7430); }
            break;
    }
    return im;
}
static Img makeFar(int var) {
    Img im(32, 32);
    Rng r(777u + var * 31u);
    im.fill(0, 0, 32, 32, 0xFF1B2144);
    for (int gy = 0; gy < 5; gy++) for (int gx = 0; gx < 5; gx++) {
        float f = r.f();
        u32 c = f < 0.22f ? 0xFFB8A56A : (f < 0.30f ? 0xFF6A92B8 : 0xFF161B38);
        im.fill(gx * 6 + 2, gy * 6 + 3, 2, 2, c);
    }
    return im;
}

// ==== STICKMAN BEGIN ====
// ---- Stickman player (Animator-vs-Animation style, Spider-Man moveset) -----------------
//  No sprite files: the player is a skeleton posed from joint angles every frame.
//  Smoothness comes from three things:
//    1. continuous cycles - run / idle / swing poses are computed from a continuous phase,
//       not picked from a handful of stepped frames;
//    2. pose smoothing - the displayed pose chases the target pose with critically-damped
//       exponential easing, so every state change (jump -> fall -> swing -> dive -> land)
//       flows into the next instead of snapping (hip height is blended too);
//    3. anti-aliased capsule rendering - limbs are rasterised with analytic coverage into a
//       small RGBA texture, so rotated limbs and the round head have soft, clean edges.
//  Coordinates are relative to the body centre (Player::y), +x = facing direction, y grows
//  downward; the soles sit STK_FEET_Y pixels below the body centre.
//  Change STK_BODY / STK_OUTLINE to recolour him (orange 0xFF8A1E is the "Second Coming").
enum Frame {
    F_IDLE,      // breathing loop (phase driven)
    F_RUN,       // run cycle (phase driven)
    F_SHOOT,     // thwip: web arm thrown up and forward
    F_ATTACH,    // web caught, body snaps taut
    F_SWING,     // swing, blended between "trailing" and "reaching" by swing position
    F_JUMP,      // rising, lead knee up
    F_FALL,      // dropping, limbs spread
    F_FLIP,      // double-jump tuck somersault
    F_RELEASE,   // let go of the web: superhero dive
    F_LAND,      // normal landing squash
    F_HERO,      // hard fall: three-point superhero landing
    F_HIT,       // knocked back
    F_DEAD,      // limp
    F_CLING,     // wall-clinging idle
    F_CLIMB,     // alternating wall crawl
    F_SLIDE,     // low skid along the roof
    F_COUNT
};
static const int STK_FEET_Y = 26;               // soles, relative to the body centre
static const u32 STK_BODY = 0x0B0B12;           // limb colour
static const u32 STK_OUTLINE = 0xE8ECFF;        // thin light rim so he reads on the night sky

enum StkJoint { J_HIP, J_NECK, J_HEAD, J_KNF, J_FTF, J_KNB, J_FTB, J_ELF, J_HNF, J_ELB, J_HNB, J_N };
struct StkPose {            // angles in degrees measured from "straight down", + = toward facing side
    float hipX = 0, hipY = 2, lean = 0, tilt = 0;
    float thF = 0, shF = 0, thB = 0, shB = 0;   // F = front/near limbs, B = back/far limbs
    float upF = 0, foF = 0, upB = 0, foB = 0;
    float snap = 0;                              // 0..1: how far to lower the hips until the lowest foot touches the ground
};
static const float STK_TORSO = 16, STK_THIGH = 12, STK_SHIN = 12, STK_UARM = 8, STK_FARM = 8, STK_HEADD = 6;

static void stkSolve(const StkPose& p, float jx[J_N], float jy[J_N]) {
    auto dir = [](float deg, float len, float& dx, float& dy) { float a = deg * PI / 180.0f; dx = sinf(a) * len; dy = cosf(a) * len; };
    float dx, dy, hy = p.hipY;
    for (int pass = 0; pass < 2; pass++) {
        jx[J_HIP] = p.hipX; jy[J_HIP] = hy;
        dir(p.thF, STK_THIGH, dx, dy); jx[J_KNF] = jx[J_HIP] + dx; jy[J_KNF] = jy[J_HIP] + dy;
        dir(p.shF, STK_SHIN, dx, dy);  jx[J_FTF] = jx[J_KNF] + dx; jy[J_FTF] = jy[J_KNF] + dy;
        dir(p.thB, STK_THIGH, dx, dy); jx[J_KNB] = jx[J_HIP] + dx; jy[J_KNB] = jy[J_HIP] + dy;
        dir(p.shB, STK_SHIN, dx, dy);  jx[J_FTB] = jx[J_KNB] + dx; jy[J_FTB] = jy[J_KNB] + dy;
        if (p.snap > 0.001f && pass == 0) hy += clampf(p.snap, 0.0f, 1.0f) * (float)STK_FEET_Y - std::max(jy[J_FTF], jy[J_FTB]);
        else break;
    }
    dir(180.0f - p.lean, STK_TORSO, dx, dy);
    jx[J_NECK] = jx[J_HIP] + dx; jy[J_NECK] = jy[J_HIP] + dy;
    dir(180.0f - p.lean - p.tilt, STK_HEADD, dx, dy);
    jx[J_HEAD] = jx[J_NECK] + dx; jy[J_HEAD] = jy[J_NECK] + dy;
    dir(p.upF, STK_UARM, dx, dy); jx[J_ELF] = jx[J_NECK] + dx; jy[J_ELF] = jy[J_NECK] + dy;
    dir(p.foF, STK_FARM, dx, dy); jx[J_HNF] = jx[J_ELF] + dx;  jy[J_HNF] = jy[J_ELF] + dy;
    dir(p.upB, STK_UARM, dx, dy); jx[J_ELB] = jx[J_NECK] + dx; jy[J_ELB] = jy[J_NECK] + dy;
    dir(p.foB, STK_FARM, dx, dy); jx[J_HNB] = jx[J_ELB] + dx;  jy[J_HNB] = jy[J_ELB] + dy;
}

// every animated field of a pose, so blending and smoothing can just loop over them
static float StkPose::* const STK_F[] = {
    &StkPose::hipX, &StkPose::hipY, &StkPose::lean, &StkPose::tilt,
    &StkPose::thF, &StkPose::shF, &StkPose::thB, &StkPose::shB,
    &StkPose::upF, &StkPose::foF, &StkPose::upB, &StkPose::foB, &StkPose::snap };

static StkPose stkBlend(const StkPose& a, const StkPose& b, float t) {
    StkPose o;
    for (auto m : STK_F) o.*m = lerpf(a.*m, b.*m, t);
    return o;
}

// one leg of the run cycle: phase in radians (0 = thigh vertical, moving forward)
static void stkRunLeg(float ph, float amp, float& thigh, float& shin) {
    thigh = amp * sinf(ph);
    float k = std::max(0.0f, cosf(ph));
    shin = thigh - (12.0f + 88.0f * powf(k, 1.4f));
}
// phase = cycles (continuous, any value);  swing = 0 (behind the anchor) .. 1 (past the anchor)
// style picks a random variant of the move, j (-1..1) is a random nudge so no two look the same
static StkPose stkMakePose(int f, float phase, float swing, int style = 0, float j = 0) {
    StkPose p;
    switch (f) {
        case F_IDLE: {   // low spidey stance: front hand down by the knee, back arm cocked
            float b = sinf(phase * 2.0f * PI);
            p.snap = true; p.lean = 16 + 2 * b; p.tilt = -8 + b;
            p.thF = 42 + 2 * b; p.shF = -14; p.thB = -20; p.shB = -58 - 2 * b;
            p.upF = 28 + 3 * b; p.foF = 8; p.upB = -34 - 2 * b; p.foB = -62;
            break; }
        case F_RUN: {
            float ph = phase * 2.0f * PI, amp = 46 + 6 * j, lc = sinf(ph * 2.0f);
            p.snap = true;
            stkRunLeg(ph, amp, p.thF, p.shF);
            stkRunLeg(ph + PI, amp, p.thB, p.shB);
            if (style == 1) {          // hunched spidey run, arms trailing behind
                p.lean = 30 + 2 * lc; p.tilt = -14;
                p.upF = -35 + 25 * sinf(ph + PI); p.foF = p.upF + 35;
                p.upB = -35 + 25 * sinf(ph);      p.foB = p.upB + 35;
            } else if (style == 2) {   // upright sprint, hard arm pump
                p.lean = 20 + lc; p.tilt = -8;
                p.upF = (60 + 6 * j) * sinf(ph + PI); p.foF = p.upF + 100;
                p.upB = (60 + 6 * j) * sinf(ph);      p.foB = p.upB + 100;
            } else {                   // loose Becker run, big arm swing
                p.lean = 14 + 1.5f * lc; p.tilt = -6;
                p.upF = (50 + 8 * j) * sinf(ph + PI); p.foF = p.upF + 85;
                p.upB = (50 + 8 * j) * sinf(ph);      p.foB = p.upB + 85;
            }
            break; }
        case F_SHOOT:   // thwip: web arm thrown up and forward
            if (style == 1) {   // side thwip, legs split
                p.hipY = 0; p.lean = 14; p.thF = 52; p.shF = 28; p.thB = -48; p.shB = -34;
                p.upF = 122; p.foF = 128; p.upB = -70; p.foB = -48;
            } else {
                p.hipY = 0; p.lean = 8; p.thF = 62; p.shF = 8; p.thB = -22; p.shB = -68;
                p.upF = 146; p.foF = 150; p.upB = -55; p.foB = -25;
            }
            break;
        case F_ATTACH:  // web caught: arm straight up, legs hang, body stretched
            p.hipY = 3; p.lean = 0; p.thF = 18; p.shF = 6; p.thB = -12; p.shB = -42;
            p.upF = 176; p.foF = 176; p.upB = 35; p.foB = 65; break;
        case F_SWING: { // blend between "swinging up to the anchor" (a) and "past it" (b)
            StkPose a, b;
            a.hipY = 3; a.lean = 4; a.thF = -8; a.shF = -26; a.thB = -24; a.shB = -48;
            a.upF = 177; a.foF = 177; a.upB = -42; a.foB = -62;
            b.hipY = 3; b.lean = -4; b.thF = 40; b.shF = 12; b.thB = 14; b.shB = -10;
            b.upF = 177; b.foF = 177; b.upB = 75; b.foB = 105;
            if (style == 1) {          // knees tucked up
                a.thF = 40; a.shF = -50; a.thB = 20; a.shB = -80; a.lean = 14; a.upB = -20; a.foB = 5;
                b.thF = 75; b.shF = -15; b.thB = 55; b.shB = -45; b.lean = 2; b.upB = 40; b.foB = 70;
            } else if (style == 2) {   // legs spread, free arm flung out
                a.thF = 22; a.shF = 4; a.thB = -38; a.shB = -14; a.upB = -75; a.foB = -80;
                b.thF = 52; b.shF = 18; b.thB = -12; b.shB = 6; b.upB = 110; b.foB = 128;
            } else if (style == 3) {   // long layout, body straight, free arm at the side
                a.thF = -14; a.shF = -16; a.thB = -20; a.shB = -22; a.lean = 8; a.upB = -20; a.foB = -25;
                b.thF = 22; b.shF = 18; b.thB = 12; b.shB = 8; b.lean = -2; b.upB = 40; b.foB = 50;
            }
            a.thB += 8 * j; b.thB -= 8 * j; a.lean += 3 * j;
            p = stkBlend(a, b, clampf(swing, 0.0f, 1.0f)); break; }
        case F_JUMP:    // rising
            if (style == 1) {          // crouched leap, knees up, arms wide
                p.hipY = -2; p.lean = 22; p.thF = 95; p.shF = -60; p.thB = 70; p.shB = -80;
                p.upF = 90; p.foF = 110; p.upB = -60; p.foB = -40;
            } else if (style == 2) {   // star jump
                p.hipY = -2; p.lean = 0; p.thF = 40; p.shF = 30; p.thB = -40; p.shB = -30;
                p.upF = 140; p.foF = 150; p.upB = -140; p.foB = -150;
            } else {                   // lead knee up, trailing leg kicked back
                p.hipY = -2; p.lean = 10 + 3 * j; p.thF = 78; p.shF = 6; p.thB = -24; p.shB = -76;
                p.upF = 118; p.foF = 138; p.upB = -68; p.foB = -30;
            }
            break;
        case F_FALL:    // dropping
            if (style == 1) {          // curled, arms up over the head
                p.hipY = 0; p.lean = 20; p.thF = 60; p.shF = -20; p.thB = 40; p.shB = -50;
                p.upF = 70; p.foF = 100; p.upB = 60; p.foB = 90;
            } else {                   // limbs spread
                p.hipY = 0; p.lean = 0; p.thF = 32; p.shF = 6; p.thB = -22; p.shB = -34;
                p.upF = 112; p.foF = 100; p.upB = -104; p.foB = -112;
            }
            break;
        case F_FLIP:    // somersault: tight tuck, arms hugging the shins
            p.hipY = 2; p.lean = 38; p.tilt = -10; p.thF = 112; p.shF = -30; p.thB = 98; p.shB = -42;
            p.upF = 70; p.foF = 118; p.upB = 55; p.foB = 108; break;
        case F_CLING: // compact wall-cling pose, hands and feet reaching for the facade
            p.hipY = 1; p.lean = 2; p.tilt = 0; p.thF = 46; p.shF = -25; p.thB = -42; p.shB = 24;
            p.upF = 128; p.foF = 158; p.upB = -108; p.foB = -142; break;
        case F_CLIMB: { // alternating arms and legs; phase follows the climb rate
            float c = sinf(phase * 2.0f * PI), d = cosf(phase * 2.0f * PI);
            p.hipY = 1; p.lean = 1; p.tilt = 0;
            p.thF = 34 + 24*c; p.shF = -12 - 30*std::max(0.0f,d);
            p.thB = -34 - 24*c; p.shB = 12 + 30*std::max(0.0f,-d);
            p.upF = 100 + 55*d; p.foF = 135 + 22*d;
            p.upB = -100 - 55*d; p.foB = -135 - 22*d; break; }
        case F_SLIDE:   // skid along the roof, keeping the speed in low
            p.snap = 1;
            if (style == 1) {          // low crouch skid, one hand dragging ahead, back leg trailing
                p.lean = 55 + 4 * j; p.tilt = -18; p.thF = 75; p.shF = -20; p.thB = -80; p.shB = -88;
                p.upF = 40; p.foF = 15; p.upB = -50; p.foB = -90;
            } else if (style == 2) {   // kneeling slide, free arm cocked back
                p.lean = 28 + 4 * j; p.tilt = -10; p.thF = 95; p.shF = 40; p.thB = -70; p.shB = -118;
                p.upF = 70; p.foF = 85; p.upB = -75; p.foB = -100;
            } else {                   // feet-first slide, leaning back on one hand
                p.lean = -35 + 4 * j; p.tilt = 10; p.thF = 85; p.shF = 82; p.thB = 76; p.shB = 70;
                p.upF = 70; p.foF = 40; p.upB = -60; p.foB = -78;
            }
            break;
        case F_RELEASE: // let go of the web: superhero dive
            p.hipX = -3; p.hipY = 3; p.lean = 55; p.thF = -50; p.shF = -60; p.thB = -58; p.shB = -62;
            p.upF = 128; p.foF = 130; p.upB = 122; p.foB = 125; break;
        case F_LAND:    // landing squash
            p.snap = true;
            if (style == 1) {          // deep crouch, both hands down
                p.lean = 50; p.tilt = -20; p.thF = 95; p.shF = -50; p.thB = 80; p.shB = -70;
                p.upF = 40; p.foF = 15; p.upB = 20; p.foB = 0;
            } else if (style == 2) {   // one hand down, back leg trailing
                p.lean = 40; p.tilt = -14; p.thF = 70; p.shF = -22; p.thB = -40; p.shB = -100;
                p.upF = 60; p.foF = 25; p.upB = -60; p.foB = -30;
            } else {
                p.lean = 36 + 4 * j; p.tilt = -12; p.thF = 78; p.shF = -32; p.thB = 56; p.shB = -58;
                p.upF = 55; p.foF = 92; p.upB = 28; p.foB = 70;
            }
            break;
        case F_HERO:    // three-point landing: one knee down, one fist on the ground, other arm cocked back
            p.snap = true; p.lean = 44; p.tilt = -24; p.thF = 88; p.shF = -4; p.thB = -34; p.shB = -118;
            p.upF = 52; p.foF = 22; p.upB = -48; p.foB = -78; break;
        case F_HIT:     // knocked back
            p.hipY = 1; p.lean = -22; p.tilt = 10; p.thF = 40; p.shF = 12; p.thB = -30; p.shB = -8;
            p.upF = 140; p.foF = 162; p.upB = 98; p.foB = 122; break;
        default:        // F_DEAD: limp, spread out (the game spins him)
            p.hipY = 1; p.lean = 0; p.tilt = 12; p.thF = 36; p.shF = 40; p.thB = -36; p.shB = -40;
            p.upF = 100; p.foF = 78; p.upB = -100; p.foB = -78; break;
    }
    return p;
}

// ---- pose smoothing --------------------------------------------------------------------
// Every joint angle is a damped spring chasing the target pose. The slight overshoot gives
// follow-through (arms and head settle a beat after the body), which is what makes it flow.
struct StkAnim { StkPose cur, vel; bool init = false; double last = 0, ang = 0; int lastFrame = -1; float dt = 0, t = 0; };   // t = seconds since the frame changed
static double stkNow() { return (double)SDL_GetTicks() / 1000.0; }
// spring stiffness (1/seconds): cycles track tightly, one-shots can float
static float stkRate(int from, int to) {
    if (to == F_RUN || to == F_IDLE) return (from == to) ? 60.0f : 18.0f;
    if (to == F_SWING) return 22.0f;
    if (to == F_SLIDE) return 26.0f;
    if (to == F_SHOOT || to == F_ATTACH || to == F_RELEASE || to == F_HIT) return 28.0f;
    if (to == F_HERO || to == F_LAND) return 32.0f;
    return 18.0f;
}
static const StkPose& stkAdvance(StkAnim& an, int frame, float phase, float swing, int style = 0, float j = 0) {
    StkPose tgt = stkMakePose(frame, phase, swing, style, j);
    double now = stkNow();
    an.dt = clampf((float)(now - an.last), 0.0f, 0.05f);
    an.last = now;
    if (!an.init) {
        an.cur = tgt; an.init = true;
        for (auto m : STK_F) an.vel.*m = 0;
    } else {
        // a new move starts soft and firms up over ~0.15s, so poses never pop
        float ease = clampf(an.t / 0.15f, 0.0f, 1.0f);
        float w = stkRate(an.lastFrame, frame) * (0.45f + 0.55f * ease * ease * (3 - 2 * ease));
        float zeta = (frame == F_RUN || frame == F_IDLE) ? 1.0f : 0.7f;   // one-shots overshoot a little
        int n = (int)ceilf(an.dt * 240.0f);
        float h = n ? an.dt / n : 0;
        for (int i = 0; i < n; i++)
            for (auto m : STK_F) {
                float& x = an.cur.*m; float& v = an.vel.*m;
                v += (w * w * (tgt.*m - x) - 2 * zeta * w * v) * h;
                x += v * h;
            }
    }
    an.t = frame == an.lastFrame ? an.t + an.dt : 0;
    an.lastFrame = frame;
    return an.cur;
}
// body rotation: flips and spins are used as given, everything else eases along the shortest way round
static double stkAngle(StkAnim& an, double target, bool spin) {
    if (spin) an.ang = fmod(target, 360.0);
    else {
        double d = fmod(target - an.ang, 360.0);
        if (d > 180) d -= 360; else if (d < -180) d += 360;
        an.ang += d * (1.0 - exp(-8.0 * an.dt));
    }
    return an.ang;
}

// joints of a pose rotated about the body centre and placed on screen
static void stkPlace(const StkPose& pose, float cx, float feetY, double angleDeg, float X[J_N], float Y[J_N]) {
    float jx[J_N], jy[J_N];
    stkSolve(pose, jx, jy);
    float a = (float)(angleDeg * PI / 180.0), c = cosf(a), s = sinf(a);
    float ox = cx, oy = feetY - (float)STK_FEET_Y;
    for (int i = 0; i < J_N; i++) { X[i] = ox + jx[i] * c - jy[i] * s; Y[i] = oy + jx[i] * s + jy[i] * c; }
}

// ---- anti-aliased capsule renderer ------------------------------------------------------
static const int STK_TEX = 112;                 // texture side; joints stay well inside +-56 px of the body centre
static SDL_Texture* gStkTex = nullptr;
static float gStkBuf[STK_TEX * STK_TEX * 4];    // premultiplied-ready float RGBA scratch
struct StkBone { int a, b; };
static float stkDistSeg(float px, float py, float x0, float y0, float x1, float y1) {
    float vx = x1 - x0, vy = y1 - y0, wx = px - x0, wy = py - y0;
    float l2 = vx * vx + vy * vy, t = l2 > 1e-6f ? clampf((wx * vx + wy * vy) / l2, 0.0f, 1.0f) : 0.0f;
    float dx = wx - vx * t, dy = wy - vy * t;
    return sqrtf(dx * dx + dy * dy);
}
// composite a coloured "distance field" layer (union of capsules / disc) over the scratch buffer
static void stkLayer(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float rLimb, float rHead, u32 c, float ox, float oy) {
    float cr = ((c >> 16) & 255) / 255.0f, cg = ((c >> 8) & 255) / 255.0f, cb = (c & 255) / 255.0f;
    float r = rLimb + 0.5f;
    float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
    auto grow = [&](float x, float y, float pad) { minX = std::min(minX, x - pad); maxX = std::max(maxX, x + pad); minY = std::min(minY, y - pad); maxY = std::max(maxY, y + pad); };
    for (int i = 0; i < n; i++) { grow(X[bones[i].a] - ox, Y[bones[i].a] - oy, r + 1); grow(X[bones[i].b] - ox, Y[bones[i].b] - oy, r + 1); }
    if (head) grow(X[J_HEAD] - ox, Y[J_HEAD] - oy, rHead + 1.5f);
    int x0 = std::max(0, (int)floorf(minX)), x1 = std::min(STK_TEX - 1, (int)ceilf(maxX));
    int y0 = std::max(0, (int)floorf(minY)), y1 = std::min(STK_TEX - 1, (int)ceilf(maxY));
    for (int py = y0; py <= y1; py++) for (int px = x0; px <= x1; px++) {
        float fx = px + 0.5f + ox, fy = py + 0.5f + oy, d = 1e9f;
        for (int i = 0; i < n; i++) d = std::min(d, stkDistSeg(fx, fy, X[bones[i].a], Y[bones[i].a], X[bones[i].b], Y[bones[i].b]) - rLimb);
        if (head) d = std::min(d, hypotf(fx - X[J_HEAD], fy - Y[J_HEAD]) - rHead);
        float cov = clampf(0.5f - d, 0.0f, 1.0f);
        if (cov <= 0) continue;
        float* q = &gStkBuf[(py * STK_TEX + px) * 4];
        float inv = 1.0f - cov;                        // "over" operator, straight alpha stored premultiplied
        q[0] = cr * cov + q[0] * inv; q[1] = cg * cov + q[1] * inv; q[2] = cb * cov + q[2] * inv; q[3] = cov + q[3] * inv;
    }
}
static void stkDrawBones(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float ox, float oy) {
    stkLayer(X, Y, bones, n, head, 2.35f, 5.9f, STK_OUTLINE, ox, oy);   // thin light rim ...
    stkLayer(X, Y, bones, n, head, 1.5f, 4.95f, STK_BODY, ox, oy);      // ... then the uniform-width body
}
static void drawStickman(const StkPose& pose, int cx, int feetY, double angleDeg) {
    if (!gStkTex) {
        gStkTex = SDL_CreateTexture(gRen, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STREAMING, STK_TEX, STK_TEX);
        if (!gStkTex) return;
        SDL_SetTextureBlendMode(gStkTex, SDL_BLENDMODE_BLEND);
    }
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    const float ox = (float)cx - STK_TEX / 2, oy = (float)(feetY - STK_FEET_Y) - STK_TEX / 2;
    memset(gStkBuf, 0, sizeof(gStkBuf));
    static const StkBone farSet[] = { {J_NECK, J_ELB}, {J_ELB, J_HNB}, {J_HIP, J_KNB}, {J_KNB, J_FTB}, {J_HIP, J_NECK} };
    static const StkBone nearLeg[] = { {J_HIP, J_KNF}, {J_KNF, J_FTF} };
    static const StkBone nearArm[] = { {J_NECK, J_ELF}, {J_ELF, J_HNF} };
    stkDrawBones(X, Y, farSet, 5, true, ox, oy);   // far limbs + torso + head form one silhouette
    stkDrawBones(X, Y, nearLeg, 2, false, ox, oy); // near limbs get their own rim so they separate from it
    stkDrawBones(X, Y, nearArm, 2, false, ox, oy);
    static Uint32 px[STK_TEX * STK_TEX];
    for (int i = 0; i < STK_TEX * STK_TEX; i++) {
        const float* q = &gStkBuf[i * 4];
        float a = q[3];
        if (a <= 0.001f) { px[i] = 0; continue; }
        // un-premultiply: the blend mode expects straight alpha
        Uint32 r = (Uint32)clampf(q[0] / a * 255.0f + 0.5f, 0, 255), g = (Uint32)clampf(q[1] / a * 255.0f + 0.5f, 0, 255);
        Uint32 b = (Uint32)clampf(q[2] / a * 255.0f + 0.5f, 0, 255), al = (Uint32)clampf(a * 255.0f + 0.5f, 0, 255);
        px[i] = r | (g << 8) | (b << 16) | (al << 24);   // ABGR8888 -> bytes R,G,B,A in memory
    }
    SDL_UpdateTexture(gStkTex, nullptr, px, STK_TEX * (int)sizeof(Uint32));
    SDL_Rect dst = { (int)floorf(ox), (int)floorf(oy), STK_TEX, STK_TEX };
    SDL_RenderCopy(gRen, gStkTex, nullptr, &dst);
}
// where the web hand of a pose ends up on screen
static void stickHand(const StkPose& pose, int cx, int feetY, double angleDeg, float& hx, float& hy) {
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    hx = X[J_HNF]; hy = Y[J_HNF];
}
// ==== STICKMAN END ====
static float gRunPhase = 0;                    // run-cycle phase in cycles, advanced with ground speed
static StkAnim gPlayerAnim, gMenuAnim;         // smoothed poses (player in the run, stickman on the title screen)

static void buildArt() {
    for (int s = 0; s < 6; s++) for (int v = 0; v < 3; v++) gTile[s][v] = mkTex(makeTile(s, v));
    for (int v = 0; v < 3; v++) gFar[v] = mkTex(makeFar(v));
}
static void tileMod(int r, int g, int b) {
    for (int s = 0; s < 6; s++) for (int v = 0; v < 3; v++) SDL_SetTextureColorMod(gTile[s][v], (Uint8)r, (Uint8)g, (Uint8)b);
}

// ============================================================================
//  SETTINGS / PERSISTENCE
// ============================================================================
struct Settings { float music = 0.6f, sfx = 0.8f, sens = 1.0f; bool shake = true, reduced = false, full = true, webAssist = true, swingTrails = true, rain = false, dayNight = true; float best = 0; };
static Settings cfg;
static std::string savePath, ctlPath, progPath, dailyPath, achievementPath, recordsPath;
static int recordBestCombo = 0, recordBestTricks = 0, recordBestCoins = 0;
static float recordTopSpeed = 0;
static int dailyKey = 0;
static bool challengeDone[3] = {false, false, false};
static bool achievementDone[4] = {false, false, false, false};
static void refreshDaily();
static void unlockAchievement(int index, const char* title);
static prog::Data gProg;                       // coins, skill levels, rebirths (saved in progress.txt)
static int coinMilestones = 0, runCoins = 0;   // 200 m rewards already paid this run / coins earned this run
static void saveProg() { prog::saveFile(progPath, gProg); }
static void fmtNum(long long v, char* out, size_t n) {   // 1234567 -> "1,234,567"
    char t[32]; snprintf(t, sizeof t, "%lld", v);
    int len = (int)strlen(t), o = 0;
    for (int i = 0; i < len && o < (int)n - 2; i++) { if (i > 0 && (len - i) % 3 == 0) out[o++] = ','; out[o++] = t[i]; }
    out[o] = 0;
}
// physical safety cap: above this the collision step would tunnel through thin obstacles
static const float PHYS_CAP = 8.0f;
static float runMult() { return std::min(prog::totalMult(gProg, prog::RUN), PHYS_CAP); }
static float swingMult() { return std::min(prog::totalMult(gProg, prog::SWING), PHYS_CAP); }
static void loadCfg() {
    char* pp = SDL_GetPrefPath("PixelCity", "StickmanPixelCity");
    std::string dir = pp ? pp : "";
    savePath = dir + "save.txt";
    ctlPath = dir + "controls.txt";
    progPath = dir + "progress.txt";
    dailyPath = dir + "daily.txt";
    achievementPath = dir + "achievements.txt";
    recordsPath = dir + "records.txt";
    { FILE* rf = fopen(recordsPath.c_str(), "r"); if (rf) { fscanf(rf, "%d %d %d %f", &recordBestCombo, &recordBestTricks, &recordBestCoins, &recordTopSpeed); fclose(rf); } }
    { FILE* af = fopen(achievementPath.c_str(), "r"); if (af) { for (int i = 0; i < 4; ++i) { int v = 0; if (fscanf(af, "%d", &v) == 1) achievementDone[i] = v != 0; } fclose(af); } }
    if (pp) SDL_free(pp);
    { FILE* df = fopen(dailyPath.c_str(), "r"); int key = 0, a = 0, b = 0, c = 0;
      if (df) { if (fscanf(df, "%d %d %d %d", &key, &a, &b, &c) == 4) { dailyKey = key; challengeDone[0] = a != 0; challengeDone[1] = b != 0; challengeDone[2] = c != 0; } fclose(df); }
      refreshDaily(); }
    prog::loadFile(progPath, gProg);
    FILE* f = fopen(savePath.c_str(), "r");
    if (!f) return;
    int sh = 1, rd = 0, fu = 1, wa = 1, st = 1, rn = 0, dn = 1;
    float m, s, se, b;
    int got = fscanf(f, "%f %f %f %d %d %d %f %d %d %d %d", &m, &s, &se, &sh, &rd, &fu, &b, &wa, &st, &rn, &dn);
    if (got >= 7) {
        cfg.music = clampf(m, 0, 1); cfg.sfx = clampf(s, 0, 1); cfg.sens = clampf(se, 0.5f, 1.5f);
        cfg.shake = sh != 0; cfg.reduced = rd != 0; cfg.full = fu != 0; cfg.best = std::max(0.0f, b);
        cfg.webAssist = got < 8 ? true : wa != 0; cfg.swingTrails = got < 9 ? true : st != 0;
        cfg.rain = got < 10 ? false : rn != 0; cfg.dayNight = got < 11 ? true : dn != 0;
    }
    fclose(f);
}
static void saveCfg() {
    FILE* f = fopen(savePath.c_str(), "w");
    if (!f) return;
    fprintf(f, "%f %f %f %d %d %d %f %d %d %d %d\n", cfg.music, cfg.sfx, cfg.sens, cfg.shake, cfg.reduced, cfg.full, cfg.best, cfg.webAssist, cfg.swingTrails, cfg.rain, cfg.dayNight);
    fclose(f);
    saveProg();
}

// ---- control bindings + touch layout (kept in their own file so old saves still load) ----
enum Act { A_LEFT, A_RIGHT, A_JUMP, A_SLIDE, A_SWING, A_PAUSE, A_N };
static const char* const ACT_LABEL[A_N] = {"STEER LEFT", "STEER RIGHT", "JUMP", "SLIDE", "SWING", "PAUSE"};
static const SDL_Scancode ACT_DEFAULT[A_N] = {SDL_SCANCODE_A, SDL_SCANCODE_D, SDL_SCANCODE_SPACE, SDL_SCANCODE_S, SDL_SCANCODE_LSHIFT, SDL_SCANCODE_P};
struct Controls {
    SDL_Scancode key[A_N];
    float scale = 1.0f, alpha = 0.7f;   // touch button size and opacity
    bool lefty = false;                 // mirror the touch layout for left-handed play
    float px[3], py[3];                 // custom touch button centres as screen fractions (-1 = default spot)
    Controls() { resetKeys(); resetTouch(); }
    void resetKeys() { for (int i = 0; i < A_N; i++) key[i] = ACT_DEFAULT[i]; }
    void resetTouch() { scale = 1.0f; alpha = 0.7f; lefty = false; for (int i = 0; i < 3; i++) px[i] = py[i] = -1.0f; }
};
static Controls ctl;
static void loadControls() {
    FILE* f = fopen(ctlPath.c_str(), "r");
    if (!f) return;
    int k[A_N], lf = 0;
    float sc, al, px[3], py[3];
    int n = fscanf(f, "%d %d %d %d %d %d %f %f %d %f %f %f %f %f %f", &k[0], &k[1], &k[2], &k[3], &k[4], &k[5],
                   &sc, &al, &lf, &px[0], &py[0], &px[1], &py[1], &px[2], &py[2]);
    if (n == 15) {
        for (int i = 0; i < A_N; i++) if (k[i] > 0 && k[i] < SDL_NUM_SCANCODES) ctl.key[i] = (SDL_Scancode)k[i];
        ctl.scale = clampf(sc, 0.7f, 1.4f); ctl.alpha = clampf(al, 0.2f, 1.0f); ctl.lefty = lf != 0;
        for (int i = 0; i < 3; i++) { ctl.px[i] = px[i] < 0 ? -1.0f : clampf(px[i], 0, 1); ctl.py[i] = px[i] < 0 ? -1.0f : clampf(py[i], 0, 1); }
    }
    fclose(f);
}
static void saveControls() {
    FILE* f = fopen(ctlPath.c_str(), "w");
    if (!f) return;
    for (int i = 0; i < A_N; i++) fprintf(f, "%d ", (int)ctl.key[i]);
    fprintf(f, "%f %f %d", ctl.scale, ctl.alpha, ctl.lefty ? 1 : 0);
    for (int i = 0; i < 3; i++) fprintf(f, " %f %f", ctl.px[i], ctl.py[i]);
    fprintf(f, "\n");
    fclose(f);
}

// ============================================================================
//  AUDIO  (fully synthesised: ambience, wind, generative cinematic loop, SFX)
// ============================================================================
struct Voice { bool on = false; int type = 0; float t = 0, dur = 0.1f, f0 = 440, f1 = 440, amp = 0.5f, ph = 0; };
static SDL_AudioDeviceID gAud = 0;
static Voice vox[12];
static std::atomic<float> aMusic{0.6f}, aSfx{0.8f}, aWind{0.0f};
static std::atomic<int> aMode{0};  // 0 off, 1 menu, 2 gameplay
static bool audioStarted = false;

static void audioCB(void*, Uint8* stream, int len) {
    float* o = (float*)stream;
    int n = len / (int)(sizeof(float) * 2);
    const float sr = 44100.0f;
    static double mt = 0;
    static u32 nz = 22222;
    static float wlp = 0, rlp = 0, bph = 0, kph = 0, nlp = 0, lpb = 0;
    static float pad[3] = {0, 0, 0}, arp = 0;
    static const float bassF[4] = {55.0f, 43.65f, 65.41f, 49.0f};
    static const float chord[4][3] = {{220, 261.63f, 329.63f}, {174.61f, 220, 261.63f}, {261.63f, 329.63f, 392}, {196, 246.94f, 293.66f}};
    float mv = aMusic.load(), sv = aSfx.load(), wind = aWind.load();
    int mode = aMode.load();
    for (int i = 0; i < n; i++) {
        nz ^= nz << 13; nz ^= nz >> 17; nz ^= nz << 5;
        float noise = ((nz & 0xFFFF) / 32768.0f) - 1.0f;
        float m = 0;
        if (mode > 0) {
            double step = mt / 0.15625;
            int si = (int)step; float sp = (float)(step - si);
            int bar = (si / 8) & 3;
            for (int k = 0; k < 3; k++) {
                pad[k] += chord[bar][k] / sr; if (pad[k] > 1) pad[k] -= 1;
                m += sinf(2 * PI * pad[k]) * 0.035f;
            }
            bph += bassF[bar] / sr; if (bph > 1) bph -= 1;
            float saw = (2 * bph - 1);
            lpb += (saw - lpb) * 0.06f;
            m += lpb * 0.22f * (0.6f + 0.4f * expf(-sp * 2.0f));
            if (mode == 2) {
                int idx = (si % 4 == 3) ? 1 : (si % 4);
                arp += chord[bar][idx] * 2 / sr; if (arp > 1) arp -= 1;
                m += (2 * fabsf(2 * arp - 1) - 1) * 0.07f * expf(-sp * 4);
                float tt = sp * 0.15625f;
                if (si % 4 == 0) { kph += (50 + 110 * expf(-tt * 35)) / sr; m += sinf(2 * PI * kph) * expf(-tt * 14) * 0.45f; }
                nlp += (noise - nlp) * 0.5f;
                if (si % 2 == 1) m += (noise - nlp) * expf(-sp * 10) * 0.05f;
                if (si % 8 == 4) m += noise * expf(-sp * 5) * 0.12f;
            } else m *= 0.7f;
            mt += 1.0 / sr;
        }
        m *= mv * 0.8f;
        float s = 0;
        for (int v = 0; v < 12; v++) {
            Voice& vo = vox[v];
            if (!vo.on) continue;
            float tt = vo.t / vo.dur, env = (1 - tt) * (1 - tt);
            float f = vo.f0 + (vo.f1 - vo.f0) * tt;
            if (vo.type == 3) f = tt < 0.4f ? vo.f0 : vo.f1;
            vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
            float w;
            switch (vo.type) {
                case 0: w = noise * 0.5f + sinf(2 * PI * vo.ph) * 0.3f; break;
                case 1: w = sinf(2 * PI * vo.ph) * 0.6f + (vo.ph < 0.5f ? 0.15f : -0.15f); break;
                case 2: w = sinf(2 * PI * vo.ph) * 0.8f + (tt < 0.4f ? noise * 0.3f : 0.0f); break;
                case 3: w = sinf(2 * PI * vo.ph) * 0.5f; break;
                case 4: w = vo.ph < 0.5f ? 0.3f : -0.3f; break;
                case 5: w = (2 * vo.ph - 1) * 0.4f; break;
                case 6: w = noise * 0.4f; break;
                default: w = sinf(2 * PI * vo.ph) * 0.5f; break;
            }
            s += w * env * vo.amp;
            vo.t += 1.0f / sr;
            if (vo.t >= vo.dur) vo.on = false;
        }
        // city ambience + wind rush (speed dependent)
        rlp += (noise - rlp) * 0.0025f;
        wlp += (noise - wlp) * (0.02f + 0.12f * wind);
        s += rlp * 0.9f + wlp * (0.03f + 0.45f * wind);
        s *= sv;
        float out = clampf(m + s, -1, 1);
        o[i * 2] = out; o[i * 2 + 1] = out;
    }
}
static void initAudio() {
    SDL_AudioSpec want, have;
    SDL_zero(want);
    want.freq = 44100; want.format = AUDIO_F32SYS; want.channels = 2; want.samples = 1024; want.callback = audioCB;
    gAud = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void sfx(int type) {
    if (!gAud) return;
    static const float P[8][4] = {  // dur, f0, f1, amp
        {0.14f, 900, 1800, 0.5f}, {0.10f, 1200, 400, 0.6f}, {0.16f, 130, 45, 0.9f}, {0.16f, 880, 1320, 0.5f},
        {0.05f, 600, 600, 0.4f}, {0.90f, 440, 90, 0.6f}, {0.12f, 500, 500, 0.5f}, {0.12f, 300, 650, 0.5f}};
    SDL_LockAudioDevice(gAud);
    int slot = 0; float oldest = -1;
    for (int i = 0; i < 12; i++) { if (!vox[i].on) { slot = i; oldest = 1e9f; break; } if (vox[i].t > oldest) { oldest = vox[i].t; slot = i; } }
    Voice& v = vox[slot];
    v.on = true; v.type = type; v.t = 0; v.dur = P[type][0]; v.f0 = P[type][1]; v.f1 = P[type][2]; v.amp = P[type][3]; v.ph = 0;
    SDL_UnlockAudioDevice(gAud);
}

// ============================================================================
//  GAME DATA
// ============================================================================
enum State { TITLE, MAIN_MENU, SETTINGS, CONTROLS, LAYOUT_EDIT, HOW_TO_PLAY, CREDITS, SKILLS, PLAYING, PAUSED, GAME_OVER };
static State gState = TITLE, navRoot = MAIN_MENU;   // navRoot = the screen the current sub-screen chain was opened from
static std::vector<State> navStack;
static bool isSub(State s) { return s == SETTINGS || s == CONTROLS || s == LAYOUT_EDIT || s == HOW_TO_PLAY || s == CREDITS || s == SKILLS; }
static void openSub(State s) { if (!isSub(gState)) { navRoot = gState; navStack.clear(); } navStack.push_back(gState); gState = s; }
static void goBack() { if (!navStack.empty()) { gState = navStack.back(); navStack.pop_back(); } else gState = navRoot; }
static double gTime = 0;

struct Obs { int type; float x, w, h; bool solid; int param; float homeX = 0; };  // 0 hvac 1 tower 2 barrier 3 antenna 4 crane 5 billboard 6 dish
struct Anchor { float x, y; };
struct Building {
    float x, w, roofY; int style; u32 seed;
    std::vector<Obs> obs; std::vector<Anchor> anch;
    bool mastL = false, mastR = false, cable = false;
    bool secret = false, secretClaimed = false;
    float cx0 = 0, cy0 = 0, cx1 = 0, cy1 = 0;
};
struct Part { float x, y, vx, vy, life, max; u32 c; int sz; bool alive; };
struct Coin { float x, y; bool taken = false; };
static std::deque<Coin> coinItems;
static int coinSaveCounter = 0;

static std::deque<Building> bld;
static Part parts[220];
static int partHead = 0;
static Rng wrng(1);

struct Player {
    float x = 0, y = 0, px = 0, py = 0;   // px/py = previous position, for roof vs wall collisions
    float vx = 0, vy = 0;
    bool onGround = false, swinging = false, alive = true, usedAir = false;
    bool wallCling = false, webFlying = false;
    float wallX = 0, wallDir = 1;
    float webX = 0, webY = 0, webStartX = 0, webStartY = 0, webT = 0, webDur = 0.18f;
    float ax = 0, ay = 0, rope = 0;       // swing anchor and rope length
    float coyote = 0, jumpBuf = 0;
    float landT = 0, shootT = 0, attachT = 0, releaseT = 0, deadT = 0, flipT = 0;
    bool hero = false;                    // hard landing -> superhero pose
    int runStyle = 0, jumpStyle = 0, fallStyle = 0, swingStyle = 0, landStyle = 0, shootStyle = 0;   // random pose variants
    float slideT = 0, slideBuf = 0;       // slide time left, and a short buffer so a press just before landing still slides
    float dashT = 0, nearMissLock = 0, slingshotT = 0; bool dashUsed = false;
    int slideStyle = 0;
    float boostT = 0, boostDur = 1, boostExtra = 0;   // run-speed bonus earned from a swing
    float jit = 0;                        // random -1..1 nudge re-rolled on every move
    bool releaseFlip = false;             // somersault out of the swing
    float flipDir = 1;                    // +1 front flip, -1 back flip
    int chain = 0;
};
static Player P;
static float camX = 0, camY = 0, startX = 0, shakeT = 0, chainShowT = 0;
static float distM = 0, bonus = 0, speedBonus = 0;
static bool newBest = false;
static bool jumpEdge = false, slideEdge = false, jumpRel = false, swingHeld = false, swingWas = false;
static float steer = 0;
static bool haveTarget = false;
static float tgtX = 0, tgtY = 0;
static float trans = -1, menuT = 0, fadeIn = 0;
static float styleTick = 0;

static const float GRAV = 1400.0f;
static float difficulty() { return clampf(distM / 2000.0f, 0, 1); }
static int comboCount = 0;
static float flowTimer = 0;
static int scoreVal() { return (int)((distM + bonus + speedBonus) * (1.0f + std::min(2.0f, comboCount * 0.08f))); }
static float perfectT = 0, dashCooldown = 0, eventT = 0, eventToastT = 0, missionToastT = 0;
static float adrenaline = 0, adrenalineT = 0, challengeT = 0, challengeSwingTime = 0;
static int challengeKind = -1;
static float runTopSpeed = 0;
static int nearMisses = 0, trickCount = 0, perfectReleases = 0, padsHit = 0, bestCombo = 0;
static int perfectLandings = 0;
static float droneX = 0, droneY = 0, dronePulse = 0;
static bool droneActive = false;
static int districtShown = -1;
static const char* cityDistrictName(int d) { static const char* names[] = {"DOWNTOWN", "NEON DISTRICT", "INDUSTRIAL ZONE", "SKYLINE HEIGHTS", "OLD CITY"}; return names[d % 5]; }
static int cityDistrict() { return ((int)std::max(0.0f, distM) / 900) % 5; }
static int missionCoins = 0;
static std::string eventToast = "", missionToast = "";
static void burst(float x, float y, int n, u32 c, float spd);
static void addAdrenaline(float amount) {
    if (adrenalineT > 0) return;
    adrenaline = std::min(100.0f, adrenaline + amount);
    if (adrenaline >= 100.0f) {
        adrenaline = 0;
        adrenalineT = 4.0f;
        eventToast = "ADRENALINE MODE!";
        eventToastT = 1.4f;
        perfectT = 0.8f;
        burst(P.x, P.y - 12, cfg.reduced ? 5 : 13, 0xFF5C72, 145);
        sfx(7);
    }
}
static void unlockAchievement(int index, const char* title) {
    if (index < 0 || index >= 4 || achievementDone[index]) return;
    achievementDone[index] = true; eventToast = title; eventToastT = 2.0f; bonus += 75.0f;
    if (!achievementPath.empty()) { FILE* f = fopen(achievementPath.c_str(), "w"); if (f) { for (int i = 0; i < 4; ++i) fprintf(f, "%d%c", achievementDone[i] ? 1 : 0, i == 3 ? '\n' : ' '); fclose(f); } }
}
static std::vector<float> ghostX, ghostY, lastGhostX, lastGhostY;
static bool ghostReady = false;
static float ghostStartX = 0;
static int todayKey() {
    std::time_t now = std::time(nullptr); std::tm* local = std::localtime(&now);
    return local ? (local->tm_year + 1900) * 10000 + (local->tm_mon + 1) * 100 + local->tm_mday : 0;
}
static void saveDaily() {
    if (dailyPath.empty()) return;
    FILE* f = fopen(dailyPath.c_str(), "w"); if (!f) return;
    fprintf(f, "%d %d %d %d\n", dailyKey, challengeDone[0], challengeDone[1], challengeDone[2]); fclose(f);
}
static void refreshDaily() {
    int today = todayKey(); if (today == 0 || today == dailyKey) return;
    dailyKey = today; challengeDone[0] = challengeDone[1] = challengeDone[2] = false; saveDaily();
}

static void spawnPart(float x, float y, float vx, float vy, float life, u32 c, int sz = 2) {
    if (cfg.reduced && (partHead & 1)) { partHead = (partHead + 1) % 220; return; }
    parts[partHead] = {x, y, vx, vy, life, life, c, sz, true};
    partHead = (partHead + 1) % 220;
}
static void burst(float x, float y, int n, u32 c, float spd) {
    for (int i = 0; i < n; i++) {
        float a = (float)i / n * 2 * PI + wrng.f();
        spawnPart(x, y, cosf(a) * spd * (0.4f + wrng.f()), sinf(a) * spd * (0.4f + wrng.f()), 0.35f + wrng.f() * 0.3f, c);
    }
}
static void doShake(float t) { if (cfg.shake) shakeT = std::max(shakeT, t); }

// ---------------------------------------------------------------- generation
// Build the next rooftop and place its hazards, decorations, collectibles, and
// web anchors. The world is generated ahead of the camera as the player runs.
static void addBuilding(bool first) {
    float d = difficulty();
    Building b;
    b.seed = wrng.next();
    b.style = wrng.range(0, 5);
    b.secret = !first && wrng.f() < 0.075f;
    float gap = 0;
    if (first) { b.x = -300; b.w = 1100; b.roofY = 0; b.style = 0; }
    else {
        Building& p = bld.back();
        // Keep gaps in the same scale as the player's movement and web range.
        // The old x50 multiplier created multi-thousand-pixel gaps that could
        // only be crossed by luck, even when the city spawned anchor cables.
        gap = (float)wrng.range((int)(100 + 35 * d), (int)(210 + 110 * d));
        b.w = (float)((wrng.range((int)(900 - 300 * d), (int)(1500 - 380 * d)) / 16) * 16);
        int maxRise = gap > 150 ? 260 : 100;
        b.roofY = clampf(p.roofY + wrng.range(-maxRise, 130), -380, 260);
        b.x = p.x + p.w + gap;
        if (b.style == p.style) b.style = (b.style + 1 + wrng.range(0, 4)) % 6;
        if (gap > 150) {  // light-mast cable across the gap with multiple reachable web anchors
            p.mastR = true; b.mastL = true; p.cable = true;
            p.cx0 = p.x + p.w - 10; p.cy0 = p.roofY - 280; p.cx1 = b.x + 10; p.cy1 = b.roofY - 280;
            for (int k = 1; k <= 7; ++k) { float u = k / 8.0f; p.anch.push_back({lerpf(p.cx0, p.cx1, u), (p.cy0 + p.cy1) / 2 + 22 + 26.0f * sinf(u * PI)}); }
        }
    }
    // solid rooftop hazards (never on narrow roofs, always spaced for reaction time)
    if (!first && b.w >= 440 && wrng.f() < 0.3f + 0.5f * d) {
        int n = (b.w >= 700 && wrng.f() < 0.5f) ? 2 : 1;
        float x = b.x + 260;
        for (int i = 0; i < n; i++) {
            int ty = wrng.range(0, 2);
            float w = ty == 0 ? 28.0f : (ty == 1 ? 30.0f : 24.0f), h = ty == 0 ? 20.0f : (ty == 1 ? 46.0f : 14.0f);
            float span = (b.x + b.w - 200) - x - w;
            if (span < 0) break;
            x += wrng.range(0, (int)std::min(span, 160.0f));
            b.obs.push_back({ty, x, w, h, true, 0});
            if (ty == 2 && wrng.f() < 0.38f) { b.obs.back().param = 1; b.obs.back().homeX = x; }
            x += w + 230;
        }
    }
    // Spider-Man should almost always have another place to shoot a web.
    // Put several dependable anchor points across every building, at different
    // heights, so the player can choose a route instead of waiting for one point.
    // The points sit above the roofline and stay within the normal web-search range.
    if (!first) {
        static const float anchorSpots[] = {0.18f, 0.40f, 0.63f, 0.84f};
        static const float anchorHeights[] = {310.0f, 430.0f, 350.0f, 470.0f};
        for (int i = 0; i < 4; ++i) {
            float ax = b.x + b.w * anchorSpots[i];
            float ay = b.roofY - anchorHeights[i];
            b.anch.push_back({ax, ay});
        }
    }
    // decor that doubles as anchors
    if (!first && wrng.f() < 0.75f) {
        float x = b.x + wrng.range(30, std::max(31, (int)b.w - 30)), h = (float)wrng.range(220, 460);
        b.obs.push_back({3, x, 2, h, false, 0});
        b.anch.push_back({x + 1, b.roofY - h});
        b.anch.push_back({x + 1, b.roofY - h * 0.55f});
    }
    if (b.w > 320 && wrng.f() < (b.style == 5 ? 0.95f : 0.65f)) {
        float x = b.x + wrng.range(40, (int)b.w - 170), h = (float)wrng.range(220, 300);
        b.obs.push_back({4, x, 110, h, false, 0});
        b.anch.push_back({x + 110, b.roofY - h + 4});
    }
    if (b.w > 320 && wrng.f() < 0.65f) {
        float x = b.x + wrng.range(20, (int)b.w - 130);
        b.obs.push_back({5, x, 96, 114, false, wrng.range(0, 3)});
        b.anch.push_back({x + 48, b.roofY - 114});
    }
    if (wrng.f() < 0.4f) b.obs.push_back({6, b.x + wrng.range(20, std::max(21, (int)b.w - 20)), 12, 16, false, 0});
    // A small, unmistakable launch pad appears on some wide rooftops.
    if (!first && b.w > 650 && wrng.f() < 0.22f) {
        float px = b.x + wrng.range(180, std::max(181, (int)b.w - 100));
        b.obs.push_back({7, px, 58, 12, false, 0});
    }
    // Small 2D coin trails: roof-level for safe routes, with occasional elevated risky trails.
    if (!first) {
        int count = wrng.range(5, 9);
        float start = b.x + b.w * 0.16f;
        bool risky = wrng.f() < 0.30f;
        for (int i = 0; i < count; ++i) {
            float x = start + i * std::min(44.0f, b.w * 0.075f);
            if (x >= b.x + b.w - 12) break;
            float y = b.roofY - (risky ? 180.0f + 18.0f * sinf(i * 0.7f) : 32.0f);
            coinItems.push_back({x, y, false});
        }
    }
    if (b.secret) {
        // A short hidden rooftop route: the glowing arch marks a bonus cache.
        float sx = b.x + b.w * 0.5f;
        for (int i = 0; i < 7; ++i) coinItems.push_back({sx - 72 + i * 24.0f, b.roofY - 78 - (i % 2) * 12.0f, false});
    }
    bld.push_back(std::move(b));
}
static void ensureWorld() {
    while (bld.back().x + bld.back().w < camX + W + 1400) addBuilding(false);
    while (bld.size() > 3 && bld.front().x + bld.front().w < camX - 800) bld.pop_front();
    while (!coinItems.empty() && coinItems.front().x < camX - 160) coinItems.pop_front();
}

static void startRun() {
    refreshDaily();
    if (ghostX.size() > 8) { lastGhostX = ghostX; lastGhostY = ghostY; ghostReady = true; }
    bld.clear(); coinItems.clear(); coinSaveCounter = 0;
    for (auto& p : parts) p.alive = false;
    wrng = Rng(SDL_GetTicks() * 2654435761u + 17u);
    P = Player();
    gPlayerAnim = StkAnim(); gRunPhase = 0;
    distM = bonus = speedBonus = 0; styleTick = 0; coinMilestones = runCoins = 0; newBest = false; chainShowT = 0; shakeT = 0;
    comboCount = 0; flowTimer = 0; perfectT = dashCooldown = eventT = eventToastT = missionToastT = 0;
    adrenaline = adrenalineT = challengeT = challengeSwingTime = 0; challengeKind = -1; runTopSpeed = 0;
    nearMisses = trickCount = perfectReleases = padsHit = bestCombo = missionCoins = perfectLandings = 0;
    droneActive = false; dronePulse = 0; districtShown = -1;
    ghostX.clear(); ghostY.clear(); ghostStartX = P.x; eventToast.clear(); missionToast.clear();
    addBuilding(true);
    P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; P.vx = 230; P.onGround = true;
    startX = P.x;
    P.runStyle = wrng.range(0, 2);
    camX = P.x - W * 0.30f; camY = P.y - H * 0.58f;
    ensureWorld();
    gState = PLAYING;
    aMode = 2;
}

// ---------------------------------------------------------------- web
static bool findAnchor(float& ox, float& oy) {
    float best = 1e9f;
    bool found = false;
    const float maxDx = cfg.webAssist ? 3000.0f : 2600.0f;
    const float maxReach = cfg.webAssist ? 3200.0f : 2800.0f;
    for (auto& b : bld) {
        if (b.x > P.x + maxDx || b.x + b.w < P.x - 80) continue;
        for (auto& a : b.anch) {
            float dx = a.x - P.x, dy = P.y - a.y;
            if (dx < 10 || dx > maxDx || dy < 35 || dy > 1900 || hypotf(dx, dy) > maxReach) continue;
            float score = fabsf(dx - 620) + fabsf(dy - 360) * 0.6f;
            if (score < best) { best = score; ox = a.x; oy = a.y; found = true; }
        }
    }
    return found;
}
static void attachWeb(float ax, float ay) {
    P.swinging = true;
    P.ax = ax; P.ay = ay;
    P.rope = std::max(90.0f, hypotf(P.x - ax, P.y - ay));
    P.chain++;
    P.swingStyle = wrng.range(0, 3); P.jit = wrng.f() * 2 - 1;
    P.attachT = 0.18f;
    P.usedAir = false;
    if (P.chain >= 2) { bonus += 10.0f * P.chain; chainShowT = 1.6f; }
    burst(ax, ay, 8, 0xFFFFFF, 90);
    sfx(1);
}
static void releaseWeb(bool boosted) {
    if (!P.swinging) return;
    P.swinging = false;
    P.releaseFlip = P.vx > 250 && wrng.f() < 0.4f;
    P.flipDir = wrng.f() < 0.75f ? 1.0f : -1.0f;
    P.fallStyle = wrng.range(0, 1);
    P.releaseT = P.releaseFlip ? 0.5f : 0.25f;
    burst(P.x, P.y - 20, 4, 0xBFD8FF, 60);
    if (boosted) sfx(7); else sfx(6);
}
static void killPlayer() {
    if (!P.alive) return;
    P.alive = false; P.swinging = false; P.deadT = 0;
    P.vy = -320; P.vx = std::min(P.vx, 80.0f) * 0.4f;
    doShake(0.4f);
    burst(P.x, P.y, 14, 0xD62839, 160);
    sfx(5); aMode = 1;
}

static void solidHit(float L, float T, float R, float Bt, bool lethalSide) {
    float pl = P.x - 8, pr = P.x + 8, pt = P.y - 24, pb = P.y + 26, prevB = P.py + 26;
    if (!(pr > L && pl < R && pb > T && pt < Bt)) return;
    if (prevB <= T + 14 && P.vy >= 0) { P.y = T - 26; P.vy = 0; P.onGround = true; return; }
    if (pb - T < 26 && P.vy >= -50) { P.y = T - 26; P.vy = std::min(P.vy, 0.0f); P.onGround = true; return; }  // ledge assist
    if (lethalSide || P.vx > 200) { killPlayer(); return; }
    const bool sideHit = (P.py + 26 > T + 10 && P.py - 24 < Bt - 10);
    if (sideHit && !P.onGround && P.alive) {
        bool leftSide = P.x < (L + R) * 0.5f;
        P.x = leftSide ? L - 9 : R + 9;
        P.wallX = P.x; P.wallDir = leftSide ? 1.0f : -1.0f;
        P.wallCling = true; P.swinging = false; P.webFlying = false;
        P.vx = P.vy = 0; P.onGround = false; P.landT = 0; P.releaseT = 0;
        return;
    }
    if (P.x < (L + R) * 0.5f) P.x = L - 8; else P.x = R + 8;
    P.vx = std::min(P.vx, 0.0f) * 0.2f;
    if (P.swinging) releaseWeb(false);
}
static void collide() {
    for (auto& b : bld) {
        if (b.x + b.w < P.x - 40 || b.x > P.x + 40) continue;
        solidHit(b.x, b.roofY, b.x + b.w, b.roofY + 3200, false);
        if (!P.alive) return;
        for (auto& o : b.obs) {
            if (o.type == 7) {
                float top = b.roofY - 18.0f;
                if (P.vx > 0 && P.x + 8 > o.x && P.x - 8 < o.x + o.w && P.py + 26 <= top + 12 && P.y + 26 >= top && P.vy >= 0) {
                    P.y = top - 26; P.vy = -760.0f; P.onGround = false; P.usedAir = false;
                    padsHit++; addAdrenaline(10.0f); comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount); bonus += 35;
                    eventToast = "ROOFTOP LAUNCH!"; eventToastT = 1.2f; burst(P.x, top, cfg.reduced ? 4 : 9, 0x7FE0FF, 130); sfx(7);
                }
            } else if (o.solid) { solidHit(o.x, b.roofY - o.h, o.x + o.w, b.roofY, true); if (!P.alive) return; }
        }
    }
}

static void stepPhysics(float dt) {
    Player& p = P;
    if (!p.alive) {
        p.vy += GRAV * dt; p.x += p.vx * dt; p.y += p.vy * dt;
        return;
    }
    const float rm = runMult(), sm = swingMult();
    float runSp = (230 + 230 * difficulty()) * rm;
    p.px = p.x; p.py = p.y;
    p.coyote -= dt; p.jumpBuf -= dt;
    if (jumpEdge) { p.jumpBuf = 0.12f; jumpEdge = false; }
    p.slideBuf -= dt;
    if (slideEdge) { p.slideBuf = 0.15f; slideEdge = false; }
    p.boostT -= dt; p.dashT = std::max(0.0f, p.dashT - dt); dashCooldown = std::max(0.0f, dashCooldown - dt);
    p.nearMissLock = std::max(0.0f, p.nearMissLock - dt);
    if (p.swinging && swingHeld && p.vx > 250) p.slingshotT = std::min(1.0f, p.slingshotT + dt * 0.9f);
    if (adrenalineT > 0) adrenalineT = std::max(0.0f, adrenalineT - dt);
    else adrenaline = std::max(0.0f, adrenaline - dt * 1.7f);
    float target = runSp + p.boostExtra * clampf(p.boostT / p.boostDur, 0.0f, 1.0f);
    if (adrenalineT > 0) target += 135.0f;
    if (p.wallCling && p.jumpBuf > 0) {
        p.wallCling = false; p.vx = -p.wallDir * 300.0f; p.vy = -500.0f; p.jumpBuf = 0; p.usedAir = true; p.flipT = 0.18f; sfx(7);
    }
    if (p.wallCling) {
        // hold the web button to climb, let go to slide down
        p.x = p.wallX;
        p.vx = 0;
        p.vy = swingHeld ? -190.0f : 150.0f;
        // Lean toward the wall to turn the climb into a faster wall-run.
        if (steer * p.wallDir > 0.25f) {
            p.vy = -330.0f;
            if (!cfg.reduced && ((int)(gTime * 24)) % 3 == 0)
                spawnPart(p.x - p.wallDir * 7, p.y + 8, -p.wallDir * 25, 25, 0.22f, 0x7FE0FF, 1);
        }
        p.y += p.vy * dt;
        bool onFacade = false;
        for (auto& b : bld)
            if (p.wallX >= b.x - 12 && p.wallX <= b.x + b.w + 12 && p.y > b.roofY + 8 && p.y < b.roofY + 3100) { onFacade = true; break; }
        if (!onFacade) { p.wallCling = false; p.vy = 80; }
        collide();
        if (p.y > 900) killPlayer();
        return;
    }
    if (p.jumpBuf > 0) {
        if (p.swinging) { releaseWeb(true); p.vx = std::min(p.vx + 230.0f, 1550.0f); p.vy -= 200; p.jumpBuf = 0; comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount); bonus += 18; eventToast = "WEB ZIP BURST!"; eventToastT = 0.9f; burst(p.x, p.y, cfg.reduced ? 3 : 7, 0xFFFFFF, 120); }
        else if (p.onGround || p.coyote > 0) {
            p.vy = -560; p.onGround = false; p.coyote = 0; p.jumpBuf = 0; p.slideT = 0; p.jumpStyle = wrng.range(0, 2); p.fallStyle = wrng.range(0, 1); p.jit = wrng.f() * 2 - 1; sfx(7);
            for (int i = 0; i < 4; i++) spawnPart(p.x, p.y + 26, (i - 1.5f) * 25, -20, 0.3f, 0x8A90B0);
        } else if (!p.usedAir) { p.vy = -440; p.usedAir = true; p.jumpBuf = 0; p.flipT = 0.55f; trickCount++; addAdrenaline(12.0f); comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount); bonus += 5; p.flipDir = wrng.f() < 0.8f ? 1.0f : -1.0f; sfx(7); }
    }
    if (jumpRel) { if (p.vy < -250 && !p.swinging) p.vy *= 0.6f; jumpRel = false; }
    // Air dash uses the existing SLIDE input, so mobile controls stay unchanged.
    if (slideEdge && !p.onGround && !p.wallCling && dashCooldown <= 0) {
        p.slideBuf = 0; p.dashT = 0.18f; dashCooldown = 1.8f; p.dashUsed = true;
        p.vx = std::min(std::max(p.vx, 500.0f) + 260.0f, 1450.0f); p.vy *= 0.45f;
        comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount); bonus += 8;
        eventToast = "AIR DASH!"; eventToastT = 0.8f; burst(p.x, p.y, cfg.reduced ? 3 : 7, 0x7FE0FF, 100); sfx(7);
        slideEdge = false;
    }
    if (p.slideBuf > 0 && p.onGround && p.slideT <= 0) {
        p.slideBuf = 0; p.slideT = 0.7f; p.slideStyle = wrng.range(0, 2); p.jit = wrng.f() * 2 - 1;
        p.vx = std::min(std::max(p.vx, target) * 1.1f, 760.0f * rm);
        sfx(6); burst(p.x, p.y + 24, 5, 0x9AA0C0, 70);
    }
    if (p.onGround) {
        if (p.slideT > 0) p.vx *= expf(-0.45f * dt);   // a slide holds onto the speed
        else p.vx += (target - p.vx) * std::min(1.0f, 4 * dt);
    }
    p.slideT = p.onGround ? p.slideT - dt : 0;
    bool wasGround = p.onGround;
    p.onGround = false;
    p.vy += GRAV * (p.swinging ? sm * (adrenalineT > 0 ? 1.06f : 1.0f) : 1.0f) * dt;   // stronger pendulum; adrenaline adds a little lift and pace
    const float preVy = p.vy;
    if (!wasGround && fabsf(steer) > 0.01f && fabsf(p.vx) < 700 * rm) p.vx += steer * 240 * cfg.sens * dt;
    p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.swinging) {
        float dx = p.x - p.ax, dy = p.y - p.ay, d = hypotf(dx, dy);
        if (d > p.rope && d > 0.001f) {
            float nx = dx / d, ny = dy / d;
            p.x = p.ax + nx * p.rope; p.y = p.ay + ny * p.rope;
            float vr = p.vx * nx + p.vy * ny;
            if (vr > 0) { p.vx -= vr * nx; p.vy -= vr * ny; }
        }
        if (p.vx > 0 && p.y > p.ay) p.vx += 110 * sm * dt;   // gentle "pump" at the bottom of the arc
        float dr = expf(-0.12f * dt); p.vx *= dr; p.vy *= dr;
        if (p.x - p.ax > 200) releaseWeb(false);
    } else {
        float dr = expf(-0.05f * dt); p.vx *= dr;
    }
    collide();
    if (!p.alive) return;
    if (p.onGround) {
        p.wallCling = false;
        if (p.swinging) releaseWeb(false);
        p.coyote = 0.1f; p.usedAir = false;
        if (!wasGround) {  // landing
            p.hero = preVy > 640.0f; p.landT = p.hero ? 0.62f : 0.22f; p.flipT = 0;
            float over = p.vx - runSp;   // speed carried out of a swing becomes a run boost
            if (p.chain >= 1 && over > 40) {
                p.boostExtra = clampf(over * 0.6f, 60, 250);
                p.boostDur = p.boostT = 2.0f + 3.0f * clampf(over / 400.0f, 0, 1);
                if (p.slideBuf > 0) { p.boostT += 1; p.boostDur += 1; }   // landing straight into a slide keeps it going longer
            }
            p.landStyle = wrng.range(0, 2); p.runStyle = wrng.range(0, 2); p.jit = wrng.f() * 2 - 1;
            bonus += 25 + (p.chain >= 2 ? 10.0f * p.chain : 0);
            if (p.chain >= 2) chainShowT = 1.6f;
            p.chain = 0;
            if (p.hero) { comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount); bonus += 10; }
            if (preVy > 360.0f && p.vx > 360.0f) { perfectLandings++; addAdrenaline(18.0f); bonus += 35; comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount); chainShowT = 1.3f; eventToast = "PERFECT LANDING! +35"; eventToastT = 1.1f; speedBonus += 10; burst(p.x, p.y + 8, cfg.reduced ? 3 : 8, 0xFFE9A0, 90); }
            sfx(2); doShake(0.12f);
            for (int i = 0; i < (p.hero ? 12 : 6); i++) {
                float spread = p.hero ? 58.0f : 35.0f;
                spawnPart(p.x, p.y + 26, (i - (p.hero ? 5.5f : 2.5f)) * spread / (p.hero ? 2.0f : 1.0f),
                          -30 - wrng.f() * (p.hero ? 65.0f : 30.0f), p.hero ? 0.48f : 0.35f,
                          p.hero ? 0xC2C9DF : 0x9AA0C0);
            }
        }
    }
    if (p.y > 900) killPlayer();
}

// ============================================================================
//  INPUT
// ============================================================================
enum { R_NONE, R_SWING, R_JUMP, R_PAUSE, R_UI, R_STEER, R_SLIDER, R_SLIDE, R_DRAG };
struct Touch { bool on = false; SDL_FingerID id = 0; float x = 0, y = 0, sx = 0, ox = 0, oy = 0; int role = 0; int btn = 0; };
static Touch tch[10];
enum { B_PLAY = 1, B_CONTROLS, B_SETTINGS, B_HOW, B_CREDITS, B_BACK, B_RESUME, B_RESTART, B_MENU, B_TRY,
       B_SHAKE, B_REDUCED, B_FULL, B_TAB_KEYS, B_TAB_TOUCH, B_EDIT_LAYOUT, B_RESET_TAB, B_LEFTY, B_DONE, B_RESET_LAYOUT, B_KEY,
       B_SKILLS, B_UP_RUN, B_UP_SWING, B_RB_RUN, B_RB_SWING, B_WEB_ASSIST, B_SWING_TRAILS, B_RAIN, B_DAY_NIGHT,
       S_MUSIC, S_SFX, S_SENS, S_SIZE, S_ALPHA };
// kind: 0 button, 1 slider, 2 toggle, 3 key binding, 4 web-icon button.  style bits: 1 centred label, 2 primary (bigger), 4 outlined cell, 8 tab, 16 disabled
struct Btn { int id, kind, x, y, w, h; const char* label; float* val; bool* flag; float vmin, vmax; int style = 0, act = 0; };
static std::vector<Btn> btns;
static Btn pauseBtn;
static int gFocus = -1;        // keyboard / mouse-hover focus into btns (-1 = none)
static int gRebind = -1;       // action currently waiting for a new key (-1 = none)
static int ctlTab = 0;         // CONTROLS screen tab: 0 keyboard, 1 touch
static float flashT = 0, uiAge = 0, noteT = 0;
static char gNote[48] = "";

static void setNote(const char* s) { snprintf(gNote, sizeof gNote, "%s", s); noteT = 2.5f; }
static bool hasGlyph(unsigned char ch) { if (ch >= 128) return false; for (int i = 0; i < 7; i++) if (gGl[ch][i]) return true; return false; }
static void keyLabel(SDL_Scancode sc, char* out, size_t n) {
    switch (sc) {
        case SDL_SCANCODE_LSHIFT: snprintf(out, n, "L SHIFT"); return;
        case SDL_SCANCODE_RSHIFT: snprintf(out, n, "R SHIFT"); return;
        case SDL_SCANCODE_LCTRL: snprintf(out, n, "L CTRL"); return;
        case SDL_SCANCODE_RCTRL: snprintf(out, n, "R CTRL"); return;
        case SDL_SCANCODE_LALT: snprintf(out, n, "L ALT"); return;
        case SDL_SCANCODE_RALT: snprintf(out, n, "R ALT"); return;
        case SDL_SCANCODE_RETURN: snprintf(out, n, "ENTER"); return;
        case SDL_SCANCODE_SPACE: snprintf(out, n, "SPACE"); return;
        case SDL_SCANCODE_UP: snprintf(out, n, "UP ARROW"); return;
        case SDL_SCANCODE_DOWN: snprintf(out, n, "DOWN ARROW"); return;
        case SDL_SCANCODE_LEFT: snprintf(out, n, "LEFT ARROW"); return;
        case SDL_SCANCODE_RIGHT: snprintf(out, n, "RIGHT ARROW"); return;
        default: break;
    }
    const char* nm = SDL_GetScancodeName(sc);
    bool ok = nm && *nm;
    for (const char* c = nm; ok && *c; ++c) { unsigned char u = (unsigned char)toupper((unsigned char)*c); if (u != ' ' && !hasGlyph(u)) ok = false; }
    if (ok) snprintf(out, n, "%.12s", nm); else snprintf(out, n, "KEY %d", (int)sc);
    for (char* c = out; *c; ++c) *c = (char)toupper((unsigned char)*c);
}

// ---- on-screen touch buttons: 0 swing, 1 jump, 2 slide.  Honours size, left-handed mode and custom positions.
static void ctlPos(int i, float& x, float& y, float& r) {
    static const float R[3] = {46, 36, 28};
    float s = ctl.scale;
    r = R[i] * s;
    if (ctl.px[i] >= 0) { x = ctl.px[i] * W; y = ctl.py[i] * H; }
    else {
        float sr = R[0] * s, sx = W - safeR - sr - 6, sy = H - safeB - sr - 4;
        float jx = sx - 125 * s, jy = sy + 10 * s;
        if (i == 0) { x = sx; y = sy; }
        else if (i == 1) { x = jx; y = jy; }
        else { x = jx - 80 * s; y = jy + 4 * s; }
        if (ctl.lefty) x = W - x;
    }
    float m = r + 2;
    x = clampf(x, m, W - m); y = clampf(y, m, H - m);
}
static bool inSteerZone(float x) { return ctl.lefty ? x > W * 0.45f : x < W * 0.55f; }

// ---- skill upgrade screen layout (shared by buildUI and render).  Rows follow the sketch: JUMP, RUN, SWING, ZIP
static const int SKILL_ROW[4] = {-1, prog::RUN, prog::SWING, -1};   // -1 = coming soon
static const char* const SKILL_ROW_NAME[4] = {"JUMP", "RUN SPEED", "SWING SPEED", "ZIP"};
struct SkillLay { int rx, rw, rowY[4], rowH, bx[2], bw, bh, infoW, wcx, wcy, wr; };
static SkillLay skillLay(int px, int pw) {
    SkillLay L;
    int top = 62, bottom = H - 14 - 38 - 8, gap = 4;
    L.rowH = (int)clampf((float)((bottom - top - 3 * gap) / 4), 40.0f, 64.0f);
    int total = 4 * L.rowH + 3 * gap, y0 = top + std::max(0, (bottom - top - total) / 2);
    for (int i = 0; i < 4; i++) L.rowY[i] = y0 + i * (L.rowH + gap);
    int leftW = std::min(170, (pw - 40) * 30 / 100);
    L.rx = px + 20 + leftW + 10; L.rw = px + pw - 20 - L.rx;
    L.bw = 88; L.bh = std::min(L.rowH - 8, 30);
    L.bx[1] = L.rx + L.rw - L.bw; L.bx[0] = L.bx[1] - L.bw - 6;
    L.infoW = L.bx[0] - L.rx - 8;
    L.wcx = px + 20 + leftW / 2; L.wcy = (top + bottom) / 2; L.wr = std::min(leftW / 2, (bottom - top) / 2) - 2;
    return L;
}

static void buildUI() {
    btns.clear();
    float bh = std::max(minTouch * 0.8f, 30.0f);
    pauseBtn = {0, 0, (int)(W / 2 - 22), (int)safeT, 44, 44, "", nullptr, nullptr, 0, 1};
    int pw = std::min(W - (int)(safeL + safeR), 560), px = (W - pw) / 2;
    int footY = H - 14 - 38;                                   // footer button row inside a sheet
    auto add = [&](int id, int kind, int x, int y, int w, int h, const char* label, float* v, bool* f, float lo, float hi, int style, int act) {
        Btn b = {id, kind, x, y, w, h, label, v, f, lo, hi, style, act};
        btns.push_back(b);
    };
    switch (gState) {
        case MAIN_MENU: {
            if (trans >= 0) break;
            int x = (int)safeL + 8, w = (int)std::min(230.0f, W * 0.42f);
            int top = 82, n = 5, gap = 5;
            int ih = (int)clampf((float)((H - top - 34 - gap * (n - 1)) / n), 26.0f, bh + 4);
            int y = top;
            add(B_PLAY, 0, x, y, w, ih + 6, "PLAY", nullptr, nullptr, 0, 1, 2, 0); y += ih + 6 + gap;
            add(B_CONTROLS, 0, x, y, w, ih, "CONTROLS", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_SETTINGS, 0, x, y, w, ih, "SETTINGS", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_HOW, 0, x, y, w, ih, "HOW TO PLAY", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_CREDITS, 0, x, y, w, ih, "CREDITS", nullptr, nullptr, 0, 1, 0, 0);
            add(B_SKILLS, 4, W - (int)safeR - 54, (int)safeT + 10, 46, 46, "UPGRADES", nullptr, nullptr, 0, 1, 0, 0);
        } break;
        case SETTINGS: {
            int cw = (pw - 56) / 2, y = 74, c1 = px + 20, c2 = px + 36 + cw, th = 40;
            add(S_MUSIC, 1, c1, y, cw, th, "MUSIC", &cfg.music, nullptr, 0, 1, 0, 0);
            add(S_SFX, 1, c1, y + 46, cw, th, "EFFECTS", &cfg.sfx, nullptr, 0, 1, 0, 0);
            add(S_SENS, 1, c1, y + 92, cw, th, "STEERING", &cfg.sens, nullptr, 0.5f, 1.5f, 0, 0);
            add(B_SHAKE, 2, c2, y, cw, th, "CAMERA SHAKE", nullptr, &cfg.shake, 0, 1, 0, 0);
            add(B_REDUCED, 2, c2, y + 46, cw, th, "PERFORMANCE MODE", nullptr, &cfg.reduced, 0, 1, 0, 0);
            add(B_FULL, 2, c2, y + 92, cw, th, "IMMERSIVE", nullptr, &cfg.full, 0, 1, 0, 0);
            add(B_WEB_ASSIST, 2, c1, y + 138, cw, th, "WEB ASSIST", nullptr, &cfg.webAssist, 0, 1, 0, 0);
            add(B_SWING_TRAILS, 2, c2, y + 138, cw, th, "SWING TRAILS", nullptr, &cfg.swingTrails, 0, 1, 0, 0);
            add(B_RAIN, 2, c1, y + 184, cw, th, "RAIN EFFECTS", nullptr, &cfg.rain, 0, 1, 0, 0);
            add(B_DAY_NIGHT, 2, c2, y + 184, cw, th, "DAY / NIGHT TINT", nullptr, &cfg.dayNight, 0, 1, 0, 0);
            add(B_BACK, 0, W / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case CONTROLS: {
            int cw = (pw - 56) / 2, c1 = px + 20, c2 = px + 36 + cw, gy = 96, th = 38, pitch = 42;
            add(B_TAB_KEYS, 0, c1, 60, 130, 26, "KEYBOARD", nullptr, nullptr, 0, 1, 1 | 8, 0);
            add(B_TAB_TOUCH, 0, c1 + 138, 60, 130, 26, "TOUCH", nullptr, nullptr, 0, 1, 1 | 8, 0);
            if (ctlTab == 0) {
                static const int L[3] = {A_LEFT, A_RIGHT, A_PAUSE}, R[3] = {A_JUMP, A_SLIDE, A_SWING};
                for (int i = 0; i < 3; i++) add(B_KEY, 3, c1, gy + i * pitch, cw, th, ACT_LABEL[L[i]], nullptr, nullptr, 0, 1, 0, L[i]);
                for (int i = 0; i < 3; i++) add(B_KEY, 3, c2, gy + i * pitch, cw, th, ACT_LABEL[R[i]], nullptr, nullptr, 0, 1, 0, R[i]);
            } else {
                add(S_SIZE, 1, c1, gy, cw, th, "BUTTON SIZE", &ctl.scale, nullptr, 0.7f, 1.4f, 0, 0);
                add(S_ALPHA, 1, c1, gy + pitch, cw, th, "BUTTON OPACITY", &ctl.alpha, nullptr, 0.2f, 1.0f, 0, 0);
                add(S_SENS, 1, c1, gy + 2 * pitch, cw, th, "STEERING", &cfg.sens, nullptr, 0.5f, 1.5f, 0, 0);
                add(B_LEFTY, 2, c2, gy, cw, th, "LEFT HANDED", nullptr, &ctl.lefty, 0, 1, 0, 0);
                add(B_EDIT_LAYOUT, 0, c2, gy + pitch + 4, cw, 32, "EDIT LAYOUT", nullptr, nullptr, 0, 1, 1 | 4, 0);
                add(B_RESET_LAYOUT, 0, c2, gy + 2 * pitch + 4, cw, 32, "RESET LAYOUT", nullptr, nullptr, 0, 1, 1 | 4, 0);
            }
            add(B_BACK, 0, W / 2 - 170, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(B_RESET_TAB, 0, W / 2 + 10, footY, 160, 30, "RESET TAB", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case LAYOUT_EDIT: {
            int bw = 104, gap = 12, left = (int)safeL + 8, right = W - (int)safeR - 8;
            int sw = (int)clampf((float)((right - left - 2 * bw - 4 * gap) / 2), 90.0f, 180.0f);
            int y = 10;
            add(B_DONE, 0, left, y, bw, 30, "DONE", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(S_SIZE, 1, left + bw + gap * 2, y - 2, sw, 40, "SIZE", &ctl.scale, nullptr, 0.7f, 1.4f, 0, 0);
            add(S_ALPHA, 1, left + bw + gap * 3 + sw, y - 2, sw, 40, "OPACITY", &ctl.alpha, nullptr, 0.2f, 1.0f, 0, 0);
            add(B_RESET_LAYOUT, 0, right - bw, y, bw, 30, "RESET", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case HOW_TO_PLAY: case CREDITS:
            add(B_BACK, 0, W / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            break;
        case PAUSED: {
            int w = 250, n = 5, gap = 5, top = (int)(H * 0.28f);
            int ih = (int)clampf((float)((H - top - 16 - gap * (n - 1)) / n), 24.0f, bh);
            int x = W / 2 - w / 2, y = top;
            add(B_RESUME, 0, x, y, w, ih + 4, "RESUME", nullptr, nullptr, 0, 1, 1 | 2, 0); y += ih + 4 + gap;
            add(B_RESTART, 0, x, y, w, ih, "RESTART", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_CONTROLS, 0, x, y, w, ih, "CONTROLS", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_SETTINGS, 0, x, y, w, ih, "SETTINGS", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_MENU, 0, x, y, w, ih, "MAIN MENU", nullptr, nullptr, 0, 1, 1, 0);
        } break;
        case GAME_OVER: {
            int y = H - (int)safeB - 46;
            add(B_TRY, 0, W / 2 - 205, y, 200, 38, "TRY AGAIN", nullptr, nullptr, 0, 1, 1 | 2, 0);
            add(B_MENU, 0, W / 2 + 5, y, 200, 38, "MAIN MENU", nullptr, nullptr, 0, 1, 1, 0);
            add(B_SKILLS, 4, W - (int)safeR - 54, (int)safeT + 10, 46, 46, "UPGRADES", nullptr, nullptr, 0, 1, 0, 0);
        } break;
        case SKILLS: {
            SkillLay L = skillLay(px, pw);
            static char lb[4][28];
            const int ids[2][2] = {{B_UP_RUN, B_RB_RUN}, {B_UP_SWING, B_RB_SWING}};
            for (int k = 0; k < 2; k++) {
                const int sk = k == 0 ? prog::RUN : prog::SWING, row = k == 0 ? 1 : 2;
                char c[20];
                if (prog::atMaxLevel(gProg, sk)) snprintf(lb[k * 2], sizeof lb[0], "MAX LEVEL");
                else { fmtNum(prog::DEF[sk].upgradeCost, c, sizeof c); snprintf(lb[k * 2], sizeof lb[0], "UPGRADE %s", c); }
                if (prog::atMaxRebirth(gProg, sk)) snprintf(lb[k * 2 + 1], sizeof lb[0], "MAX REBIRTH");
                else { fmtNum(prog::DEF[sk].rebirthCost, c, sizeof c); snprintf(lb[k * 2 + 1], sizeof lb[0], "REBIRTH %s", c); }
                int by = L.rowY[row] + (L.rowH - L.bh) / 2;
                add(ids[k][0], 0, L.bx[0], by, L.bw, L.bh, lb[k * 2], nullptr, nullptr, 0, 1, 1 | 4 | (prog::canUpgrade(gProg, sk) ? 0 : 16), 0);
                add(ids[k][1], 0, L.bx[1], by, L.bw, L.bh, lb[k * 2 + 1], nullptr, nullptr, 0, 1, 1 | 4 | (prog::canRebirth(gProg, sk) ? 0 : 16), 0);
            }
            add(B_BACK, 0, W / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        default: break;
    }
}
static bool inRect(float x, float y, int rx, int ry, int rw, int rh, int pad = 0) {
    return x >= rx - pad && x <= rx + rw + pad && y >= ry - pad && y <= ry + rh + pad;
}
static void setSlider(const Btn& b, float x) {
    float t = clampf((x - b.x) / (float)b.w, 0, 1);
    *b.val = b.vmin + (b.vmax - b.vmin) * t;
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void startAudio() {
    if (!audioStarted && gAud) { SDL_PauseAudioDevice(gAud, 0); audioStarted = true; aMode = 1; }
}
static void enterMenu() {                       // PRESS TO START -> main menu
    startAudio();
    gState = MAIN_MENU; flashT = 0.5f; menuT = 0; sfx(7);
}
static void activate(int id) {
    sfx(4);
    switch (id) {
        case B_PLAY: trans = 0; break;
        case B_CONTROLS: openSub(CONTROLS); break;
        case B_SETTINGS: openSub(SETTINGS); break;
        case B_HOW: openSub(HOW_TO_PLAY); break;
        case B_CREDITS: openSub(CREDITS); break;
        case B_EDIT_LAYOUT: openSub(LAYOUT_EDIT); break;
        case B_SKILLS: openSub(SKILLS); break;
        case B_UP_RUN: case B_UP_SWING: {
            const int sk = id == B_UP_RUN ? prog::RUN : prog::SWING;
            if (prog::upgrade(gProg, sk)) { saveProg(); sfx(3); gNote[0] = 0; }
            else setNote(prog::atMaxLevel(gProg, sk) ? "ALREADY MAX LEVEL" : "NOT ENOUGH COINS");
        } break;
        case B_RB_RUN: case B_RB_SWING: {
            const int sk = id == B_RB_RUN ? prog::RUN : prog::SWING;
            if (prog::doRebirth(gProg, sk)) { saveProg(); sfx(7); setNote("REBIRTH COMPLETE"); }
            else if (prog::atMaxRebirth(gProg, sk)) setNote("MAX REBIRTH");
            else if (!prog::atMaxLevel(gProg, sk)) setNote("REACH MAX LEVEL FIRST");
            else setNote("NOT ENOUGH COINS");
        } break;
        case B_BACK: case B_DONE: goBack(); break;
        case B_RESUME: gState = PLAYING; break;
        case B_RESTART: case B_TRY: startRun(); break;
        case B_MENU: gState = MAIN_MENU; navStack.clear(); trans = -1; menuT = 0; aMode = 1; break;
        case B_SHAKE: cfg.shake = !cfg.shake; saveCfg(); break;
        case B_WEB_ASSIST: cfg.webAssist = !cfg.webAssist; saveCfg(); break;
        case B_SWING_TRAILS: cfg.swingTrails = !cfg.swingTrails; saveCfg(); break;
        case B_RAIN: cfg.rain = !cfg.rain; saveCfg(); break;
        case B_DAY_NIGHT: cfg.dayNight = !cfg.dayNight; saveCfg(); break;
        case B_REDUCED: cfg.reduced = !cfg.reduced; saveCfg(); break;
        case B_FULL:
            cfg.full = !cfg.full; saveCfg();
            SDL_SetWindowFullscreen(gWin, cfg.full ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
            break;
        case B_TAB_KEYS: ctlTab = 0; gFocus = -1; gRebind = -1; break;
        case B_TAB_TOUCH: ctlTab = 1; gFocus = -1; gRebind = -1; break;
        case B_LEFTY:
            ctl.lefty = !ctl.lefty;
            for (int i = 0; i < 3; i++) if (ctl.px[i] >= 0) ctl.px[i] = 1.0f - ctl.px[i];   // keep custom spots mirrored
            saveControls();
            break;
        case B_RESET_LAYOUT:
            for (int i = 0; i < 3; i++) ctl.px[i] = ctl.py[i] = -1.0f;
            ctl.scale = 1.0f; ctl.alpha = 0.7f;
            saveControls(); setNote("LAYOUT RESET");
            break;
        case B_RESET_TAB:
            if (ctlTab == 0) ctl.resetKeys();
            else { ctl.resetTouch(); cfg.sens = 1.0f; saveCfg(); }
            saveControls(); setNote("RESET TO DEFAULTS");
            break;
        default: break;
    }
}
static void pressBtn(const Btn& b) {
    if (b.kind == 3) { gRebind = b.act; gNote[0] = 0; sfx(4); return; }
    if (b.kind == 1) return;
    activate(b.id);
}
static void assignKey(int a, SDL_Scancode sc) {
    gNote[0] = 0;
    for (int j = 0; j < A_N; j++) if (j != a && ctl.key[j] == sc) {
        ctl.key[j] = ctl.key[a];                                    // swap so nothing is left unbound
        char b[48]; snprintf(b, sizeof b, "SWAPPED WITH %s", ACT_LABEL[j]); setNote(b);
    }
    ctl.key[a] = sc;
    saveControls(); sfx(3);
}
static void saveAll() { saveCfg(); saveControls(); }
static void releaseAll() {
    for (auto& t : tch) t = Touch();
    swingHeld = false; slideEdge = false; steer = 0;
}
static void toInternal(float nx, float ny, float& x, float& y) {
    x = (nx * OUTW - OFFX) / SC; y = (ny * OUTH - OFFY) / SC;
}
static void fingerDown(const SDL_TouchFingerEvent& e) {
    startAudio();
    if (portrait) return;
    if (gState == TITLE) { enterMenu(); return; }
    if (gRebind >= 0) gRebind = -1;                  // tapping anywhere cancels a pending key capture
    Touch* t = nullptr;
    for (auto& q : tch) if (!q.on) { t = &q; break; }
    if (!t) return;
    t->on = true; t->id = e.fingerId; toInternal(e.x, e.y, t->x, t->y); t->sx = t->x; t->role = R_NONE;
    if (gState == PLAYING) {
        float x[3], y[3], r[3];
        for (int i = 0; i < 3; i++) ctlPos(i, x[i], y[i], r[i]);
        if (inRect(t->x, t->y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 6)) t->role = R_PAUSE;
        else if (hypotf(t->x - x[0], t->y - y[0]) <= r[0] * 1.2f) t->role = R_SWING;
        else if (hypotf(t->x - x[1], t->y - y[1]) <= r[1] * 1.25f) { t->role = R_JUMP; jumpEdge = true; }
        else if (hypotf(t->x - x[2], t->y - y[2]) <= r[2] * 1.25f) { t->role = R_SLIDE; slideEdge = true; }
        else if (inSteerZone(t->x)) t->role = R_STEER;
    } else {
        if (gState == LAYOUT_EDIT) {
            for (int i = 0; i < 3; i++) {
                float x, y, r; ctlPos(i, x, y, r);
                if (hypotf(t->x - x, t->y - y) <= r * 1.15f) { t->role = R_DRAG; t->btn = i; t->ox = x - t->x; t->oy = y - t->y; return; }
            }
        }
        for (size_t i = 0; i < btns.size(); i++) {
            const Btn& b = btns[i];
            if (inRect(t->x, t->y, b.x, b.y, b.w, b.h, 4)) {
                t->btn = (int)i; t->role = b.kind == 1 ? R_SLIDER : R_UI; gFocus = (int)i;
                if (b.kind == 1) setSlider(b, t->x);
                break;
            }
        }
    }
}
static void fingerMove(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_SLIDER && t.btn >= 0 && t.btn < (int)btns.size()) setSlider(btns[t.btn], t.x);
        if (t.role == R_DRAG) { ctl.px[t.btn] = clampf((t.x + t.ox) / W, 0, 1); ctl.py[t.btn] = clampf((t.y + t.oy) / H, 0, 1); }
    }
}
static void fingerUp(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_JUMP) jumpRel = true;
        else if (t.role == R_PAUSE) { if (inRect(t.x, t.y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 10) && gState == PLAYING) { gState = PAUSED; sfx(4); } }
        else if (t.role == R_UI) {
            if (t.btn >= 0 && t.btn < (int)btns.size()) {
                Btn b = btns[t.btn];
                if (inRect(t.x, t.y, b.x, b.y, b.w, b.h, 6)) { t = Touch(); pressBtn(b); continue; }
            }
        }
        else if (t.role == R_SLIDER || t.role == R_DRAG) saveAll();
        t = Touch();
    }
}
static void pollHeld() {
    swingHeld = false; steer = 0;
    for (auto& t : tch) if (t.on) {
        if (t.role == R_SWING) swingHeld = true;
        if (t.role == R_STEER) steer = clampf((t.x - t.sx) / 50.0f, -1, 1);
    }
    const Uint8* ks = SDL_GetKeyboardState(nullptr);   // keyboard uses the rebindable keys
    if (ks[ctl.key[A_SWING]]) swingHeld = true;
    float kst = (ks[ctl.key[A_RIGHT]] ? 1.0f : 0.0f) - (ks[ctl.key[A_LEFT]] ? 1.0f : 0.0f);
    if (kst != 0) steer = kst;
}

// ---- keyboard / mouse navigation of menus ----
static void mouseHover(int mx, int my) {
    if (gState == PLAYING || gState == TITLE || portrait) return;
    int ww = 1, wh = 1; SDL_GetWindowSize(gWin, &ww, &wh);
    float x, y; toInternal((float)mx / std::max(1, ww), (float)my / std::max(1, wh), x, y);
    int f = -1;
    for (size_t i = 0; i < btns.size(); i++) if (inRect(x, y, btns[i].x, btns[i].y, btns[i].w, btns[i].h)) { f = (int)i; break; }
    gFocus = f;
}
static void menuKey(SDL_Scancode sc) {
    int n = (int)btns.size();
    if (n == 0) return;
    if (sc == SDL_SCANCODE_UP || sc == SDL_SCANCODE_DOWN) {
        int d = sc == SDL_SCANCODE_DOWN ? 1 : -1;
        gFocus = gFocus < 0 ? (d > 0 ? 0 : n - 1) : (gFocus + d + n) % n;
        sfx(6);
    } else if ((sc == SDL_SCANCODE_LEFT || sc == SDL_SCANCODE_RIGHT) && gFocus >= 0 && btns[gFocus].kind == 1) {
        const Btn& b = btns[gFocus];
        *b.val = clampf(*b.val + (sc == SDL_SCANCODE_RIGHT ? 1 : -1) * (b.vmax - b.vmin) * 0.05f, b.vmin, b.vmax);
        aMusic = cfg.music; aSfx = cfg.sfx; saveAll();
    } else if (sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_KP_ENTER || sc == SDL_SCANCODE_SPACE) {
        if (gFocus < 0) gFocus = 0;
        else pressBtn(Btn(btns[gFocus]));
    }
}

// ============================================================================
//  RENDERING
// ============================================================================
static void drawHalo(int cx, int cy) {
    for (int i = 0; i < 3; i++) disc(cx, cy, 34 - i * 8, 0x6A78FF, 9);
}
static void drawBackdrop(float cx, float cy, double t) {
    static const u32 sky[] = {0x070A1E, 0x0A0F28, 0x0E1432, 0x131A3C, 0x1A1F46, 0x222350, 0x2B2A5A, 0x35305F, 0x3F3566};
    const int nb = 9;
    for (int i = 0; i < nb; i++) rect(0, i * H / nb, W, H / nb + 1, sky[i]);
    for (int i = 0; i < 80; i++) {
        u32 h = hash3(i, 77, 3);
        int sx = pmod((int)(h % (u32)(W * 2)) - (int)(cx * 0.02f), W), sy = (int)((h >> 10) % (u32)(H * 0.6f));
        bool dim = ((int)(t * 2 + i)) % 7 == 0;
        rect(sx, sy, 1, 1, 0xFFFFFF, dim ? 90 : 220);
    }
    disc((int)(W * 0.82f), (int)(H * 0.16f), 14, 0xE8ECFF, 230);
    disc((int)(W * 0.82f) + 5, (int)(H * 0.16f) - 3, 12, 0x0E1432, 255);
    for (int i = 0; i < 6; i++) {  // layered, drifting pixel clouds
        int x = pmod((int)(i * 260 + t * (6 + i * 2) - cx * 0.05f), W + 300) - 150;
        int y = 40 + (i * 47) % 120;
        rect(x, y, 70, 8, 0x3A3B72, 90);
        rect(x + 10, y - 6, 40, 6, 0x3A3B72, 90);
        rect(x + 20, y + 8, 50, 5, 0x3A3B72, 90);
        // Tiny upper-edge highlights add depth without using textures.
        rect(x + 13, y - 5, 30, 2, 0x8992C8, 35);
        rect(x + 24, y + 9, 35, 1, 0x171D43, 65);
    }
    // Small bird silhouettes drift independently from the city, using a fixed
    // count so the effect stays cheap on mobile devices.
    if (!cfg.reduced) {
        for (int i = 0; i < 4; ++i) {
            int bx = pmod((int)(i * 181 + t * (13 + i * 2) - cx * 0.025f), W + 24) - 12;
            int by = 54 + (i * 37) % std::max(1, H / 3) + (int)(sinf((float)t * 1.8f + i) * 2.0f);
            line((float)(bx - 4), (float)(by + 1), (float)bx, (float)by, 0xA9B4D8, 125);
            line((float)bx, (float)by, (float)(bx + 4), (float)(by + 1), 0xA9B4D8, 125);
        }
    }
    // A restrained sunset glow rolls through the horizon as the sky cycles.
    // It is only a translucent wash, so no extra textures or per-frame buffers
    // are needed. Turning day/night off keeps the original night palette.
    if (cfg.dayNight) {
        float phase = (float)fmod(t / 90.0, 1.0);
        float sunset = clampf(1.0f - fabsf(phase - 0.52f) / 0.18f, 0.0f, 1.0f);
        int glowA = (int)(sunset * 22.0f);
        if (glowA > 0) {
            for (int band = 0; band < 5; ++band)
                rect(0, H * 2 / 5 + band * 7, W, 7, 0xF07B69, glowA * (5 - band) / 5);
        }
    }
    { int ax = W + 20 - (int)fmod(t * 28.0, (double)(W + 80)), ay = (int)(H * 0.22f);  // distant aircraft
      rect(ax - 3, ay, 6, 2, 0xAAB4D8); rect(ax + 4, ay, 18, 1, 0xAAB4D8, 60);
      if (((int)(t * 2)) & 1) rect(ax, ay - 2, 2, 2, 0xFF3030); else rect(ax, ay - 2, 2, 2, 0xFFFFFF); }
    // far skyline
    static int farW[24], farH[24]; static int farP = 0;
    if (!farP) { Rng r(5); for (int i = 0; i < 24; i++) { farW[i] = (r.range(40, 90) / 8) * 8; farH[i] = r.range(60, 170); farP += farW[i]; } }
    float off = fmodf(cx * 0.10f, (float)farP);
    int x = (int)-off, idx = 0;
    while (x < W) {
        int bw = farW[idx % 24], top = (int)(H * 0.60f - farH[idx % 24] - (cy + 210) * 0.04f);
        if (x + bw > 0) {
            rect(x, top, bw, H - top, 0x141A3A);
            for (int ty = top; ty < H; ty += 32) for (int tx = 0; tx < bw; tx += 32) {
                SDL_Rect s = {0, 0, std::min(32, bw - tx), 32}, d = {x + tx, ty, s.w, 32};
                SDL_RenderCopy(gRen, gFar[hash3(idx, tx, ty) % 3], &s, &d);
            }
            rect(x, top, bw, 2, 0x2A3260);
        }
        x += bw; idx++;
    }
    rect(0, (int)(H * 0.45f), W, H, 0x2B2F6A, 28);
    // mid skyline (bigger, darker facades, independent parallax)
    static int midW[10], midH[10], midS[10], midP = 0;
    if (!midP) { Rng r(9); for (int i = 0; i < 10; i++) { midW[i] = (r.range(96, 176) / 16) * 16; midH[i] = r.range(0, 90); midS[i] = r.range(0, 5); midP += midW[i] + 10; } }
    tileMod(85, 92, 140);
    off = fmodf(cx * 0.30f, (float)midP);
    x = (int)-off; idx = 0;
    while (x < W) {
        int bw = midW[idx % 10], top = (int)(H * 0.30f + midH[idx % 10] - (cy + 210) * 0.12f);
        if (x + bw > 0) {
            for (int ty = top; ty < H; ty += 64) for (int tx = 0; tx < bw; tx += 64) {
                SDL_Rect s = {0, 0, std::min(64, bw - tx), 64}, d = {x + tx, ty, s.w, 64};
                SDL_RenderCopy(gRen, gTile[midS[idx % 10]][hash3(idx, tx, ty) % 3], &s, &d);
            }
            rect(x - 1, top - 4, bw + 2, 4, 0x1B2048);
            rect(x + bw / 2, top - 22, 2, 18, 0x1B2048);
            if (((int)(t * 1.3) + idx) & 1) rect(x + bw / 2 - 1, top - 24, 4, 3, 0xFF3A3A, 200);
        }
        x += bw + 10; idx++;
    }
    tileMod(255, 255, 255);
    rect(0, (int)(H * 0.5f), W, H, 0x3A3F80, 34);  // atmospheric haze
}

static void drawObs(const Obs& o, int sx, int sy, double t) {
    int x = sx, y = sy;
    switch (o.type) {
        case 0:  // HVAC
            rect(x, y - 20, 28, 20, 0x59606E); rect(x, y - 20, 28, 2, 0x8A93A6);
            disc(x + 8, y - 11, 5, 0x1B1F28);
            { int ph = (int)(t * 12) & 1; if (ph) { rect(x + 3, y - 12, 10, 2, 0x4A5060); rect(x + 7, y - 16, 2, 10, 0x4A5060); } else { line(x + 4, y - 15, x + 12, y - 7, 0x4A5060); line(x + 12, y - 15, x + 4, y - 7, 0x4A5060); } }
            for (int i = 0; i < 3; i++) rect(x + 17, y - 16 + i * 4, 9, 2, 0x2B303B);
            break;
        case 1:  // water tower
            rect(x + 3, y - 18, 3, 18, 0x3B2A1E); rect(x + 24, y - 18, 3, 18, 0x3B2A1E);
            line(x + 4, y - 18, x + 25, y - 2, 0x3B2A1E);
            rect(x, y - 42, 30, 24, 0x7A5236); rect(x, y - 36, 30, 2, 0x4A301F); rect(x, y - 26, 30, 2, 0x4A301F);
            rect(x + 3, y - 40, 4, 20, 0x9A6B46); rect(x + 4, y - 46, 22, 4, 0x4A301F); rect(x + 9, y - 50, 12, 4, 0x4A301F);
            break;
        case 2:  // barrier
            rect(x, y - 14, 24, 14, 0xC9C3B5);
            for (int i = 0; i < 3; i++) rect(x + 2 + i * 8, y - 12, 4, 10, 0xE0A81E);
            rect(x, y - 14, 24, 2, 0xE8E3D5);
            break;
        case 3: {  // antenna
            int h = (int)o.h;
            rect(x, y - h, 2, h, 0x2A2F3F); rect(x - 5, y - h + 20, 12, 1, 0x2A2F3F); rect(x - 3, y - h + 30, 8, 1, 0x2A2F3F);
            if (((int)(t * 1.5) + (int)o.x) & 1) { disc(x, y - h - 2, 4, 0xFF2A2A, 60); rect(x - 1, y - h - 3, 4, 4, 0xFF4040); }
        } break;
        case 4: {  // construction crane
            int h = (int)o.h, jw = (int)o.w;
            rect(x, y - h, 6, h, 0xC9A227);
            for (int i = 0; i < h; i += 10) { rect(x, y - h + i, 6, 1, 0x6B5611); line(x, y - h + i, x + 5, y - h + i + 9, 0x6B5611); }
            rect(x - 30, y - h, 30 + jw, 4, 0xC9A227); rect(x - 30, y - h + 4, 14, 10, 0x555B68);
            rect(x - 6, y - h - 8, 12, 8, 0x3A4150);
            rect(x + jw - 1, y - h + 4, 1, 26, 0x888888); rect(x + jw - 3, y - h + 30, 5, 4, 0xD9481F);
            if (((int)(t * 2)) & 1) { disc(x + 3, y - h - 10, 3, 0xFF4040, 70); rect(x + 2, y - h - 11, 3, 3, 0xFF5050); }
            rect(x + jw - 2, y - h + 1, 3, 3, 0xFFE9A0);
        } break;
        case 7: { // rooftop launch pad
            rect(x, y - 18, (int)o.w, 18, 0x17283B); rect(x + 3, y - 15, (int)o.w - 6, 12, 0x267F9A);
            for (int i = 0; i < 4; ++i) rect(x + 7 + i * 12, y - 13, 5, 3, 0xB8F4FF);
            int pulse = (int)(35 + 25 * sinf((float)t * 7 + o.x));
            rect(x + 2, y - 19, (int)o.w - 4, 2, 0x7FE0FF, pulse + 120);
        } break;
        case 5: {  // animated billboard
            static const char* ads[4] = {"NEON NOODLES", "CITY BANK", "SKY TV", "PIZZA 24/7"};
            static const u32 bg[4] = {0x3A1030, 0x103A50, 0x2A1050, 0x503A10};
            int w = (int)o.w;
            rect(x + 8, y - 70, 4, 70, 0x2A2F3F); rect(x + w - 12, y - 70, 4, 70, 0x2A2F3F);
            rect(x, y - 114, w, 46, 0x1A1D28);
            rect(x + 3, y - 111, w - 6, 40, bg[o.param & 3]);
            SDL_Rect clip = {x + 3, y - 111, w - 6, 40};
            SDL_RenderSetClipRect(gRen, &clip);
            { const char* s = ads[o.param & 3]; int tw = textW(s, 2) + 40; int tx = x + 3 + w - 6 - (int)fmod(t * 30.0, (double)(tw + w));
              text(s, tx, y - 100, 2, 0xFFE9A0);
              rect(x + 3, y - 80, w - 6, 3, 0xFF3A6A, 160 + (int)(60 * sinf((float)t * 4))); }
            SDL_RenderSetClipRect(gRen, nullptr);
            rect(x, y - 114, w, 2, 0x6A7090);
        } break;
        default:  // dish
            rect(x, y - 6, 2, 6, 0x4A5060); rect(x - 6, y - 14, 12, 3, 0xB8BED0); rect(x - 4, y - 11, 8, 2, 0x8A90A8); rect(x - 1, y - 16, 2, 4, 0x6A7090);
            break;
    }
}
static void drawFacade(const Building& b, int sx, int sy) {
    u32 tm = (u32)(gTime * 0.4);
    int y0 = sy + 8;
    int r0 = std::max(0, (int)floorf((0 - y0) / 64.0f));
    int cols = ((int)b.w + 63) / 64;
    for (int r = r0; y0 + r * 64 < H; r++) {
        for (int c = 0; c < cols; c++) {
            int tx = sx + c * 64;
            if (tx + 64 < 0 || tx > W) continue;
            int v = (int)(hash3(b.seed + c, r, 7) % 3);
            if (hash3(c + (u32)b.seed, r, tm) % 29 == 0) v = (v + 1) % 3;
            int sw = std::min(64, (int)b.w - c * 64);
            SDL_Rect s = {0, 0, sw, 64}, d = {tx, y0 + r * 64, sw, 64};
            SDL_RenderCopy(gRen, gTile[b.style][v], &s, &d);
        }
    }
    int top = std::max(sy, 0);
    rect(sx, top, 3, H - top, 0x05060F, 130);
    rect(sx + (int)b.w - 3, top, 3, H - top, 0x6A78FF, 40);
    rect(sx - 2, sy, (int)b.w + 4, 8, 0x4B5068);
    rect(sx - 2, sy, (int)b.w + 4, 2, 0x8A93B0);
    rect(sx, sy + 6, (int)b.w, 2, 0x1B1E2C);
}
static void drawCable(const Building& b, float cx, float cy) {
    if (!b.cable) return;
    float x0 = b.cx0 - cx, y0 = b.cy0 - cy, x1 = b.cx1 - cx, y1 = b.cy1 - cy;
    if (x1 < -20 || x0 > W + 20) return;
    float px = x0, py = y0;
    for (int i = 1; i <= 24; i++) {
        float u = i / 24.0f, qx = lerpf(x0, x1, u), qy = lerpf(y0, y1, u) + 22 * 4 * u * (1 - u);
        line(px, py + 1, qx, qy + 1, 0x05060F, 200); line(px, py, qx, qy, 0x9AA3C0);
        px = qx; py = qy;
    }
    float ax = (x0 + x1) / 2, ay = (y0 + y1) / 2 + 22;
    disc((int)ax, (int)ay + 2, 8, 0xFFE8A0, 45);
    rect((int)ax - 3, (int)ay - 2, 6, 6, 0xFFE8A0); rect((int)ax - 1, (int)ay - 4, 2, 2, 0x4A5060);
}
static void drawMasts(const Building& b, int sx, int sy) {
    if (b.mastR) { int x = sx + (int)b.w - 12; rect(x, sy - 280, 3, 280, 0x2A2F3F); rect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) rect(x, sy - 284, 3, 3, 0xFF4040); }
    if (b.mastL) { int x = sx + 9; rect(x, sy - 280, 3, 280, 0x2A2F3F); rect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) rect(x, sy - 284, 3, 3, 0xFF4040); }
}

static int pickFrame() {
    Player& p = P;
    if (!p.alive) return p.deadT < 0.3f ? F_HIT : F_DEAD;
    if (p.wallCling) return swingHeld ? F_CLIMB : F_CLING;
    if (p.swinging && !p.onGround) return p.attachT > 0 ? F_ATTACH : F_SWING;
    if (p.shootT > 0 && !p.onGround) return F_SHOOT;
    if (p.releaseT > 0) return p.releaseFlip ? F_FLIP : F_RELEASE;
    if (p.slideT > 0 && p.onGround) return F_SLIDE;
    if (p.landT > 0) return p.hero ? F_HERO : F_LAND;
    if (p.onGround) return F_RUN;
    if (p.flipT > 0) return F_FLIP;
    return p.vy < 0 ? F_JUMP : F_FALL;
}

static void drawCityTraffic(float cx, float cy) {
    // Tiny parallax traffic sprites: fixed count, no entities or physics to update.
    const int roadY = (int)(H * 0.70f - (cy + 210.0f) * 0.06f);
    for (int i = 0; i < 7; ++i) {
        int x = pmod((int)(i * 173 + gTime * (38 + i * 3) - cx * 0.18f), W + 40) - 20;
        int y = roadY + (i % 3) * 7;
        rect(x, y, 17, 5, 0x20243D, 220);
        rect(x + 3, y - 2, 8, 2, 0x65749B, 190);
        rect(x + 2, y + 4, 3, 2, 0xFFE5A0, 180);
        rect(x + 13, y + 4, 2, 2, 0xFF515B, 180);
    }
    // A small helicopter silhouette crosses the skyline on a slow loop.
    int hx = pmod((int)(W + 90 - gTime * 22.0), W + 180) - 90;
    int hy = (int)(H * 0.24f + sinf((float)gTime * 0.7f) * 12.0f);
    rect(hx - 9, hy, 19, 4, 0x262B46, 230);
    rect(hx + 7, hy - 3, 7, 3, 0x262B46, 230);
    rect(hx - 2, hy - 5, 4, 2, 0x9AA7D0, 180);
    rect(hx - 15, hy - 6, 30, 1, 0x9AA7D0, 140);
    rect(hx - 12, hy + 4, 2, 3, 0x262B46, 220); rect(hx + 8, hy + 4, 2, 3, 0x262B46, 220);
}
static void drawWeatherAndTint(float cx, float cy) {
    if (cfg.dayNight) {
        // Low-alpha color wash cycles slowly; no render-target or shader cost.
        float phase = (float)fmod(gTime / 90.0, 1.0);
        int alpha = (int)(8 + 12 * (0.5f + 0.5f * sinf(phase * 2.0f * PI)));
        rect(0, 0, W, H, 0x202B58, alpha);
    } else {
        rect(0, 0, W, H, 0xE5A85D, 9);
    }
    if (!cfg.rain) return;
    const int count = cfg.reduced ? 16 : 42;
    for (int i = 0; i < count; ++i) {
        u32 h = hash3((u32)i, 41, 77);
        int x = pmod((int)(h % (u32)(W + 1)) - (int)(gTime * (100 + i % 5 * 12)) - (int)(cx * 0.04f), W);
        int y = pmod((int)((h >> 9) % (u32)(H + 1)) + (int)(gTime * (220 + i % 7 * 9)) - (int)(cy * 0.03f), H);
        line((float)x, (float)y, (float)x - 3, (float)y + 8, 0x9DBDFF, 85);
    }
}

static void drawWorldScene(float cx, float cy) {
    // Previous-run ghost: a simple translucent stick figure, with no collision.
    if (ghostReady && !lastGhostX.empty()) {
        size_t gi = std::min(lastGhostX.size() - 1, (size_t)std::max(0.0f, distM));
        int gx = (int)(lastGhostX[gi] - cx), gy = (int)(lastGhostY[gi] - cy);
        if (gx > -30 && gx < W + 30 && gy > -50 && gy < H + 50) {
            disc(gx, gy - 24, 7, 0x7FE0FF, 42);
            line((float)gx, (float)gy - 17, (float)gx, (float)gy + 8, 0x7FE0FF, 70);
            line((float)gx, (float)gy - 9, (float)gx - 10, (float)gy - 1, 0x7FE0FF, 70);
            line((float)gx, (float)gy - 9, (float)gx + 10, (float)gy - 1, 0x7FE0FF, 70);
            line((float)gx, (float)gy + 8, (float)gx - 8, (float)gy + 21, 0x7FE0FF, 70);
            line((float)gx, (float)gy + 8, (float)gx + 8, (float)gy + 21, 0x7FE0FF, 70);
        }
    }
    for (auto& b : bld) {
        if (b.x + b.w < cx - 160 || b.x > cx + W + 160) continue;
        int sx = (int)floorf(b.x - cx), sy = (int)floorf(b.roofY - cy);
        for (auto& o : b.obs) if (!o.solid) drawObs(o, (int)floorf(o.x - cx), sy, gTime);
        drawFacade(b, sx, sy);
        if (b.secret && !b.secretClaimed) {
            int ax = (int)(b.x + b.w * 0.5f - cx), ay = sy;
            rect(ax - 15, ay - 42, 30, 42, 0x7FE0FF, 35);
            rect(ax - 15, ay - 42, 4, 42, 0x7FE0FF, 190); rect(ax + 11, ay - 42, 4, 42, 0x7FE0FF, 190);
            rect(ax - 15, ay - 42, 30, 4, 0xDCEBFF, 210);
            text("SECRET", ax - 18, ay - 54, 1, 0x7FE0FF, 210);
        }
        drawMasts(b, sx, sy);
        for (auto& o : b.obs) if (o.solid) drawObs(o, (int)floorf(o.x - cx), sy, gTime);
    }
    for (auto& b : bld) drawCable(b, cx, cy);
    for (const auto& c : coinItems) if (!c.taken) {
        int x = (int)(c.x - cx), y = (int)(c.y - cy);
        if (x < -12 || x > W + 12 || y < -12 || y > H + 12) continue;
        int pulse = (int)(2.0f * sinf((float)gTime * 5.0f + c.x * 0.01f));
        disc(x, y, 7 + pulse, 0xFFE9A0, 45); disc(x, y, 4, 0xFFE9A0); rect(x - 1, y - 3, 2, 6, 0xB8862B);
    }
    // Each district gets a subtle palette wash without replacing the existing pixel-art assets.
    if (!cfg.reduced) {
        static const u32 districtTint[5] = {0x5269A8, 0x9A36A8, 0xB66A35, 0x3B8CA8, 0x64805B};
        rect(0, 0, W, H, districtTint[cityDistrict()], 9);
    }
}
static void drawParticles(float cx, float cy) {
    for (auto& p : parts) if (p.alive)
        rect((int)(p.x - cx), (int)(p.y - cy), p.sz, p.sz, p.c, (int)(255 * clampf(p.life / p.max, 0, 1)));
}
static void drawPlayerAndWeb(float cx, float cy) {
    Player& p = P;
    int sx = (int)floorf(p.x - cx), sy = (int)floorf(p.y - cy);
    // anchor hint (glowing target while airborne)
    if (haveTarget && !p.swinging && p.alive) {
        int ax = (int)(tgtX - cx), ay = (int)(tgtY - cy);
        int r = 5 + (int)(2 * sinf((float)gTime * 8));
        disc(ax, ay, r + 2, 0x7FE0FF, 40); rect(ax - 1, ay - 1, 3, 3, 0xFFFFFF);
    }
    double target = 0;
    bool spin = false;
    if (p.swinging) target = atan2((double)(p.ax - p.x), (double)(p.y - p.ay)) * 180.0 / PI;
    else if (!p.alive) { target = gTime * 500; spin = true; }
    else if (!p.onGround && ((p.releaseFlip && p.releaseT > 0) || p.flipT > 0)) {   // somersault, eased in and out
        float u = p.releaseFlip && p.releaseT > 0 ? 1.0f - p.releaseT / 0.5f : 1.0f - p.flipT / 0.55f;
        u = clampf(u, 0, 1);
        target = (u * u * (3 - 2 * u)) * 360.0 * p.flipDir;
        spin = true;
    }
    else if (!p.onGround && p.releaseT > 0) target = clampf(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / PI * 0.6f, -30, 42);  // dive follows the flight path
    else if (!p.onGround) target = clampf(p.vy * 0.01f, -8, 14);
    const int fr = pickFrame();
    int style = 0;
    if (fr == F_RUN) style = p.runStyle;
    else if (fr == F_JUMP) style = p.jumpStyle;
    else if (fr == F_FALL) style = p.fallStyle;
    else if (fr == F_LAND) style = p.landStyle;
    else if (fr == F_SHOOT) style = p.shootStyle;
    else if (fr == F_SLIDE) style = p.slideStyle;
    else if (fr == F_SWING || fr == F_ATTACH) style = p.swingStyle;
    const StkPose& pose = stkAdvance(gPlayerAnim, fr, p.wallCling ? (float)gTime * (swingHeld ? 1.5f : 0.35f) : gRunPhase, clampf(0.5f + (p.x - p.ax) / 80.0f, 0, 1), style, p.jit);
    double ang = stkAngle(gPlayerAnim, target, spin);
    float hfx, hfy;
    stickHand(pose, sx, sy + 26, ang, hfx, hfy);
    if (p.swinging) {
        int hx = (int)hfx, hy = (int)hfy, ax = (int)(p.ax - cx), ay = (int)(p.ay - cy);
        // Soft pixel glow at the anchor makes the web connection readable
        // against bright windows without adding a costly blur pass.
        int pulse = 3 + (int)(2.0f * (0.5f + 0.5f * sinf((float)gTime * 9.0f)));
        disc(ax, ay, pulse + 4, 0x7FE0FF, 24);
        disc(ax, ay, pulse, 0xDCEBFF, 75);
        line((float)hx, (float)hy + 1, (float)ax, (float)ay + 1, 0x05060F, 220);
        line((float)hx, (float)hy, (float)ax, (float)ay, 0xFFFFFF);
        line((float)hx + 1, (float)hy, (float)ax + 1, (float)ay, 0xC8D8FF, 150);
    } else if (p.webFlying && p.alive) {
        int wx = (int)(p.webX - cx), wy = (int)(p.webY - cy);
        line(hfx, hfy + 1, wx, wy + 1, 0x05060F, 220); line(hfx, hfy, wx, wy, 0xFFFFFF);
        disc(wx, wy, 3, 0xDCEBFF); rect(wx - 1, wy - 1, 3, 3, 0xFFFFFF);
    } else if (p.shootT > 0 && p.alive) {
        float u = 1 - p.shootT / 0.14f;
        line(hfx, hfy, hfx + 70 * u, hfy - 70 * u, 0xFFFFFF, 200);
    }
    if (cfg.swingTrails && !cfg.reduced && p.swinging && p.alive) {
        float speed = clampf(hypotf(p.vx, p.vy) / 900.0f, 0.25f, 1.0f);
        for (int i = 1; i <= 5; ++i) {
            float q = (float)i / 6.0f;
            int tx = sx - (int)((18.0f + 30.0f * speed) * q);
            int ty = sy + (int)(sinf((float)gTime * 8.0f + i) * 8.0f * q);
            line((float)tx, (float)ty, (float)(tx - 9 - (int)(speed * 8)), (float)(ty + 3),
                 i % 2 ? 0xE8262F : 0xBFD8FF, (int)(95.0f * (1.0f - q)));
        }
    }
    if (droneActive && P.alive) {
        int dx = (int)(droneX - cx), dy = (int)(droneY - cy);
        if (dx > -45 && dx < W + 45 && dy > -45 && dy < H + 45) {
            disc(dx, dy, 15, 0xE8262F, cfg.reduced ? 30 : 55);
            rect(dx - 18, dy - 4, 36, 8, 0x202638); rect(dx - 12, dy - 7, 24, 3, 0x59657A);
            rect(dx - 10, dy - 2, 20, 4, 0xE8262F); rect(dx - 4, dy - 1, 8, 2, 0xFFFFFF);
            line(dx - 16, dy + 6, dx - 23, dy + 12, 0x8A93B0); line(dx + 16, dy + 6, dx + 23, dy + 12, 0x8A93B0);
        }
    }
    drawHalo(sx, sy - 6);
    drawStickman(pose, sx, sy + 26, ang);
    if (p.vx > 420 && p.alive)  // speed lines
        for (int i = 0; i < 4; i++) rect(sx - 40 - (int)hash3(i, (u32)(gTime * 20), 1) % 50, sy - 30 + i * 14, 20 + (int)hash3(i, 4, 4) % 20, 1, 0xFFFFFF, 70);
}

// ---------------------------------------------------------------- UI drawing
// Look: clean, high-contrast, white-on-ink with a single red accent, slanted highlight bars and thin rules
// (inspired by the menus of Marvel's Spider-Man; the spider emblem below is original, drawn in code).
static const u32 UI_INK = 0x070A14, UI_WHITE = 0xF4F7FF, UI_DIM = 0x8C96B8, UI_RED = 0xE8262F, UI_RED_D = 0x6A0E16;

static void hline(int x, int y, int w, u32 c, int a) { rect(x, y, w, 1, c, a); }
static void slantBar(int x, int y, int w, int h, int shear, u32 c, int a) {   // parallelogram leaning right
    for (int r = 0; r < h; r++) {
        int off = (h - 1 - r) * shear / std::max(1, h - 1);
        rect(x + off, y + r, w - shear, 1, c, a);
    }
}
static void ringDraw(int cx, int cy, int r, int th, u32 c, int a) {
    int ri = r - th;
    for (int dy = -r; dy <= r; dy++) {
        int xo = (int)sqrtf((float)(r * r - dy * dy));
        if (ri > 0 && std::abs(dy) < ri) {
            int xi = (int)sqrtf((float)(ri * ri - dy * dy));
            rect(cx - xo, cy + dy, xo - xi, 1, c, a);
            rect(cx + xi + 1, cy + dy, xo - xi, 1, c, a);
        } else rect(cx - xo, cy + dy, xo * 2 + 1, 1, c, a);
    }
}
static void thickLine(float x0, float y0, float x1, float y1, int r, u32 c, int a = 255) {
    float dx = x1 - x0, dy = y1 - y0;
    int n = std::max(1, (int)hypotf(dx, dy));
    for (int i = 0; i <= n; i++) { float t = (float)i / n; disc((int)lroundf(x0 + dx * t), (int)lroundf(y0 + dy * t), r, c, a); }
}
static void ellipseFill(int cx, int cy, int rx, int ry, u32 c) {
    ry = std::max(1, ry);
    for (int dy = -ry; dy <= ry; dy++) {
        int dx = (int)(rx * sqrtf(std::max(0.0f, 1.0f - (float)(dy * dy) / (float)(ry * ry))));
        rect(cx - dx, cy + dy, dx * 2 + 1, 1, c);
    }
}
// original spider emblem: slim body, long hooked legs.  s = half-height in pixels.
static void drawSpider(int cx, int cy, float s, u32 c) {
    static const float L[5][4][2] = {
        {{0.06f, -0.20f}, {0.26f, -0.60f}, {0.46f, -0.86f}, {0.80f, -1.00f}},
        {{0.09f, -0.10f}, {0.46f, -0.38f}, {0.82f, -0.44f}, {1.00f, -0.72f}},
        {{0.10f, 0.00f}, {0.56f, -0.04f}, {0.90f, 0.12f}, {1.04f, 0.42f}},
        {{0.11f, 0.14f}, {0.48f, 0.38f}, {0.74f, 0.68f}, {0.80f, 1.00f}},
        {{0.09f, 0.30f}, {0.26f, 0.68f}, {0.32f, 0.94f}, {0.26f, 1.14f}}};
    int r = std::max(0, (int)lroundf(s * 0.07f));
    for (int side = -1; side <= 1; side += 2)
        for (int i = 0; i < 5; i++)
            for (int k = 0; k < 3; k++)
                thickLine(cx + side * L[i][k][0] * s, cy + L[i][k][1] * s * 0.9f, cx + side * L[i][k + 1][0] * s, cy + L[i][k + 1][1] * s * 0.9f, r, c);
    ellipseFill(cx, cy + (int)(0.34f * s), std::max(1, (int)(0.17f * s)), (int)(0.38f * s), c);
    ellipseFill(cx, cy - (int)(0.10f * s), std::max(1, (int)(0.10f * s)), (int)(0.15f * s), c);
    ellipseFill(cx, cy - (int)(0.30f * s), std::max(1, (int)(0.06f * s)), (int)(0.07f * s), c);
}
// spider web: 8 spokes and 3 octagonal rings
static void drawWebIcon(int cx, int cy, float r, u32 c, int a = 255) {
    for (int i = 0; i < 8; i++) { float an = i * PI / 4; line((float)cx, (float)cy, cx + cosf(an) * r, cy + sinf(an) * r, c, a); }
    for (int k = 1; k <= 3; k++) {
        float rr = r * k / 3.0f;
        for (int i = 0; i < 8; i++) {
            float a0 = i * PI / 4, a1 = (i + 1) * PI / 4;
            line(cx + cosf(a0) * rr, cy + sinf(a0) * rr, cx + cosf(a1) * rr, cy + sinf(a1) * rr, c, a);
        }
    }
}
static int textWSp(const char* s, int sc, int gap) { int n = (int)strlen(s); return n <= 0 ? 0 : n * (6 * sc + gap) - gap - sc; }
static void textSp(const char* s, int x, int y, int sc, u32 c, int gap, int a = 255) {
    char b[2] = {0, 0};
    for (; *s; ++s) { b[0] = *s; text(b, x, y, sc, c, a); x += 6 * sc + gap; }
}
static void textSpC(const char* s, int cx, int y, int sc, u32 c, int gap, int a = 255) { textSp(s, cx - textWSp(s, sc, gap) / 2, y, sc, c, gap, a); }

static float easeOut(float t) { t = clampf(t, 0, 1); return 1 - (1 - t) * (1 - t); }

static void drawButton(const Btn& b, int idx, bool foc, bool pr) {
    float e = easeOut((uiAge - idx * 0.05f) / 0.22f);       // staggered slide-in when a screen opens
    if (e <= 0) return;
    int a = (int)(255 * e), ox = (int)((1 - e) * -22);
    bool hot = foc || pr;
    if (b.style & 16) { hot = false; a = a * 120 / 255; }   // disabled
    int x = b.x + ox;
    if (b.kind == 4) {                                      // round web-icon button with a caption underneath
        int cx = x + b.w / 2, cy = b.y + b.h / 2, r = b.w / 2;
        disc(cx, cy, r, hot ? UI_WHITE : UI_INK, hot ? 245 * a / 255 : 170 * a / 255);
        ringDraw(cx, cy, r, 2, hot ? UI_RED : UI_WHITE, a);
        drawWebIcon(cx, cy, (float)(r - 6), hot ? UI_INK : UI_WHITE, a);
        text(b.label, cx - textW(b.label, 1) / 2, b.y + b.h + 4, 1, hot ? UI_WHITE : UI_DIM, a);
        return;
    }
    if (b.kind == 1) {                                      // slider
        char v[16]; snprintf(v, sizeof v, "%d%%", (int)lroundf(*b.val * 100));
        text(b.label, x, b.y + 3, 1, hot ? UI_WHITE : UI_DIM, a);
        text(v, x + b.w - textW(v, 1), b.y + 3, 1, UI_WHITE, a);
        int ty = b.y + 22, fw = (int)((*b.val - b.vmin) / (b.vmax - b.vmin) * b.w);
        rect(x, ty + 1, b.w, 2, UI_WHITE, 55 * a / 255);
        rect(x, ty, fw, 4, UI_WHITE, a);
        slantBar(x + fw - 4, ty - 5, 8, 14, 3, hot ? UI_WHITE : UI_RED, a);
        hline(x, b.y + b.h - 1, b.w, UI_WHITE, 26 * a / 255);
        if (hot) rect(x - 7, b.y + 4, 2, b.h - 10, UI_RED, a);
        return;
    }
    if (b.kind == 2) {                                      // toggle
        int sc = fitScale(b.label, b.w - 56, 2);
        text(b.label, x, b.y + (b.h - 7 * sc) / 2, sc, hot ? UI_WHITE : 0xC9D1EE, a);
        bool on = *b.flag;
        int tx = x + b.w - 34, ty = b.y + b.h / 2 - 7;
        rect(tx, ty, 32, 14, on ? UI_RED : UI_WHITE, on ? a : 45 * a / 255);
        rect(tx + (on ? 19 : 3), ty + 3, 10, 8, on ? UI_WHITE : UI_DIM, a);
        hline(x, b.y + b.h - 1, b.w, UI_WHITE, 26 * a / 255);
        if (hot) rect(x - 7, b.y + 4, 2, b.h - 10, UI_RED, a);
        return;
    }
    if (b.kind == 3) {                                      // key binding box
        bool cap = gRebind == b.act && gRebind >= 0;
        text(b.label, x, b.y + 2, 1, hot || cap ? UI_WHITE : UI_DIM, a);
        int by = b.y + 14, bh2 = b.h - 16;
        if (cap) rect(x, by, b.w, bh2, UI_RED, a);
        else rect(x, by, b.w, bh2, UI_WHITE, (hot ? 38 : 14) * a / 255);
        int oa = (cap ? 255 : (hot ? 230 : 90)) * a / 255;
        hline(x, by, b.w, UI_WHITE, oa); hline(x, by + bh2 - 1, b.w, UI_WHITE, oa);
        rect(x, by, 1, bh2, UI_WHITE, oa); rect(x + b.w - 1, by, 1, bh2, UI_WHITE, oa);
        char k[24];
        if (cap) snprintf(k, sizeof k, "%s", (((int)(gTime * 3)) & 1) ? "PRESS A KEY" : "PRESS A KEY.");
        else keyLabel(ctl.key[b.act], k, sizeof k);
        int sc = fitScale(k, b.w - 12, 2);
        text(k, x + (b.w - textW(k, sc)) / 2, by + (bh2 - 7 * sc) / 2, sc, UI_WHITE, a);
        return;
    }
    // kind 0: list item / tab / outlined cell button
    int w = b.w;
    if (b.style & 8) {                                      // tab
        bool act = b.id == (ctlTab == 0 ? B_TAB_KEYS : B_TAB_TOUCH);
        if (act) slantBar(x, b.y, w, b.h, b.h / 4, UI_WHITE, a);
        else if (hot) slantBar(x, b.y, w, b.h, b.h / 4, UI_WHITE, 60 * a / 255);
        int sc = fitScale(b.label, w - 24, 2);
        text(b.label, x + (w - textW(b.label, sc)) / 2 + b.h / 8, b.y + (b.h - 7 * sc) / 2, sc, act ? UI_INK : UI_WHITE, a);
        return;
    }
    if (b.style & 4) {                                      // outlined cell button
        rect(x, b.y, w, b.h, UI_WHITE, hot ? a : 0);
        int oa = (hot ? 255 : 100) * a / 255;
        hline(x, b.y, w, UI_WHITE, oa); hline(x, b.y + b.h - 1, w, UI_WHITE, oa);
        rect(x, b.y, 1, b.h, UI_WHITE, oa); rect(x + w - 1, b.y, 1, b.h, UI_WHITE, oa);
        int sc = fitScale(b.label, w - 16, 2);
        text(b.label, x + (w - textW(b.label, sc)) / 2, b.y + (b.h - 7 * sc) / 2, sc, hot ? UI_INK : UI_WHITE, a);
        return;
    }
    int shear = b.h / 4;
    if (hot) slantBar(x, b.y, w, b.h, shear, UI_WHITE, 245 * a / 255);
    else hline(x, b.y + b.h - 1, w, UI_WHITE, 30 * a / 255);
    int sc = fitScale(b.label, w - 40, (b.style & 2) ? 3 : 2);
    int tw = textW(b.label, sc), ty = b.y + (b.h - 7 * sc) / 2;
    int tx = (b.style & 1) ? x + (w - tw) / 2 : x + 16 + (hot ? 4 : 0);
    if (!hot && (b.style & 2)) rect(x, b.y + 4, 3, b.h - 8, UI_RED, a);       // accent tick on the main action
    text(b.label, tx, ty, sc, hot ? UI_INK : UI_WHITE, a);
    if (hot) {                                              // red chevron on the highlighted row
        int o = (int)(1 + 1.5f * sinf((float)gTime * 7));
        text(">", x + w - shear - 18 + o, b.y + (b.h - 14) / 2, 2, UI_RED);
    }
}
static void drawButtons() {
    for (size_t i = 0; i < btns.size(); i++) {
        bool pr = false;
        for (auto& t : tch) if (t.on && t.btn == (int)i && (t.role == R_UI || t.role == R_SLIDER)) pr = true;
        drawButton(btns[i], (int)i, gFocus == (int)i, pr);
    }
}
// one on-screen touch button (also used by the layout editor).  i: 0 swing, 1 jump, 2 slide
static void drawCtlButton(int i, bool pressed, bool editing) {
    float fx, fy, fr; ctlPos(i, fx, fy, fr);
    int cx = (int)fx, cy = (int)fy, r = (int)fr;
    float al = ctl.alpha, k = ctl.scale;
    int fillA = (int)(150 * al) + 20, ringA = (int)(255 * clampf(al + 0.2f, 0, 1));
    disc(cx, cy, r, pressed ? UI_WHITE : UI_INK, pressed ? 230 : fillA);
    ringDraw(cx, cy, r, 2, pressed ? UI_RED : UI_WHITE, pressed ? 255 : ringA);
    if (editing) ringDraw(cx, cy, r + 5, 1, UI_WHITE, 140);
    u32 ic = pressed ? UI_INK : UI_WHITE;
    if (i == 0) {
        drawSpider(cx, cy, 17 * k, ic);
    } else if (i == 1) {
        for (int j = 0; j < 2; j++) {
            float oy = (-3 + j * 8) * k;
            thickLine(cx - 9 * k, cy + oy + 6 * k, cx, cy + oy - 3 * k, 1, ic, 255);
            thickLine(cx, cy + oy - 3 * k, cx + 9 * k, cy + oy + 6 * k, 1, ic, 255);
        }
    } else {
        thickLine(cx - 10 * k, cy - 5 * k, cx + 8 * k, cy - 5 * k, 1, ic, 255);
        thickLine(cx + 3 * k, cy - 10 * k, cx + 9 * k, cy - 5 * k, 1, ic, 255);
        thickLine(cx + 3 * k, cy, cx + 9 * k, cy - 5 * k, 1, ic, 255);
        rect(cx - (int)(10 * k), cy, (int)(8 * k), 1, ic, 128);
    }
}
static void drawRotateScreen() {
    rect(0, 0, W, H, 0x070A1E);
    int cx = W / 2, cy = H / 2 - 30;
    float a = sinf((float)gTime * 2.0f);
    rect(cx - 12, cy - 20, 24, 40, 0xE8ECFF); rect(cx - 10, cy - 17, 20, 30, 0x0E1432); rect(cx - 3, cy + 15, 6, 2, 0xE8ECFF);
    int ax = cx + 36 + (int)(a * 6);
    text(">", ax, cy - 8, 3, UI_RED);
    textC("ROTATE YOUR", cx, cy + 50, fitScale("ROTATE YOUR", W - 20, 3), 0xFFFFFF);
    textC("DEVICE", cx, cy + 50 + 26, fitScale("DEVICE", W - 20, 3), 0xFFFFFF);
    textC("TO LANDSCAPE", cx, cy + 50 + 52, fitScale("TO LANDSCAPE", W - 20, 2), UI_RED);
}
// big centred logo for the press-to-start screen
static void drawLogoBig() {
    int sc = (int)clampf(W / 120.0f, 3, 6);
    float s = clampf(H * 0.15f, 26, 54);
    int cy = (int)(H * 0.30f);
    drawHalo(W / 2, cy);
    drawSpider(W / 2 + 2, cy + 3, s, UI_RED_D);          // soft red drop shadow
    drawSpider(W / 2, cy, s, UI_WHITE);
    int ty = cy + (int)s + 16;
    textSpC("STICKMAN", W / 2 + 2, ty + 2, sc, UI_RED_D, sc);
    textSpC("STICKMAN", W / 2, ty, sc, UI_WHITE, sc);
    int y2 = ty + 7 * sc + 10, w2 = textWSp("STICKMAN", sc, sc);
    slantBar(W / 2 - w2 / 2, y2, w2, 3, 3, UI_RED, 255);
    textSpC("PIXEL CITY", W / 2, y2 + 10, 2, 0xBFD0FF, 8);
}
// compact logo above the main menu list
static void drawLogoSmall(float e) {
    int x = (int)safeL + 8, y = 18;
    int a = (int)(255 * e);
    drawSpider(x + 17, y + 20, 16, UI_WHITE);
    int tx = x + 44;
    textSp("STICKMAN", tx + 1, y + 3, 3, UI_RED_D, 3, a);
    textSp("STICKMAN", tx, y + 2, 3, UI_WHITE, 3, a);
    slantBar(tx, y + 27, 54, 3, 3, UI_RED, a);
    textSp("PIXEL CITY", tx, y + 35, 1, 0xBFD0FF, 5, a);
}
static void drawMenuScene(double dt) {
    menuT += (float)dt;
    drawBackdrop(menuT * 16.0f, -200, gTime);
    drawCityTraffic(0, 0);
    // foreground rooftop ledge slab
    int roofY = (int)(H * 0.76f), sx0 = (int)(W * 0.50f), sw = W - sx0 + 20;
    Building mb; mb.x = (float)sx0; mb.w = (float)(sw / 16 * 16); mb.roofY = 0; mb.style = 1; mb.seed = 99;
    drawFacade(mb, sx0, roofY);
    // radio mast with blinking light
    int mx = (int)(W * 0.90f), mtop = (int)(H * 0.20f);
    rect(mx, mtop, 3, roofY - mtop, 0x2A2F3F); rect(mx - 5, mtop + 18, 13, 1, 0x2A2F3F);
    if (((int)(gTime * 1.5)) & 1) { disc(mx + 1, mtop - 2, 4, 0xFF2A2A, 70); rect(mx, mtop - 3, 3, 3, 0xFF4040); }
    // stickman standing on the ledge, rope to the mast
    int spx = (int)(W * 0.68f);
    float t = fmodf((float)gTime, 6.4f);
    int frame = F_IDLE;
    double ang = 0; int px = spx, py = roofY, fy = roofY;
    // A clear Spider-Man-style loop: crouch-launch, shoot a web, pendulum swing,
    // release into a flip, then land and immediately prepare for the next swing.
    if (t < 0.55f) {
        frame = F_JUMP; float u = t / 0.55f;
        py = fy - (int)(18.0f + 115.0f * sinf(u * PI * 0.5f));
        px = spx - (int)(18.0f * u);
    } else if (t < 3.65f) {
        float u = (t - 0.55f) / 3.10f;
        frame = u < 0.10f ? F_SHOOT : F_SWING;
        float arc = sinf(u * PI);
        px = (int)lerpf((float)spx - 18.0f, (float)(W + 72), easeOut(u));
        py = fy - (int)(75.0f + 205.0f * arc);
        ang = -52.0 * cosf(u * PI * 0.88f);
    } else if (t < 4.55f) {
        float u = (t - 3.65f) / 0.90f;
        frame = F_FLIP; px = W + 72 + (int)(u * 42.0f);
        py = fy - (int)(95.0f * (1.0f - u) + 24.0f * sinf(u * PI));
        ang = 360.0 * u;
    } else if (t < 5.25f) {
        float u = (t - 4.55f) / 0.70f;
        frame = F_FALL; px = (int)lerpf((float)(W + 114), (float)spx + 14.0f, u);
        py = fy - (int)(55.0f * (1.0f - u)); ang = 20.0 * (1.0f - u);
    } else {
        float u = (t - 5.25f) / 1.15f;
        frame = u < 0.22f ? F_LAND : F_IDLE;
        px = (int)lerpf((float)spx + 14.0f, (float)spx, easeOut(u));
        py = fy - (int)(12.0f * sinf(std::min(1.0f, u / 0.22f) * PI) * (u < 0.22f ? 1.0f : 0.0f));
        ang = 0;
    }
    const StkPose& pose = stkAdvance(gMenuAnim, frame, (float)gTime * 0.83f, 0.5f);
    float hx, hy;
    stickHand(pose, px, py, ang, hx, hy);
    int handX = (int)hx, handY = (int)hy;
    float webLen = (t >= 0.9f && t < 1.25f) ? (t - 0.9f) / 0.35f : (t >= 1.25f && t < 3.5f ? 1.0f : 0.0f);
    float wx = lerpf((float)handX, (float)mx + 1, webLen), wy = lerpf((float)handY, (float)mtop, webLen);
    if (t >= 0.9f && t < 3.5f) {
        float px0 = (float)handX, py0 = (float)handY;
        for (int i = 1; i <= 16; i++) {
            float u = i / 16.0f, qx = lerpf((float)handX, wx, u), qy = lerpf((float)handY, wy, u);
            line(px0, py0 + 1, qx, qy + 1, 0x05060F, 200); line(px0, py0, qx, qy, 0xFFFFFF);
            px0 = qx; py0 = qy;
        }
    }
    if (cfg.swingTrails && !cfg.reduced && t >= 1.15f && t < 3.65f) {
        for (int i = 1; i <= 4; ++i) {
            float q = (float)i / 5.0f;
            int tx = px - (int)(q * (22.0f + 24.0f * sinf(t * 2.1f)));
            int ty = py + (int)(q * (8.0f + 15.0f * cosf(t * 2.0f)));
            thickLine((float)tx, (float)ty, (float)(tx - 12), (float)(ty + 4), 0, i % 2 ? UI_RED : 0xBFD8FF, 100 - i * 15);
        }
    }
    drawHalo(px, py - 26);
    drawStickman(pose, px, py, ang);
}

static void drawHUD() {
    char b[64];
    int x = (int)safeL, y = (int)safeT;
    text("SCORE", x, y, 1, UI_DIM);
    snprintf(b, sizeof b, "%d", scoreVal());
    textShadow(b, x, y + 10, 3, UI_WHITE);
    snprintf(b, sizeof b, "%dM", (int)distM);
    textShadow(b, x, y + 35, 2, 0xBFD8FF);
    int rx = W - (int)safeR;
    snprintf(b, sizeof b, "BEST %dM", (int)std::max(cfg.best, distM));
    text(b, rx - textW(b, 1), y, 1, UI_DIM);
    { char cb[40]; fmtNum(gProg.coins, cb, sizeof cb); char t[48]; snprintf(t, sizeof t, "COINS %s", cb);
      textShadow(t, rx - textW(t, 1), y + 12, 1, 0xFFE9A0); }
    // pause button: a slim ring with two bars
    int pcx = pauseBtn.x + 22, pcy = pauseBtn.y + 20;
    disc(pcx, pcy, 15, UI_INK, 110);
    ringDraw(pcx, pcy, 15, 1, UI_WHITE, 150);
    rect(pcx - 5, pcy - 6, 3, 12, UI_WHITE); rect(pcx + 2, pcy - 6, 3, 12, UI_WHITE);
    if (chainShowT > 0) {
        snprintf(b, sizeof b, "SWING CHAIN +%d", 10 * std::max(2, P.chain));
        textSpC(b, W / 2, (int)(H * 0.22f), 2, 0x7FE0FF, 2);
    }
    if (comboCount > 0) { snprintf(b, sizeof b, "FLOW X%.2f", 1.0f + std::min(2.0f, comboCount * 0.08f)); textSpC(b, W / 2, (int)(H * 0.14f), 1, 0xFFE9A0, 2); }
    if (gState == PLAYING) { const char* dn = cityDistrictName(cityDistrict()); text(dn, W / 2 - textW(dn, 1) / 2, (int)(H * 0.055f), 1, 0xAAB4D8); }
    if (P.swinging && P.alive) { float tension = clampf(hypotf(P.vx, P.vy) / 1450.0f, 0, 1); int tw = 78, tx = W / 2 - tw / 2, ty = (int)(H * 0.19f); textSpC("WEB TENSION", W / 2, ty, 1, 0xBFD8FF, 1); rect(tx, ty + 9, tw, 4, 0x202943); rect(tx, ty + 9, (int)(tw * tension), 4, tension > 0.88f ? 0xFFE9A0 : 0x7FE0FF); }
    if (eventToastT > 0 && !eventToast.empty()) textSpC(eventToast.c_str(), W / 2, (int)(H * 0.26f), 2, perfectT > 0 ? 0xFFFFFF : 0x7FE0FF, 2);
    if (perfectT > 0) { int a = (int)(150 * clampf(perfectT / 0.75f, 0, 1)); rect(0, 0, W, 2, 0xBFD8FF, a); rect(0, H - 2, W, 2, 0xBFD8FF, a); }
    if (missionToastT > 0) textSpC(missionToast.c_str(), W / 2, (int)(H * 0.31f), 1, 0xFFE9A0, 2);
    if (gState == PLAYING && !cfg.reduced) {
        snprintf(b, sizeof b, "DAILY  %s  %s  %s", challengeDone[0] ? "500M OK" : "500M", challengeDone[1] ? "20 COINS OK" : "20 COINS", challengeDone[2] ? "3 PERFECT OK" : "3 PERFECT");
        textSpC(b, W / 2, H - 12, 1, 0xC9D1EE, 1);
    }
    if (gState == PLAYING && P.alive) {
        int aw = 92, ax = W / 2 - aw / 2, ay = (int)(H * 0.255f);
        if (adrenalineT > 0) {
            textSpC("ADRENALINE", W / 2, ay - 2, 1, 0xFF7A8D, 2);
            rect(ax - 2, ay + 8, aw + 4, 5, 0x202943);
            rect(ax, ay + 9, (int)(aw * clampf(adrenalineT / 4.0f, 0, 1)), 3, 0xFF5C72);
        } else {
            textSpC("ADRENALINE", W / 2, ay - 2, 1, 0xC9D1EE, 1);
            rect(ax - 2, ay + 8, aw + 4, 5, 0x202943);
            rect(ax, ay + 9, (int)(aw * clampf(adrenaline / 100.0f, 0, 1)), 3, 0xFF5C72);
        }
        if (challengeT > 0 && challengeKind == 2) {
            char ch[40]; snprintf(ch, sizeof ch, "SWING %d/5 SEC", (int)challengeSwingTime);
            textSpC(ch, W / 2, ay + 19, 1, 0x7FE0FF, 1);
        }
    }
    if (P.boostT > 0 && P.alive) {
        int bw = 90, by = (int)(H * 0.30f);
        textSpC("SWING BOOST", W / 2, by, 1, 0xFFE9A0, 3);
        rect(W / 2 - bw / 2, by + 11, bw, 1, UI_WHITE, 50);
        rect(W / 2 - bw / 2, by + 10, (int)(bw * clampf(P.boostT / P.boostDur, 0, 1)), 3, 0xFFE9A0);
    }
    for (int i = 0; i < 3; i++) {
        bool pr = false;
        int role = i == 0 ? R_SWING : (i == 1 ? R_JUMP : R_SLIDE);
        for (auto& t : tch) if (t.on && t.role == role) pr = true;
        if (i == 0 && swingHeld) pr = true;                 // keyboard presses light the on-screen buttons too
        drawCtlButton(i, pr, false);
    }
}
static void dim(int a) { rect(0, 0, W, H, 0x03040C, a); }
static void shadeLeft(int w, int aMax) {
    for (int x = 0; x < w; x += 2) rect(x, 0, 2, H, UI_INK, (int)(aMax * (1.0f - (float)x / w)));
}
static void shadeEdges(int h, int aMax) {
    for (int y = 0; y < h; y += 2) {
        int a = (int)(aMax * (1.0f - (float)y / h));
        rect(0, y, W, 2, UI_INK, a); rect(0, H - 2 - y, W, 2, UI_INK, a);
    }
}
// a clean dark sheet with a red slash and thin rules, used by every sub-screen
static void sheet(int px, int pw, const char* title) {
    float e = easeOut(uiAge / 0.25f);
    rect(px, 10, pw, H - 20, UI_INK, (int)(228 * e));
    hline(px, 10, pw, UI_WHITE, (int)(150 * e));
    slantBar(px + 20, 10, 46, 4, 4, UI_RED, 255);
    textSp(title, px + 20, 24, 3, UI_WHITE, 3, (int)(255 * e));
    hline(px + 20, 54, pw - 40, UI_WHITE, (int)(60 * e));
}
static void drawLines(const char* const* ls, int n, int cx, int y0, int maxW) {
    for (int i = 0; i < n; i++) {
        float e = easeOut((uiAge - 0.1f - i * 0.05f) / 0.22f);
        int sc = fitScale(ls[i], maxW, 2);
        int tw = textW(ls[i], sc);
        text(ls[i], cx - tw / 2, y0 + i * 24 + (int)((1 - e) * 8), sc, 0xDDE6FF, (int)(255 * e));
    }
}

static void drawStatLine(const char* label, const char* val, int cx, int y, u32 vc) {
    textSpC(label, cx, y, 1, UI_DIM, 3);
    int sc = 3; while (sc > 1 && textWSp(val, sc, 2) > 140) sc--;
    textSpC(val, cx, y + 11 + (3 - sc) * 3, sc, vc, 2);
}
static void render(double dt) {
    SDL_SetRenderTarget(gRen, gTarget);
    SDL_SetRenderDrawBlendMode(gRen, SDL_BLENDMODE_BLEND);
    if (portrait) drawRotateScreen();
    else {
        static State prevS = (State)-1;
        if (gState != prevS) { uiAge = 0; gFocus = -1; gRebind = -1; prevS = gState; }
        uiAge += (float)dt; noteT -= (float)dt; if (flashT > 0) flashT -= (float)dt;
        bool world = gState == PLAYING || gState == PAUSED || gState == GAME_OVER || (isSub(gState) && (navRoot == PAUSED || navRoot == GAME_OVER));
        buildUI();
        if (gFocus >= (int)btns.size()) gFocus = -1;
        if (world) {
            float shx = 0, shy = 0;
            if (shakeT > 0 && cfg.shake) { shx = ((int)hash3((u32)(gTime * 90), 1, 2) % 5) - 2.0f; shy = ((int)hash3((u32)(gTime * 90), 3, 4) % 5) - 2.0f; }
            float cx = floorf(camX + shx), cy = floorf(camY + shy);
            drawBackdrop(cx, cy, gTime);
            drawCityTraffic(cx, cy);
            drawWorldScene(cx, cy);
            drawWeatherAndTint(cx, cy);
            drawParticles(cx, cy);
            drawPlayerAndWeb(cx, cy);
            rect(0, (int)(H * 0.86f), W, H, 0x2A3060, 30);
            if (gState == PLAYING) drawHUD();
        } else { drawMenuScene(dt); drawWeatherAndTint(0, 0); }

        int pw = std::min(W - (int)(safeL + safeR), 560), px = (W - pw) / 2;
        switch (gState) {
            case TITLE: {
                shadeEdges(70, 200); dim(115);
                drawLogoBig();
                int by0 = (int)(H * 0.80f) - 12;
                for (int i = 0; i < 28; i++) { int a = (int)(150 * sinf(PI * (i + 0.5f) / 28.0f)); rect(0, by0 + i, W, 1, UI_INK, a); }   // soft dark band behind the prompt
                if (uiAge > 0.9f) {
                    float pulse = 0.5f + 0.5f * sinf((float)gTime * 3.2f);
                    int a = (int)(90 + 165 * pulse), y = (int)(H * 0.80f);
                    textSpC("PRESS TO START", W / 2, y, 2, UI_WHITE, 4, a);
                    int half = textWSp("PRESS TO START", 2, 4) / 2 + 14;
                    hline(W / 2 - half - 70, y + 6, 70, UI_WHITE, a / 2); hline(W / 2 + half, y + 6, 70, UI_WHITE, a / 2);
                }
                textSpC("FAN-MADE TRIBUTE. NOT AFFILIATED.", W / 2, H - (int)safeB - 8, 1, UI_DIM, 2, 160);
                if (cfg.best > 0) { char b[40]; snprintf(b, sizeof b, "BEST %dM", (int)cfg.best); text(b, (int)safeL + 4, (int)safeT + 2, 1, UI_DIM); }
                if (uiAge < 0.7f) rect(0, 0, W, H, 0x000000, (int)(255 * (1 - uiAge / 0.7f)));
            } break;
            case MAIN_MENU:
                shadeLeft((int)(W * 0.62f), 235);
                drawLogoSmall(easeOut(uiAge / 0.3f));
                drawButtons();
                if (cfg.best > 0) { char b[40]; snprintf(b, sizeof b, "BEST %dM", (int)cfg.best); text(b, (int)safeL + 10, H - (int)safeB - 12, 1, UI_DIM); }
                { char cb[32], t[48]; fmtNum(gProg.coins, cb, sizeof cb); snprintf(t, sizeof t, "COINS %s", cb);
                  textShadow(t, W - (int)safeR - 8 - textW(t, 1), (int)safeT + 10 + 46 + 16, 1, 0xFFE9A0); }
                break;
            case SKILLS: {
                dim(150); sheet(px, pw, "SKILL UPGRADES");
                SkillLay L = skillLay(px, pw);
                float e = easeOut((uiAge - 0.05f) / 0.25f);
                int A = (int)(255 * e);
                // coins, top right of the sheet
                { char cb[32], t[48]; fmtNum(gProg.coins, cb, sizeof cb); snprintf(t, sizeof t, "COINS %s", cb);
                  int sc = fitScale(t, pw - 40 - 300, 2), tw = textW(t, sc), tx = px + pw - 20 - tw;
                  disc(tx - 13, 34, 6, 0xFFE9A0, A); ringDraw(tx - 13, 34, 6, 1, 0xB8862B, A);
                  text(t, tx, 34 - 7 * sc / 2, sc, 0xFFE9A0, A); }
                // spider web diagram on the left (nodes: JUMP top, RUN left, SWING right, ZIP bottom)
                {
                    int cx = L.wcx, cy = L.wcy, r = L.wr;
                    for (int k = 1; k <= 3; k++) {
                        float rr = r * k / 3.0f; int al = (k == 3 ? 170 : 90) * A / 255;
                        line(cx, cy - rr, cx + rr, cy, UI_WHITE, al); line(cx + rr, cy, cx, cy + rr, UI_WHITE, al);
                        line(cx, cy + rr, cx - rr, cy, UI_WHITE, al); line(cx - rr, cy, cx, cy - rr, UI_WHITE, al);
                    }
                    line(cx, cy - r, cx, cy + r, UI_WHITE, 120 * A / 255); line(cx - r, cy, cx + r, cy, UI_WHITE, 120 * A / 255);
                    line(cx - r / 2.0f, cy - r / 2.0f, cx + r / 2.0f, cy + r / 2.0f, UI_WHITE, 50 * A / 255);
                    line(cx + r / 2.0f, cy - r / 2.0f, cx - r / 2.0f, cy + r / 2.0f, UI_WHITE, 50 * A / 255);
                    const float nx[4] = {0, -0.62f, 0.62f, 0}, ny[4] = {-0.62f, 0, 0, 0.62f};
                    const char* nl[4] = {"J", "R", "S", "Z"};
                    for (int i = 0; i < 4; i++) {
                        int ncx = cx + (int)(nx[i] * r), ncy = cy + (int)(ny[i] * r);
                        int sk = SKILL_ROW[i];
                        float fill = sk >= 0 ? gProg.level[sk] / (float)prog::MAX_LEVEL : 0.0f;
                        disc(ncx, ncy, 10, UI_INK, 235 * A / 255);
                        if (fill > 0) disc(ncx, ncy, 2 + (int)(7 * fill), UI_RED, A);
                        ringDraw(ncx, ncy, 10, 1, sk >= 0 ? UI_WHITE : UI_DIM, (sk >= 0 ? 230 : 120) * A / 255);
                        text(nl[i], ncx - 2, ncy - 3, 1, sk >= 0 ? UI_WHITE : UI_DIM, A);
                    }
                }
                // skill rows
                for (int i = 0; i < 4; i++) {
                    float re = easeOut((uiAge - 0.08f - i * 0.05f) / 0.22f);
                    int ra = (int)(255 * re), y = L.rowY[i];
                    int sk = SKILL_ROW[i];
                    hline(L.rx, y + L.rowH, L.rw, UI_WHITE, 28 * ra / 255);
                    int lsc = fitScale(SKILL_ROW_NAME[i], L.infoW, 2);
                    text(SKILL_ROW_NAME[i], L.rx, y + 2, lsc, sk >= 0 ? UI_WHITE : UI_DIM, ra);
                    int barY = y + L.rowH - 8, barW = L.infoW;
                    if (sk < 0) {
                        text("COMING SOON", L.rx, y + 22, 1, UI_DIM, ra);
                        hline(L.rx, barY, barW, UI_WHITE, 50 * ra / 255); hline(L.rx, barY + 3, barW, UI_WHITE, 50 * ra / 255);
                        rect(L.rx, barY, 1, 4, UI_WHITE, 50 * ra / 255); rect(L.rx + barW - 1, barY, 1, 4, UI_WHITE, 50 * ra / 255);
                        continue;
                    }
                    char t[64];
                    snprintf(t, sizeof t, "LV %d/%d  REBIRTH %d/%d", gProg.level[sk], prog::MAX_LEVEL, gProg.rebirth[sk], prog::MAX_REBIRTH);
                    text(t, L.rx, y + 19, 1, UI_WHITE, ra);
                    snprintf(t, sizeof t, "BONUS +%.2fX  REB X%.1f", prog::totalBonus(gProg, sk), prog::rebirthMult(gProg, sk));
                    text(t, L.rx, y + 29, 1, 0xBFD8FF, ra);
                    rect(L.rx, barY, barW, 4, UI_WHITE, 40 * ra / 255);
                    rect(L.rx, barY, (int)(barW * gProg.level[sk] / (float)prog::MAX_LEVEL), 4, UI_RED, ra);
                }
                drawButtons();
                int fy = H - 14 - 38 + 12;
                if (noteT > 0 && gNote[0]) text(gNote, px + 20, fy, 1, UI_RED);
                if (prog::totalMult(gProg, prog::RUN) > PHYS_CAP || prog::totalMult(gProg, prog::SWING) > PHYS_CAP) {
                    const char* cap = "IN-GAME SPEED CAPS AT X8";
                    text(cap, px + pw - 20 - textW(cap, 1), fy, 1, UI_DIM);
                }
            } break;
            case SETTINGS:
                dim(110); sheet(px, pw, "SETTINGS");
                drawButtons();
                break;
            case CONTROLS: {
                dim(110); sheet(px, pw, "CONTROLS");
                drawButtons();
                int hy = 96 + 3 * 42 + 1;
                if (noteT > 0 && gNote[0]) textSpC(gNote, W / 2, hy, 1, UI_RED, 2);
                else textSpC(ctlTab == 0 ? "SELECT A BOX, THEN PRESS A NEW KEY. ESC CANCELS" : "TO MOVE THE BUTTONS USE EDIT LAYOUT", W / 2, hy, 1, UI_DIM, 2);
            } break;
            case LAYOUT_EDIT: {
                dim(140);
                int zx = ctl.lefty ? (int)(W * 0.45f) : 0, zw = (int)(W * 0.55f);
                rect(zx, 0, zw, H, UI_WHITE, 12);
                int ex = ctl.lefty ? zx : zw;
                for (int y = 0; y < H; y += 8) rect(ex, y, 1, 4, UI_WHITE, 70);
                textSpC("STEER ZONE", zx + zw / 2, H / 2 - 20, 2, UI_WHITE, 4, 80);
                textSpC("DRAG A FINGER HERE TO STEER", zx + zw / 2, H / 2 + 2, 1, UI_DIM, 2, 150);
                textSpC("DRAG THE BUTTONS INTO PLACE", W / 2, 50, 1, UI_WHITE, 3, 190);
                for (int i = 0; i < 3; i++) {
                    bool pr = false;
                    for (auto& t : tch) if (t.on && t.role == R_DRAG && t.btn == i) pr = true;
                    drawCtlButton(i, pr, true);
                }
                drawButtons();
            } break;
            case HOW_TO_PLAY: {
                dim(110); sheet(px, pw, "HOW TO PLAY");
                int c1 = px + 22, c2 = px + (int)(pw * 0.24f), c3 = px + (int)(pw * 0.60f), y0 = 66;
                textSp("ACTION", c1, y0, 1, UI_DIM, 3); textSp("TOUCH", c2, y0, 1, UI_DIM, 3); textSp("KEYBOARD", c3, y0, 1, UI_DIM, 3);
                hline(c1, y0 + 11, pw - 44, UI_WHITE, 45);
                char k[A_N][16];
                for (int i = 0; i < A_N; i++) keyLabel(ctl.key[i], k[i], sizeof k[i]);
                char steerK[40], pauseK[40];
                snprintf(steerK, sizeof steerK, "%s / %s", k[A_LEFT], k[A_RIGHT]);
                snprintf(pauseK, sizeof pauseK, "%s / ESC", k[A_PAUSE]);
                const char* rows[5][3] = {{"STEER", ctl.lefty ? "DRAG RIGHT SIDE" : "DRAG LEFT SIDE", steerK}, {"JUMP", "JUMP BUTTON", k[A_JUMP]},
                    {"SLIDE", "SLIDE BUTTON", k[A_SLIDE]}, {"SWING", "HOLD SWING", k[A_SWING]}, {"PAUSE", "PAUSE BUTTON", pauseK}};
                for (int i = 0; i < 5; i++) {
                    float e = easeOut((uiAge - 0.1f - i * 0.05f) / 0.22f);
                    int a = (int)(255 * e), y = y0 + 18 + i * 22 + (int)((1 - e) * 8);
                    int s1 = fitScale(rows[i][0], c2 - c1 - 8, 2), s2 = fitScale(rows[i][1], c3 - c2 - 8, 2), s3 = fitScale(rows[i][2], px + pw - 22 - c3, 2);
                    text(rows[i][0], c1, y, s1, UI_WHITE, a);
                    text(rows[i][1], c2, y, s2, 0xC9D1EE, a);
                    text(rows[i][2], c3, y, s3, UI_WHITE, a);
                    hline(c1, y + 17, pw - 44, UI_WHITE, 22 * a / 255);
                }
                static const char* tips[] = {"HOLD SWING IN THE AIR NEAR A GLOWING ANCHOR. RELEASE TO FLY.", "LAND FAST OUT OF A SWING FOR A SPEED BOOST. SLIDE TO KEEP IT.", "CHAIN SWINGS FOR BONUS POINTS."};
                for (int i = 0; i < 3; i++) textSpC(tips[i], W / 2, y0 + 18 + 5 * 22 + 8 + i * 12, 1, UI_DIM, 1);
                drawButtons();
            } break;
            case CREDITS: {
                dim(110); sheet(px, pw, "CREDITS");
                static const char* ls[] = {"STICKMAN: PIXEL CITY", "STICKMAN STYLE INSPIRED BY ALAN BECKER", "MENU STYLE INSPIRED BY MARVEL SPIDER-MAN GAMES",
                    "FAN-MADE TRIBUTE. NOT AFFILIATED.", "ALL ART AND AUDIO ARE GENERATED IN CODE", "BUILT WITH C++ AND SDL2"};
                drawLines(ls, 6, W / 2, 72, pw - 40);
                drawButtons();
            } break;
            case PAUSED: {
                dim(150); shadeEdges(60, 160);
                int ty = (int)(H * 0.10f);
                textSpC("PAUSED", W / 2 + 2, ty + 2, 5, UI_RED_D, 6);
                textSpC("PAUSED", W / 2, ty, 5, UI_WHITE, 6);
                slantBar(W / 2 - 30, ty + 7 * 5 + 8, 60, 3, 3, UI_RED, 255);
                drawButtons();
            } break;
            case GAME_OVER: {
                dim(165); shadeEdges(60, 160);
                int ty = (int)(H * 0.10f);
                textSpC("GAME OVER", W / 2 + 2, ty + 2, 5, UI_RED_D, 6);
                textSpC("GAME OVER", W / 2, ty, 5, UI_WHITE, 6);
                slantBar(W / 2 - 30, ty + 7 * 5 + 8, 60, 3, 3, UI_RED, 255);
                char b[32];
                int sy = ty + 7 * 5 + 28;
                snprintf(b, sizeof b, "%d", scoreVal()); drawStatLine("SCORE", b, W / 2 - 150, sy, UI_WHITE);
                snprintf(b, sizeof b, "%dM", (int)distM); drawStatLine("DISTANCE", b, W / 2, sy, 0xBFD8FF);
                snprintf(b, sizeof b, "PERFECT %d  TRICKS %d", perfectReleases, trickCount); textSpC(b, W / 2, sy + 19, 1, 0xC9D1EE, 1);
                snprintf(b, sizeof b, "NEAR MISSES %d  LANDINGS %d  BEST FLOW %d", nearMisses, perfectLandings, bestCombo); textSpC(b, W / 2, sy + 31, 1, 0xFFE9A0, 1);
                snprintf(b, sizeof b, "RECORDS: FLOW %d  TRICKS %d  COINS %d", recordBestCombo, recordBestTricks, recordBestCoins); textSpC(b, W / 2, sy + 54, 1, 0xBFD8FF, 1);
                snprintf(b, sizeof b, "TOP SPEED %.0f", recordTopSpeed); textSpC(b, W / 2, sy + 65, 1, 0xC9D1EE, 1);
                { char cb[32]; fmtNum(gProg.coins, cb, sizeof cb); drawStatLine("TOTAL COINS", cb, W / 2 + 168, sy, 0xFFE9A0);
                  if (runCoins > 0) { snprintf(b, sizeof b, "+%d THIS RUN", runCoins); textSpC(b, W / 2 + 168, sy + 36, 1, 0xFFE9A0, 2); } }
                snprintf(b, sizeof b, "BEST %dM", (int)cfg.best);
                int by = sy + 42;
                if (newBest) {
                    int bw = textWSp(b, 2, 3) + 90;
                    textSp(b, W / 2 - bw / 2, by, 2, 0xFFE9A0, 3);
                    int nx = W / 2 - bw / 2 + textWSp(b, 2, 3) + 14;
                    slantBar(nx, by - 3, 62, 19, 5, UI_RED, 255);
                    text("NEW!", nx + 9, by + 1, 2, UI_WHITE);
                } else textSpC(b, W / 2, by, 2, 0xBFD8FF, 3);
                drawButtons();
            } break;
            default: break;
        }
        if (flashT > 0) { float f = clampf(flashT / 0.5f, 0, 1); rect(0, 0, W, H, UI_WHITE, (int)(230 * f * f)); }
        if (fadeIn > 0) rect(0, 0, W, H, 0x000000, (int)(255 * clampf(fadeIn / 0.5f, 0, 1)));
        if (trans > 0.7f) rect(0, 0, W, H, 0x000000, (int)(255 * clampf((trans - 0.7f) / 0.3f, 0, 1)));
    }
    SDL_SetRenderTarget(gRen, nullptr);
    SDL_SetRenderDrawColor(gRen, 0, 0, 0, 255);
    SDL_RenderClear(gRen);
    SDL_Rect dst = {OFFX, OFFY, W * SC, H * SC};
    SDL_RenderCopy(gRen, gTarget, nullptr, &dst);
    SDL_RenderPresent(gRen);
}

// ============================================================================
//  UPDATE
// ============================================================================
static void updateGame(double dt) {
    pollHeld();
    Player& p = P;
    // A few rooftop hazards slide back and forth. Their rendered and collision
    // positions share the same world coordinate, so there is no visual mismatch.
    for (auto& b : bld) for (auto& o : b.obs) if (o.solid && o.param == 1)
        o.x = o.homeX + sinf((float)gTime * 1.8f + o.homeX * 0.01f) * 42.0f;
    // Briefly ease time near the bottom of a fast swing, making the release
    // window readable without a costly post-processing effect.
    if (p.swinging && swingHeld && p.vy > 180.0f && p.vx > 420.0f && !cfg.reduced) dt *= 0.78;
    // the shot flies to the anchor first, the rope only attaches when it arrives
    if (swingHeld && !swingWas && !p.wallCling && p.alive && !p.onGround && !p.swinging && !p.webFlying) {
        sfx(0);
        p.shootT = 0.14f; p.shootStyle = wrng.range(0, 1);
        if (findAnchor(tgtX, tgtY)) {
            p.webFlying = true;
            p.webStartX = p.webX = p.x;
            p.webStartY = p.webY = p.y - 10;
            p.webT = 0;
            { const float sm = swingMult(); p.webDur = clampf(hypotf(tgtX - p.webStartX, tgtY - p.webStartY) / (1900.0f * sm), 0.12f / sm, 0.65f); }
        }
    }

    swingWas = swingHeld;
    haveTarget = false;
    if (p.alive && !p.onGround && !p.swinging && !p.webFlying) {
        haveTarget = findAnchor(tgtX, tgtY);
    }

    if (p.webFlying) {
        p.webT += (float)dt;
        const float progress = clampf(p.webT / p.webDur, 0, 1);
        p.webX = lerpf(p.webStartX, tgtX, progress);
        p.webY = lerpf(p.webStartY, tgtY, progress);

        if (!swingHeld || p.onGround || !p.alive) {
            p.webFlying = false;
        } else if (progress >= 1.0f) {
            p.webFlying = false;
            attachWeb(tgtX, tgtY);
        }
    }
    if (p.swinging && !swingHeld) {
        // The best release is fast and close to the bottom of the arc. A short
        // timing window rewards skill without requiring a new button.
        float speed = hypotf(p.vx, p.vy);
        bool perfect = speed > 470.0f && p.vy > 40.0f && p.x > p.ax;
        if (perfect) {
            p.vx = std::min(p.vx + 180.0f + 140.0f * p.slingshotT, 1650.0f); p.vy -= 55.0f;
            bonus += 30.0f + 20.0f * p.slingshotT; p.slingshotT = 0; speedBonus += 15.0f; perfectT = 0.75f;
            perfectReleases++; addAdrenaline(24.0f); comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount);
            chainShowT = 1.4f; eventToast = "PERFECT RELEASE!"; eventToastT = 1.0f;
            burst(p.x, p.y - 12, cfg.reduced ? 4 : 10, 0xBFD8FF, 150); sfx(7);
        } else if (speed > 520.0f) { p.vx = std::min(p.vx + 95.0f + 60.0f * p.slingshotT, 1500.0f); bonus += 12.0f + 8.0f * p.slingshotT; chainShowT = 1.2f; p.slingshotT = 0; } else p.slingshotT = 0;
        // A taut, fast web stores a little elastic energy for a satisfying rebound.
        if (speed > 620.0f && p.rope > 100.0f && hypotf(p.x - p.ax, p.y - p.ay) > p.rope * 0.88f) { p.vy -= 115.0f; p.vx = std::min(p.vx + 45.0f, 1650.0f); bonus += 8; eventToast = "WEB REBOUND!"; eventToastT = 0.8f; }
        releaseWeb(false);
    }
    // fixed timestep physics
    static double acc = 0;
    acc += dt;
    int guard = 0;
    // faster runs/swings use smaller physics steps so collisions can't tunnel
    const int sub = (int)clampf(ceilf(std::max(fabsf(p.vx), fabsf(p.vy)) / 1100.0f), 1.0f, 4.0f);
    const double h = 1.0 / (120.0 * sub);
    while (acc >= h && guard++ < 12 * sub) { stepPhysics((float)h); acc -= h; }
    if (guard >= 12 * sub) acc = 0;
    // timers
    p.landT -= (float)dt; p.shootT -= (float)dt; p.attachT -= (float)dt; p.releaseT -= (float)dt; p.flipT -= (float)dt;
    if (p.alive && p.onGround) gRunPhase += (float)dt * 1.44f * clampf(p.vx / 230.0f, 0.6f, 2.2f);
    chainShowT -= (float)dt; shakeT -= (float)dt; styleTick -= (float)dt;
    if (p.alive && p.swinging && styleTick <= 0) {
        // Risk/reward for a low swing near a roof edge, evaluated only a few times per second.
        float roof = 1e9f;
        for (const auto& b : bld) if (p.x >= b.x && p.x <= b.x + b.w) { roof = std::min(roof, b.roofY); }
        float clearance = roof - p.y;
        if (clearance > -120.0f && clearance < 150.0f) {
            bonus += 4.0f; speedBonus += 1.0f; chainShowT = std::max(chainShowT, 0.65f);
        }
        styleTick = 0.35f;
    }
    if (p.alive) {
        distM = std::max(distM, (p.x - startX) / 16.0f);
        int district = cityDistrict();
        if (district != districtShown) { districtShown = district; if (distM > 5) { eventToast = cityDistrictName(district); eventToastT = 1.5f; } }
        // A lightweight pursuit drone follows from behind. Flow and swinging keep the gap open.
        if (distM > 350.0f) {
            if (!droneActive) { droneActive = true; droneX = p.x - 560.0f; droneY = p.y - 90.0f; }
            dronePulse += (float)dt;
            float desiredX = p.x - (p.swinging ? 720.0f : (comboCount >= 3 ? 680.0f : 430.0f));
            droneX += (desiredX - droneX) * clampf((float)dt * (comboCount >= 3 ? 0.8f : 1.45f), 0, 1);
            float desiredY = p.y - (p.swinging ? 210.0f : 95.0f) + sinf(dronePulse * 2.8f) * 22.0f;
            droneY += (desiredY - droneY) * clampf((float)dt * 1.6f, 0, 1);
        }

        for (auto& b : bld) if (b.secret && !b.secretClaimed && p.onGround && p.x > b.x + b.w * 0.5f - 22 && p.x < b.x + b.w * 0.5f + 22) {
            b.secretClaimed = true; bonus += 60; gProg.coins += 5; runCoins += 5; missionCoins += 5; saveProg();
            eventToast = "SECRET ROOFTOP FOUND! +5 COINS"; eventToastT = 1.8f; burst(p.x, p.y - 30, cfg.reduced ? 4 : 10, 0x7FE0FF, 95); sfx(3);
        }
        if (distM >= 1000) unlockAchievement(0, "ACHIEVEMENT: CITY MARATHON");
        if (nearMisses >= 10) unlockAchievement(1, "ACHIEVEMENT: CLOSE CALLS");
        if (perfectReleases >= 10) unlockAchievement(2, "ACHIEVEMENT: WEB MASTER");
        if (bestCombo >= 10) unlockAchievement(3, "ACHIEVEMENT: COMBO KING");
        if (!cfg.reduced && (ghostX.empty() || p.x - ghostStartX >= ghostX.size() * 16.0f)) { ghostX.push_back(p.x); ghostY.push_back(p.y); }
        // Near misses are checked at a low rate against rooftop hazards, not as
        // extra physics bodies. One reward per short window prevents score farming.
        if (p.nearMissLock <= 0 && !p.onGround) {
            for (const auto& b : bld) for (const auto& o : b.obs) if (o.solid) {
                float ox = o.x + o.w * 0.5f, oy = b.roofY - o.h * 0.5f;
                float dx = fabsf(p.x - ox), dy = fabsf((p.y + 4) - oy);
                if (dx < o.w * 0.5f + 28 && dy < o.h * 0.5f + 34 && !(dx < o.w * 0.5f + 8 && dy < o.h * 0.5f + 12)) {
                    nearMisses++; addAdrenaline(15.0f); comboCount++; flowTimer = 3.2f; bestCombo = std::max(bestCombo, comboCount); bonus += 15; p.nearMissLock = 0.8f;
                    eventToast = "NEAR MISS +15"; eventToastT = 0.75f; burst(p.x, p.y, cfg.reduced ? 2 : 5, 0xFFE9A0, 65); break;
                }
            }
        }
        // Short events rotate through the run; the swing challenge rewards staying airborne.
        eventT += (float)dt;
        if (challengeKind == 2 && challengeT > 0 && p.swinging) challengeSwingTime += (float)dt;
        if (challengeT > 0) {
            challengeT = std::max(0.0f, challengeT - (float)dt);
            if (challengeKind == 2 && challengeSwingTime >= 5.0f) {
                bonus += 90; addAdrenaline(18); eventToast = "SWING CHALLENGE COMPLETE! +90"; eventToastT = 1.5f; challengeT = 0; challengeKind = -1;
            } else if (challengeT <= 0) {
                if (challengeKind == 2) { eventToast = "CHALLENGE MISSED"; eventToastT = 0.9f; }
                challengeKind = -1;
            }
        }
        if (eventT > 24.0f && challengeT <= 0) {
            eventT = 0; int kind = wrng.range(0, 3); eventToastT = 2.0f;
            if (kind == 0) {
                eventToast = "COIN RUSH AHEAD";
                float x = p.x + 420; for (int i = 0; i < 10; ++i) coinItems.push_back({x + i * 34.0f, p.y - 100.0f - sinf(i * 0.35f) * 35.0f, false});
            } else if (kind == 1) {
                eventToast = "HIGH-SPEED SECTION"; p.boostExtra = std::max(p.boostExtra, 140.0f); p.boostDur = p.boostT = 2.8f;
            } else if (kind == 2) { eventToast = "SWING CHALLENGE: 5 SECONDS AIRBORNE"; challengeKind = 2; challengeT = 8.0f; challengeSwingTime = 0; }
            else { eventToast = "STORM FRONT"; burst(p.x + 220, p.y - 120, cfg.reduced ? 3 : 8, 0x9DBDFF, 90); }
        }
        if (!challengeDone[0] && distM >= 500) { challengeDone[0] = true; missionToast = "DAILY GOAL COMPLETE: 500M"; missionToastT = 2.0f; bonus += 40; saveDaily(); }
        if (!challengeDone[1] && missionCoins >= 20) { challengeDone[1] = true; missionToast = "DAILY GOAL COMPLETE: 20 COINS"; missionToastT = 2.0f; bonus += 40; saveDaily(); }
        if (!challengeDone[2] && perfectReleases >= 3) { challengeDone[2] = true; missionToast = "DAILY GOAL COMPLETE: 3 PERFECT RELEASES"; missionToastT = 2.0f; bonus += 50; saveDaily(); }
        flowTimer = std::max(0.0f, flowTimer - (float)dt); if (flowTimer <= 0) comboCount = 0;
        eventToastT = std::max(0.0f, eventToastT - (float)dt); perfectT = std::max(0.0f, perfectT - (float)dt);
        missionToastT = std::max(0.0f, missionToastT - (float)dt);
        int earned = prog::coinsForDistance(distM, coinMilestones);   // 15 coins every 200 m
        if (earned > 0) { gProg.coins += earned; runCoins += earned; sfx(3); saveProg(); }
        for (auto& c : coinItems) if (!c.taken && fabsf(c.x - p.x) < 24.0f && fabsf(c.y - (p.y - 12.0f)) < 42.0f) {
            c.taken = true; gProg.coins++; runCoins++; missionCoins++; coinSaveCounter++;
            bonus += 2.0f; spawnPart(c.x, c.y, 0, -45, 0.22f, 0xFFE9A0, 2); sfx(3);
            if (coinSaveCounter >= 5) { saveProg(); coinSaveCounter = 0; }
        }
        runTopSpeed = std::max(runTopSpeed, hypotf(p.vx, p.vy));
        if (p.vx > 420) speedBonus += (float)dt * 20.0f;
        if (p.slideT > 0 && p.onGround && ((int)(gTime * 40)) % 2 == 0)
            spawnPart(p.x - 10, p.y + 26, -60 - wrng.f() * 60, -20 - wrng.f() * 40, 0.3f, 0xB0B6D0);
        if (p.swinging || p.vx > 350) {  // web trail sparks
            if (((int)(gTime * 30)) % 3 == 0) spawnPart(p.x - 6, p.y - 8, -30, 10, 0.25f, 0x7FA8FF, 1);
        }
    } else {
        if (coinSaveCounter > 0) { saveProg(); coinSaveCounter = 0; }
        p.deadT += (float)dt;
        if (p.deadT > 1.1f && gState == PLAYING) {
            if (distM > cfg.best) { cfg.best = distM; newBest = true; }
            if (ghostX.size() > 8) ghostReady = true;
            recordBestCombo = std::max(recordBestCombo, bestCombo);
            recordBestTricks = std::max(recordBestTricks, trickCount);
            recordBestCoins = std::max(recordBestCoins, runCoins);
            recordTopSpeed = std::max(recordTopSpeed, runTopSpeed);
            if (!recordsPath.empty()) { FILE* rf = fopen(recordsPath.c_str(), "w"); if (rf) { fprintf(rf, "%d %d %d %.1f\n", recordBestCombo, recordBestTricks, recordBestCoins, recordTopSpeed); fclose(rf); } }
            saveCfg();
            gState = GAME_OVER;
        }
    }
    for (auto& q : parts) if (q.alive) {
        q.life -= (float)dt; if (q.life <= 0) { q.alive = false; continue; }
        q.x += q.vx * (float)dt; q.y += q.vy * (float)dt; q.vy += 300 * (float)dt;
    }
    // Cinematic follow camera: lead into fast movement and keep room above the
    // player during a swing, then ease back toward the normal running view.
    const float speedLead = clampf((p.vx - 260.0f) * 0.20f, 0.0f, 150.0f);
    float tx = p.x - W * 0.30f + speedLead;
    float ty = p.y - H * 0.58f;
    float camEaseX = 5.5f, camEaseY = 3.8f;
    if (p.swinging) {
        float ropeMid = lerpf(p.y, p.ay, 0.38f);
        float arcLook = clampf(-p.vy * 0.10f, -55.0f, 75.0f);
        ty = ropeMid - H * 0.55f + arcLook;
        tx += clampf(p.vx * 0.08f, 0.0f, 70.0f);
        camEaseX = 4.8f; camEaseY = 3.0f;
    } else if (!p.onGround && p.alive) {
        // Anticipate the landing when falling, without snapping the camera.
        ty += clampf(p.vy * 0.055f, -25.0f, 85.0f);
    }
    if (p.wallCling) { ty = p.y - H * 0.52f; camEaseY = 5.0f; }
    if (p.landT > 0 && p.hero) {
        // Briefly hold a wider, lower hero-landing composition.
        ty = p.y - H * 0.64f;
        camEaseX = 3.2f; camEaseY = 2.2f;
    }
    if (p.alive || p.deadT < 0.6f) {
        camX += (tx - camX) * (1 - expf(-camEaseX * (float)dt));
        camY += (ty - camY) * (1 - expf(-camEaseY * (float)dt));
    }
    ensureWorld();
    aWind = clampf((p.vx - 250) / 400.0f, 0, 1) * (p.onGround ? 0.4f : 1.0f);
}

int main(int, char**) {
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
    SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
    SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "1");  // lets you test on a desktop with the mouse
    SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");
    SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }
    loadCfg();
    loadControls();
    Uint32 flags = SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
#ifdef __ANDROID__
    flags |= SDL_WINDOW_FULLSCREEN;
#endif
    gWin = SDL_CreateWindow("Stickman: Pixel City", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 600, flags);
    gRen = gWin ? SDL_CreateRenderer(gWin, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC) : nullptr;
    if (!gRen) {
        fprintf(stderr, "Could not create window/renderer: %s\n", SDL_GetError());
        return 1;
    }
    SDL_SetRenderDrawBlendMode(gRen, SDL_BLENDMODE_BLEND);
    initFont();
    recalcDisplay();
    buildArt();
    initAudio();
    startRun();           // builds a valid world, then drop back to the menu
    gState = TITLE; aMode = 1; menuT = 0;     // opens on the PRESS TO START screen

    bool running = true;
    Uint64 last = SDL_GetPerformanceCounter();
    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_QUIT: running = false; break;
                case SDL_WINDOWEVENT:
                    if (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED || e.window.event == SDL_WINDOWEVENT_RESIZED) { recalcDisplay(); releaseAll(); }
                    if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST) { releaseAll(); if (gState == PLAYING) gState = PAUSED; }
                    break;
                case SDL_APP_WILLENTERBACKGROUND:
                    releaseAll(); if (gState == PLAYING) gState = PAUSED; saveCfg();
                    if (gAud) SDL_PauseAudioDevice(gAud, 1);
                    break;
                case SDL_APP_DIDENTERFOREGROUND:
                    if (gAud && audioStarted) SDL_PauseAudioDevice(gAud, 0);
                    break;
                case SDL_FINGERDOWN: fingerDown(e.tfinger); break;
                case SDL_FINGERMOTION: fingerMove(e.tfinger); break;
                case SDL_FINGERUP: fingerUp(e.tfinger); break;
                case SDL_KEYDOWN: {
                    SDL_Scancode sc = e.key.keysym.scancode;
                    startAudio();
                    if (gState == TITLE) { if (!e.key.repeat) enterMenu(); break; }
                    if (gRebind >= 0) {                                   // waiting for a new key for an action
                        if (e.key.repeat) break;
                        if (sc == SDL_SCANCODE_ESCAPE) { gRebind = -1; sfx(4); }
                        else { assignKey(gRebind, sc); gRebind = -1; }
                        break;
                    }
                    if (sc == SDL_SCANCODE_AC_BACK || sc == SDL_SCANCODE_ESCAPE) {
                        if (e.key.repeat) break;
                        if (gState == PLAYING) gState = PAUSED;
                        else if (gState == PAUSED) gState = PLAYING;
                        else if (isSub(gState)) activate(B_BACK);
                        break;
                    }
                    if (gState == PLAYING) {
                        if (e.key.repeat) break;
                        if (sc == ctl.key[A_JUMP]) jumpEdge = true;
                        if (sc == ctl.key[A_SLIDE]) slideEdge = true;
                        if (sc == ctl.key[A_PAUSE]) { gState = PAUSED; sfx(4); }
                    } else if (gState == PAUSED && sc == ctl.key[A_PAUSE]) gState = PLAYING;
                    else menuKey(sc);
                } break;
                case SDL_KEYUP:
                    if (gState == PLAYING && e.key.keysym.scancode == ctl.key[A_JUMP]) jumpRel = true;
                    break;
                case SDL_MOUSEMOTION: mouseHover(e.motion.x, e.motion.y); break;
                default: break;
            }
        }
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = (double)(now - last) / (double)SDL_GetPerformanceFrequency();
        last = now;
        dt = std::min(dt, 0.05);
        gTime += dt;
        if (fadeIn > 0) fadeIn -= (float)dt;
        if (!portrait) {
            if (gState == PLAYING) updateGame(dt);
            else if (gState == GAME_OVER) {  // let the death tumble finish, but nothing else simulates
                for (auto& q : parts) if (q.alive) { q.life -= (float)dt; if (q.life <= 0) q.alive = false; }
            }
            if (gState == MAIN_MENU && trans >= 0) {
                trans += (float)dt;
                if (trans >= 1.0f) { trans = -1; startRun(); fadeIn = 0.5f; }
            }
        }
        render(dt);
    }
    saveCfg();
    SDL_Quit();
    return 0;
}
