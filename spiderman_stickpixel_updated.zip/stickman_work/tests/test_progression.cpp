#include "../src/progression.h"
#include <cassert>
#include <cmath>
#include <cstdio>
using namespace prog;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static bool near(float a, float b) { return fabsf(a - b) < 1e-3f; }
int main() {
    // coin rewards: every 200 m = 15 coins
    int paid = 0;
    CHECK(coinsForDistance(0, paid) == 0);
    CHECK(coinsForDistance(199.9f, paid) == 0);
    CHECK(coinsForDistance(200, paid) == 15 && paid == 1);
    CHECK(coinsForDistance(200, paid) == 0);          // no double pay
    CHECK(coinsForDistance(399, paid) == 0);
    CHECK(coinsForDistance(1000, paid) == 60 && paid == 5);   // 4 more milestones
    // upgrade: blocked without coins, costs, levels
    Data d;
    CHECK(!canUpgrade(d, RUN) && !upgrade(d, RUN) && d.level[RUN] == 0 && d.coins == 0);
    d.coins = 499; CHECK(!upgrade(d, RUN) && d.coins == 499);
    d.coins = 500; CHECK(upgrade(d, RUN) && d.level[RUN] == 1 && d.coins == 0);
    CHECK(near(levelBonus(d, RUN), 0.25f) && near(totalMult(d, RUN), 1.25f));
    d.coins = 749; CHECK(!upgrade(d, SWING));
    d.coins = 750; CHECK(upgrade(d, SWING) && d.level[SWING] == 1 && d.coins == 0);
    CHECK(near(levelBonus(d, SWING), 0.20f));
    CHECK(d.level[RUN] == 1);                          // separate progression
    // max level 50
    d.coins = 1000000; d.level[RUN] = 49;
    CHECK(upgrade(d, RUN) && d.level[RUN] == 50);
    long long c = d.coins; CHECK(!upgrade(d, RUN) && d.level[RUN] == 50 && d.coins == c);
    CHECK(near(levelBonus(d, RUN), 12.5f));
    // rebirth: only at max level, costs 1000 / 5000
    CHECK(!canRebirth(d, SWING));                      // swing not maxed
    d.coins = 999; CHECK(!doRebirth(d, RUN));
    d.coins = 1000; CHECK(doRebirth(d, RUN) && d.level[RUN] == 0 && d.rebirth[RUN] == 1 && d.coins == 0);
    CHECK(near(rebirthMult(d, RUN), 1.1f) && near(totalMult(d, RUN), 1.1f));
    CHECK(d.level[SWING] == 1 && d.rebirth[SWING] == 0);   // swing untouched
    d.level[SWING] = 50; d.coins = 4999; CHECK(!doRebirth(d, SWING));
    d.coins = 5000; CHECK(doRebirth(d, SWING) && d.coins == 0 && d.rebirth[SWING] == 1 && d.level[SWING] == 0);
    CHECK(d.rebirth[RUN] == 1);
    // rebirth + upgrades combine: (1+0.25*10)*1.1
    d.level[RUN] = 10; CHECK(near(totalMult(d, RUN), 3.5f * 1.1f)); CHECK(near(totalBonus(d, RUN), 3.85f - 1.0f));
    // rebirth cap 50
    d.rebirth[RUN] = 49; d.level[RUN] = 50; d.coins = 1000;
    CHECK(doRebirth(d, RUN) && d.rebirth[RUN] == 50);
    d.level[RUN] = 50; d.coins = 100000; CHECK(atMaxRebirth(d, RUN) && !rebirthReady(d, RUN) && !doRebirth(d, RUN) && d.rebirth[RUN] == 50 && d.coins == 100000);
    CHECK(near(rebirthMult(d, RUN), 6.0f));
    // save / load round trip + file
    Data e; e.coins = 123456789012LL; e.level[RUN] = 37; e.level[SWING] = 12; e.rebirth[RUN] = 50; e.rebirth[SWING] = 4;
    Data f; CHECK(parse(serialize(e).c_str(), f));
    CHECK(f.coins == e.coins && f.level[0] == 37 && f.level[1] == 12 && f.rebirth[0] == 50 && f.rebirth[1] == 4);
    CHECK(saveFile("/tmp/prog_test.txt", e));
    Data g; CHECK(loadFile("/tmp/prog_test.txt", g) && g.coins == e.coins && g.level[1] == 12 && g.rebirth[1] == 4);
    // corrupt / hostile files are clamped or rejected
    Data h; CHECK(parse("PROG1 -5 999 -3 77 1000", h) && h.coins == 0 && h.level[0] == 50 && h.level[1] == 0 && h.rebirth[0] == 50 && h.rebirth[1] == 50);
    Data k; k.coins = 7; CHECK(!parse("garbage", k) && k.coins == 7);
    CHECK(!loadFile("/tmp/does_not_exist_xyz", k));
    // full simulated playthrough of a run's coins then buying
    Data p; int pd = 0; float dist = 0;
    for (int i = 0; i < 20000; i++) { dist += 1.0f; p.coins += coinsForDistance(dist, pd); }   // 20,000 m
    CHECK(p.coins == 100 * 15);
    printf(fails ? "%d FAILED\n" : "ALL TESTS PASSED\n", fails);
    return fails != 0;
}
