# Stickman: Pixel City

A mobile-first, landscape pixel-art endless runner written in **C++17 + SDL2** as a single source file.
Run across rooftops, aim your web at buildings, cranes, signs and masts and swing from whatever it hits, swing, release and chain swings for bonus points.

## Features

- **Stickman player in the style of Alan Becker's *Animator vs. Animation*** - uniform-width limbs, a plain round head, no face.
  He is not a sprite: the skeleton is posed from joint angles every frame, so there are **no asset files**.
  Smooth by construction: run / idle / swing poses come from a continuous phase (stride speed follows ground speed),
  every joint angle is a damped spring chasing the target pose, so limbs overshoot and settle (follow-through) and every move flows into the next, and limbs are drawn as anti-aliased capsules.
- **Spider-Man-inspired moveset, randomised per move:** every run, jump, fall, web shot, swing and landing picks a random pose variant (hunched or sprinting run, tucked / spread / layout swings, star-jump or crouched leaps, deep-crouch or one-hand landings) plus a small random nudge, and a fast release sometimes ends in a front or back somersault. Also idle crouch, web throw, double-jump tuck flip, superhero landing, hit and defeat. Web shots travel to their selected anchor before swing attachment; wall contact can enter an attached crawl state with alternating limb poses.
- Procedurally generated city, parallax skyline, fonts, music and sound effects - everything is made in code.
- Pixel-perfect integer scaling that adapts to any phone resolution, with safe-area margins and touch targets sized from the screen DPI.
- **Swing boost:** landing with speed carried out of a swing gives a temporary run-speed bonus (2-5 s, bigger for faster swings), shown by a bar on the HUD.
- **Slide:** a short low skid that holds onto your speed (with three random slide poses and dust); pressing SLIDE just before landing slides straight out of the fall and lengthens the boost.
- Press-to-start title, clean menu / settings / controls screens, rebindable keyboard controls, a drag-and-drop touch layout editor and a saved best score.
- Larger procedural buildings, expanded gaps, camera tracking tuned for vertical movement.

## Wall climbing

Touch a building face while holding the web button (SWING) and you stick to it. Keep holding to climb, let go to slide down, and reach the roof line to be pulled up and over the edge into a run. JUMP kicks you away from the wall (higher if you were climbing) and holding the web button as you leave flows straight into a swing. You can't re-grab the wall you just left for a moment, and walls only catch you while the web is held, so running past a building never grabs you by accident. At 100 % Swing Assist the climb is automatic. Tests: `tests/test_wall_climb.cpp`.

## Air tricks

Tap **SLIDE** while high in the air (no extra button). What you get depends on when you tap: rising = **front flip** (steer back for a **back flip**), right at the top of the arc = **twist** (a perfect-timing bonus), falling = **cartwheel**. A trick only starts if it can finish before you land, so near a roof the same tap is the normal pre-landing slide. It pays when it completes: faster = more score, flipping through a near miss pays extra (or a small bonus if the near miss comes just after), and it feeds the combo and Flow meter. Landing mid-trick is SLOPPY (no reward, a short stumble). You need a fresh air action for each trick (jump, double jump, web release, wall kick or running off an edge), and tricking non-stop pays less. Tricks never affect collision. Tests: `tests/test_air_tricks.cpp`.

## Controls

| Action | Touch | Keyboard (default, rebindable) |
| --- | --- | --- |
| Steer | Slide a finger on the steer side of the screen | `A` / `D` |
| Jump / double jump | Tap the JUMP button | `Space` |
| Slide / air trick | Tap SLIDE on a roof or just before landing; tap it high in the air for a trick | `S` |
| Aim | Drag the AIM stick above the SWING button (hidden at 100 % Swing Assist) | Arrow keys |
| Rope | Hold SWING in the air, release to fly | Hold `Left Shift` |
| Wall climb | Hold SWING while touching a building face to stick; hold to climb, release to slide down, tap JUMP to kick off | Same keys |
| Pause | Pause button / Back button | `P` or `Esc` |

Menus: `Up` / `Down` to move, `Left` / `Right` to adjust sliders, `Enter` / `Space` to select, `Esc` to go back. The mouse also works (hover to highlight, click to select, and it acts as touch in-game).

### Customising controls

Open **CONTROLS** from the main menu or the pause menu. Choices are saved in `controls.txt` next to the save file.

- **Keyboard tab** - select a box, then press the new key. `Esc` cancels. If the key is already used, the two actions swap so nothing is left unbound. *Reset tab* restores the defaults.
- **Touch tab** - button size, button opacity, steering sensitivity and a **left-handed** mode that mirrors the whole layout (buttons and steer zone).
- **Edit layout** - drag the SWING, JUMP and SLIDE buttons anywhere on the screen; the shaded area shows the steer zone. *Reset* puts them back.

## Interface

The title opens on a **PRESS TO START** screen (tap, click or press any key). Menus use a clean, high-contrast style inspired by the Spider-Man games: white on ink, a single red accent, slanted highlight bars and thin rules. The spider emblem is an original shape drawn in code; there are still no asset files.

## Build (desktop)

Requires a C++17 compiler, CMake 3.16+ and the SDL2 development package.

```bash
# Debian / Ubuntu
sudo apt install build-essential cmake libsdl2-dev
# macOS
brew install cmake sdl2

cmake -S . -B build
cmake --build build
./build/stickman_pixel_city
```

Without CMake on Linux / macOS:

```bash
g++ -std=c++17 -O2 src/main.cpp $(sdl2-config --cflags --libs) -o stickman_pixel_city
```

On Windows use CMake with a vcpkg SDL2 install (`-DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/buildsystems/vcpkg.cmake`).

## Build (Android)

The game is plain SDL2, so it drops into SDL's stock Android project:

1. Clone [libsdl-org/SDL](https://github.com/libsdl-org/SDL) (2.x) and open its `android-project` folder in Android Studio.
2. Copy `src/main.cpp` into `android-project/app/jni/src/`.
3. In `app/jni/src/Android.mk` set `LOCAL_SRC_FILES := main.cpp` and add `LOCAL_CPPFLAGS += -std=c++17`.
4. Build and run.

The code requests landscape-only SDL orientation hints, handles the Android back button and background / foreground pause. Android builds should also set `android:screenOrientation="landscape"` on the SDL activity in the Android manifest, since the Android manifest is supplied by the SDL Android wrapper and is not included in this source-only repository.

## Customising the stickman

Everything lives in the `STICKMAN BEGIN / END` block of `src/main.cpp`:

- `STK_BODY` / `STK_OUTLINE` - limb colour and the thin rim that keeps him readable on the night sky
  (try `0xFF8A1E` for the orange "Second Coming" look).
- `stkMakePose()` - every pose as a handful of joint angles (`stkRate()` sets how fast he eases between them) (degrees from straight down, positive = toward the facing side).
- `STK_THIGH`, `STK_SHIN`, `STK_UARM`, ... - limb lengths.

## Credits

Stickman style inspired by Alan Becker's *Animator vs. Animation*. This is an unofficial fan tribute and is not affiliated with or endorsed by Alan Becker or Alan Becker Productions.

## License

[MIT](LICENSE) - Copyright (c) 2026 xzestqtips (zkqruvz).

## Skill upgrades, coins and rebirth
- Tap the spider-web **UPGRADES** icon on the main menu or game-over screen.
- Every 200 m travelled earns 15 coins. Coins, levels and rebirths are saved in `progress.txt` next to `save.txt`.
- Run Speed: +0.25 per level, 500 coins, max level 50, rebirth 1,000 coins.
- Swing Speed: +0.20 per level, 750 coins, max level 50, rebirth 5,000 coins.
- Rebirth (needs level 50) resets that skill's level and adds a permanent +0.1x multiplier, up to rebirth 50. Total speed = (1 + level bonus) x (1 + 0.1 x rebirths).
- Logic lives in `src/progression.h`. Tests: `tests/test_progression.cpp` (logic) and `tests/test_game.cpp` (headless run of the real game code with a stub SDL).

## Swing Assist (Settings -> SWING ASSIST, 0-100 %, saved between runs)

The slider moves in exact 1 % steps (drag it, use the `-` / `+` boxes beside it, or Left / Right on a keyboard) and shows the percentage.
The AIM stick points the web; Swing Assist decides how much the game helps. All of it is continuous, so every percent changes something:

| Setting | What happens |
| --- | --- |
| **0 %** Manual | No help. One exact ray along the stick: the web sticks to the first surface it hits (building face, roof, crane, sign, mast, cable) or fizzles if it hits nothing above you. |
| **1-99 %** Partial | The stick stays visible and usable. The aim cone widens (about 41 degrees at 50 %, 80 degrees at 99 %), the game casts rays across the cone and blends its own score of the surface hit into the choice (`cost = (1-w)*aim + w*auto`, `w` = percent), reach grows and surfaces behind you are allowed less and less. 50 % is an even split; 75-99 % lets the auto pick lead while the stick still nudges. |
| **100 %** Full auto | The stick is hidden. Whenever you are airborne the game fans out rays, picks the best surface and attaches almost instantly (no visible web flight), releases at a good point in the arc once a next anchor is ready, and aims again, without ever moving the player directly. JUMP still releases (and holds the auto web back for half a second); the SWING button still climbs walls. |

The stick keeps its last direction for about 1.3 s after you let go (so you can aim, then tap SWING with the same thumb) and then returns to the default forward-up aim. Switching away from 100 % brings the stick back immediately.

There are no fixed anchor points any more. `pickAnchor()` in `src/main.cpp` casts rays (`rayTarget()`) against building boxes, rooftop obstacles, cranes, signs, masts and gap cables; the first thing a ray touches is where the web sticks, so a web can never attach through a building. Hits must be above the player and not too close or too far. The best few candidates get a short look-ahead (the game's own pendulum rules) so swings that end in a wall or the street are avoided, and recently used spots are skipped for a while. The line is re-checked while the web is in flight and the web is cancelled if something moves into the way. Tests: `tests/test_web_attach.cpp`.

Tests: `tests/test_swing_assist.cpp` (`g++ -std=c++17 -O1 -Itests/stub -o /tmp/tsa tests/test_swing_assist.cpp && /tmp/tsa`) checks all 101 settings (save/restore, slider, buttons, stick visibility, selection behaviour) and runs 100 % full-auto in real runs.


## Swing feel

- **Flow** (`gFlow`, the thin bar under the chain text): grows with good releases, fades when you stop swinging (fast on the ground, slowly in the air). Full flow makes the swing pump up to 60 % stronger and raises the speed cap a little.
- **Perfect release:** let go while rising forward at roughly 25-55 degrees with some speed (`releaseEval()`), after at least 0.35 s on the rope. You get the normal fast-release boost plus an extra 8-18 %, eased in over 0.32 s, a PERFECT popup with a streak counter, bonus points, a gold burst, a short camera kick, a tiny shake (respects CAMERA SHAKE) and a rising chime.
- **Body:** on the rope the stickman leans into the direction of travel the faster he goes; in flight he streamlines along the flight path above 650 px/s.
- **Camera:** looks further ahead and slightly up/down with speed; punches forward on a perfect release; no zoom, so pixels stay crisp.
- **Trails:** 16 fading pixel afterimages above 650 px/s while airborne (gold after a perfect release; half as many with FEWER PARTICLES).
- **Auto assist:** the 100 % auto-release now waits for the perfect window (or a later point in the arc), and the auto picker also aims rays at mast tips, crane jibs and sign tops. A web is never re-shot after a release below 100 % unless you press SWING again.
- Tests: `tests/test_swing_feel.cpp`.

## Swings that meet a wall

A web swing that runs into a building face no longer just sticks to it (`swingMeetsWall()` in `src/main.cpp`):
- **Mantle:** close under the roof edge and still rising, the player lets go with a pop that clears the lip and lands on the roof.
- **Rope wrap:** lower down, the rope wraps round the roof corner (at most twice per swing) and the swing carries on in front of the wall with the same rope-length rules.
- Otherwise (no roof corner above you, or after two wraps) the old wall-cling applies. The swing look-ahead treats a wrap as a small penalty instead of a dead end. Tests: `tests/test_wall_wrap.cpp`.

## Flow combo

One combo system sits on top of the existing flow/score code (`src/combo.h`, pure logic; glue is `comboHit()` / `nearMissTick()` in `src/main.cpp`). Its points go into the normal `bonus` score and every skill also nudges the flow meter, which now drains at half speed while a combo is alive.

| Skill | When it counts |
|---|---|
| PERFECT | a perfect release (the existing 25-55 degree window) |
| FAST SWING | a committed let-go (over 0.35 s) faster than about 90 % of your peak swing speed for your Swing Speed level (never under 450 px/s) |
| TRICK | an air jump flip or a wall jump |
| NEAR MISS | flying over a roof or rooftop block within 26 px at 400+ px/s without touching it, until you clear the far edge |
| SMOOTH LANDING | pressing slide just before touchdown |
| LONG SWING | landing after 5 or more swings in a row without touching the ground (20 x chain base points, +0.5x) |

- **Variety builds the multiplier.** A skill that is new to the last three adds +0.30x, one seen in the last three +0.15x, the same skill again only +0.05x and 60 % points. The same skill can not re-score inside a short cooldown (0.3-0.8 s), so button mashing goes nowhere.
- **Cap:** 5.0x (`combo::MAX_MULT`). Existing flat bonuses (swing chain, landing) stay unmultiplied; only skills are multiplied.
- **Milestones** follow the multiplier: GOOD 1.5x, GREAT 2.5x, AMAZING 3.5x, LEGENDARY 4.5x, each with a one-off reward (25 / 60 / 120 / 250). Effects grow with the tier: bigger bursts, camera punch, tinted afterimages, and from AMAZING a soft edge light (turned off by Fewer particles).
- **Decay:** the window is 4.0 s and shrinks to 2.6 s at LEGENDARY (runs out 1.5x faster on the ground). After that the multiplier drains 0.9x per second and blinks red; a new skill picks the combo back up. A crash ends it at once.
- **Best combo** (hits, points, peak multiplier) is saved in `combo.txt` and shown on the game-over screen.
- Tuning knobs are the constants at the top of `src/combo.h`. Tests: `tests/test_combo.cpp` (logic) and `tests/test_combo_game.cpp` (real game code: score, crash, near miss, releases, landings, save).
