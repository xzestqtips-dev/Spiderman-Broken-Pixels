# NYC Pixel Runner

A mobile-first, landscape pixel-art endless runner written in **C++17 + SDL2** as a single source file.
Run through an original New York-inspired street scene, jump over moving traffic, and web-swing from buildings, signs, masts, and cables. The city scrolls endlessly and shifts smoothly through morning, daytime, sunset, and night.

## Features

- **Stickman player in the style of Alan Becker's *Animator vs. Animation*** - uniform-width limbs, a plain round head, no face.
  He is not a sprite: the skeleton is posed from joint angles every frame, so there are **no asset files**.
  Smooth by construction: run / idle / swing poses come from a continuous phase (stride speed follows ground speed),
  every joint angle is a damped spring chasing the target pose, so limbs overshoot and settle (follow-through) and every move flows into the next, and limbs are drawn as anti-aliased capsules.
- **Spider-Man-inspired moveset, randomised per move:** every run, jump, fall, web shot, swing and landing picks a random pose variant (hunched or sprinting run, tucked / spread / layout swings, star-jump or crouched leaps, deep-crouch or one-hand landings) plus a small random nudge, and a fast release sometimes ends in a front or back somersault. Also idle crouch, web throw, double-jump tuck flip, superhero landing, hit and defeat. Web shots travel to their selected anchor before swing attachment; wall contact can enter an attached crawl state with alternating limb poses.
- Procedurally generated brick apartments, storefronts, fire escapes, water towers, subway entrances, crosswalks, and a scrolling multilane street.
- Traffic includes taxis, cars, buses, and trucks. Vehicles follow lanes, brake for red lights, accelerate on green, and keep safe spacing from traffic ahead; running into the side of a vehicle ends the run, but vehicle roofs are safe platforms (see "Street rules").
- A smooth 180-second day/night cycle changes the sky, city ambience, window lights, streetlights, signals, and vehicle headlights.
- Procedural parallax skyline, fonts, music and sound effects - everything is made in code.
- Pixel-perfect integer scaling that adapts to any phone resolution, with safe-area margins and touch targets sized from the screen DPI.
- **Swing boost:** landing with speed carried out of a swing gives a temporary run-speed bonus (2-5 s, bigger for faster swings), shown by a bar on the HUD.
- **Slide:** a short low skid that holds onto your speed (with three random slide poses and dust); pressing SLIDE just before landing slides straight out of the fall and lengthens the boost.
- Press-to-start title, clean menu / settings / controls screens, rebindable keyboard controls, a drag-and-drop touch layout editor and a saved best score.
- Continuous street-level ground with the original jump, slide, air-trick, web-swing, scoring, combo, pause, and touch-control systems preserved.

## Sprite sheets

`assets/spritesheet.tga` + `.txt` hold the fixed pixel art, grouped into categories (buildings, vehicles, people, sky, player, ui, font), and `assets/sheets/` splits the same sprites per category. The player poses, UI pieces, font glyphs and street props are baked from the game's own draw code, so they stay in sync with it. See `assets/SPRITESHEET.md` for names and pivots; regenerate with `tools/gen_spritesheet.sh`.

## Rooftop start and main menu

The main menu is the real game world: the player idles on the **opening rooftop** with the city (and live traffic) behind the menu panel. Pressing **PLAY** pans the camera from the menu framing to the gameplay framing over `MENU_SEQ_SECS`, then control starts on the spot (`beginRunFromMenu()`, nothing is rebuilt). Every run (including RESTART) begins on that rooftop because the street is deadly. The opening roof is the only standable roof (`Building::startRoof`, handled in `collide()`); the starting building also gets web poles like every other building, so every building is a web anchor. Tests: `tests/test_rooftop_start.cpp`. `startRun(true)` builds the idle menu scene.

## Street rules (fall damage, rideable vehicles)

- **The street is about fall damage, not instant death** (`src/falldamage.h`). The impact is your downward speed at touchdown: under 760 px/s (about 2 storeys) is free, 760-1150 px/s is a **HARD LANDING** (you survive but lose over half your speed and your combo), and 1150 px/s or more (about 5 storeys) ends the run with a pixel splat, then GAME OVER. A **roll** (press SLIDE just before touchdown, or land right after finishing an air trick) absorbs about 18 % of the impact, and the Jump Height upgrade raises both thresholds in proportion so jumping higher never means landing harder. Vehicle roofs and the opening rooftop never hurt.
- **Vehicle roofs are safe.** Land on a taxi, car, bus or truck and you ride it: you move with the vehicle (including when it brakes or accelerates). Steering back stands you still on the roof; with no input you drift slowly forward and can jump or web off. Running into a vehicle's *side* is still fatal.
- **Restart instantly** with the RESTART button, `R` or `Enter` on the GAME OVER screen (no reload; `startRun()` resets everything).
- Code: `collide()` (roof landing + street death), `stepPhysics()` (roof grip), `killPlayer(true)` (ground death). Tests: `tests/test_ground_vehicle.cpp`.

## Difficulty tiers (endless)

`src/difficulty.h` maps distance to a tier and a smooth ramp. Tiers: **BEGINNER** (0 m), **INTERMEDIATE** (400 m), **ADVANCED** (1,000 m), **EXPERT** (2,000 m), **MASTER** (3,500 m). The ramp is continuous (no jumps at tier edges), reaches 1.0 at MASTER and then creeps up to 1.25 by 8.5 km, so it never stops but never becomes unfair. It drives:
- **Run speed:** `230 + 230 x ramp` px/s before upgrades.
- **Traffic:** vehicles spawn up to 40 % closer together and drive up to 37 % faster. Beginner traffic is taxis and cars only; buses unlock at Intermediate, trucks at Advanced, motorcycles at Expert.
- **Street crates** (from 120 m): wooden crates in the run path. Variety grows with the tier (small, wide, tall, double) and they get more frequent, but the minimum gap is always one full jump plus a landing margin at the current speed, they are never taller than a normal jump clears, and none is placed within 220 px of a vehicle.
- **Buildings:** the existing rooftop-obstacle and avenue-gap scaling, capped at 1.0 so every gap stays swingable.
The current tier is shown under the score and announced when it changes. Tests: `tests/test_difficulty.cpp`.

## Crates, vaulting and new moves

- Running into a crate on foot triggers an automatic **one-handed vault** (`F_VAULT`): plant the front hand, swing the legs over, push off. The hop is sized to the crate and your speed, you can also jump over or land on top, and a crate never kills (clipping one in mid-air just bumps you off). Air tricks will not start if they would end inside a crate.
- **Roll** (`F_ROLL`): a forward roll on landing (see Street rules). Hitbox and physics are unchanged, it only absorbs impact and keeps your speed.
- **Backflip / front flip** now have separate poses (`F_BACKFLIP`, `F_FLIP`), and every flip opens up (`F_FLIPOPEN`) for the last 22 % so the feet reach for the landing. Landing crouch depth scales with impact.
- Animation is visual only: collision boxes and physics are exactly as before. Tests: `tests/test_street_crates.cpp`, `tests/test_fall_damage.cpp`.

## Sky and skyline

Lighting uses one clock, `gSkyTime`: the menu is pinned to golden hour (stable, no day/night flicker); a run starts in the late afternoon and drifts through sunset to night. The sky is a dithered gradient texture rebuilt on resize; the skyline is three procedurally generated parallax strips (far haze, mid, near) that wrap seamlessly, plus clouds, sun and moon. Everything is original art generated in code.

**Bug fixed:** `blendRgb()` subtracted unsigned channel values, so any channel getting darker wrapped around (undefined behaviour). That corrupted sky, skyline and street colours (garish bands, black areas, flicker that differed per CPU). Tests: `tests/test_sky.cpp`.

### Rendering without SDL
`tests/stub_gfx/SDL.h` is a software SDL used by `tests/shot.cpp` to render real frames to PPM at any resolution: `g++ -std=c++17 -O1 -Itests/stub_gfx tests/shot.cpp -o /tmp/shot && /tmp/shot 1280 720 menu 0 0 0` (args: width height tag time menuT mode; mode 0 menu, 1 backdrop, 2 gameplay, 3 on a vehicle). `tests/run_all.sh` builds and runs every `tests/test_*.cpp` against the stub SDL and prints PASS / FAIL / COMPILE-ERROR per test (it exits non-zero unless all pass). The same tests are available through CMake: `cmake -S . -B build -DBUILD_TESTING=ON && cmake --build build && ctest --test-dir build --output-on-failure`.
Tests that need free space below the player define `PCITY_TEST_STREET_Y` (moves the deadly street down; test builds only, the shipped value stays 0). `tests/test_bot_smoke.cpp` is a loose playability baseline on the real street.

## Wall climbing

Touch a building face while airborne and holding the web button (SWING) to cling to the wall. Keep holding to climb, let go to slide down, and JUMP kicks you away; holding SWING as you leave flows into a web swing. Ground-level running stays on the street, so buildings remain scenery and swing anchors rather than rooftop platforms.

## Air tricks

Tap **SLIDE** while high in the air (no extra button). What you get depends on when you tap: rising = **front flip** (steer back for a **back flip**), right at the top of the arc = **twist** (a perfect-timing bonus), falling = **cartwheel**. A trick only starts if it can finish before you land, so close to the street the same tap is the normal pre-landing slide. It pays when it completes: faster = more score, flipping through a near miss pays extra (or a small bonus if the near miss comes just after), and it feeds the combo and Flow meter. Landing mid-trick is SLOPPY (no reward, a short stumble). You need a fresh air action for each trick (jump, double jump, web release, wall kick or running off an edge), and tricking non-stop pays less. Tricks never affect collision. Tests: `tests/test_air_tricks.cpp`.

## Controls

| Action | Touch | Keyboard (default, rebindable) |
| --- | --- | --- |
| Steer | Slide a finger on the steer side of the screen | `A` / `D` |
| Jump / double jump | Tap the JUMP button | `Space` |
| Slide / air trick | Tap SLIDE on the street or just before landing; tap it high in the air for a trick | `S` |
| Web | Hold SWING in the air: the web picks a building or mast itself. Release to fly | Hold `Left Shift` |
| Wall climb | Hold SWING while touching a building face to stick; hold to climb, release to slide down, tap JUMP to kick off | Same keys |
| Pause | Pause button / Back button | `P` or `Esc` |

Menus: `Up` / `Down` to move, `Left` / `Right` to adjust sliders, `Enter` / `Space` to select, `Esc` to go back. The mouse also works (hover to highlight, click to select, and it acts as touch in-game).

### Customising controls

Open **CONTROLS** from the main menu or the pause menu. Choices are saved in `controls.txt` next to the save file.

- **Keyboard tab** - select a box, then press the new key. `Esc` cancels. If the key is already used, the two actions swap so nothing is left unbound. *Reset tab* restores the defaults.
- **Touch tab** - button size, button opacity, steering sensitivity and a **left-handed** mode that mirrors the whole layout (buttons and steer zone).
- **Edit layout** - drag the SWING, JUMP and SLIDE buttons anywhere on the screen; the shaded area shows the steer zone. *Reset* puts them back.

## Interface

The title opens on a **PRESS TO START** screen (tap, click or press any key). Menus use a clean, high-contrast style inspired by the Spider-Man games: white on ink, a single red accent, slanted highlight bars and thin rules. The spider emblem is an original shape drawn in code; there are still no asset files.

## Build (desktop)

Requires a C++17 compiler, CMake 3.16+ and the SDL2 development package.

```bash
# Debian / Ubuntu
sudo apt install build-essential cmake libsdl2-dev
# macOS
brew install cmake sdl2

cmake -S . -B build
cmake --build build
./build/nyc_pixel_runner
```

Without CMake on Linux / macOS:

```bash
g++ -std=c++17 -O2 src/main.cpp $(sdl2-config --cflags --libs) -o nyc_pixel_runner
```

On Windows use CMake with a vcpkg SDL2 install (`-DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/buildsystems/vcpkg.cmake`).

## Build (Android)

The game is plain SDL2, so it drops into SDL's stock Android project:

1. Clone [libsdl-org/SDL](https://github.com/libsdl-org/SDL) (2.x) and open its `android-project` folder in Android Studio.
2. Copy `src/main.cpp` and `src/*.h` into `android-project/app/jni/src/`, and copy `assets/spritesheet.tga` + `assets/spritesheet.txt` into `android-project/app/src/main/assets/assets/` (the sprite sheet).
3. In `app/jni/src/Android.mk` set `LOCAL_SRC_FILES := main.cpp` and add `LOCAL_CPPFLAGS += -std=c++17`.
4. Build and run.

The code requests landscape-only SDL orientation hints, handles the Android back button and background / foreground pause. Android builds should also set `android:screenOrientation="landscape"` on the SDL activity in the Android manifest, since the Android manifest is supplied by the SDL Android wrapper and is not included in this source-only repository.

## Customising the stickman

Everything lives in the `STICKMAN BEGIN / END` block of `src/main.cpp`:

- `STK_BODY` / `STK_OUTLINE` - limb colour and the thin rim that keeps him readable on the night sky
  (try `0xFF8A1E` for the orange "Second Coming" look).
- `stkMakePose()` - every pose as a handful of joint angles (`stkRate()` sets how fast he eases between them) (degrees from straight down, positive = toward the facing side).
- `STK_THIGH`, `STK_SHIN`, `STK_UARM`, ... - limb lengths.

## Credits

Stickman style inspired by Alan Becker's *Animator vs. Animation*. This is an unofficial fan tribute and is not affiliated with or endorsed by Alan Becker or Alan Becker Productions.

## License

[MIT](LICENSE) - Copyright (c) 2026 xzestqtips (zkqruvz).

## Skill upgrades, coins and rebirth
- Tap the spider-web **UPGRADES** icon on the main menu or game-over screen. Every 200 m travelled earns 15 coins. Coins, levels and rebirths are saved in `progress.txt` next to `save.txt`.
- Five skills (logic in `src/progression.h`):

| Skill | Effect per level | Price | Max level | Rebirth |
| --- | --- | --- | --- | --- |
| Run Speed | +0.25 | 500 flat | 50 | 1,000 coins, up to 50 |
| Swing Speed | +0.20 | 750 flat | 50 | 5,000 coins, up to 50 |
| Jump Height | +1.2 % launch speed (cap +30 %, about 1.7x height); also raises fall tolerance | 300, +35 per level | 25 | none |
| Air Control | +4 % mid-air steering (up to 2.2x; hard cap 3x) | 250, +25 per level | 30 | none |
| Web Control | +3 % steering force on the web (up to 1.9x; hard cap 2.2x) | 400, +30 per level | 30 | none |

- Maxing a new skill costs about 18,000 (Jump), 18,400 (Air) and 25,000 (Web) coins, in line with maxing Run Speed (25,000). Rebirth (Run and Swing only, needs level 50) resets that skill's level and adds a permanent +0.1x multiplier. Total speed = (1 + level bonus) x (1 + 0.1 x rebirths), capped at 8x in physics.
- **Save format:** `progress.txt` is now `PROG2 coins <5 levels> <5 rebirths>`. Old `PROG1` files still load (new skills start at level 0), damaged files are rejected without touching your data, and out-of-range values are clamped. Tests: `tests/test_progression.cpp`, `tests/test_abilities.cpp`, `tests/test_game.cpp`.

## Web targeting

There is no aim stick and no Swing Assist setting. Press SWING in the air and `pickAnchor()` in `src/main.cpp` casts a fan of rays (plus rays at mast tips, crane jibs and sign tops), scores the candidates with a short swing simulation, and the web flies to the best one. Hold SWING to stay attached, release to fly. If nothing is in reach you get a small puff and can press again. Limits are the `PICK_*` constants.

## Swing feel

- **Flow** (`gFlow`, the thin bar under the chain text): grows with good releases, fades when you stop swinging (fast on the ground, slowly in the air). Full flow makes the swing pump up to 60 % stronger and raises the speed cap a little.
- **Perfect release:** let go while rising forward at roughly 25-55 degrees with some speed (`releaseEval()`), after at least 0.35 s on the rope. You get the normal fast-release boost plus an extra 8-18 %, eased in over 0.32 s, a PERFECT popup with a streak counter, bonus points, a gold burst, a short camera kick, a tiny shake (respects CAMERA SHAKE) and a rising chime.
- **Body:** on the rope the stickman leans into the direction of travel the faster he goes; in flight he streamlines along the flight path above 650 px/s.
- **Camera:** looks further ahead and slightly up/down with speed; punches forward on a perfect release; no zoom, so pixels stay crisp.
- **Trails:** 16 fading pixel afterimages above 650 px/s while airborne (gold after a perfect release; half as many with FEWER PARTICLES).
- **Auto assist:** the 100 % auto-release now waits for the perfect window (or a later point in the arc), and the auto picker also aims rays at mast tips, crane jibs and sign tops. A web is never re-shot after a release below 100 % unless you press SWING again.
- Tests: `tests/test_swing_feel.cpp`.

## Swings that meet a wall

A web swing that runs into a building face no longer just sticks to it (`swingMeetsWall()` in `src/main.cpp`):
- **Mantle:** close under the roof edge and still rising, the player lets go with a pop that clears the lip before descending back to street level.
- **Rope wrap:** lower down, the rope wraps round the roof corner (at most twice per swing) and the swing carries on in front of the wall with the same rope-length rules.
- Otherwise (no roof corner above you, or after two wraps) the old wall-cling applies. The swing look-ahead treats a wrap as a small penalty instead of a dead end. Tests: `tests/test_wall_wrap.cpp`.

## Flow combo

One combo system sits on top of the existing flow/score code (`src/combo.h`, pure logic; glue is `comboHit()` / `nearMissTick()` in `src/main.cpp`). Its points go into the normal `bonus` score and every skill also nudges the flow meter, which now drains at half speed while a combo is alive.

| Skill | When it counts |
|---|---|
| PERFECT | a perfect release (the existing 25-55 degree window) |
| FAST SWING | a committed let-go (over 0.35 s) faster than about 90 % of your peak swing speed for your Swing Speed level (never under 450 px/s) |
| TRICK | an air jump flip or a wall jump |
| NEAR MISS | low flight within 26 px of street level at 400+ px/s, until you rise clear |
| SMOOTH LANDING | pressing slide just before touchdown |
| LONG SWING | landing after 5 or more swings in a row without touching the ground (20 x chain base points, +0.5x) |

- **Variety builds the multiplier.** A skill that is new to the last three adds +0.30x, one seen in the last three +0.15x, the same skill again only +0.05x and 60 % points. The same skill can not re-score inside a short cooldown (0.3-0.8 s), so button mashing goes nowhere.
- **Cap:** 5.0x (`combo::MAX_MULT`). Existing flat bonuses (swing chain, landing) stay unmultiplied; only skills are multiplied.
- **Milestones** follow the multiplier: GOOD 1.5x, GREAT 2.5x, AMAZING 3.5x, LEGENDARY 4.5x, each with a one-off reward (25 / 60 / 120 / 250). Effects grow with the tier: bigger bursts, camera punch, tinted afterimages, and from AMAZING a soft edge light (turned off by Fewer particles).
- **Decay:** the window is 4.0 s and shrinks to 2.6 s at LEGENDARY (runs out 1.5x faster on the ground). After that the multiplier drains 0.9x per second and blinks red; a new skill picks the combo back up. A crash ends it at once.
- **Best combo** (hits, points, peak multiplier) is saved in `combo.txt` and shown on the game-over screen.
- Tuning knobs are the constants at the top of `src/combo.h`. Tests: `tests/test_combo.cpp` (logic) and `tests/test_combo_game.cpp` (real game code: score, crash, near miss, releases, landings, save).

## Endless NYC streets and traffic

The block generator keeps skyscraper faces and rooftop props as web anchors while the player runs on a continuous street plane. Each block gap creates a signalized intersection. Cars are simulated in two opposing lanes: they brake for red lights and slower vehicles, then resume on green. Traffic is generated ahead of the camera and retired behind it, so the route remains endless. Vehicle contact is a real gameplay collision, and the existing Spider-Sense warns about approaching traffic.

The day/night loop lasts 180 seconds. Sky gradients, building tint and windows, streetlights, traffic signals, and headlight beams share the same phase.

Run the headless traffic/gameplay checks with:

```bash
g++ -std=c++17 -O2 -Itests/stub -o /tmp/test_nyc_traffic tests/test_nyc_traffic.cpp && /tmp/test_nyc_traffic
```

## Web zip, dive and Spider-Sense
- **Web zip (point launch):** tap **SLIDE while swinging** (keyboard: **Z** any time in the air). The web goes to a forward, elevated anchor 140-560 px away (chosen by the normal anchor picker, with the current swing anchor excluded) and pulls you there with bounded acceleration (no teleport, collision still runs). You leave the anchor with your speed (capped) plus a small upward pop, keep full control, and can swing, trick or wall-grab straight away. 1.1 s cooldown. A jump cancels a zip and keeps its speed. The cooldown is 0.5 s if the zip is interrupted.
- **Dive:** hold **SLIDE in the air** for about 0.2 s (keyboard: hold **X**). Extra downward pull (bounded), head-first pose, momentum kept. Ends on release, landing, wall, web attach or after 1.3 s (then 0.8 s cooldown).
- **Spider-Sense:** short tick marks around the head toward a likely collision, red screen edges and "!" when it is imminent. Looks 0.8 s ahead along your trajectory, stays silent while safe or while the web is held against a wall (you can grab it).
- Tests: `tests/test_zip_dive.cpp`. No new on-screen buttons were added and the controls save format is unchanged.

## Swing feel pass
- The automatic swing "pump" is now much weaker (120 vs 190) and the release timing bonus is smaller (up to about +20 % instead of +32 %), so speed comes mostly from gravity and the arc. Release never changes direction or resets velocity.
- Free fall: the camera looks further down while falling fast and further ahead at high speed; pixel-art wind streaks appear near the screen edges above about 650 px/s (hidden with Reduced effects on); wind sound now follows total speed, including falling.
- Safety: non-finite positions/velocities are repaired and velocity is clamped to +-4000 px/s every step. Tests: `tests/test_swing_momentum.cpp`.

## Display
The game renders at the device's real resolution with a whole-number pixel scale (round(short side / 360)), so the pixel art is sharp and unchanged. The picture is rounded up to cover the screen (no black bars; under one game pixel is cropped at the right/bottom). The visible height therefore varies by device (about 300-450 game pixels). Tests: `tests/test_fit_screen.cpp`.

## City art (New York look)

Facades are life-size: a storey is 96 px (about 3.2 m next to the 1.75 m stickman). Six styles (glass tower, limestone, red brick, brownstone, warehouse loft, terracotta) are defined by `makeTile()` and `WIN_GEO`; `drawFacade()` adds the cornice, stone ground floor, quoins and street shade, and `drawFireEscape()` lines fire escapes up with the windows. In the street the skyline stands on the horizon (`drawBackdrop(..., streetLevel)`). Preview: `tests/shot_city.cpp`. Playability check: `tests/bot_swing.cpp`.

## Swing feel (Marvel-style) tuning
- Rope whip: the effective rope is reeled in ~13% from just before the lowest point through the upswing, conserving angular momentum (`reelStep`).
- Chain build-up: swing damping 0.12 -> 0.06 (down to 0.02 with Flow/chain), +3% speed per extra web in a chain (max 5), stronger pump, speed cap rises with Flow and chain.
- Release: instant pop along the velocity (60% of the boost, rest eases in), ~0.15 s at 45% gravity, forced releases get a boost floor.
- Web attach: flight time capped at 0.2 s, with a pull toward the anchor and 60% gravity while it travels.
- Camera: zoom eases from 1.0 to 0.9 at speed (extra scratch texture, only drawn while zoomed; off with Reduced effects), plus more speed lines.
- Pose/web: body tilt follows the rope and leans into travel at speed; the web line sags when slack and straightens when taut.
Tests: `tests/run_all.sh` (new: `tests/test_swing_marvel.cpp`).

## Untouchable buildings
Building walls no longer collide with the player (no hit, wall cling, climb, wrap or death). Every roof is a landing spot when you come down onto it from above; rooftop objects stay solid and webs still attach to buildings. The old behavior is one switch away: `gWallsSolid = true` in `src/main.cpp` (the wall tests set it). New test: `tests/test_untouchable_walls.cpp`.

## Web Catch (rescues)
A non-combat Spider-Man moment: civilians fall from the sky ahead of you (`rescueTick()` in `src/main.cpp`, roughly one every 1800-3200 px once you are 2000 px into the run). Touch one while airborne (38 px reach) to catch it: it pays `RESCUE` combo points (a new `combo::RESCUE` skill, so it counts toward variety and the multiplier), adds Flow, and chains for a streak bonus (up to +100). A civilian that reaches the street is lost and resets the streak (no damage to you). Fallers drift a little, fall at up to 620 px/s, are drawn with a pulsing ring, and never use the world RNG. Not spawned behind the menu. Tuning: `FALLER_G`, `FALLER_TERM`, `CATCH_R`. Test: `tests/test_rescue.cpp`.

## Living city
Purely decorative life that costs no gameplay (no collision, no stored objects, no world RNG; everything is a function of world position and `gTime`):
- **Pedestrians** stroll along the sidewalk in every block (1-3 per 300 px, varied coats, some carry bags), stepping out of and into doorways with a fade; they dim at night.
- **Manhole steam** plumes drift up from the street every so often (hidden with FEWER PARTICLES).
- **News helicopter** crosses the skyline about every 70 s with a blinking tail light, a flickering rotor and a search-light beam at night.
- **Pigeon flock** (V formation, flapping) crosses the sky in daylight about every 26 s (4 birds with FEWER PARTICLES).
Code: `drawSkyLife()` (called at the end of `drawBackdrop()`) and `drawCityLife()` (called from `drawStreetScene()`) in `src/main.cpp`.

## Sprite sheet
All fixed-size pixel art now lives in `assets/spritesheet.tga` (uncompressed 32-bit TGA, 1024x632) with `assets/spritesheet.txt` listing `name x y w h` for each of the 153 sprites, instead of being drawn by code each run:
- building facade tiles (`tile_<style>_<variant>`, `far_<n>`), vehicles (`car_<type>_<colour>_<e|w>_<lean>`: taxi, car, bus, truck, motorbike in each paint colour, facing east and west), rescue civilians (`faller_<shirt>_<frame>`), pedestrians (`ped_<coat>_<bag>_<step>_<e|w>`), the news helicopter (`heli_<frame>`) and pigeons (`bird_<frame>`).
- `src/sprites.h` loads the sheet (looks in `assets/`, then `../assets/`) and draws sprites with `sprDraw()`. If the sheet is missing the game still runs: buildings become flat grey and vehicles/people are not drawn (a message is printed).
- Edit the TGA in any pixel editor (keep the names and rectangles), or change the painters in `tools/sprite_art.h` and run `tools/gen_spritesheet.sh` to regenerate both files.
- Also drawn from the sheet now (code fallback if the sheet or a sprite is missing): every `text()` glyph (`font_<hex>`, tinted), the rooftop props (chimney, dish, water tower, antenna, helipad, shed, billboards), street crates and the fixed-size rooftop obstacles. Sprite pivots are read from columns 7 and 8 of `spritesheet.txt`. See `assets/SPRITESHEET.md` for exactly what is and is not wired.
- Still drawn in code by design: the stickman (rendered from joint angles every frame at any rotation), sky and skyline gradients, day/night lighting, UI buttons and icons, particles, web lines, and effects such as brake lights, headlight beams, rings and steam. Shop fronts, billboards, rooftop props and landmarks are built from parameters per building, so they were not moved.

## Marvel-style movement: buffered web tap, release launch shape, dive-to-swing
Code: `releaseShape()`, `diveToSwing()` / `diveConvertBonus()` and the web-tap buffer in `updateGame()` (`src/main.cpp`); tests in `tests/test_launch_dive.cpp`.
- **Buffered web tap** (`WEB_BUF` = 0.15 s): a web tap made while it cannot fire yet (still on the ground or a wall, or no anchor in reach) is kept and retried every 0.05 s, so a slightly early tap still attaches. Releasing the button, or the time running out, drops it. A tap with an anchor in reach fires on the same frame as before.
- **Release launch shape**: where on the arc you let go steers the launch. Released high (velocity 28 to 58+ degrees above the horizontal, at speed) the velocity is turned up by as much as ~12 degrees and the low-gravity hang is up to 1.9x longer: a high ballistic jump. Released flat near the bottom (about 20 degrees down to -25) it is flattened toward the horizontal, +7 % speed and almost no hang: a low fast dive. Between 20 and 28 degrees nothing changes. The speed cap still applies; failed releases and wall vaults are not shaped.
- **Dive-to-swing**: attaching a web during a dive (or up to 0.35 s after it ends) while hanging below the anchor turns the speed the rope would cancel into speed along the swing (`DIVE_CONVERT` = 0.45 of it beyond `DIVE_MIN_VR`/2, capped by the swing speed cap), shows DIVE SWING and adds a little Flow.
