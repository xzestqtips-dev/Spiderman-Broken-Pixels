#pragma once
// Pixel-art painters. These run ONLY in tools/gen_spritesheet.cpp (never in the game): they draw every fixed-size sprite into
// an Img, and the generator packs them into assets/spritesheet.tga. Needs the definitions from src/main.cpp (Img, Rng, TILE, WIN_GEO, ...).

// ---- building tiles (96x96 repeating facades) and the distant-city tiles (32x32) ----
static void paneLit(Img& im, Rng& r, int x, int y, int w, int h, u32 dark, u32 darkTop) {
    const float f = r.f();
    if (f < 0.22f) {   // warm lamp light, a curtain line near the bottom
        im.fill(x, y, w, h, 0xFFFFD98A); im.fill(x, y + h * 2 / 3, w, h - h * 2 / 3, 0xFFD9A55C); im.fill(x, y, w, 2, 0xFFFFEBB8);
    } else if (f < 0.26f) {   // TV glow
        im.fill(x, y, w, h, 0xFF9CCBE6); im.fill(x, y + h / 2, w, h - h / 2, 0xFF6FA0C4);
    } else {
        im.fill(x, y, w, h, dark); im.fill(x, y, w, std::max(2, h / 3), darkTop);   // sky reflection in the upper third
        im.fill(x, y, w, 1, darkTop + 0x00101010);
    }
}
static Img makeTile(int st, int var) {
    Img im(TILE, TILE);
    Rng r(1234u + st * 97u + var * 7919u);
    const WinGeo& g = WIN_GEO[st];
    auto brick = [&](u32 base, u32 mortar, u32 hi, u32 lo) {
        for (int y = 0; y < TILE; y++) for (int x = 0; x < TILE; x++) {
            const int row = y / 4;
            u32 c = base;
            if (y % 4 == 3 || (x + (row % 2) * 4) % 8 == 7) c = mortar;
            else {
                const u32 h = (u32)(x * 7 + y * 13 + row * 5) % 17u;
                if (h == 0) c = hi; else if (h == 1) c = lo;
            }
            im.set(x, y, c);
        }
    };
    for (int wr = 0; wr < g.rows; wr++) for (int wc = 0; wc < g.cols; wc++) { (void)wr; (void)wc; }
    switch (st) {
        case 0: {   // glass and steel: dark mullions, spandrel band at every floor
            im.fill(0, 0, TILE, TILE, 0xFF273648);
            for (int wr = 0; wr < g.rows; wr++) {
                const int ty = wr * g.rowPitch;
                im.fill(0, ty + 43, TILE, 5, 0xFF1E2B3A); im.fill(0, ty + 43, TILE, 1, 0xFF5B7691);
                for (int wc = 0; wc < g.cols; wc++) {
                    const int tx = wc * g.colPitch;
                    paneLit(im, r, tx + g.x0, ty + g.y0, g.w, g.h, 0xFF2F445C, 0xFF42607F);
                    im.fill(tx, ty, 3, 48, 0xFF16212D);
                    for (int k = 0; k < 5; k++) im.set(tx + 8 + k * 2, ty + 28 - k * 2, 0xFF6D8CAA);   // glint
                }
            }
        } break;
        case 1: {   // limestone: piers, recessed windows, carved lintels
            for (int y = 0; y < TILE; y++) for (int x = 0; x < TILE; x++) im.set(x, y, ((x * 7 + y * 13) % 11 == 0) ? 0xFFA89C84 : 0xFFB6AA91);
            for (int wc = 0; wc < g.cols; wc++) {
                const int tx = wc * g.colPitch, x = tx + g.x0, y = g.y0;
                im.fill(tx, 0, 7, TILE, 0xFFC6BAA0); im.fill(tx + 7, 0, 1, TILE, 0xFF978B74);
                im.fill(x - 2, y - 5, g.w + 4, 5, 0xFFD3C7AD); im.fill(x - 2, y - 1, g.w + 4, 1, 0xFF8B8068);
                im.fill(x - 1, y - 1, g.w + 2, g.h + 2, 0xFF8F8470);
                paneLit(im, r, x, y, g.w, g.h, 0xFF2A2833, 0xFF3A4252);
                im.fill(x, y + g.h / 2, g.w, 1, 0xFF8F8470);
                im.fill(x - 2, y + g.h, g.w + 4, 3, 0xFFD3C7AD); im.fill(x - 2, y + g.h + 3, g.w + 4, 1, 0xFF8B8068);
                im.fill(x + 3, y + g.h + 9, g.w - 6, 10, 0xFFA99D85); im.fill(x + 4, y + g.h + 10, g.w - 8, 8, 0xFFB9AD94);
            }
            im.fill(0, 93, TILE, 3, 0xFFA09478); im.fill(0, 93, TILE, 1, 0xFFD3C7AD);
        } break;
        case 2: {   // red brick walk-up with stone lintels and sills
            brick(0xFF7C3F37, 0xFF4F2A27, 0xFF8C4A41, 0xFF6C352F);
            for (int wc = 0; wc < g.cols; wc++) {
                const int x = wc * g.colPitch + g.x0, y = g.y0;
                im.fill(x - 3, y - 5, g.w + 6, 5, 0xFFD0C4AB); im.fill(x - 3, y - 1, g.w + 6, 1, 0xFF8E8268);
                im.fill(x - 1, y - 1, g.w + 2, g.h + 2, 0xFF2C1B1A);
                paneLit(im, r, x, y, g.w, g.h, 0xFF222A35, 0xFF34404F);
                im.fill(x, y + g.h / 2 - 1, g.w, 2, 0xFF2C1B1A); im.fill(x + g.w / 2, y, 1, g.h, 0xFF2C1B1A);
                im.fill(x - 3, y + g.h, g.w + 6, 4, 0xFFD0C4AB); im.fill(x - 3, y + g.h + 4, g.w + 6, 1, 0xFF3A201D);
            }
            im.fill(0, 93, TILE, 3, 0xFFB8AC93); im.fill(0, 93, TILE, 1, 0xFFD0C4AB);   // stringcourse
        } break;
        case 3: {   // brownstone: rusticated courses, arched windows
            for (int y = 0; y < TILE; y++) for (int x = 0; x < TILE; x++) {
                u32 c = 0xFF6B5148;
                if (y % 8 == 7) c = 0xFF54413A; else if ((x * 5 + y * 11) % 13 == 0) c = 0xFF76594F;
                im.set(x, y, c);
            }
            for (int wc = 0; wc < g.cols; wc++) {
                const int x = wc * g.colPitch + g.x0, y = g.y0;
                im.fill(x - 3, y - 3, g.w + 6, g.h + 6, 0xFF9C8A78);
                paneLit(im, r, x, y, g.w, g.h, 0xFF211D26, 0xFF332F3E);
                for (int k = 0; k < 6; k++) { im.fill(x - 3, y - 3 + k, 3 - std::min(3, k / 2), 1, 0); im.fill(x + g.w + std::min(3, k / 2), y - 3 + k, 3 - std::min(3, k / 2), 1, 0); }
                im.fill(x + g.w / 2, y, 1, g.h, 0xFF9C8A78); im.fill(x, y + g.h / 3, g.w, 1, 0xFF9C8A78);
                im.fill(x - 4, y + g.h + 3, g.w + 8, 4, 0xFFA8977F); im.fill(x - 4, y + g.h + 7, g.w + 8, 1, 0xFF42322C);
            }
            im.fill(0, 92, TILE, 4, 0xFF8A7664); im.fill(0, 92, TILE, 1, 0xFFAA977F);
        } break;
        case 4: {   // warehouse loft: dark brick, big steel-framed windows
            brick(0xFF58423B, 0xFF3A2B27, 0xFF664C44, 0xFF4B3730);
            for (int wc = 0; wc < g.cols; wc++) {
                const int x = wc * g.colPitch + g.x0, y = g.y0;
                im.fill(x - 3, y - 3, g.w + 6, g.h + 6, 0xFF1E2229);
                paneLit(im, r, x, y, g.w, g.h, 0xFF1F2936, 0xFF2F3E52);
                im.fill(x + g.w / 3, y, 2, g.h, 0xFF1E2229); im.fill(x + g.w * 2 / 3, y, 2, g.h, 0xFF1E2229);
                im.fill(x, y + g.h / 3, g.w, 2, 0xFF1E2229); im.fill(x, y + g.h * 2 / 3, g.w, 2, 0xFF1E2229);
                im.fill(x - 4, y + g.h + 3, g.w + 8, 3, 0xFF8A8478);
            }
        } break;
        default: {   // terracotta deco: fluted piers, green copper spandrels
            for (int y = 0; y < TILE; y++) for (int x = 0; x < TILE; x++) im.set(x, y, (x % 6 < 2) ? 0xFFBFAD8E : 0xFFCDBB9C);
            for (int wc = 0; wc < g.cols; wc++) {
                const int x = wc * g.colPitch + g.x0, y = g.y0;
                im.fill(x - 4, y - 4, g.w + 8, g.h + 8, 0xFFD9CBAD);
                im.fill(x - 3, y - 3, g.w + 6, g.h + 6, 0xFFA89874);
                paneLit(im, r, x, y, g.w, g.h, 0xFF2B2A33, 0xFF3C4150);
                im.fill(x + g.w / 2, y, 1, g.h, 0xFFA89874);
            }
            im.fill(0, 84, TILE, 10, 0xFF5E8F86); im.fill(0, 84, TILE, 1, 0xFF8FC0B5);
            for (int x = 3; x < TILE; x += 8) { im.fill(x, 87, 3, 3, 0xFF3F6B64); }
        } break;
    }
    return im;
}
static Img makeFar(int var) {
    Img im(32, 32);
    Rng r(777u + var * 31u);
    im.fill(0, 0, 32, 32, 0xFF1B2144);
    for (int gy = 0; gy < 5; gy++) for (int gx = 0; gx < 5; gx++) {
        float f = r.f();
        u32 c = f < 0.22f ? 0xFFB8A56A : (f < 0.30f ? 0xFF6A92B8 : 0xFF161B38);
        im.fill(gx * 6 + 2, gy * 6 + 3, 2, 2, c);
    }
    return im;
}

// ---- helpers ----
static void fillA(Img& im, int x, int y, int w, int h, u32 rgb, int a = 255) {   // straight-alpha "over" blend into an Img
    for (int yy = y; yy < y + h; yy++) for (int xx = x; xx < x + w; xx++) {
        if (xx < 0 || yy < 0 || xx >= im.w || yy >= im.h) continue;
        u32& d = im.p[(size_t)yy * im.w + xx];
        const float sa = a / 255.0f, da = (d >> 24) / 255.0f, oa = sa + da * (1.0f - sa);
        if (oa <= 0) continue;
        u32 o = (u32)(oa * 255.0f + 0.5f) << 24;
        for (int sh = 16; sh >= 0; sh -= 8) {
            const float s = (float)((rgb >> sh) & 255), dd = (float)((d >> sh) & 255);
            o |= (u32)std::min(255.0f, (s * sa + dd * da * (1.0f - sa)) / oa + 0.5f) << sh;
        }
        d = o;
    }
}

// ---- vehicles: facing east (or mirrored west), life-size box, no brake lights / glints / headlight beams (those stay dynamic) ----
static Img paintCar(int type, u32 color, bool east, int lean) {
    const float S = trafficScale(type);
    const int RW = (int)trafficWidth(type), RH = (int)trafficHeight(type);
    const int w = (int)lroundf(trafficWidth(type) / S), h = (int)lroundf(trafficHeight(type) / S);
    Img im(RW, RH);
    auto R = [&](int lx, int ly, int lw, int lh, u32 c, int a = 255) {
        const int x0 = (int)lroundf(lx * S), x1 = (int)lroundf((lx + lw) * S), y0 = (int)lroundf(ly * S), y1 = (int)lroundf((ly + lh) * S);
        const int pw = std::max(lw > 0 ? 1 : 0, x1 - x0), ph = std::max(lh > 0 ? 1 : 0, y1 - y0);
        fillA(im, east ? x0 : RW - x0 - pw, y0, pw, ph, c, a);
    };
    const u32 md = blendRgb(color, 0x0C0E18, 0.25f), lt = blendRgb(color, 0xFFFFFF, 0.42f);
    const u32 glass = 0x8FC3D6, glassHi = 0xCFEAF2, ink = 0x14161E, trim = 0xE9E3D2;
    R(2, h - 3, w - 4, 2, 0x000000, 70);                                  // contact shadow
    if (type == 4) {   // motorcycle + helmeted rider
        const u32 jacket = blendRgb(color, 0x0C0E18, 0.35f);
        for (int k = 0; k < 2; k++) { const int wx = k ? w - 10 : 0; R(wx, h - 9, 9, 9, ink); R(wx + 1, h - 8, 7, 7, 0x2A2D36); R(wx + 3, h - 6, 3, 3, 0x9AA0AA); }
        R(5, h - 12, w - 12, 4, color); R(5, h - 12, w - 12, 1, lt);
        R(w - 8, h - 14, 3, 2, 0x8A9098); R(w - 3, h - 12, 2, 2, 0xFFF1B2);
        R(2, h - 11, 4, 2, ink);
        R(4 + lean, 5, 7, 8, jacket); R(8 + lean, 3, 4, 8, jacket);
        R(6 + lean, 0, 6, 6, ink); R(7 + lean, 1, 5, 4, color); R(9 + lean, 2, 3, 2, glass);
        R(0, h - 12, 2, 2, 0xAA3939);                                      // tail light (dim; braking overlay is dynamic)
        return im;
    }
    switch (type) {
        case 2: {   // city bus
            R(0, 1, w, h - 8, ink); R(1, 2, w - 2, h - 10, color);
            R(1, 2, w - 2, 2, lt); R(1, h - 15, w - 2, 3, 0xE9C544); R(1, h - 12, w - 2, 4, md);
            for (int i = 0; i < 5; i++) { R(5 + i * 13, 6, 10, 9, ink); R(6 + i * 13, 7, 8, 7, glass); R(6 + i * 13, 7, 8, 2, glassHi); }
            R(w - 11, 5, 9, 11, ink); R(w - 10, 6, 7, 9, glass);
            R(w - 18, 0, 0, 0, ink);
            R(12, 0, 22, 3, ink); R(13, 0, 20, 2, 0xA9B0B8); R(w - 13, 3, 11, 3, 0xF2F2E8);
            R(w - 3, h - 13, 3, 4, 0xFFF1B2);
        } break;
        case 3: {   // box truck
            const int boxW = w - 24;
            R(0, 1, boxW, h - 8, ink); R(1, 2, boxW - 2, h - 10, 0xE4E0D4); R(1, 2, boxW - 2, 2, 0xFFFFFF);
            R(1, h - 13, boxW - 2, 3, color); R(boxW - 3, 3, 2, h - 12, 0xB8B4A8);
            for (int i = 0; i < 4; i++) R(4 + i * 10, 5, 1, h - 16, 0xC8C4B8);
            R(boxW, 9, 24, h - 16, ink); R(boxW + 1, 10, 22, h - 18, color); R(boxW + 1, 10, 22, 2, lt);
            R(boxW + 12, 12, 10, 9, ink); R(boxW + 13, 13, 8, 7, glass); R(boxW + 13, 13, 8, 2, glassHi);
            R(w - 3, h - 13, 3, 4, 0xFFF1B2); R(w - 2, h - 9, 2, 3, 0x777E86);
        } break;
        default: {  // taxi (0) / city car (1)
            R(1, 10, w - 2, h - 15, ink); R(2, 11, w - 4, h - 17, color);
            R(2, 11, w - 4, 2, lt); R(2, h - 10, w - 4, 3, md);
            R(8, 3, w - 20, 9, ink); R(9, 4, w - 22, 8, color); R(9, 4, w - 22, 1, lt);
            R(10, 5, w - 25, 6, ink); R(11, 6, (w - 27) / 2 - 1, 5, glass); R(12 + (w - 27) / 2, 6, (w - 27) / 2 - 1, 5, glass); R(11, 6, 4, 2, glassHi);
            if (type == 0) {
                R(w / 2 - 6, 0, 11, 4, ink); R(w / 2 - 5, 0, 9, 3, 0xF8E7A1); R(w / 2 - 4, 0, 7, 1, 0xFFF8D8);
                for (int x = 5; x < w - 6; x += 6) R(x, h - 13, 3, 2, ink);
            } else R(w / 2 - 3, 2, 7, 1, trim, 160);
            R(w - 3, h - 14, 3, 3, 0xFFF1B2);
        } break;
    }
    R(0, h - 13, 2, 3, 0xAA3939);                                          // tail light (dim; braking overlay is dynamic)
    for (int k = 0; k < 2; k++) { const int wx = k ? w - 12 : 4; R(wx, h - 8, 9, 7, ink); R(wx + 2, h - 6, 5, 5, 0x2A2D36); R(wx + 3, h - 5, 3, 3, 0x9AA0AA); }
    return im;
}

// ---- people, aircraft, birds (all drawn facing east; the generator also bakes the west-facing mirror where it matters) ----
static Img paintFaller(int shirt, int flap) {   // origin of the sprite = (6, 10)
    static const u32 SHIRT[4] = {0xE0524A, 0x4AA3E0, 0x5CC97A, 0xE0B84A};
    Img im(13, 18); const int x = 6, y = 10;
    fillA(im, x - 2, y - 9, 4, 4, 0xF2C9A0);
    fillA(im, x - 3, y - 5, 6, 8, SHIRT[shirt & 3]);
    fillA(im, x - 3, y + 3, 2, 5, 0x3A3F5C); fillA(im, x + 1, y + 3, 2, 5, 0x3A3F5C);
    fillA(im, x - 6, y - (flap ? 10 : 6), 2, 5, 0xF2C9A0);
    fillA(im, x + 4, y - (flap ? 6 : 10), 2, 5, 0xF2C9A0);
    return im;
}
static Img paintPed(int coat, int bag, int step, bool east) {   // origin = (4, 12): x = feet centre, y = ground line
    static const u32 COAT[PED_COATS] = {0xB8453C, 0x3E6FA8, 0x4E9A66, 0xD0A23C, 0x7A4E99, 0x555B66};
    Img im(9, 12); const int sx = 4, fy = 12;
    fillA(im, sx - 1, fy - 12, 3, 3, 0xEAC49A);
    fillA(im, sx - 2, fy - 9, 5, 6, COAT[coat % PED_COATS]);
    fillA(im, sx - 2 + step, fy - 3, 2, 3, 0x2F3445); fillA(im, sx + 1 - step, fy - 3, 2, 3, 0x2F3445);
    if (bag) fillA(im, sx - 4 + (east ? 7 : 0), fy - 7, 2, 4, 0xE8E0C8);
    return im;
}
static Img paintHeli(int rotorFrame) {   // origin = (19, 3): the helicopter's reference point is at (19, 3)
    Img im(35, 11); const int x = 19, y = 3;
    const u32 body = 0x4A5668;
    fillA(im, x - 7, y, 14, 6, body); fillA(im, x - 5, y - 1, 8, 2, body);
    fillA(im, x - 5, y + 1, 5, 3, 0x9FD4FF);
    fillA(im, x - 18, y + 1, 12, 2, body); fillA(im, x - 19, y - 2, 2, 5, body);
    fillA(im, x - 6, y + 7, 12, 1, body);
    fillA(im, x - (rotorFrame ? 15 : 11), y - 3, rotorFrame ? 30 : 22, 1, 0x20242E, 190);
    return im;
}
static Img paintBird(int up) {   // origin = (3, 2)
    Img im(9, 4); const int x = 3, y = 2;
    fillA(im, x, y, 3, 2, 0x5B6070);
    fillA(im, x - 3, y - (up ? 2 : 0), 3, 1, 0x5B6070); fillA(im, x + 3, y - (up ? 2 : 0), 3, 1, 0x5B6070);
    return im;
}
