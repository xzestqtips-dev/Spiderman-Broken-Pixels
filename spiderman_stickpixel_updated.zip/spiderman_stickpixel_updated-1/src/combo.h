// ============================================================================
//  Flow combo: chained skills build a multiplier.  Pure C++ (no SDL) so it can be unit tested.
//
//  One combo system, fed by the events the game already has (perfect release, air trick, near miss,
//  fast swing, perfect landing, long swing sequence).  Points go straight into the game's existing
//  `bonus` score, and the flow meter (gFlow) is nudged from the same events.
//
//  * Multiplier grows by variety: a skill that is new to the last few events adds the most, the same
//    skill again adds almost nothing and pays less, so holding one button does not climb the ladder.
//  * Multiplier is capped at MAX_MULT.  Tiers (GOOD / GREAT / AMAZING / LEGENDARY) follow the multiplier.
//  * Inactivity: after the window runs out the multiplier drains back to 1.0x, then the combo ends.
//    A new skill during the drain picks the combo back up.  A crash ends it at once.
// ============================================================================
#pragma once
#include <algorithm>
#include <cstdio>
#include <string>

namespace combo {

enum Kind { PERFECT = 0, TRICK, NEAR_MISS, FAST, LAND, LONGCHAIN, STUNT, KIND_N };   // STUNT = a skill-based air trick (flip / twist / cartwheel)

static const float MAX_MULT   = 5.0f;    // scoring ceiling
static const float WINDOW     = 4.0f;    // seconds a combo survives with no new skill (tier 0)
static const float WINDOW_MIN = 2.6f;    // ...shrinks as the tier rises: higher tiers need a steady rhythm
static const float GROUND_RUSH = 1.5f;   // the window runs out faster while running on the ground
static const float DRAIN      = 0.9f;    // multiplier lost per second once the window is over
static const int   TIERS      = 4;
static const float TIER_AT[TIERS + 1] = {1.0f, 1.5f, 2.5f, 3.5f, 4.5f};   // multiplier needed for tier 0..4
static const int   TIER_BONUS[TIERS + 1] = {0, 25, 60, 120, 250};         // flat reward on reaching a tier (x1, not multiplied)

inline const char* tierName(int t) {
    static const char* const N[TIERS + 1] = {"", "GOOD", "GREAT", "AMAZING", "LEGENDARY"};
    return N[std::min(std::max(t, 0), TIERS)];
}
inline const char* kindName(int k) {
    static const char* const N[KIND_N] = {"PERFECT", "TRICK", "NEAR MISS", "FAST SWING", "SMOOTH LANDING", "LONG SWING", "AIR TRICK"};
    return N[std::min(std::max(k, 0), KIND_N - 1)];
}

// default base points per skill (before the multiplier)
static const float BASE_PTS[KIND_N] = {15.0f, 20.0f, 25.0f, 12.0f, 20.0f, 0.0f, 30.0f};
// the same skill can not be re-scored inside this many seconds (stops button spam)
static const float KIND_CD[KIND_N] = {0.0f, 0.5f, 0.6f, 0.8f, 0.3f, 0.0f, 0.35f};

struct Best { int count = 0; int pts = 0; float mult = 1.0f; };

struct State {
    float mult = 1.0f;       // current multiplier, 1..MAX_MULT
    int   count = 0;         // skills chained in this combo
    int   pts = 0;           // points earned by this combo
    float timer = 0;         // seconds left before the drain starts
    bool  draining = false;
    int   tier = 0;          // 0..4 (shown tier, follows mult with a little hysteresis)
    int   lastKind = -1;
    int   recent[3] = {-1, -1, -1};   // the last three skills, newest first
    float cd[KIND_N] = {0, 0, 0, 0, 0, 0, 0};
    float peakMult = 1.0f;   // best multiplier inside this combo
    // feedback the HUD reads
    float tierPopT = 0;      // > 0 while a milestone banner shows
    int   tierPop = 0;       // which tier the banner is for
    bool  tierUp = false;    // set when a milestone was just reached; the game clears it after the effects
    float awardT = 0;        // > 0 while the last "+points" shows
    int   lastAward = 0;
    int   lastKindShown = -1;
    float hitT = 0;          // short pulse on every scored skill
    int   runBestCount = 0;  // longest combo of this run (for the game-over screen)
    float runBestMult = 1.0f;
    Best  best;              // saved record
    bool  bestDirty = false; // a new record was set; the game saves it
};

inline int tierFor(float mult) {
    int t = 0;
    for (int i = 1; i <= TIERS; i++) if (mult >= TIER_AT[i]) t = i;
    return t;
}
inline float windowFor(int tier) {
    const float u = (float)std::min(std::max(tier, 0), TIERS) / (float)TIERS;
    return WINDOW + (WINDOW_MIN - WINDOW) * u;
}
inline bool active(const State& s) { return s.count > 0; }

// a new run: everything resets except the saved record
inline void resetRun(State& s) {
    Best b = s.best;
    s = State();
    s.best = b;
}

// the combo is over (decayed away or crashed): record it if it is the best so far, then clear
inline void finish(State& s) {
    if (s.count > 0) {
        bool better = s.count > s.best.count || (s.count == s.best.count && s.pts > s.best.pts);
        if (better) { s.best.count = s.count; s.best.pts = s.pts; s.best.mult = s.peakMult; s.bestDirty = true; }
    }
    s.mult = 1.0f; s.count = 0; s.pts = 0; s.timer = 0; s.draining = false; s.tier = 0;
    s.lastKind = -1; s.recent[0] = s.recent[1] = s.recent[2] = -1; s.peakMult = 1.0f;
}
inline void crash(State& s) { finish(s); s.tierPopT = 0; s.awardT = 0; s.hitT = 0; }

// a skill happened.  base < 0 uses the default table.  Returns the points earned (already x multiplier).
inline int event(State& s, Kind k, float base = -1.0f) {
    if (k < 0 || k >= KIND_N) return 0;
    if (s.cd[k] > 0) return 0;
    s.cd[k] = KIND_CD[k];
    if (base < 0) base = BASE_PTS[k];

    // variety: 0 = same as the last skill, 1 = seen in the last three, 2 = fresh
    int vary = 2;
    if (k == s.lastKind) vary = 0;
    else for (int i = 0; i < 3; i++) if (s.recent[i] == (int)k) vary = 1;
    float inc = vary == 2 ? 0.30f : (vary == 1 ? 0.15f : 0.05f);
    if (k == LONGCHAIN) inc = 0.50f;

    s.draining = false;
    s.mult = std::min(MAX_MULT, s.mult + inc);
    s.peakMult = std::max(s.peakMult, s.mult);
    s.count++;
    s.runBestCount = std::max(s.runBestCount, s.count);
    s.runBestMult = std::max(s.runBestMult, s.mult);
    s.recent[2] = s.recent[1]; s.recent[1] = s.recent[0]; s.recent[0] = (int)k; s.lastKind = (int)k;

    float pts = base * s.mult * (vary == 0 ? 0.6f : 1.0f);
    int p = (int)(pts + 0.5f);

    // milestones: only upwards (the drain lowers the tier quietly)
    const int nt = tierFor(s.mult);
    if (nt > s.tier) {
        s.tier = nt; s.tierPop = nt; s.tierPopT = 1.5f; s.tierUp = true;
        p += TIER_BONUS[nt];
    }
    s.timer = windowFor(s.tier);
    s.pts += p; s.lastAward = p; s.awardT = 1.0f; s.lastKindShown = (int)k; s.hitT = 0.25f;
    return p;
}

inline void update(State& s, float dt, bool onGround) {
    for (int i = 0; i < KIND_N; i++) s.cd[i] = std::max(0.0f, s.cd[i] - dt);
    s.tierPopT = std::max(0.0f, s.tierPopT - dt);
    s.awardT = std::max(0.0f, s.awardT - dt);
    s.hitT = std::max(0.0f, s.hitT - dt);
    if (s.count <= 0) return;
    if (!s.draining) {
        s.timer -= dt * (onGround ? GROUND_RUSH : 1.0f);
        if (s.timer <= 0) { s.timer = 0; s.draining = true; }
        return;
    }
    s.mult -= DRAIN * dt;
    // the tier falls once the multiplier is a little below its line (hysteresis, so it does not flicker)
    while (s.tier > 0 && s.mult < TIER_AT[s.tier] - 0.1f) s.tier--;
    if (s.mult <= 1.0f) finish(s);
}

// 0..1 for the HUD timer bar: full while the window is open, then the drain level
inline float meter(const State& s) {
    if (s.count <= 0) return 0;
    if (s.draining) return std::min(std::max((s.mult - 1.0f) / (MAX_MULT - 1.0f), 0.0f), 1.0f) * 0.5f;
    return 0.5f + 0.5f * std::min(std::max(s.timer / windowFor(s.tier), 0.0f), 1.0f);
}

// ---- saving ("COMBO1 bestCount bestPts bestMult x100") ------------------------------------------
inline std::string serialize(const Best& b) {
    char t[96];
    snprintf(t, sizeof t, "COMBO1 %d %d %d\n", b.count, b.pts, (int)(b.mult * 100.0f + 0.5f));
    return t;
}
inline bool parse(const char* text, Best& out) {
    int c, p, m;
    if (!text || sscanf(text, "COMBO1 %d %d %d", &c, &p, &m) != 3) return false;
    out.count = std::max(0, c); out.pts = std::max(0, p);
    out.mult = std::min(std::max(m / 100.0f, 1.0f), MAX_MULT);
    return true;
}
inline bool saveFile(const std::string& path, const Best& b) {
    if (path.empty()) return false;
    std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return false;
    std::string s = serialize(b);
    bool ok = fwrite(s.data(), 1, s.size(), f) == s.size();
    ok = (fclose(f) == 0) && ok;
    if (!ok) { remove(tmp.c_str()); return false; }
    return rename(tmp.c_str(), path.c_str()) == 0;
}
inline bool loadFile(const std::string& path, Best& out) {
    if (path.empty()) return false;
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return false;
    char buf[128] = {0};
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f); buf[n] = 0;
    return parse(buf, out);
}

}  // namespace combo
