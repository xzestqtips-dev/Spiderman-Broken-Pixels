#pragma once
#include <algorithm>
#include <cstdio>
#include <string>

namespace combo {

enum Kind { PERFECT = 0, TRICK, NEAR_MISS, FAST, LAND, LONGCHAIN, STUNT, KIND_N };

static const float MAX_MULT   = 5.0f;
static const float WINDOW     = 4.0f;
static const float WINDOW_MIN = 2.6f;
static const float GROUND_RUSH = 1.5f;
static const float DRAIN      = 0.9f;
static const int   TIERS      = 4;
static const float TIER_AT[TIERS + 1] = {1.0f, 1.5f, 2.5f, 3.5f, 4.5f};
static const int   TIER_BONUS[TIERS + 1] = {0, 25, 60, 120, 250};

inline const char* tierName(int t) {
    static const char* const N[TIERS + 1] = {"", "GOOD", "GREAT", "AMAZING", "LEGENDARY"};
    return N[std::min(std::max(t, 0), TIERS)];
}
inline const char* kindName(int k) {
    static const char* const N[KIND_N] = {"PERFECT", "TRICK", "NEAR MISS", "FAST SWING", "SMOOTH LANDING", "LONG SWING", "AIR TRICK"};
    return N[std::min(std::max(k, 0), KIND_N - 1)];
}

static const float BASE_PTS[KIND_N] = {15.0f, 20.0f, 25.0f, 12.0f, 20.0f, 0.0f, 30.0f};
static const float KIND_CD[KIND_N] = {0.0f, 0.5f, 0.6f, 0.8f, 0.3f, 0.0f, 0.35f};

struct Best { int count = 0; int pts = 0; float mult = 1.0f; };

struct State {
    float mult = 1.0f;
    int   count = 0;
    int   pts = 0;
    float timer = 0;
    bool  draining = false;
    int   tier = 0;
    int   lastKind = -1;
    int   recent[3] = {-1, -1, -1};
    float cd[KIND_N] = {0, 0, 0, 0, 0, 0, 0};
    float peakMult = 1.0f;
    float tierPopT = 0;
    int   tierPop = 0;
    bool  tierUp = false;
    float awardT = 0;
    int   lastAward = 0;
    int   lastKindShown = -1;
    float hitT = 0;
    int   runBestCount = 0;
    float runBestMult = 1.0f;
    Best  best;
    bool  bestDirty = false;
};

inline int tierFor(float mult) {
    int t = 0;
    for (int i = 1; i <= TIERS; i++) if (mult >= TIER_AT[i]) t = i;
    return t;
}
inline float windowFor(int tier) {
    const float u = (float)std::min(std::max(tier, 0), TIERS) / (float)TIERS;
    return WINDOW + (WINDOW_MIN - WINDOW) * u;
}
inline bool active(const State& s) { return s.count > 0; }

inline void resetRun(State& s) {
    Best b = s.best;
    s = State();
    s.best = b;
}

inline void finish(State& s) {
    if (s.count > 0) {
        bool better = s.count > s.best.count || (s.count == s.best.count && s.pts > s.best.pts);
        if (better) { s.best.count = s.count; s.best.pts = s.pts; s.best.mult = s.peakMult; s.bestDirty = true; }
    }
    s.mult = 1.0f; s.count = 0; s.pts = 0; s.timer = 0; s.draining = false; s.tier = 0;
    s.lastKind = -1; s.recent[0] = s.recent[1] = s.recent[2] = -1; s.peakMult = 1.0f;
}
inline void crash(State& s) { finish(s); s.tierPopT = 0; s.awardT = 0; s.hitT = 0; }

inline int event(State& s, Kind k, float base = -1.0f) {
    if (k < 0 || k >= KIND_N) return 0;
    if (s.cd[k] > 0) return 0;
    s.cd[k] = KIND_CD[k];
    if (base < 0) base = BASE_PTS[k];

    int vary = 2;
    if (k == s.lastKind) vary = 0;
    else for (int i = 0; i < 3; i++) if (s.recent[i] == (int)k) vary = 1;
    float inc = vary == 2 ? 0.30f : (vary == 1 ? 0.15f : 0.05f);
    if (k == LONGCHAIN) inc = 0.50f;

    s.draining = false;
    s.mult = std::min(MAX_MULT, s.mult + inc);
    s.peakMult = std::max(s.peakMult, s.mult);
    s.count++;
    s.runBestCount = std::max(s.runBestCount, s.count);
    s.runBestMult = std::max(s.runBestMult, s.mult);
    s.recent[2] = s.recent[1]; s.recent[1] = s.recent[0]; s.recent[0] = (int)k; s.lastKind = (int)k;

    float pts = base * s.mult * (vary == 0 ? 0.6f : 1.0f);
    int p = (int)(pts + 0.5f);

    const int nt = tierFor(s.mult);
    if (nt > s.tier) {
        s.tier = nt; s.tierPop = nt; s.tierPopT = 1.5f; s.tierUp = true;
        p += TIER_BONUS[nt];
    }
    s.timer = windowFor(s.tier);
    s.pts += p; s.lastAward = p; s.awardT = 1.0f; s.lastKindShown = (int)k; s.hitT = 0.25f;
    return p;
}

inline void update(State& s, float dt, bool onGround) {
    for (int i = 0; i < KIND_N; i++) s.cd[i] = std::max(0.0f, s.cd[i] - dt);
    s.tierPopT = std::max(0.0f, s.tierPopT - dt);
    s.awardT = std::max(0.0f, s.awardT - dt);
    s.hitT = std::max(0.0f, s.hitT - dt);
    if (s.count <= 0) return;
    if (!s.draining) {
        s.timer -= dt * (onGround ? GROUND_RUSH : 1.0f);
        if (s.timer <= 0) { s.timer = 0; s.draining = true; }
        return;
    }
    s.mult -= DRAIN * dt;
    while (s.tier > 0 && s.mult < TIER_AT[s.tier] - 0.1f) s.tier--;
    if (s.mult <= 1.0f) finish(s);
}

inline float meter(const State& s) {
    if (s.count <= 0) return 0;
    if (s.draining) return std::min(std::max((s.mult - 1.0f) / (MAX_MULT - 1.0f), 0.0f), 1.0f) * 0.5f;
    return 0.5f + 0.5f * std::min(std::max(s.timer / windowFor(s.tier), 0.0f), 1.0f);
}

inline std::string serialize(const Best& b) {
    char t[96];
    snprintf(t, sizeof t, "COMBO1 %d %d %d\n", b.count, b.pts, (int)(b.mult * 100.0f + 0.5f));
    return t;
}
inline bool parse(const char* text, Best& out) {
    int c, p, m;
    if (!text || sscanf(text, "COMBO1 %d %d %d", &c, &p, &m) != 3) return false;
    out.count = std::max(0, c); out.pts = std::max(0, p);
    out.mult = std::min(std::max(m / 100.0f, 1.0f), MAX_MULT);
    return true;
}
inline bool saveFile(const std::string& path, const Best& b) {
    if (path.empty()) return false;
    std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return false;
    std::string s = serialize(b);
    bool ok = fwrite(s.data(), 1, s.size(), f) == s.size();
    ok = (fclose(f) == 0) && ok;
    if (!ok) { remove(tmp.c_str()); return false; }
    return rename(tmp.c_str(), path.c_str()) == 0;
}
inline bool loadFile(const std::string& path, Best& out) {
    if (path.empty()) return false;
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return false;
    char buf[128] = {0};
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f); buf[n] = 0;
    return parse(buf, out);
}

}
