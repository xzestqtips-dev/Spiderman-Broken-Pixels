#pragma once
#include <algorithm>
#include <cstdio>
#include <string>

namespace prog {

enum Skill { RUN = 0, SWING = 1, SKILL_COUNT = 2 };

static const int   MAX_LEVEL   = 50;
static const int   MAX_REBIRTH = 50;
static const float REBIRTH_STEP = 0.1f;
static const int   COIN_EVERY_M = 200;
static const int   COIN_REWARD  = 15;

struct Def { const char* name; float perLevel; int upgradeCost; int rebirthCost; };
static const Def DEF[SKILL_COUNT] = {
    {"RUN SPEED",   0.25f,  500, 1000},
    {"SWING SPEED", 0.20f,  750, 5000},
};

struct Data {
    long long coins = 0;
    int level[SKILL_COUNT]   = {0, 0};
    int rebirth[SKILL_COUNT] = {0, 0};
};

inline float levelBonus(const Data& d, int s)  { return DEF[s].perLevel * d.level[s]; }
inline float rebirthMult(const Data& d, int s) { return 1.0f + REBIRTH_STEP * d.rebirth[s]; }
inline float totalMult(const Data& d, int s)   { return (1.0f + levelBonus(d, s)) * rebirthMult(d, s); }
inline float totalBonus(const Data& d, int s)  { return totalMult(d, s) - 1.0f; }

inline bool atMaxLevel(const Data& d, int s)   { return d.level[s] >= MAX_LEVEL; }
inline bool atMaxRebirth(const Data& d, int s) { return d.rebirth[s] >= MAX_REBIRTH; }

inline bool canUpgrade(const Data& d, int s) { return !atMaxLevel(d, s) && d.coins >= DEF[s].upgradeCost; }
inline bool upgrade(Data& d, int s) {
    if (!canUpgrade(d, s)) return false;
    d.coins -= DEF[s].upgradeCost; d.level[s]++;
    return true;
}
inline bool rebirthReady(const Data& d, int s) { return atMaxLevel(d, s) && !atMaxRebirth(d, s); }
inline bool canRebirth(const Data& d, int s)   { return rebirthReady(d, s) && d.coins >= DEF[s].rebirthCost; }
inline bool doRebirth(Data& d, int s) {
    if (!canRebirth(d, s)) return false;
    d.coins -= DEF[s].rebirthCost; d.level[s] = 0; d.rebirth[s]++;
    return true;
}

inline int coinsForDistance(float distM, int& paid) {
    int reached = distM > 0 ? (int)(distM / COIN_EVERY_M) : 0;
    if (reached <= paid) return 0;
    int n = reached - paid; paid = reached;
    return n * COIN_REWARD;
}

inline std::string serialize(const Data& d) {
    char b[160];
    snprintf(b, sizeof b, "PROG1 %lld %d %d %d %d\n", d.coins, d.level[RUN], d.level[SWING], d.rebirth[RUN], d.rebirth[SWING]);
    return b;
}
inline bool parse(const char* text, Data& out) {
    long long c; int l0, l1, r0, r1;
    if (!text || sscanf(text, "PROG1 %lld %d %d %d %d", &c, &l0, &l1, &r0, &r1) != 5) return false;
    out.coins = std::max(0LL, c);
    out.level[RUN] = std::min(std::max(l0, 0), MAX_LEVEL);   out.level[SWING] = std::min(std::max(l1, 0), MAX_LEVEL);
    out.rebirth[RUN] = std::min(std::max(r0, 0), MAX_REBIRTH); out.rebirth[SWING] = std::min(std::max(r1, 0), MAX_REBIRTH);
    return true;
}
inline bool saveFile(const std::string& path, const Data& d) {
    if (path.empty()) return false;
    std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return false;
    std::string s = serialize(d);
    bool ok = fwrite(s.data(), 1, s.size(), f) == s.size();
    ok = (fclose(f) == 0) && ok;
    if (!ok) { remove(tmp.c_str()); return false; }
    return rename(tmp.c_str(), path.c_str()) == 0;
}
inline bool loadFile(const std::string& path, Data& out) {
    if (path.empty()) return false;
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return false;
    char buf[256] = {0};
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f); buf[n] = 0;
    return parse(buf, out);
}

}
