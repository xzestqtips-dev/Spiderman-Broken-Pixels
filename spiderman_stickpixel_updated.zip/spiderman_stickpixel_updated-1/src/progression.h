#pragma once
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

namespace prog {

// RUN and SWING keep their original indices (saved files and tests rely on them). JUMP / AIR / WEB were added later.
enum Skill { RUN = 0, SWING = 1, JUMP = 2, AIR = 3, WEB = 4, SKILL_COUNT = 5 };

static const int   MAX_LEVEL   = 50;
static const int   MAX_REBIRTH = 50;
static const float REBIRTH_STEP = 0.1f;
static const int   COIN_EVERY_M = 200;
static const int   COIN_REWARD  = 15;

// upgradeCost is the price of level 1; every further level adds costStep (0 = flat price, as RUN / SWING always had).
// maxLevel / maxRebirth are per skill. The newer skills have no rebirth: their physics effect is capped, so a multiplier would do nothing.
struct Def { const char* name; float perLevel; int upgradeCost; int rebirthCost; int costStep; int maxLevel; int maxRebirth; };
static const Def DEF[SKILL_COUNT] = {
    {"RUN SPEED",    0.25f,  500, 1000,  0, 50, 50},
    {"SWING SPEED",  0.20f,  750, 5000,  0, 50, 50},
    {"JUMP HEIGHT",  0.012f, 300,    0, 35, 25,  0},   // +30 % jump speed at level 25 (about 1.7x the height); also raises fall tolerance
    {"AIR CONTROL",  0.04f,  250,    0, 25, 30,  0},   // +120 % mid-air steering at level 30
    {"WEB CONTROL",  0.03f,  400,    0, 30, 30,  0},   // +90 % steering force on the web at level 30
};

struct Data {
    long long coins = 0;
    int level[SKILL_COUNT]   = {0, 0, 0, 0, 0};
    int rebirth[SKILL_COUNT] = {0, 0, 0, 0, 0};
};

inline int maxLevel(int s)   { return DEF[s].maxLevel; }
inline int maxRebirth(int s) { return DEF[s].maxRebirth; }
inline int upgradeCostAt(const Data& d, int s) { return DEF[s].upgradeCost + DEF[s].costStep * d.level[s]; }

inline float levelBonus(const Data& d, int s)  { return DEF[s].perLevel * d.level[s]; }
inline float rebirthMult(const Data& d, int s) { return 1.0f + REBIRTH_STEP * d.rebirth[s]; }   // always 1.0 for skills without rebirth
inline float totalMult(const Data& d, int s)   { return (1.0f + levelBonus(d, s)) * rebirthMult(d, s); }
inline float totalBonus(const Data& d, int s)  { return totalMult(d, s) - 1.0f; }

inline bool atMaxLevel(const Data& d, int s)   { return d.level[s] >= DEF[s].maxLevel; }
inline bool atMaxRebirth(const Data& d, int s) { return d.rebirth[s] >= DEF[s].maxRebirth; }

inline bool canUpgrade(const Data& d, int s) { return !atMaxLevel(d, s) && d.coins >= upgradeCostAt(d, s); }
inline bool upgrade(Data& d, int s) {
    if (!canUpgrade(d, s)) return false;
    d.coins -= upgradeCostAt(d, s); d.level[s]++;
    return true;
}
inline bool rebirthReady(const Data& d, int s) { return atMaxLevel(d, s) && !atMaxRebirth(d, s); }
inline bool canRebirth(const Data& d, int s)   { return rebirthReady(d, s) && d.coins >= DEF[s].rebirthCost; }
inline bool doRebirth(Data& d, int s) {
    if (!canRebirth(d, s)) return false;
    d.coins -= DEF[s].rebirthCost; d.level[s] = 0; d.rebirth[s]++;
    return true;
}

inline int coinsForDistance(float distM, int& paid) {
    int reached = distM > 0 ? (int)(distM / COIN_EVERY_M) : 0;
    if (reached <= paid) return 0;
    int n = reached - paid; paid = reached;
    return n * COIN_REWARD;
}

// Save format. PROG2 lists coins, then a level and a rebirth count for every skill. PROG1 (the original two-skill file) is still read:
// its new skills simply start at level 0. Unknown or damaged files are rejected without touching the data.
inline std::string serialize(const Data& d) {
    std::string out = "PROG2 " + std::to_string(d.coins);
    for (int i = 0; i < SKILL_COUNT; i++) out += " " + std::to_string(d.level[i]);
    for (int i = 0; i < SKILL_COUNT; i++) out += " " + std::to_string(d.rebirth[i]);
    return out + "\n";
}
inline bool parse(const char* text, Data& out) {
    if (!text) return false;
    Data r;
    long long c; int v[2 * SKILL_COUNT] = {0};
    if (strncmp(text, "PROG2 ", 6) == 0) {
        const char* p = text + 6; char* end = nullptr;
        c = strtoll(p, &end, 10); if (end == p) return false; p = end;
        for (int i = 0; i < 2 * SKILL_COUNT; i++) { v[i] = (int)strtol(p, &end, 10); if (end == p) return false; p = end; }
        r.coins = std::max(0LL, c);
        for (int i = 0; i < SKILL_COUNT; i++) { r.level[i] = std::min(std::max(v[i], 0), DEF[i].maxLevel); r.rebirth[i] = std::min(std::max(v[SKILL_COUNT + i], 0), DEF[i].maxRebirth); }
    } else {
        int l0, l1, r0, r1;
        if (sscanf(text, "PROG1 %lld %d %d %d %d", &c, &l0, &l1, &r0, &r1) != 5) return false;
        r.coins = std::max(0LL, c);
        r.level[RUN] = std::min(std::max(l0, 0), DEF[RUN].maxLevel);   r.level[SWING] = std::min(std::max(l1, 0), DEF[SWING].maxLevel);
        r.rebirth[RUN] = std::min(std::max(r0, 0), DEF[RUN].maxRebirth); r.rebirth[SWING] = std::min(std::max(r1, 0), DEF[SWING].maxRebirth);
    }
    out = r;
    return true;
}
inline bool saveFile(const std::string& path, const Data& d) {
    if (path.empty()) return false;
    std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return false;
    std::string s = serialize(d);
    bool ok = fwrite(s.data(), 1, s.size(), f) == s.size();
    ok = (fclose(f) == 0) && ok;
    if (!ok) { remove(tmp.c_str()); return false; }
    return rename(tmp.c_str(), path.c_str()) == 0;
}
inline bool loadFile(const std::string& path, Data& out) {
    if (path.empty()) return false;
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return false;
    char buf[512] = {0};
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f); buf[n] = 0;
    return parse(buf, out);
}

}
