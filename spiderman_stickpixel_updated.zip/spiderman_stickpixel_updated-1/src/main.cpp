#include <SDL.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <string>
#include <vector>

#include "progression.h"
#include "combo.h"

typedef uint32_t u32;
static const float pi = 3.14159265f;
static float clampValue(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float lerpValue(float a, float b, float t) { return a + (b - a) * t; }
static int positiveModulo(int a, int m) { a %= m; return a < 0 ? a + m : a; }
static u32 hashCoordinates(u32 a, u32 b, u32 c) {
    u32 h = a * 374761393u + b * 668265263u + c * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}
struct Rng {
    u32 s;
    explicit Rng(u32 seed = 1) : s(seed ? seed : 1) {}
    u32 next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float f() { return (next() & 0xFFFFFF) / 16777216.0f; }
    int range(int a, int b) { if (b < a) b = a; return a + (int)(f() * (b - a + 1)); }
};

static SDL_Window* uvzWindow = nullptr;
static SDL_Renderer* uvzRenderer = nullptr;
static SDL_Texture* uvzRenderTarget = nullptr;
static int uvzOutputWidth = 1280, uvzOutputHeight = 720;
static int uvzWorldWidth = 640, uvzWorldHeight = 360, uvzPixelScale = 3;
static int uvzOffsetX = 0, uvzOffsetY = 0;
static float uvzScaleX = 3.0f, uvzScaleY = 3.0f;
static int uvzDisplayWidth = 1280, uvzDisplayHeight = 720;
static bool portrait = false;
static float uvzSafeLeft = 14, uvzSafeRight = 14, uvzSafeTop = 8, uvzSafeBottom = 10;
static float uvzMinimumTouchSize = 40;

static void recalculateDisplayLayout() {
    SDL_GetRendererOutputSize(uvzRenderer, &uvzOutputWidth, &uvzOutputHeight);
    portrait = uvzOutputHeight > uvzOutputWidth;
    const int minD = std::min(uvzOutputWidth, uvzOutputHeight);
    uvzPixelScale = std::max(1, (int)lroundf(minD / 360.0f));

    uvzScaleX = uvzScaleY = (float)uvzPixelScale;
    uvzWorldWidth = std::max(1, (uvzOutputWidth + uvzPixelScale - 1) / uvzPixelScale); uvzWorldHeight = std::max(1, (uvzOutputHeight + uvzPixelScale - 1) / uvzPixelScale);
    uvzDisplayWidth = uvzWorldWidth * uvzPixelScale; uvzDisplayHeight = uvzWorldHeight * uvzPixelScale;
    uvzOffsetX = (uvzOutputWidth - uvzDisplayWidth) / 2; uvzOffsetY = (uvzOutputHeight - uvzDisplayHeight) / 2;
    if (uvzRenderTarget) SDL_DestroyTexture(uvzRenderTarget);
    uvzRenderTarget = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, uvzWorldWidth, uvzWorldHeight);
    uvzSafeLeft = uvzSafeRight = std::max(14.0f, uvzWorldWidth * 0.035f);
    uvzSafeTop = 8; uvzSafeBottom = 10;
    float ddpi = 0;
    if (SDL_GetDisplayDPI(0, &ddpi, nullptr, nullptr) != 0 || ddpi < 80) ddpi = 400;
    uvzMinimumTouchSize = clampValue(48.0f * ddpi / 160.0f / uvzScaleY, 36.0f, 56.0f);
}

static void setDrawColor(u32 c, int a = 255) {
    SDL_SetRenderDrawColor(uvzRenderer, (c >> 16) & 255, (c >> 8) & 255, c & 255, (Uint8)a);
}
static void drawFilledRect(int x, int y, int w, int h, u32 c, int a = 255) {
    if (w <= 0 || h <= 0) return;
    setDrawColor(c, a);
    SDL_Rect r = {x, y, w, h};
    SDL_RenderFillRect(uvzRenderer, &r);
}
static void drawDisc(int cx, int cy, int r, u32 c, int a = 255) {
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        drawFilledRect(cx - dx, cy + dy, dx * 2 + 1, 1, c, a);
    }
}
static void drawLine(float x0, float y0, float x1, float y1, u32 c, int a = 255) {
    setDrawColor(c, a);
    SDL_RenderDrawLine(uvzRenderer, (int)x0, (int)y0, (int)x1, (int)y1);
}

struct Glyph { char c; uint8_t r[7]; };
static const Glyph fontGlyphs[] = {
    {'A',{0x0E,0x11,0x11,0x1F,0x11,0x11,0x11}}, {'B',{0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E}},
    {'C',{0x0E,0x11,0x10,0x10,0x10,0x11,0x0E}}, {'D',{0x1E,0x11,0x11,0x11,0x11,0x11,0x1E}},
    {'E',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}}, {'F',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x10}},
    {'G',{0x0E,0x11,0x10,0x17,0x11,0x11,0x0F}}, {'H',{0x11,0x11,0x11,0x1F,0x11,0x11,0x11}},
    {'I',{0x0E,0x04,0x04,0x04,0x04,0x04,0x0E}}, {'J',{0x07,0x02,0x02,0x02,0x02,0x12,0x0C}},
    {'K',{0x11,0x12,0x14,0x18,0x14,0x12,0x11}}, {'L',{0x10,0x10,0x10,0x10,0x10,0x10,0x1F}},
    {'M',{0x11,0x1B,0x15,0x15,0x11,0x11,0x11}}, {'N',{0x11,0x11,0x19,0x15,0x13,0x11,0x11}},
    {'O',{0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'P',{0x1E,0x11,0x11,0x1E,0x10,0x10,0x10}},
    {'Q',{0x0E,0x11,0x11,0x11,0x15,0x12,0x0D}}, {'R',{0x1E,0x11,0x11,0x1E,0x14,0x12,0x11}},
    {'S',{0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E}}, {'T',{0x1F,0x04,0x04,0x04,0x04,0x04,0x04}},
    {'U',{0x11,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'V',{0x11,0x11,0x11,0x11,0x11,0x0A,0x04}},
    {'W',{0x11,0x11,0x11,0x15,0x15,0x15,0x0A}}, {'X',{0x11,0x11,0x0A,0x04,0x0A,0x11,0x11}},
    {'Y',{0x11,0x11,0x11,0x0A,0x04,0x04,0x04}}, {'Z',{0x1F,0x01,0x02,0x04,0x08,0x10,0x1F}},
    {'0',{0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}}, {'1',{0x04,0x0C,0x04,0x04,0x04,0x04,0x0E}},
    {'2',{0x0E,0x11,0x01,0x02,0x04,0x08,0x1F}}, {'3',{0x1F,0x02,0x04,0x02,0x01,0x11,0x0E}},
    {'4',{0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}}, {'5',{0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E}},
    {'6',{0x06,0x08,0x10,0x1E,0x11,0x11,0x0E}}, {'7',{0x1F,0x01,0x02,0x04,0x08,0x08,0x08}},
    {'8',{0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}}, {'9',{0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C}},
    {'.',{0,0,0,0,0,0x0C,0x0C}}, {':',{0,0x0C,0x0C,0,0x0C,0x0C,0}},
    {'-',{0,0,0,0x1F,0,0,0}}, {'/',{0x01,0x02,0x02,0x04,0x08,0x08,0x10}},
    {'!',{0x04,0x04,0x04,0x04,0x04,0,0x04}}, {'?',{0x0E,0x11,0x01,0x02,0x04,0,0x04}},
    {'+',{0,0x04,0x04,0x1F,0x04,0x04,0}}, {'%',{0x19,0x19,0x02,0x04,0x08,0x13,0x13}}, {',',{0,0,0,0,0x0C,0x04,0x08}},
    {'<',{0x02,0x04,0x08,0x10,0x08,0x04,0x02}}, {'>',{0x08,0x04,0x02,0x01,0x02,0x04,0x08}},
};
static uint8_t gGl[128][7];
static void initFont() {
    memset(gGl, 0, sizeof(gGl));
    for (const Glyph& g : fontGlyphs) memcpy(gGl[(int)g.c], g.r, 7);
}
static int measureTextWidth(const char* s, int sc) { return (int)strlen(s) * 6 * sc - sc; }
static void text(const char* s, int x, int y, int sc, u32 c, int a = 255) {
    static std::vector<SDL_Rect> rs;
    rs.clear();
    int cx = x;
    for (; *s; ++s) {
        unsigned char ch = (unsigned char)toupper((unsigned char)*s);
        if (ch < 128) {
            for (int r = 0; r < 7; r++) {
                uint8_t bits = gGl[ch][r];
                for (int b = 0; b < 5; b++)
                    if (bits & (16 >> b)) rs.push_back({cx + b * sc, y + r * sc, sc, sc});
            }
        }
        cx += 6 * sc;
    }
    setDrawColor(c, a);
    if (!rs.empty()) SDL_RenderFillRects(uvzRenderer, rs.data(), (int)rs.size());
}
static void drawTextWithShadow(const char* s, int x, int y, int sc, u32 c, u32 sh = 0x05060F) {
    text(s, x + std::max(1, sc / 2), y + std::max(1, sc / 2), sc, sh, 220);
    text(s, x, y, sc, c);
}
static void drawCenteredText(const char* s, int cx, int y, int sc, u32 c) { drawTextWithShadow(s, cx - measureTextWidth(s, sc) / 2, y, sc, c); }
static int fitTextScale(const char* s, int maxW, int maxSc) {
    int sc = maxSc;
    while (sc > 1 && measureTextWidth(s, sc) > maxW) sc--;
    return sc;
}

struct Img {
    int w, h;
    std::vector<u32> p;
    Img(int w_, int h_) : w(w_), h(h_), p((size_t)w_ * h_, 0) {}
    void set(int x, int y, u32 c) { if (x >= 0 && y >= 0 && x < w && y < h) p[(size_t)y * w + x] = c; }
    u32 get(int x, int y) const { return (x >= 0 && y >= 0 && x < w && y < h) ? p[(size_t)y * w + x] : 0; }
    void fill(int x, int y, int ww, int hh, u32 c) {
        for (int yy = y; yy < y + hh; yy++) for (int xx = x; xx < x + ww; xx++) set(xx, yy, c);
    }
};
static SDL_Texture* createTexture(const Img& im) {
    SDL_Texture* t = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC, im.w, im.h);
    SDL_UpdateTexture(t, nullptr, im.p.data(), im.w * 4);
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    return t;
}

static SDL_Texture* gTile[6][3];
static SDL_Texture* gFar[3];

static u32 chooseWindowLightColor(Rng& r, u32 off) {
    float f = r.f();
    if (f < 0.28f) return 0xFFFFD98A;
    if (f < 0.36f) return 0xFF8FE3FF;
    if (f < 0.40f) return 0xFFFF9CB8;
    return off;
}
static void drawWindowRect(Img& im, Rng& r, int x, int y, int w, int h, u32 off, u32 frame) {
    im.fill(x - 1, y - 1, w + 2, h + 2, frame);
    u32 c = chooseWindowLightColor(r, off);
    im.fill(x, y, w, h, c);
    if (c != off) im.fill(x, y + h - 2, w, 2, 0xFFE0B060);
    else im.fill(x, y, w, 1, off + 0x00080808);
}
static Img makeTile(int st, int var) {
    Img im(64, 64);
    Rng r(1234u + st * 97u + var * 7919u);
    switch (st) {
        case 0:
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                u32 c = 0xFF23405E;
                if (((x + y) >> 3) % 7 == 0) c = 0xFF2C5070;
                if (x % 16 == 0 || y % 16 == 0) c = 0xFF111F32;
                im.set(x, y, c);
            }
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) {
                u32 l = chooseWindowLightColor(r, 0);
                if (l) { im.fill(i * 16 + 1, j * 16 + 1, 15, 15, l); im.fill(i * 16 + 1, j * 16 + 12, 15, 4, 0xFFC89A50); }
            }
            break;
        case 1:
            im.fill(0, 0, 64, 64, 0xFF3A3D4F);
            for (int x = 0; x < 64; x += 16) im.fill(x, 0, 1, 64, 0xFF2E3141);
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++)
                drawWindowRect(im, r, 3 + i * 16, 3 + j * 16, 10, 12, 0xFF1B2030, 0xFF22242F);
            break;
        case 2:
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                int row = y / 4; u32 c = 0xFF6B3A35;
                if (y % 4 == 3 || (x + (row % 2) * 4) % 8 == 7) c = 0xFF4A2826;
                else if ((x * 7 + y * 13) % 11 == 0) c = 0xFF7A433C;
                im.set(x, y, c);
            }
            for (int j = 0; j < 2; j++) for (int i = 0; i < 4; i++) {
                int x = i * 16 + 4, y = j * 32 + 6;
                im.fill(x - 1, y - 2, 10, 2, 0xFF9A8A7A);
                drawWindowRect(im, r, x, y, 8, 16, 0xFF1A1620, 0xFF2A1A1A);
                im.fill(x - 1, y + 17, 10, 2, 0xFF9A8A7A);
            }
            break;
        case 3:
            im.fill(0, 0, 64, 64, 0xFF4F4866);
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) {
                drawWindowRect(im, r, 4 + i * 16, 3 + j * 16, 8, 9, 0xFF221E30, 0xFF2B263A);
                im.fill(i * 16 + 1, j * 16 + 13, 14, 2, 0xFF2B263A);
                im.fill(i * 16 + 1, j * 16 + 12, 14, 1, 0xFF7A7298);
            }
            break;
        case 4:
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                u32 c = (x % 4 < 2) ? 0xFF313745 : 0xFF2A2F3B;
                if (y >= 28 && y < 32) c = (((x + y) / 4) % 2) ? 0xFFB8872A : 0xFF1A1A1A;
                im.set(x, y, c);
            }
            drawWindowRect(im, r, 6, 10, 12, 6, 0xFF14171F, 0xFF1E222C);
            drawWindowRect(im, r, 38, 10, 12, 6, 0xFF14171F, 0xFF1E222C);
            drawWindowRect(im, r, 6, 44, 12, 6, 0xFF14171F, 0xFF1E222C);
            drawWindowRect(im, r, 38, 44, 12, 6, 0xFF14171F, 0xFF1E222C);
            break;
        default:
            im.fill(0, 0, 64, 64, 0xFF121828);
            for (int k = 0; k < 2; k++) {
                im.fill(k * 32 + 3, 3, 29, 3, 0xFF4A4E5C);
                for (int i = 0; i < 29; i++) { im.set(k * 32 + 3 + i, 6 + i, 0xFF7A4818); im.set(k * 32 + 31 - i, 6 + i, 0xFF7A4818); }
            }
            for (int x : {0, 32}) { im.fill(x, 0, 3, 64, 0xFF9A5B22); im.fill(x, 0, 1, 64, 0xFFC9822F); }
            for (int y : {0, 32}) { im.fill(0, y, 64, 3, 0xFF9A5B22); im.fill(0, y, 64, 1, 0xFFC9822F); }
            if (r.f() < 0.7f) { im.fill(12, 14, 3, 3, 0xFFFFE9A0); im.fill(11, 17, 5, 1, 0xFF8A7430); }
            if (r.f() < 0.5f) { im.fill(46, 46, 3, 3, 0xFFFFE9A0); im.fill(45, 49, 5, 1, 0xFF8A7430); }
            break;
    }
    return im;
}
static Img makeFar(int var) {
    Img im(32, 32);
    Rng r(777u + var * 31u);
    im.fill(0, 0, 32, 32, 0xFF1B2144);
    for (int gy = 0; gy < 5; gy++) for (int gx = 0; gx < 5; gx++) {
        float f = r.f();
        u32 c = f < 0.22f ? 0xFFB8A56A : (f < 0.30f ? 0xFF6A92B8 : 0xFF161B38);
        im.fill(gx * 6 + 2, gy * 6 + 3, 2, 2, c);
    }
    return im;
}

enum Frame {
    F_IDLE,
    F_RUN,
    F_SHOOT,
    F_ATTACH,
    F_SWING,
    F_JUMP,
    F_FALL,
    F_FLIP,
    F_RELEASE,
    F_LAND,
    F_HERO,
    F_HIT,
    F_DEAD,
    F_CLING,
    F_CLIMB,
    F_SLIDE,
    F_WALLJUMP,
    F_TWIST,
    F_STAR,
    F_DIVE,
    F_COUNT
};
static const int STK_FEET_Y = 26;
static const u32 STK_BODY = 0x0B0B12;
static const u32 STK_OUTLINE = 0xE8ECFF;

enum StkJoint { J_HIP, J_NECK, J_HEAD, J_KNF, J_FTF, J_KNB, J_FTB, J_ELF, J_HNF, J_ELB, J_HNB, J_N };
struct StkPose {
    float hipX = 0, hipY = 2, lean = 0, tilt = 0;
    float thF = 0, shF = 0, thB = 0, shB = 0;
    float upF = 0, foF = 0, upB = 0, foB = 0;
    float snap = 0;
};
static const float STK_TORSO = 16, STK_THIGH = 12, STK_SHIN = 12, STK_UARM = 8, STK_FARM = 8, STK_HEADD = 6;

static void stkSolve(const StkPose& p, float jx[J_N], float jy[J_N]) {
    auto dir = [](float deg, float len, float& dx, float& dy) { float a = deg * pi / 180.0f; dx = sinf(a) * len; dy = cosf(a) * len; };
    float dx, dy, hy = p.hipY;
    for (int pass = 0; pass < 2; pass++) {
        jx[J_HIP] = p.hipX; jy[J_HIP] = hy;
        dir(p.thF, STK_THIGH, dx, dy); jx[J_KNF] = jx[J_HIP] + dx; jy[J_KNF] = jy[J_HIP] + dy;
        dir(p.shF, STK_SHIN, dx, dy);  jx[J_FTF] = jx[J_KNF] + dx; jy[J_FTF] = jy[J_KNF] + dy;
        dir(p.thB, STK_THIGH, dx, dy); jx[J_KNB] = jx[J_HIP] + dx; jy[J_KNB] = jy[J_HIP] + dy;
        dir(p.shB, STK_SHIN, dx, dy);  jx[J_FTB] = jx[J_KNB] + dx; jy[J_FTB] = jy[J_KNB] + dy;
        if (p.snap > 0.001f && pass == 0) hy += clampValue(p.snap, 0.0f, 1.0f) * (float)STK_FEET_Y - std::max(jy[J_FTF], jy[J_FTB]);
        else break;
    }
    dir(180.0f - p.lean, STK_TORSO, dx, dy);
    jx[J_NECK] = jx[J_HIP] + dx; jy[J_NECK] = jy[J_HIP] + dy;
    dir(180.0f - p.lean - p.tilt, STK_HEADD, dx, dy);
    jx[J_HEAD] = jx[J_NECK] + dx; jy[J_HEAD] = jy[J_NECK] + dy;
    dir(p.upF, STK_UARM, dx, dy); jx[J_ELF] = jx[J_NECK] + dx; jy[J_ELF] = jy[J_NECK] + dy;
    dir(p.foF, STK_FARM, dx, dy); jx[J_HNF] = jx[J_ELF] + dx;  jy[J_HNF] = jy[J_ELF] + dy;
    dir(p.upB, STK_UARM, dx, dy); jx[J_ELB] = jx[J_NECK] + dx; jy[J_ELB] = jy[J_NECK] + dy;
    dir(p.foB, STK_FARM, dx, dy); jx[J_HNB] = jx[J_ELB] + dx;  jy[J_HNB] = jy[J_ELB] + dy;
}

static float StkPose::* const STK_F[] = {
    &StkPose::hipX, &StkPose::hipY, &StkPose::lean, &StkPose::tilt,
    &StkPose::thF, &StkPose::shF, &StkPose::thB, &StkPose::shB,
    &StkPose::upF, &StkPose::foF, &StkPose::upB, &StkPose::foB, &StkPose::snap };

static StkPose stkBlend(const StkPose& a, const StkPose& b, float t) {
    StkPose o;
    for (auto m : STK_F) o.*m = lerpValue(a.*m, b.*m, t);
    return o;
}

static void stkRunLeg(float ph, float amp, float& thigh, float& shin) {
    thigh = amp * sinf(ph);
    float k = std::max(0.0f, cosf(ph));
    shin = thigh - (12.0f + 88.0f * powf(k, 1.4f));
}
static StkPose stkMakePose(int f, float phase, float swing, int style = 0, float j = 0) {
    StkPose p;
    switch (f) {
        case F_IDLE: {
            float b = sinf(phase * 2.0f * pi);
            p.snap = true; p.lean = 16 + 2 * b; p.tilt = -8 + b;
            p.thF = 42 + 2 * b; p.shF = -14; p.thB = -20; p.shB = -58 - 2 * b;
            p.upF = 28 + 3 * b; p.foF = 8; p.upB = -34 - 2 * b; p.foB = -62;
            break; }
        case F_RUN: {
            float ph = phase * 2.0f * pi, amp = 46 + 6 * j, lc = sinf(ph * 2.0f);
            p.snap = true;
            stkRunLeg(ph, amp, p.thF, p.shF);
            stkRunLeg(ph + pi, amp, p.thB, p.shB);
            if (style == 1) {
                p.lean = 30 + 2 * lc; p.tilt = -14;
                p.upF = -35 + 25 * sinf(ph + pi); p.foF = p.upF + 35;
                p.upB = -35 + 25 * sinf(ph);      p.foB = p.upB + 35;
            } else if (style == 2) {
                p.lean = 20 + lc; p.tilt = -8;
                p.upF = (60 + 6 * j) * sinf(ph + pi); p.foF = p.upF + 100;
                p.upB = (60 + 6 * j) * sinf(ph);      p.foB = p.upB + 100;
            } else {
                p.lean = 14 + 1.5f * lc; p.tilt = -6;
                p.upF = (50 + 8 * j) * sinf(ph + pi); p.foF = p.upF + 85;
                p.upB = (50 + 8 * j) * sinf(ph);      p.foB = p.upB + 85;
            }
            break; }
        case F_SHOOT:
            if (style == 1) {
                p.hipY = 0; p.lean = 14; p.thF = 52; p.shF = 28; p.thB = -48; p.shB = -34;
                p.upF = 122; p.foF = 128; p.upB = -70; p.foB = -48;
            } else {
                p.hipY = 0; p.lean = 8; p.thF = 62; p.shF = 8; p.thB = -22; p.shB = -68;
                p.upF = 146; p.foF = 150; p.upB = -55; p.foB = -25;
            }
            break;
        case F_ATTACH:
            p.hipY = 3; p.lean = 0; p.thF = 18; p.shF = 6; p.thB = -12; p.shB = -42;
            p.upF = 176; p.foF = 176; p.upB = 35; p.foB = 65; break;
        case F_SWING: {
            StkPose a, b;
            a.hipY = 3; a.lean = 4; a.thF = -8; a.shF = -26; a.thB = -24; a.shB = -48;
            a.upF = 177; a.foF = 177; a.upB = -42; a.foB = -62;
            b.hipY = 3; b.lean = -4; b.thF = 40; b.shF = 12; b.thB = 14; b.shB = -10;
            b.upF = 177; b.foF = 177; b.upB = 75; b.foB = 105;
            if (style == 1) {
                a.thF = 40; a.shF = -50; a.thB = 20; a.shB = -80; a.lean = 14; a.upB = -20; a.foB = 5;
                b.thF = 75; b.shF = -15; b.thB = 55; b.shB = -45; b.lean = 2; b.upB = 40; b.foB = 70;
            } else if (style == 2) {
                a.thF = 22; a.shF = 4; a.thB = -38; a.shB = -14; a.upB = -75; a.foB = -80;
                b.thF = 52; b.shF = 18; b.thB = -12; b.shB = 6; b.upB = 110; b.foB = 128;
            } else if (style == 3) {
                a.thF = -14; a.shF = -16; a.thB = -20; a.shB = -22; a.lean = 8; a.upB = -20; a.foB = -25;
                b.thF = 22; b.shF = 18; b.thB = 12; b.shB = 8; b.lean = -2; b.upB = 40; b.foB = 50;
            }
            a.thB += 8 * j; b.thB -= 8 * j; a.lean += 3 * j;
            p = stkBlend(a, b, clampValue(swing, 0.0f, 1.0f)); break; }
        case F_JUMP:
            if (style == 1) {
                p.hipY = -2; p.lean = 22; p.thF = 95; p.shF = -60; p.thB = 70; p.shB = -80;
                p.upF = 90; p.foF = 110; p.upB = -60; p.foB = -40;
            } else if (style == 2) {
                p.hipY = -2; p.lean = 0; p.thF = 40; p.shF = 30; p.thB = -40; p.shB = -30;
                p.upF = 140; p.foF = 150; p.upB = -140; p.foB = -150;
            } else {
                p.hipY = -2; p.lean = 10 + 3 * j; p.thF = 78; p.shF = 6; p.thB = -24; p.shB = -76;
                p.upF = 118; p.foF = 138; p.upB = -68; p.foB = -30;
            }
            break;
        case F_FALL:
            if (style == 1) {
                p.hipY = 0; p.lean = 20; p.thF = 60; p.shF = -20; p.thB = 40; p.shB = -50;
                p.upF = 70; p.foF = 100; p.upB = 60; p.foB = 90;
            } else {
                p.hipY = 0; p.lean = 0; p.thF = 32; p.shF = 6; p.thB = -22; p.shB = -34;
                p.upF = 112; p.foF = 100; p.upB = -104; p.foB = -112;
            }
            break;
        case F_FLIP:
            p.hipY = 2; p.lean = 38; p.tilt = -10; p.thF = 112; p.shF = -30; p.thB = 98; p.shB = -42;
            p.upF = 70; p.foF = 118; p.upB = 55; p.foB = 108; break;
        case F_CLING:
            p.hipY = 1; p.lean = 2; p.tilt = 0; p.thF = 46; p.shF = -25; p.thB = -42; p.shB = 24;
            p.upF = 128; p.foF = 158; p.upB = -108; p.foB = -142; break;
        case F_CLIMB: {
            float c = sinf(phase * 2.0f * pi), d = cosf(phase * 2.0f * pi);
            p.hipY = 1; p.lean = 1; p.tilt = 0;
            p.thF = 34 + 24*c; p.shF = -12 - 30*std::max(0.0f,d);
            p.thB = -34 - 24*c; p.shB = 12 + 30*std::max(0.0f,-d);
            p.upF = 100 + 55*d; p.foF = 135 + 22*d;
            p.upB = -100 - 55*d; p.foB = -135 - 22*d; break; }
        case F_WALLJUMP:
            p.hipY = 0; p.lean = -14; p.tilt = 6; p.thF = 18; p.shF = -8; p.thB = -22; p.shB = -34;
            p.upF = 150; p.foF = 158; p.upB = 138; p.foB = 150; break;
        case F_TWIST:
            p.hipY = 1; p.lean = 0; p.tilt = 0; p.thF = 8; p.shF = 4; p.thB = -8; p.shB = -6;
            p.upF = 35; p.foF = 135; p.upB = -35; p.foB = -135; break;
        case F_DIVE:

            p.hipY = 1; p.lean = 72; p.tilt = -6; p.thF = 6; p.shF = -4; p.thB = -14; p.shB = -10;
            p.upF = 158; p.foF = 164; p.upB = 148; p.foB = 158; break;
        case F_STAR:
            p.hipY = 1; p.lean = 0; p.tilt = 0; p.thF = 38; p.shF = 40; p.thB = -38; p.shB = -40;
            p.upF = 122; p.foF = 128; p.upB = -122; p.foB = -128; break;
        case F_SLIDE:
            p.snap = 1;
            if (style == 1) {
                p.lean = 55 + 4 * j; p.tilt = -18; p.thF = 75; p.shF = -20; p.thB = -80; p.shB = -88;
                p.upF = 40; p.foF = 15; p.upB = -50; p.foB = -90;
            } else if (style == 2) {
                p.lean = 28 + 4 * j; p.tilt = -10; p.thF = 95; p.shF = 40; p.thB = -70; p.shB = -118;
                p.upF = 70; p.foF = 85; p.upB = -75; p.foB = -100;
            } else {
                p.lean = -35 + 4 * j; p.tilt = 10; p.thF = 85; p.shF = 82; p.thB = 76; p.shB = 70;
                p.upF = 70; p.foF = 40; p.upB = -60; p.foB = -78;
            }
            break;
        case F_RELEASE:
            p.hipX = -3; p.hipY = 3; p.lean = 55; p.thF = -50; p.shF = -60; p.thB = -58; p.shB = -62;
            p.upF = 128; p.foF = 130; p.upB = 122; p.foB = 125; break;
        case F_LAND:
            p.snap = true;
            if (style == 1) {
                p.lean = 50; p.tilt = -20; p.thF = 95; p.shF = -50; p.thB = 80; p.shB = -70;
                p.upF = 40; p.foF = 15; p.upB = 20; p.foB = 0;
            } else if (style == 2) {
                p.lean = 40; p.tilt = -14; p.thF = 70; p.shF = -22; p.thB = -40; p.shB = -100;
                p.upF = 60; p.foF = 25; p.upB = -60; p.foB = -30;
            } else {
                p.lean = 36 + 4 * j; p.tilt = -12; p.thF = 78; p.shF = -32; p.thB = 56; p.shB = -58;
                p.upF = 55; p.foF = 92; p.upB = 28; p.foB = 70;
            }
            break;
        case F_HERO:
            p.snap = true; p.lean = 44; p.tilt = -24; p.thF = 88; p.shF = -4; p.thB = -34; p.shB = -118;
            p.upF = 52; p.foF = 22; p.upB = -48; p.foB = -78; break;
        case F_HIT:
            p.hipY = 1; p.lean = -22; p.tilt = 10; p.thF = 40; p.shF = 12; p.thB = -30; p.shB = -8;
            p.upF = 140; p.foF = 162; p.upB = 98; p.foB = 122; break;
        default:
            p.hipY = 1; p.lean = 0; p.tilt = 12; p.thF = 36; p.shF = 40; p.thB = -36; p.shB = -40;
            p.upF = 100; p.foF = 78; p.upB = -100; p.foB = -78; break;
    }
    return p;
}

struct StkAnim { StkPose cur, vel; bool init = false; double last = 0, ang = 0; int lastFrame = -1; float dt = 0, t = 0; };
static double stkNow() { return (double)SDL_GetTicks() / 1000.0; }
static float stkRate(int from, int to) {
    if (to == F_RUN || to == F_IDLE) return (from == to) ? 60.0f : 18.0f;
    if (to == F_SWING) return 22.0f;
    if (to == F_DIVE) return 24.0f;
    if (to == F_TWIST || to == F_STAR || to == F_WALLJUMP) return 26.0f;
    if (to == F_SLIDE) return 26.0f;
    if (to == F_SHOOT || to == F_ATTACH || to == F_RELEASE || to == F_HIT) return 28.0f;
    if (to == F_HERO || to == F_LAND) return 32.0f;
    return 18.0f;
}
static const StkPose& stkAdvance(StkAnim& an, int frame, float phase, float swing, int style = 0, float j = 0) {
    StkPose tgt = stkMakePose(frame, phase, swing, style, j);
    double now = stkNow();
    an.dt = clampValue((float)(now - an.last), 0.0f, 0.05f);
    an.last = now;
    if (!an.init) {
        an.cur = tgt; an.init = true;
        for (auto m : STK_F) an.vel.*m = 0;
    } else {
        float ease = clampValue(an.t / 0.15f, 0.0f, 1.0f);
        float w = stkRate(an.lastFrame, frame) * (0.45f + 0.55f * ease * ease * (3 - 2 * ease));
        float zeta = (frame == F_RUN || frame == F_IDLE) ? 1.0f : 0.7f;
        int n = (int)ceilf(an.dt * 240.0f);
        float h = n ? an.dt / n : 0;
        for (int i = 0; i < n; i++)
            for (auto m : STK_F) {
                float& x = an.cur.*m; float& v = an.vel.*m;
                v += (w * w * (tgt.*m - x) - 2 * zeta * w * v) * h;
                x += v * h;
            }
    }
    an.t = frame == an.lastFrame ? an.t + an.dt : 0;
    an.lastFrame = frame;
    return an.cur;
}
static double stkAngle(StkAnim& an, double target, bool spin) {
    if (spin) an.ang = fmod(target, 360.0);
    else {
        double d = fmod(target - an.ang, 360.0);
        if (d > 180) d -= 360; else if (d < -180) d += 360;
        an.ang += d * (1.0 - exp(-8.0 * an.dt));
    }
    return an.ang;
}

static bool gStkMirror = false;
static void stkPlace(const StkPose& pose, float cx, float feetY, double angleDeg, float X[J_N], float Y[J_N]) {
    float jx[J_N], jy[J_N];
    stkSolve(pose, jx, jy);
    float a = (float)(angleDeg * pi / 180.0), c = cosf(a), s = sinf(a);
    float ox = cx, oy = feetY - (float)STK_FEET_Y;
    for (int i = 0; i < J_N; i++) { X[i] = ox + jx[i] * c - jy[i] * s; Y[i] = oy + jx[i] * s + jy[i] * c; if (gStkMirror) X[i] = 2.0f * cx - X[i]; }
}

static const int STK_TEX = 112;
static SDL_Texture* gStkTex = nullptr;
static float gStkBuf[STK_TEX * STK_TEX * 4];
struct StkBone { int a, b; };
static float stkDistSeg(float px, float py, float x0, float y0, float x1, float y1) {
    float vx = x1 - x0, vy = y1 - y0, wx = px - x0, wy = py - y0;
    float l2 = vx * vx + vy * vy, t = l2 > 1e-6f ? clampValue((wx * vx + wy * vy) / l2, 0.0f, 1.0f) : 0.0f;
    float dx = wx - vx * t, dy = wy - vy * t;
    return sqrtf(dx * dx + dy * dy);
}
static void stkLayer(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float rLimb, float rHead, u32 c, float ox, float oy) {
    float cr = ((c >> 16) & 255) / 255.0f, cg = ((c >> 8) & 255) / 255.0f, cb = (c & 255) / 255.0f;
    float r = rLimb + 0.5f;
    float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
    auto grow = [&](float x, float y, float pad) { minX = std::min(minX, x - pad); maxX = std::max(maxX, x + pad); minY = std::min(minY, y - pad); maxY = std::max(maxY, y + pad); };
    for (int i = 0; i < n; i++) { grow(X[bones[i].a] - ox, Y[bones[i].a] - oy, r + 1); grow(X[bones[i].b] - ox, Y[bones[i].b] - oy, r + 1); }
    if (head) grow(X[J_HEAD] - ox, Y[J_HEAD] - oy, rHead + 1.5f);
    int x0 = std::max(0, (int)floorf(minX)), x1 = std::min(STK_TEX - 1, (int)ceilf(maxX));
    int y0 = std::max(0, (int)floorf(minY)), y1 = std::min(STK_TEX - 1, (int)ceilf(maxY));
    for (int py = y0; py <= y1; py++) for (int px = x0; px <= x1; px++) {
        float fx = px + 0.5f + ox, fy = py + 0.5f + oy, d = 1e9f;
        for (int i = 0; i < n; i++) d = std::min(d, stkDistSeg(fx, fy, X[bones[i].a], Y[bones[i].a], X[bones[i].b], Y[bones[i].b]) - rLimb);
        if (head) d = std::min(d, hypotf(fx - X[J_HEAD], fy - Y[J_HEAD]) - rHead);
        float cov = clampValue(0.5f - d, 0.0f, 1.0f);
        if (cov <= 0) continue;
        float* q = &gStkBuf[(py * STK_TEX + px) * 4];
        float inv = 1.0f - cov;
        q[0] = cr * cov + q[0] * inv; q[1] = cg * cov + q[1] * inv; q[2] = cb * cov + q[2] * inv; q[3] = cov + q[3] * inv;
    }
}
static void stkDrawBones(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float ox, float oy) {
    stkLayer(X, Y, bones, n, head, 2.35f, 5.9f, STK_OUTLINE, ox, oy);
    stkLayer(X, Y, bones, n, head, 1.5f, 4.95f, STK_BODY, ox, oy);
}
static void drawStickman(const StkPose& pose, int cx, int feetY, double angleDeg) {
    if (!gStkTex) {
        gStkTex = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STREAMING, STK_TEX, STK_TEX);
        if (!gStkTex) return;
        SDL_SetTextureBlendMode(gStkTex, SDL_BLENDMODE_BLEND);
    }
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    const float ox = (float)cx - STK_TEX / 2, oy = (float)(feetY - STK_FEET_Y) - STK_TEX / 2;
    memset(gStkBuf, 0, sizeof(gStkBuf));
    static const StkBone farSet[] = { {J_NECK, J_ELB}, {J_ELB, J_HNB}, {J_HIP, J_KNB}, {J_KNB, J_FTB}, {J_HIP, J_NECK} };
    static const StkBone nearLeg[] = { {J_HIP, J_KNF}, {J_KNF, J_FTF} };
    static const StkBone nearArm[] = { {J_NECK, J_ELF}, {J_ELF, J_HNF} };
    stkDrawBones(X, Y, farSet, 5, true, ox, oy);
    stkDrawBones(X, Y, nearLeg, 2, false, ox, oy);
    stkDrawBones(X, Y, nearArm, 2, false, ox, oy);
    static Uint32 px[STK_TEX * STK_TEX];
    for (int i = 0; i < STK_TEX * STK_TEX; i++) {
        const float* q = &gStkBuf[i * 4];
        float a = q[3];
        if (a <= 0.001f) { px[i] = 0; continue; }
        Uint32 r = (Uint32)clampValue(q[0] / a * 255.0f + 0.5f, 0, 255), g = (Uint32)clampValue(q[1] / a * 255.0f + 0.5f, 0, 255);
        Uint32 b = (Uint32)clampValue(q[2] / a * 255.0f + 0.5f, 0, 255), al = (Uint32)clampValue(a * 255.0f + 0.5f, 0, 255);
        px[i] = r | (g << 8) | (b << 16) | (al << 24);
    }
    SDL_UpdateTexture(gStkTex, nullptr, px, STK_TEX * (int)sizeof(Uint32));
    SDL_Rect dst = { (int)floorf(ox), (int)floorf(oy), STK_TEX, STK_TEX };
    SDL_RenderCopy(uvzRenderer, gStkTex, nullptr, &dst);
}
static void stickHand(const StkPose& pose, int cx, int feetY, double angleDeg, float& hx, float& hy) {
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    hx = X[J_HNF]; hy = Y[J_HNF];
}
static float gRunPhase = 0;
static StkAnim gPlayerAnim, gMenuAnim;

static void buildArt() {
    for (int s = 0; s < 6; s++) for (int v = 0; v < 3; v++) gTile[s][v] = createTexture(makeTile(s, v));
    for (int v = 0; v < 3; v++) gFar[v] = createTexture(makeFar(v));
}
static void tileMod(int r, int g, int b) {
    for (int s = 0; s < 6; s++) for (int v = 0; v < 3; v++) SDL_SetTextureColorMod(gTile[s][v], (Uint8)r, (Uint8)g, (Uint8)b);
}

struct Settings { float music = 0.6f, sfx = 0.8f, sens = 1.0f, swingAssist = 0.5f; bool shake = true, reduced = false, full = true, targetHints = true; float best = 0; };
static Settings cfg;
static std::string savePath, ctlPath, progPath;
static combo::State gCombo;
static std::string comboPath;
static prog::Data gProg;
static int coinMilestones = 0, runCoins = 0;
static void saveProg() { prog::saveFile(progPath, gProg); }
static void fmtNum(long long v, char* out, size_t n) {
    char t[32]; snprintf(t, sizeof t, "%lld", v);
    int len = (int)strlen(t), o = 0;
    for (int i = 0; i < len && o < (int)n - 2; i++) { if (i > 0 && (len - i) % 3 == 0) out[o++] = ','; out[o++] = t[i]; }
    out[o] = 0;
}
static const float PHYS_CAP = 8.0f;
static float runMult() { return std::min(prog::totalMult(gProg, prog::RUN), PHYS_CAP); }
static float swingMult() { return std::min(prog::totalMult(gProg, prog::SWING), PHYS_CAP); }
static void loadCfg() {
    char* pp = SDL_GetPrefPath("PixelCity", "StickmanPixelCity");
    std::string dir = pp ? pp : "";
    savePath = dir + "save.txt";
    ctlPath = dir + "controls.txt";
    progPath = dir + "progress.txt";
    comboPath = dir + "combo.txt";
    if (pp) SDL_free(pp);
    prog::loadFile(progPath, gProg);
    combo::loadFile(comboPath, gCombo.best);
    FILE* f = fopen(savePath.c_str(), "r");
    if (!f) return;
    int sh = 1, rd = 0, fu = 1;
    float m, s, se, b;
    if (fscanf(f, "%f %f %f %d %d %d %f", &m, &s, &se, &sh, &rd, &fu, &b) == 7) {
        cfg.music = clampValue(m, 0, 1); cfg.sfx = clampValue(s, 0, 1); cfg.sens = clampValue(se, 0.5f, 1.5f);
        cfg.shake = sh != 0; cfg.reduced = rd != 0; cfg.full = fu != 0; cfg.best = std::max(0.0f, b);
        float assist = 0.5f; int hints = 1, version = 1;
        if (fscanf(f, "%f %d", &assist, &hints) >= 1) {
            if (fscanf(f, "%d", &version) != 1) version = 1;
            cfg.swingAssist = version >= 2 ? clampValue(assist, 0.0f, 1.0f)
                                           : clampValue((assist - 0.5f) / 1.3f, 0.0f, 1.0f);
            cfg.targetHints = hints != 0;
        }
    }
    fclose(f);
}
static void saveCfg() {
    FILE* f = fopen(savePath.c_str(), "w");
    if (!f) return;
    fprintf(f, "%f %f %f %d %d %d %f %f %d 2\n", cfg.music, cfg.sfx, cfg.sens, cfg.shake, cfg.reduced, cfg.full, cfg.best, cfg.swingAssist, cfg.targetHints);
    fclose(f);
    saveProg();
}

enum Act { A_LEFT, A_RIGHT, A_JUMP, A_SLIDE, A_SWING, A_PAUSE, A_N };
static const char* const ACT_LABEL[A_N] = {"STEER LEFT", "STEER RIGHT", "JUMP", "SLIDE", "SWING", "PAUSE"};
static const SDL_Scancode ACT_DEFAULT[A_N] = {SDL_SCANCODE_A, SDL_SCANCODE_D, SDL_SCANCODE_SPACE, SDL_SCANCODE_S, SDL_SCANCODE_LSHIFT, SDL_SCANCODE_P};
struct Controls {
    SDL_Scancode key[A_N];
    float scale = 1.0f, alpha = 0.7f;
    bool lefty = false;
    float px[3], py[3];
    Controls() { resetKeys(); resetTouch(); }
    void resetKeys() { for (int i = 0; i < A_N; i++) key[i] = ACT_DEFAULT[i]; }
    void resetTouch() { scale = 1.0f; alpha = 0.7f; lefty = false; for (int i = 0; i < 3; i++) px[i] = py[i] = -1.0f; }
};
static Controls ctl;
static void loadControls() {
    FILE* f = fopen(ctlPath.c_str(), "r");
    if (!f) return;
    int k[A_N], lf = 0;
    float sc, al, px[3], py[3];
    int n = fscanf(f, "%d %d %d %d %d %d %f %f %d %f %f %f %f %f %f", &k[0], &k[1], &k[2], &k[3], &k[4], &k[5],
                   &sc, &al, &lf, &px[0], &py[0], &px[1], &py[1], &px[2], &py[2]);
    if (n == 15) {
        for (int i = 0; i < A_N; i++) if (k[i] > 0 && k[i] < SDL_NUM_SCANCODES) ctl.key[i] = (SDL_Scancode)k[i];
        ctl.scale = clampValue(sc, 0.7f, 1.4f); ctl.alpha = clampValue(al, 0.2f, 1.0f); ctl.lefty = lf != 0;
        for (int i = 0; i < 3; i++) { ctl.px[i] = px[i] < 0 ? -1.0f : clampValue(px[i], 0, 1); ctl.py[i] = px[i] < 0 ? -1.0f : clampValue(py[i], 0, 1); }
    }
    fclose(f);
}
static void saveControls() {
    FILE* f = fopen(ctlPath.c_str(), "w");
    if (!f) return;
    for (int i = 0; i < A_N; i++) fprintf(f, "%d ", (int)ctl.key[i]);
    fprintf(f, "%f %f %d", ctl.scale, ctl.alpha, ctl.lefty ? 1 : 0);
    for (int i = 0; i < 3; i++) fprintf(f, " %f %f", ctl.px[i], ctl.py[i]);
    fprintf(f, "\n");
    fclose(f);
}

struct Voice { bool on = false; int type = 0; float t = 0, dur = 0.1f, f0 = 440, f1 = 440, amp = 0.5f, ph = 0; };
static SDL_AudioDeviceID gAud = 0;
static Voice vox[12];
static std::atomic<float> aMusic{0.6f}, aSfx{0.8f}, aWind{0.0f};
static std::atomic<int> aMode{0};
static bool audioStarted = false;

static void audioCB(void*, Uint8* stream, int len) {
    float* o = (float*)stream;
    int n = len / (int)(sizeof(float) * 2);
    const float sr = 44100.0f;
    static double mt = 0;
    static u32 nz = 22222;
    static float wlp = 0, rlp = 0, bph = 0, kph = 0, nlp = 0, lpb = 0;
    static float pad[3] = {0, 0, 0}, arp = 0;
    static const float bassF[4] = {55.0f, 43.65f, 65.41f, 49.0f};
    static const float chord[4][3] = {{220, 261.63f, 329.63f}, {174.61f, 220, 261.63f}, {261.63f, 329.63f, 392}, {196, 246.94f, 293.66f}};
    float mv = aMusic.load(), sv = aSfx.load(), wind = aWind.load();
    int mode = aMode.load();
    for (int i = 0; i < n; i++) {
        nz ^= nz << 13; nz ^= nz >> 17; nz ^= nz << 5;
        float noise = ((nz & 0xFFFF) / 32768.0f) - 1.0f;
        float m = 0;
        if (mode > 0) {
            double step = mt / 0.15625;
            int si = (int)step; float sp = (float)(step - si);
            int bar = (si / 8) & 3;
            for (int k = 0; k < 3; k++) {
                pad[k] += chord[bar][k] / sr; if (pad[k] > 1) pad[k] -= 1;
                m += sinf(2 * pi * pad[k]) * 0.035f;
            }
            bph += bassF[bar] / sr; if (bph > 1) bph -= 1;
            float saw = (2 * bph - 1);
            lpb += (saw - lpb) * 0.06f;
            m += lpb * 0.22f * (0.6f + 0.4f * expf(-sp * 2.0f));
            if (mode == 2) {
                int idx = (si % 4 == 3) ? 1 : (si % 4);
                arp += chord[bar][idx] * 2 / sr; if (arp > 1) arp -= 1;
                m += (2 * fabsf(2 * arp - 1) - 1) * 0.07f * expf(-sp * 4);
                float tt = sp * 0.15625f;
                if (si % 4 == 0) { kph += (50 + 110 * expf(-tt * 35)) / sr; m += sinf(2 * pi * kph) * expf(-tt * 14) * 0.45f; }
                nlp += (noise - nlp) * 0.5f;
                if (si % 2 == 1) m += (noise - nlp) * expf(-sp * 10) * 0.05f;
                if (si % 8 == 4) m += noise * expf(-sp * 5) * 0.12f;
            } else m *= 0.7f;
            mt += 1.0 / sr;
        }
        m *= mv * 0.8f;
        float s = 0;
        for (int v = 0; v < 12; v++) {
            Voice& vo = vox[v];
            if (!vo.on) continue;
            float tt = vo.t / vo.dur, env = (1 - tt) * (1 - tt);
            float f = vo.f0 + (vo.f1 - vo.f0) * tt;
            if (vo.type == 3) f = tt < 0.4f ? vo.f0 : vo.f1;
            vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
            float w;
            switch (vo.type) {
                case 0: w = noise * 0.5f + sinf(2 * pi * vo.ph) * 0.3f; break;
                case 1: w = sinf(2 * pi * vo.ph) * 0.6f + (vo.ph < 0.5f ? 0.15f : -0.15f); break;
                case 2: w = sinf(2 * pi * vo.ph) * 0.8f + (tt < 0.4f ? noise * 0.3f : 0.0f); break;
                case 3: w = sinf(2 * pi * vo.ph) * 0.5f; break;
                case 4: w = vo.ph < 0.5f ? 0.3f : -0.3f; break;
                case 5: w = (2 * vo.ph - 1) * 0.4f; break;
                case 6: w = noise * 0.4f; break;
                default: w = sinf(2 * pi * vo.ph) * 0.5f; break;
            }
            s += w * env * vo.amp;
            vo.t += 1.0f / sr;
            if (vo.t >= vo.dur) vo.on = false;
        }
        rlp += (noise - rlp) * 0.0025f;
        wlp += (noise - wlp) * (0.02f + 0.12f * wind);
        s += rlp * 0.9f + wlp * (0.03f + 0.45f * wind);
        s *= sv;
        float out = clampValue(m + s, -1, 1);
        o[i * 2] = out; o[i * 2 + 1] = out;
    }
}
static void initAudio() {
    SDL_AudioSpec want, have;
    SDL_zero(want);
    want.freq = 44100; want.format = AUDIO_F32SYS; want.channels = 2; want.samples = 1024; want.callback = audioCB;
    gAud = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void sfx(int type) {
    if (!gAud) return;
    static const float P[9][4] = {
        {0.14f, 900, 1800, 0.5f}, {0.10f, 1200, 400, 0.6f}, {0.16f, 130, 45, 0.9f}, {0.16f, 880, 1320, 0.5f},
        {0.05f, 600, 600, 0.4f}, {0.90f, 440, 90, 0.6f}, {0.12f, 500, 500, 0.5f}, {0.12f, 300, 650, 0.5f}, {0.24f, 700, 1900, 0.55f}};
    SDL_LockAudioDevice(gAud);
    int slot = 0; float oldest = -1;
    for (int i = 0; i < 12; i++) { if (!vox[i].on) { slot = i; oldest = 1e9f; break; } if (vox[i].t > oldest) { oldest = vox[i].t; slot = i; } }
    Voice& v = vox[slot];
    v.on = true; v.type = type; v.t = 0; v.dur = P[type][0]; v.f0 = P[type][1]; v.f1 = P[type][2]; v.amp = P[type][3]; v.ph = 0;
    SDL_UnlockAudioDevice(gAud);
}

enum State { TITLE, MAIN_MENU, SETTINGS, CONTROLS, LAYOUT_EDIT, HOW_TO_PLAY, CREDITS, SKILLS, PLAYING, PAUSED, GAME_OVER };
static State gState = TITLE, navRoot = MAIN_MENU;
static std::vector<State> navStack;
static bool isSub(State s) { return s == SETTINGS || s == CONTROLS || s == LAYOUT_EDIT || s == HOW_TO_PLAY || s == CREDITS || s == SKILLS; }
static void openSub(State s) { if (!isSub(gState)) { navRoot = gState; navStack.clear(); } navStack.push_back(gState); gState = s; }
static void goBack() { if (!navStack.empty()) { gState = navStack.back(); navStack.pop_back(); } else gState = navRoot; }
static double gTime = 0;

static const float STREET_GROUND_Y = 0.0f;
static const float TRAFFIC_SIGNAL_CYCLE = 14.0f;
struct Obs { int type; float x, w, h; bool solid; int param; };
struct Building {
    float x, w, roofY; int style; u32 seed;
    std::vector<Obs> obs;
    bool mastL = false, mastR = false, cable = false;
    float cx0 = 0, cy0 = 0, cx1 = 0, cy1 = 0;
};
struct TrafficSignal { float x, offset; };
struct TrafficCar {
    float x, speed, maxSpeed, width, height;
    int type, lane, dir;
    u32 color;
};
struct Part { float x, y, vx, vy, life, max; u32 c; int sz; bool alive; };

static std::deque<Building> bld;
static std::deque<TrafficSignal> trafficSignals;
static std::deque<TrafficCar> trafficCars;
static float nextTrafficSpawnX = 0;
static int trafficSerial = 0;
static Part parts[220];
static int partHead = 0;
static Rng wrng(1);

struct Player {
    float x = 0, y = 0, px = 0, py = 0;
    float vx = 0, vy = 0;
    bool onGround = false, swinging = false, alive = true, usedAir = false;
    bool wallCling = false, webFlying = false;
    float wallX = 0, wallDir = 1;
    float webX = 0, webY = 0, webStartX = 0, webStartY = 0, webT = 0, webDur = 0.18f;
    float ax = 0, ay = 0, rope = 0;
    float coyote = 0, jumpBuf = 0;
    float landT = 0, shootT = 0, attachT = 0, releaseT = 0, deadT = 0, flipT = 0;
    bool hero = false;
    int runStyle = 0, jumpStyle = 0, fallStyle = 0, swingStyle = 0, landStyle = 0, shootStyle = 0;
    float slideT = 0, slideBuf = 0;
    int slideStyle = 0;
    float boostT = 0, boostDur = 1, boostExtra = 0;
    float jit = 0;
    bool releaseFlip = false;
    float flipDir = 1;
    int chain = 0;
    float swingT = 0;
    float launchT = 0, launchK = 0, launchDur = 0.25f;
    float perfectT = 0;
    int wrapN = 0; float wrapCool = 0;
    float vaultT = 0;
    float wallEdge = 0;
    float climbPhase = 0;
    float wallCool = 0;
    float wallLastEdge = -1e9f, wallLastCool = 0;
    float wallJumpT = 0;
    float wallImpact = 0;
    int trickType = 0;
    float trickT = 0, trickDur = 0, trickCool = 0, trickDoneT = 0, trickApexQ = 0;
    bool trickReady = false, trickNear = false;
    int trickLast = 0;
    float mantleT = 0, mantleX0 = 0, mantleY0 = 0, mantleX1 = 0, mantleY1 = 0;
    bool zipping = false; float zipX = 0, zipY = 0, zipT = 0, zipCool = 0;
    bool diving = false; float diveT = 0, diveCool = 0;
};
static Player P;
enum { T_NONE, T_FRONT, T_BACK, T_TWIST, T_CART };
static float gTrickHeat = 0;
static float gTrickMsgT = 0; static char gTrickMsg[40] = ""; static char gStuntName[28] = ""; static bool gTrickBad = false;
static float camX = 0, camY = 0, startX = 0, shakeT = 0, chainShowT = 0;
static float distM = 0, bonus = 0, speedBonus = 0;
static bool newBest = false;
static bool zipEdge = false, diveHeld = false, slideHeld = false;
static float gSlideHoldT = 0;
static float gSense = 0, gSenseTgt = 0, gSenseAng = 0, gSenseT = 0;
static bool jumpEdge = false, slideEdge = false, jumpRel = false, swingHeld = false, swingWas = false;
static float steer = 0;
static float gFlow = 0;
static int gPerfectStreak = 0;
static float gPerfectShowT = 0;
static int gComboNm = -1, gComboNmPrev = -2;
static float gComboNmX = 0, gComboNmGap = 1e9f;
static float camPunch = 0;
struct Trail { float x, y, t, max; u32 c; };
static Trail gTrail[16];
static int gTrailHead = 0;
static float gTrailTick = 0;
static bool haveTarget = false;
static float tgtX = 0, tgtY = 0;
static float aimX = 0, aimY = 0;
static bool aimDown = false;
static float aimHoldT = 0;
static float autoCool = 0, gAirT = 0, hintT = 0, nextT = 0;
static bool hintFound = false, nextOk = false;
static float hintX = 0, hintY = 0;
static void badClear();
static float gLastPickX = 1e9f, gLastPickY = 1e9f;
static float trans = -1, menuT = 0, fadeIn = 0;

static const float GRAV = 1400.0f;
static float difficulty() { return clampValue(distM / 2000.0f, 0, 1); }
static int scoreVal() { return (int)(distM + bonus + speedBonus); }

static void spawnPart(float x, float y, float vx, float vy, float life, u32 c, int sz = 2) {
    if (cfg.reduced && (partHead & 1)) { partHead = (partHead + 1) % 220; return; }
    parts[partHead] = {x, y, vx, vy, life, life, c, sz, true};
    partHead = (partHead + 1) % 220;
}
static void burst(float x, float y, int n, u32 c, float spd) {
    for (int i = 0; i < n; i++) {
        float a = (float)i / n * 2 * pi + wrng.f();
        spawnPart(x, y, cosf(a) * spd * (0.4f + wrng.f()), sinf(a) * spd * (0.4f + wrng.f()), 0.35f + wrng.f() * 0.3f, c);
    }
}
static void doShake(float t) { if (cfg.shake) shakeT = std::max(shakeT, t); }

static const int CITY_GAP_MIN = 420, CITY_GAP_MAX = 700, CITY_W_MIN = 340, CITY_W_MAX = 620;
static float trafficWidth(int type) {
    static const float widths[] = {46.0f, 42.0f, 82.0f, 70.0f};
    return widths[type & 3];
}
static float trafficHeight(int type) {
    static const float heights[] = {27.0f, 24.0f, 38.0f, 34.0f};
    return heights[type & 3];
}
static bool trafficSignalGreen(const TrafficSignal& s, int dir, double time) {
    float phase = fmodf((float)time + s.offset, TRAFFIC_SIGNAL_CYCLE);
    if (phase < 0) phase += TRAFFIC_SIGNAL_CYCLE;
    const bool eastbound = phase < TRAFFIC_SIGNAL_CYCLE * 0.5f;
    return dir > 0 ? eastbound : !eastbound;
}
static void addBuilding(bool first) {
    float d = difficulty();
    Building b;
    b.seed = wrng.next();
    b.style = wrng.range(0, 5);
    float gap = 0;
    if (first) { b.x = -300; b.w = 1100; b.roofY = -300; b.style = 0; }
    else {
        Building& p = bld.back();

        gap = (float)wrng.range((int)(CITY_GAP_MIN + 40 * d), (int)(CITY_GAP_MAX + 160 * d));
        b.w = (float)((wrng.range((int)(CITY_W_MIN - 40 * d), (int)(CITY_W_MAX - 100 * d)) / 16) * 16);
        int maxRise = gap > 300 ? 150 : 100;
        b.roofY = clampValue(p.roofY + wrng.range(-maxRise, maxRise), -560, -140);
        b.x = p.x + p.w + gap;
        trafficSignals.push_back({p.x + p.w + gap * 0.5f, wrng.f() * TRAFFIC_SIGNAL_CYCLE});
        if (b.style == p.style) b.style = (b.style + 1 + wrng.range(0, 4)) % 6;
        if (gap > 150) {
            p.mastR = true; b.mastL = true; p.cable = true;
            p.cx0 = p.x + p.w - 10; p.cy0 = p.roofY - 280; p.cx1 = b.x + 10; p.cy1 = b.roofY - 280;
        }
    }
    if (!first && b.w >= 440 && wrng.f() < 0.3f + 0.5f * d) {
        int n = (b.w >= 700 && wrng.f() < 0.5f) ? 2 : 1;
        float x = b.x + 260;
        for (int i = 0; i < n; i++) {
            int ty = wrng.range(0, 2);
            float w = ty == 0 ? 28.0f : (ty == 1 ? 30.0f : 24.0f), h = ty == 0 ? 20.0f : (ty == 1 ? 46.0f : 14.0f);
            float span = (b.x + b.w - 200) - x - w;
            if (span < 0) break;
            x += wrng.range(0, (int)std::min(span, 160.0f));
            b.obs.push_back({ty, x, w, h, true, 0});
            x += w + 230;
        }
    }
    if (!first) {

        b.obs.push_back({3, b.x + b.w * 0.22f, 3, (float)wrng.range(380, 620), false, 0});
        b.obs.push_back({3, b.x + b.w * 0.78f, 3, (float)wrng.range(380, 620), false, 0});
        int masts = wrng.range(0, 1);
        for (int i = 0; i < masts; ++i) {
            float x = b.x + 70 + wrng.f() * std::max(80.0f, b.w - 140.0f);
            float h = (float)wrng.range(260, 620);
            b.obs.push_back({3, x, 3, h, false, 0});
        }
    }
    if (b.w > 320 && wrng.f() < (b.style == 5 ? 0.95f : 0.65f)) {
        float x = b.x + wrng.range(40, (int)b.w - 170), h = (float)wrng.range(220, 300);
        b.obs.push_back({4, x, 110, h, false, 0});
    }
    if (b.w > 320 && wrng.f() < 0.65f) {
        float x = b.x + wrng.range(20, (int)b.w - 130);
        b.obs.push_back({5, x, 96, 114, false, wrng.range(0, 3)});
    }
    if (wrng.f() < 0.4f) b.obs.push_back({6, b.x + wrng.range(20, std::max(21, (int)b.w - 20)), 12, 16, false, 0});
    bld.push_back(std::move(b));
}
static void ensureWorld() {
    while (bld.back().x + bld.back().w < camX + uvzWorldWidth + 1400) addBuilding(false);
    while (bld.size() > 3 && bld.front().x + bld.front().w < camX - 800) bld.pop_front();
    while (trafficSignals.size() > 2 && trafficSignals.front().x < camX - 800) trafficSignals.pop_front();
}
static void ensureTraffic() {
    if (nextTrafficSpawnX <= 0) nextTrafficSpawnX = std::max(P.x + 380.0f, camX + uvzWorldWidth * 0.25f);
    while (nextTrafficSpawnX < camX + uvzWorldWidth + 850.0f) {
        const u32 seed = hashCoordinates((u32)(trafficSerial + 1), 0x4E5943u, 29u);
        Rng r(seed);
        const int dir = (trafficSerial & 1) ? -1 : 1;
        const int type = trafficSerial % 4;
        static const u32 colors[] = {0xE8B72D, 0xB7473F, 0x3F92B5, 0x747C86, 0x5D9B69, 0xC66F9A};
        TrafficCar car;
        car.x = nextTrafficSpawnX + r.range(0, 90);
        car.speed = 0;
        car.maxSpeed = (float)r.range(type == 2 ? 90 : 120, type == 2 ? 165 : 235);
        car.width = trafficWidth(type);
        car.height = trafficHeight(type);
        car.type = type;
        car.dir = dir;
        car.lane = dir > 0 ? 0 : 1;
        car.color = type == 0 ? 0xE8B72D : colors[1 + r.range(0, 4)];
        trafficCars.push_back(car);
        nextTrafficSpawnX += (float)r.range(280, 430);
        trafficSerial++;
    }
    for (auto it = trafficCars.begin(); it != trafficCars.end();) {
        if (it->x < camX - 620.0f || it->x > camX + uvzWorldWidth + 1900.0f) it = trafficCars.erase(it);
        else ++it;
    }
}
static void updateTraffic(float dt) {
    ensureTraffic();
    for (size_t i = 0; i < trafficCars.size(); ++i) {
        TrafficCar& car = trafficCars[i];
        float targetSpeed = car.maxSpeed;
        float nextSignalDist = 1e9f;
        const TrafficSignal* nextSignal = nullptr;
        for (const TrafficSignal& signal : trafficSignals) {
            const float d = (signal.x - car.x) * car.dir;
            if (d > 0 && d < nextSignalDist) { nextSignalDist = d; nextSignal = &signal; }
        }
        if (nextSignal && !trafficSignalGreen(*nextSignal, car.dir, gTime)) {
            const float usableGap = std::max(0.0f, nextSignalDist - car.width * 0.5f - 8.0f);
            targetSpeed = std::min(targetSpeed, sqrtf(2.0f * 520.0f * usableGap));
        }
        for (size_t j = 0; j < trafficCars.size(); ++j) {
            if (i == j) continue;
            const TrafficCar& ahead = trafficCars[j];
            if (ahead.dir != car.dir || ahead.lane != car.lane) continue;
            const float gap = (ahead.x - car.x) * car.dir - (ahead.width + car.width) * 0.5f;
            if (gap <= 0) continue;
            const float usableGap = std::max(0.0f, gap - 18.0f);
            const float followSpeed = ahead.speed + sqrtf(2.0f * 440.0f * usableGap);
            targetSpeed = std::min(targetSpeed, followSpeed);
        }
        const float accel = targetSpeed < car.speed ? 560.0f : 230.0f;
        car.speed += clampValue(targetSpeed - car.speed, -accel * dt, accel * dt);
        car.x += car.dir * car.speed * dt;
    }
}

static void startRun() {
    bld.clear();
    trafficSignals.clear(); trafficCars.clear(); nextTrafficSpawnX = 0; trafficSerial = 0;
    for (auto& p : parts) p.alive = false;
    wrng = Rng(SDL_GetTicks() * 2654435761u + 17u);
    P = Player();
    badClear(); gLastPickX = gLastPickY = 1e9f; autoCool = gAirT = hintT = nextT = 0; hintFound = nextOk = false; aimX = aimY = 0; aimHoldT = 0;
    gPlayerAnim = StkAnim(); gRunPhase = 0;
    distM = bonus = speedBonus = 0; coinMilestones = runCoins = 0; newBest = false; chainShowT = 0; shakeT = 0;
    combo::resetRun(gCombo); gComboNm = -1; gComboNmPrev = -2;
    gTrickHeat = 0; gTrickMsgT = 0; gTrickBad = false;
    zipEdge = diveHeld = slideHeld = false; gSlideHoldT = 0; gSense = gSenseTgt = gSenseT = 0;
    gFlow = 0; gPerfectStreak = 0; gPerfectShowT = 0; camPunch = 0; gTrailTick = 0; for (auto& t : gTrail) t.t = 0;
    addBuilding(true);
    P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; P.vx = 230; P.onGround = true;
    startX = P.x;
    P.runStyle = wrng.range(0, 2);
    camX = P.x - uvzWorldWidth * 0.30f; camY = P.y - uvzWorldHeight * 0.58f;
    ensureWorld();
    ensureTraffic();
    gState = PLAYING;
    aMode = 2;
}

static int assistPct() { return (int)lroundf(clampValue(cfg.swingAssist, 0.0f, 1.0f) * 100.0f); }
static bool fullAssist() { return assistPct() >= 100; }
static const float AIM_DEF_X = 0.8192f, AIM_DEF_Y = -0.5736f;
static const float AIM_HOLD = 1.3f;

struct AssistTune { float a, w, tolRad, reach, maxUp, maxLen, behindMin; };
static AssistTune assistTune(float a, bool stick) {
    AssistTune t;
    a = clampValue(a, 0.0f, 1.0f);
    t.a = a;
    t.w = a * (stick && a < 0.999f ? 0.85f : 1.0f);
    t.tolRad = (9.0f + 71.0f * powf(a, 1.15f)) * pi / 180.0f;
    t.reach = 2200.0f + 800.0f * a;
    t.maxUp = 1500.0f + 500.0f * a;
    t.maxLen = 2400.0f + 600.0f * a;
    t.behindMin = -900.0f * (1 - a) * (1 - a) + 40.0f * a;
    return t;
}

static const float BAD_R = 40.0f;
struct BadAnchor { float x, y, t; };
static BadAnchor gBad[10];
static void markBad(float x, float y, float secs) {
    int slot = 0;
    for (int i = 0; i < 10; i++) {
        if (gBad[i].t > 0 && hypotf(gBad[i].x - x, gBad[i].y - y) < BAD_R) { gBad[i].t = std::max(gBad[i].t, secs); return; }
        if (gBad[i].t < gBad[slot].t) slot = i;
    }
    gBad[slot] = {x, y, secs};
}
static void badClear() { for (auto& b : gBad) b.t = 0; }
static bool isBad(float x, float y) {
    for (auto& b : gBad) if (b.t > 0 && hypotf(b.x - x, b.y - y) < BAD_R) return true;
    return false;
}
static void badTick(float dt) { for (auto& b : gBad) if (b.t > 0) b.t -= dt; }

static bool segBox(float x0, float y0, float x1, float y1, float L, float T, float R, float Bt, float* tIn = nullptr, bool* top = nullptr) {
    const float d[2] = {x1 - x0, y1 - y0}, o[2] = {x0, y0}, lo[2] = {L, T}, hi[2] = {R, Bt};
    float t0 = 0, t1 = 1; bool enterTop = false;
    for (int i = 0; i < 2; i++) {
        if (fabsf(d[i]) < 1e-6f) { if (o[i] < lo[i] || o[i] > hi[i]) return false; continue; }
        float ta = (lo[i] - o[i]) / d[i], tb = (hi[i] - o[i]) / d[i];
        const bool lowFirst = ta <= tb;
        if (!lowFirst) std::swap(ta, tb);
        if (ta > t0) { t0 = ta; enterTop = (i == 1 && lowFirst); }
        if (tb < t1) t1 = tb;
        if (t0 > t1) return false;
    }
    if (tIn) *tIn = t0;
    if (top) *top = enterTop;
    return true;
}
static bool webBlocked(float x0, float y0, float x1, float y1) {
    const float lx = std::min(x0, x1) - 4, hx = std::max(x0, x1) + 4;
    for (auto& b : bld) {
        if (b.x > hx || b.x + b.w < lx) continue;
        float t;
        // At street height the player is in front of the facade; allow a web to reach its roofline.
        // Higher airborne paths still respect the building wall as an occluder.
        if (y0 < STREET_GROUND_Y - 140.0f &&
            segBox(x0, y0, x1, y1, b.x, b.roofY + 3, b.x + b.w, STREET_GROUND_Y - 56.0f, &t) && t < 0.97f) return true;
        for (auto& o : b.obs)
            if (o.solid && segBox(x0, y0, x1, y1, o.x, b.roofY - o.h, o.x + o.w, b.roofY, &t) && t < 0.97f) return true;
    }
    return false;
}
static const float WEB_PAD = 18.0f;
struct WebHit { float x, y, t; };
static void rayBox(float x0, float y0, float x1, float y1, float L, float T, float R, float Bt, float pad, WebHit& best) {
    float t;
    if (!segBox(x0, y0, x1, y1, L - pad, T - pad, R + pad, Bt + pad, &t)) return;
    if (t <= 0.0005f || t >= best.t) return;
    best.x = clampValue(lerpValue(x0, x1, t), L, R); best.y = clampValue(lerpValue(y0, y1, t), T, Bt); best.t = t;
}
static bool rayTarget(float x0, float y0, float dx, float dy, float len, float& hx, float& hy) {
    const float x1 = x0 + dx * len, y1 = y0 + dy * len;
    const float lx = std::min(x0, x1) - 60, rx = std::max(x0, x1) + 60;
    WebHit best = {0, 0, 2.0f};
    for (auto& b : bld) {
        if (b.x > rx || b.x + b.w < lx) continue;
        rayBox(x0, y0, x1, y1, b.x, b.roofY, b.x + b.w, b.roofY + 3200, 0, best);
        for (auto& o : b.obs) {
            const float top = b.roofY - o.h;
            switch (o.type) {
                case 0: case 1: case 2: rayBox(x0, y0, x1, y1, o.x, top, o.x + o.w, b.roofY, 0, best); break;
                case 3: rayBox(x0, y0, x1, y1, o.x, top, o.x + o.w, b.roofY, WEB_PAD, best); break;
                case 4: rayBox(x0, y0, x1, y1, o.x, top, o.x + 6, b.roofY, WEB_PAD, best);
                        rayBox(x0, y0, x1, y1, o.x - 30, top, o.x + o.w, top + 4, WEB_PAD, best); break;
                case 5: rayBox(x0, y0, x1, y1, o.x, b.roofY - 114, o.x + o.w, b.roofY - 68, WEB_PAD * 0.6f, best); break;
                default: break;
            }
        }
        if (b.cable) {
            float px = b.cx0, py = b.cy0;
            for (int i = 1; i <= 8; i++) {
                const float u = i / 8.0f, qx = lerpValue(b.cx0, b.cx1, u), qy = lerpValue(b.cy0, b.cy1, u) + 22 * 4 * u * (1 - u);
                rayBox(x0, y0, x1, y1, std::min(px, qx), std::min(py, qy), std::max(px, qx), std::max(py, qy), WEB_PAD, best);
                px = qx; py = qy;
            }
        }
    }
    if (best.t > 1.0f) return false;
    hx = best.x; hy = best.y;
    return true;
}
static float swingSpeedCap(float sm) { return 1400.0f + 300.0f * sm + 250.0f * gFlow; }
static float swingMaxFwd(float rope) { return std::max(200.0f, 0.8f * rope); }
struct ReleaseFx { float base, extra; bool perfect; };
static ReleaseFx releaseEval(float vx, float vy) {
    ReleaseFx r;
    const float sp = hypotf(vx, vy);
    r.base = 0.08f * clampValue((sp - 450.0f) / 700.0f, 0.0f, 1.0f);
    const float ang = atan2f(-vy, vx) * 180.0f / pi;
    const float angleQ = vx > 0 ? clampValue(1.0f - fabsf(ang - 40.0f) / 30.0f, 0.0f, 1.0f) : 0.0f;
    r.perfect = angleQ >= 0.5f && sp >= 380.0f;
    r.extra = r.perfect ? 0.05f + 0.07f * angleQ * clampValue((sp - 300.0f) / 500.0f, 0.0f, 1.0f) : 0.0f;
    return r;
}
static float releaseBoostK(float vx, float vy) { const ReleaseFx r = releaseEval(vx, vy); return r.base + r.extra; }
static bool autoLetGo(float dxp, float rope, float swT, float vx, float vy) {
    const float relAt = clampValue(0.28f * rope, 45.0f, 170.0f);
    return swT > 0.3f && dxp > relAt && (releaseEval(vx, vy).perfect || dxp > 0.6f * rope);
}
static void swingStep(float& x, float& y, float& vx, float& vy, float ax, float ay, float rope, float sm, float steerIn, float dt) {
    float dx = x - ax, dy = y - ay, d = hypotf(dx, dy);
    const float cap = swingSpeedCap(sm);
    if (d > 0.001f) {
        const float nx = dx / d, ny = dy / d;
        if (fabsf(steerIn) > 0.01f) {
            const float f = steerIn * 420.0f * sqrtf(sm) * dt;
            vx += f * (1.0f - nx * nx); vy += f * (-nx * ny);
        }

        if (vx > 0 && vy > 0 && ny > 0) {
            const float w = ny * ny, sp = hypotf(vx, vy), room = clampValue(1.0f - sp / cap, 0.0f, 1.0f);
            const float g = 120.0f * sm * (1.0f + 0.4f * gFlow) * w * room * dt / std::max(sp, 1.0f);
            vx += vx * g; vy += vy * g;
        }
        if (d > rope) {
            x = ax + nx * rope; y = ay + ny * rope;
            const float vr = vx * nx + vy * ny;
            if (vr > 0) { vx -= vr * nx; vy -= vr * ny; }
        }
    }
    const float dr = expf(-0.12f * dt); vx *= dr; vy *= dr;
    const float sp = hypotf(vx, vy);
    if (sp > cap) { vx *= cap / sp; vy *= cap / sp; }
}
static float simSwing(float px, float py, float vx, float vy, float ax, float ay, float sm) {
    const float dt = 1.0f / 40.0f;
    float x = px, y = py, t = 0, rope = 0, swT = 0;
    const float fl = clampValue(hypotf(ax - x, ay - (y - 10)) / (1900.0f * sm), 0.12f / sm, 0.65f);
    bool sw = false, flew = false;
    for (int i = 0; i < 120; i++) {
        if (!sw && !flew && t >= fl) { sw = true; flew = true; rope = std::max(90.0f, hypotf(x - ax, y - ay)); swT = 0; }
        vy += GRAV * (sw ? sm : 1.0f) * dt;
        x += vx * dt; y += vy * dt;
        if (sw) {
            swingStep(x, y, vx, vy, ax, ay, rope, sm, 0.0f, dt);
            swT += dt;
            const float dxp = x - ax;
            if (autoLetGo(dxp, rope, swT, vx, vy) || dxp > swingMaxFwd(rope) || swT > 2.4f) {
                sw = false;
                const float k = releaseBoostK(vx, vy); vx *= 1 + k; vy *= 1 + k;
            }
        } else vx *= expf(-0.05f * dt);
        t += dt;
        const float pl = x - 8, pr = x + 8, pt = y - 24, pb = y + 26;
        if (pb >= STREET_GROUND_Y && vy >= 0) return 0.0f;
        for (auto& b : bld) for (auto& o : b.obs) if (o.solid) {
            const float top = b.roofY - o.h;
            if (pr > o.x && pl < o.x + o.w && pb > top && pt < b.roofY) return (vx > 200 && !sw) ? 2500.0f : 500.0f;
        }
        if (y > 900) return 3000.0f;
    }
    return 0.0f;
}

struct AssistQuery {
    float fromX, fromY, vx, vy;
    float a;
    bool useAim;
    float aimDx, aimDy;
    bool stick;
    bool hasEx; float exX, exY;
};
static bool pickAnchor(const AssistQuery& q, float& ox, float& oy) {
    struct Cand { float x, y, dx, dy, len, aimErr, c; };
    static Cand cs[128];
    int n = 0;
    const AssistTune tu = assistTune(q.a, q.stick);
    const bool full = q.a >= 0.999f;
    const float sy0 = q.fromY - 10;
    float cmin = 1e9f;
    const float x0 = q.fromX;
    const float tolEff = tu.tolRad * clampValue(q.a * 10.0f, 0.0f, 1.0f);
    const int RAYS = full ? 21 : (tolEff <= 0.0f ? 1 : 25);
    const float aimAng = q.useAim ? atan2f(-q.aimDy, q.aimDx) : 0.0f;
    auto tryRay = [&](float ang, float off) {
        if (n >= 128) return;
        float hx, hy;
        if (!rayTarget(x0, sy0, cosf(ang), -sinf(ang), tu.maxLen, hx, hy)) return;
        const float dx = hx - q.fromX, dy = q.fromY - hy;
        if (dy < 25 || dy > tu.maxUp || dx > tu.reach || dx < tu.behindMin) return;
        const float len = hypotf(dx, dy);
        if (len > tu.maxLen || len < 90) return;
        if (q.hasEx && hypotf(hx - q.exX, hy - q.exY) < 150.0f) return;
        if (q.a > 0.0f && isBad(hx, hy)) return;
        if (webBlocked(x0, sy0, hx, hy)) return;
        Cand& c = cs[n];
        c.x = hx; c.y = hy; c.dx = dx; c.dy = dy; c.len = len;
        c.aimErr = fabsf(off);
        const float lead = clampValue(260.0f + 0.5f * std::max(q.vx, 0.0f), 300.0f, 760.0f);
        float sc = fabsf(dx - lead) + 0.6f * fabsf(dy - 330.0f);
        if (dx < 0) sc += 1200.0f - 3.0f * dx;
        else if (dx < 120) sc += (120.0f - dx) * 5.0f;
        if (len > 1400) sc += (len - 1400.0f) * 0.6f;
        if (hy + len > 700) sc += (hy + len - 700.0f) * 3.0f;
        if (hypotf(hx - gLastPickX, hy - gLastPickY) < BAD_R) sc -= 140.0f * (0.4f + 0.6f * q.a);
        c.c = sc;
        n++;
    };
    for (int r = 0; r < RAYS; r++) {
        float off = 0;
        if (q.useAim) off = RAYS == 1 ? 0.0f : (r - (RAYS - 1) * 0.5f) / ((RAYS - 1) * 0.5f) * tolEff;
        tryRay(q.useAim ? aimAng + off : (10.0f + 4.0f * r) * pi / 180.0f, off);
    }
    if (full || tolEff > 8.0f * pi / 180.0f) {
        for (auto& b : bld) {
            if (b.x > q.fromX + tu.reach || b.x + b.w < q.fromX) continue;
            for (auto& o : b.obs) {
                float tx[3], ty[3]; int k = 0;
                if (o.type == 3) { tx[k] = o.x + 1; ty[k++] = b.roofY - o.h + 3; }
                else if (o.type == 4) { tx[k] = o.x + o.w - 2; ty[k++] = b.roofY - o.h + 2; tx[k] = o.x + o.w * 0.5f; ty[k++] = b.roofY - o.h + 2; }
                else if (o.type == 5) { tx[k] = o.x + o.w * 0.5f; ty[k++] = b.roofY - 112; }
                for (int i = 0; i < k; i++) {
                    const float ang = atan2f(sy0 - ty[i], tx[i] - x0);
                    float off = ang - aimAng;
                    while (off > pi) off -= 2 * pi;
                    while (off < -pi) off += 2 * pi;
                    if (q.useAim && fabsf(off) > tolEff) continue;
                    tryRay(ang, q.useAim ? off : 0.0f);
                }
            }
        }
    }
    if (n == 0) return false;
    if (q.a > 0.0f) {
        const float sm = swingMult();
        bool done[128] = {false};
        for (int k = 0; k < std::min(n, 6); k++) {
            int bi = -1;
            for (int i = 0; i < n; i++) if (!done[i] && (bi < 0 || cs[i].c < cs[bi].c)) bi = i;
            done[bi] = true;
            cs[bi].c += simSwing(q.fromX, q.fromY, q.vx, q.vy, cs[bi].x, cs[bi].y, sm);
        }
        for (int i = 0; i < n; i++) if (!done[i]) cs[i].c += 2500.0f;
    }
    for (int i = 0; i < n; i++) cmin = std::min(cmin, cs[i].c);
    int best = -1; float bestCost = 1e9f;
    for (int i = 0; i < n; i++) {
        const float autoN = (cs[i].c - cmin) / 700.0f;
        const float aimN = (q.useAim && tolEff > 0.0f) ? cs[i].aimErr / tolEff : 0.0f;
        const float cost = q.useAim ? (1.0f - tu.w) * aimN + tu.w * autoN : autoN;
        if (cost < bestCost) { bestCost = cost; best = i; }
    }
    if (best < 0) return false;
    ox = cs[best].x; oy = cs[best].y;
    gLastPickX = ox; gLastPickY = oy;
    return true;
}
static void currentAim(float& dx, float& dy, bool& stick) {
    const float m = hypotf(aimX, aimY);
    stick = m > 0.28f;
    if (stick) { dx = aimX / m; dy = aimY / m; } else { dx = AIM_DEF_X; dy = AIM_DEF_Y; }
}
static AssistQuery makeQuery() {
    AssistQuery q;
    q.fromX = P.x; q.fromY = P.y; q.vx = P.vx; q.vy = P.vy;
    q.a = clampValue(cfg.swingAssist, 0.0f, 1.0f);
    if (fullAssist()) q.a = 1.0f;
    q.useAim = !fullAssist();
    currentAim(q.aimDx, q.aimDy, q.stick);
    q.hasEx = false; q.exX = q.exY = 0;
    return q;
}
static bool findAnchor(float& ox, float& oy) {
    return pickAnchor(makeQuery(), ox, oy);
}
static const u32 COMBO_COL[combo::TIERS + 1] = {0xFFFFFF, 0x7FE0FF, 0x9BFF8A, 0xFFC857, 0xFF5C8A};
static void saveComboBest() { if (gCombo.bestDirty) { gCombo.bestDirty = false; combo::saveFile(comboPath, gCombo.best); } }
static void comboHit(combo::Kind k, float base = -1.0f) {
    if (!P.alive) return;
    const int pts = combo::event(gCombo, k, base);
    if (pts <= 0) return;
    bonus += (float)pts;
    gFlow = std::min(1.0f, gFlow + 0.05f);
    const int t = gCombo.tier;
    const u32 c = COMBO_COL[t];
    burst(P.x, P.y - 10, 3 + 2 * t, c, 90.0f + 25.0f * t);
    if (gCombo.tierUp) {
        gCombo.tierUp = false;
        burst(P.x, P.y - 10, 8 + 4 * t, c, 150.0f + 30.0f * t);
        burst(P.x, P.y - 10, 5, 0xFFFFFF, 100);
        doShake(0.06f + 0.03f * t);
        if (cfg.shake) camPunch = std::max(camPunch, 0.3f + 0.15f * t);
        sfx(t >= 2 ? 8 : 3);
    }
}
static float fastSwingSpeed() {
    const float m = swingMult();
    const float peak = m <= 3.0f ? 381.0f + (m - 1.0f) * 121.0f : 623.0f + (m - 3.0f) * 105.0f;
    return std::max(450.0f, 0.9f * peak);
}
static const float TRICK_DUR[5]  = {0.0f, 0.55f, 0.55f, 0.50f, 0.45f};
static const float TRICK_BASE[5] = {0.0f, 30.0f, 36.0f, 36.0f, 28.0f};
static const char* const TRICK_NAME[5] = {"", "FRONT FLIP", "BACK FLIP", "TWIST", "CARTWHEEL"};
static bool trickFits(float dur) {
    const float feet = P.y + 26.0f;
    for (int k = 1; k <= 4; k++) {
        const float t = dur * 0.25f * k, fx = P.x + P.vx * t, fy = feet + P.vy * t + 0.5f * GRAV * t * t;
        float top = STREET_GROUND_Y;
        for (auto& b : bld) {
            if (fx < b.x - 10 || fx > b.x + b.w + 10) continue;
            for (auto& o : b.obs) if (o.type <= 2 && fx + 10 > o.x && fx - 10 < o.x + o.w) top = std::min(top, b.roofY - o.h);
        }
        if (fy > top - 10.0f) return false;
    }
    return true;
}
static bool tryTrick() {
    Player& p = P;
    if (!p.alive || p.onGround || p.swinging || p.webFlying || p.wallCling || p.trickType || !p.trickReady || p.trickCool > 0) return false;
    if (p.flipT > 0 || (p.releaseFlip && p.releaseT > 0)) return false;
    int ty; float apexQ = 0;
    if (p.vy < -130.0f) ty = steer < -0.3f ? T_BACK : T_FRONT;
    else if (p.vy <= 130.0f) { ty = T_TWIST; apexQ = 1.0f - fabsf(p.vy) / 130.0f; }
    else ty = T_CART;
    if (!trickFits(TRICK_DUR[ty])) return false;
    p.trickType = ty; p.trickT = 0; p.trickDur = TRICK_DUR[ty]; p.trickApexQ = apexQ; p.trickNear = false;
    p.trickReady = false; p.trickDoneT = 0;
    if (fullAssist()) autoCool = std::max(autoCool, p.trickDur);
    sfx(7); burst(p.x, p.y, 3, 0xBFD8FF, 60);
    return true;
}
static void trickDone() {
    Player& p = P;
    const int ty = p.trickType;
    const float sp = hypotf(p.vx, p.vy), speedK = clampValue((sp - 400.0f) / 700.0f, 0.0f, 1.0f);
    float f = 1.0f + 0.6f * speedK;
    if (ty == T_TWIST) f *= 1.0f + 0.4f * p.trickApexQ;
    if (p.trickNear) f *= 1.5f;
    f /= 1.0f + 0.35f * gTrickHeat;
    if (ty == p.trickLast && gTrickHeat > 0.3f) f *= 0.8f;
    const int before = gCombo.count;
    comboHit(combo::STUNT, TRICK_BASE[ty] * f);
    if (gCombo.count > before) {
        gFlow = std::min(1.0f, gFlow + 0.05f + 0.10f * speedK + (p.trickNear ? 0.10f : 0.0f));
        const char* pre = p.trickNear ? "CLOSE " : (ty == T_TWIST && p.trickApexQ > 0.7f ? "PERFECT " : (speedK > 0.6f ? "FAST " : ""));
        snprintf(gStuntName, sizeof gStuntName, "%s%s", pre, TRICK_NAME[ty]);
        snprintf(gTrickMsg, sizeof gTrickMsg, "%s", gStuntName); gTrickBad = false; gTrickMsgT = 0.9f;
    }
    gTrickHeat += 1.0f;
    p.trickLast = ty; p.trickType = 0; p.trickCool = 0.25f; p.trickDoneT = 0.7f;
}
static void trickStep(float dt) {
    Player& p = P;
    if (p.onGround || p.swinging || p.webFlying || p.wallCling || !p.alive) { p.trickType = 0; return; }
    p.trickT += dt;
    if (p.trickT >= p.trickDur) trickDone();
}
static void trickOnNearMiss() {
    if (P.trickType) { P.trickNear = true; return; }
    if (P.trickDoneT > 0 && P.trickLast) {
        P.trickDoneT = 0;
        gCombo.cd[combo::STUNT] = 0;
        const int before = gCombo.count;
        comboHit(combo::STUNT, 22.0f);
        if (gCombo.count > before) { gFlow = std::min(1.0f, gFlow + 0.10f); snprintf(gStuntName, sizeof gStuntName, "CLOSE CALL TRICK"); snprintf(gTrickMsg, sizeof gTrickMsg, "%s", gStuntName); gTrickBad = false; gTrickMsgT = 0.9f; }
    }
}
static void nearMissTick() {
    if (!P.alive || P.onGround || P.wallCling) { gComboNm = -1; gComboNmPrev = -2; return; }
    const Building* cur = nullptr;
    for (auto& b : bld) if (P.x >= b.x && P.x < b.x + b.w) { cur = &b; break; }
    const int id = cur ? (int)cur->x : -1;
    if (id != gComboNmPrev) {
        if (gComboNm != -1 && gComboNmGap >= -2.0f && gComboNmGap <= 26.0f && P.x - gComboNmX >= 110.0f && hypotf(P.vx, P.vy) > 400.0f)
            { comboHit(combo::NEAR_MISS); trickOnNearMiss(); }
        gComboNm = -1; gComboNmPrev = id;
        if (cur) { gComboNm = id; gComboNmX = P.x; gComboNmGap = 1e9f; }
    }
    if (!cur || gComboNm == -1) return;
    float top = STREET_GROUND_Y;
    for (auto& o : cur->obs) if (o.type <= 2 && P.x + 8 > o.x && P.x - 8 < o.x + o.w) top = std::min(top, cur->roofY - o.h);
    const float gap = top - (P.y + 26.0f);
    if (gap > -2.0f) gComboNmGap = std::min(gComboNmGap, gap);
}

static void attachWeb(float ax, float ay) {
    P.swinging = true;
    P.ax = ax; P.ay = ay;
    P.rope = std::max(90.0f, hypotf(P.x - ax, P.y - ay));
    P.chain++;
    P.swingStyle = wrng.range(0, 3); P.jit = wrng.f() * 2 - 1;
    P.attachT = 0.18f;
    P.swingT = 0; P.launchT = 0; P.wrapN = 0; P.wrapCool = 0;
    P.usedAir = false;
    if (P.chain >= 2) { bonus += 10.0f * P.chain; chainShowT = 1.6f; }
    burst(ax, ay, 8, 0xFFFFFF, 90);
    sfx(1);
}
static void releaseWeb(bool boosted, bool failed = false) {
    if (!P.swinging) return;
    P.swinging = false;
    bool perfect = false;
    if (!failed) {
        const ReleaseFx fx = releaseEval(P.vx, P.vy);
        perfect = fx.perfect && P.swingT > 0.35f;
        P.launchK = fx.base + (perfect ? fx.extra : 0.0f);
        P.launchDur = perfect ? 0.32f : 0.25f; P.launchT = P.launchDur;
        if (perfect) {
            P.perfectT = 0.7f; gPerfectStreak++; gPerfectShowT = 1.1f;
            gFlow = std::min(1.0f, gFlow + 0.25f);
            comboHit(combo::PERFECT, 10.0f + 5.0f * std::min(gPerfectStreak, 5));
            if (cfg.shake) camPunch = 1.0f;
            doShake(0.05f);
            burst(P.x, P.y - 10, 10, 0xFFE9A0, 140);
            burst(P.x, P.y - 10, 5, 0xFFFFFF, 90);
            sfx(8);
        } else {
            if (P.swingT > 0.3f) gPerfectStreak = 0;
            if (hypotf(P.vx, P.vy) > 400.0f) gFlow = std::min(1.0f, gFlow + 0.06f);
            if (P.swingT > 0.35f && hypotf(P.vx, P.vy) > fastSwingSpeed()) comboHit(combo::FAST);
        }
    } else { gPerfectStreak = 0; gFlow *= 0.5f; }
    markBad(P.ax, P.ay, failed && P.swingT < 0.45f ? 6.0f : 1.2f);
    if (!failed) P.trickReady = true;
    P.releaseFlip = P.vx > 250 && wrng.f() < 0.4f;
    P.flipDir = wrng.f() < 0.75f ? 1.0f : -1.0f;
    P.fallStyle = wrng.range(0, 1);
    P.releaseT = P.releaseFlip ? 0.5f : 0.25f;
    burst(P.x, P.y - 20, 4, 0xBFD8FF, 60);
    if (perfect) {} else if (boosted) sfx(7); else sfx(6);
}
static void killPlayer() {
    if (!P.alive) return;
    P.alive = false; P.swinging = false; P.deadT = 0; P.trickType = 0;
    combo::crash(gCombo); saveComboBest(); gComboNm = -1;
    P.vy = -320; P.vx = std::min(P.vx, 80.0f) * 0.4f;
    doShake(0.4f);
    burst(P.x, P.y, 14, 0xD62839, 160);
    sfx(5); aMode = 1;
}

static bool swingMeetsWall(float L, float T, float R, bool leftSide) {
    const float rise = (P.y + 26.0f) - T;
    if (leftSide && rise < 170.0f && P.vy < -150.0f && P.vx > 0) {
        P.x = L - 9;
        const float sp = hypotf(P.vx, P.vy);
        releaseWeb(true);
        P.vy = std::min(P.vy, -sqrtf(2.0f * GRAV * std::max(rise + 24.0f, 40.0f)));
        P.vx = std::max(P.vx * 0.6f, 200.0f);
        P.launchT = 0;
        P.vaultT = 0.8f;
        { const float v = hypotf(P.vx, P.vy), cap = swingSpeedCap(swingMult()); if (v > cap) { P.vx *= cap / v; P.vy *= cap / v; } }
        burst(P.x + 6, T, 6, 0xFFFFFF, 80);
        (void)sp;
        return true;
    }
    if (T < P.y - 20.0f && P.wrapN < 2 && P.wrapCool <= 0) {
        const float cx = leftSide ? L - 3 : R + 3, cy = T - 2;
        const float d = hypotf(P.x - cx, P.y - cy);
        if (d < 50.0f) return false;
        P.ax = cx; P.ay = cy; P.rope = d;
        P.wrapN++; P.wrapCool = 0.25f;
        P.x = leftSide ? L - 9 : R + 9;
        burst(cx, cy, 5, 0xFFFFFF, 70);
        sfx(1);
        return true;
    }
    return false;
}
static void solidHit(float L, float T, float R, float Bt, bool lethalSide, bool allowTop = true) {
    float pl = P.x - 8, pr = P.x + 8, pt = P.y - 24, pb = P.y + 26, prevB = P.py + 26;
    if (!(pr > L && pl < R && pb > T && pt < Bt)) return;
    if (allowTop && prevB <= T + 14 && P.vy >= 0) { P.y = T - 26; P.vy = 0; P.onGround = true; return; }
    if (allowTop && pb - T < 26 && P.vy >= -50) { P.y = T - 26; P.vy = std::min(P.vy, 0.0f); P.onGround = true; return; }
    if (!lethalSide && P.vaultT > 0 && P.vy < 0) { if (P.x < (L + R) * 0.5f) P.x = L - 9; return; }
    const bool webSlap = P.swinging && !lethalSide;
    const bool held = !lethalSide && (swingHeld || fullAssist() || P.zipping);
    if (lethalSide || (P.vx > 200 && !webSlap && !held)) { killPlayer(); return; }
    const bool sideHit = (P.py + 26 > T + 10 && P.py - 24 < Bt - 10);
    if (sideHit && !P.onGround && P.alive) {
        const bool leftSide = P.x < (L + R) * 0.5f;
        const float edge = leftSide ? L : R;
        P.x = leftSide ? L - 9 : R + 9;
        const bool recent = P.wallCool > 0 || (P.wallLastCool > 0 && fabsf(edge - P.wallLastEdge) < 1.0f);
        if (!recent && (webSlap || held)) {
            if (webSlap && swingMeetsWall(L, T, R, leftSide)) return;
            P.wallX = P.x; P.wallDir = leftSide ? 1.0f : -1.0f; P.wallEdge = edge;
            if (P.swinging) markBad(P.ax, P.ay, 3.0f);
            P.wallImpact = hypotf(P.vx, P.vy);
            if (P.wallImpact > 220.0f) { sfx(2); burst(P.x + P.wallDir * 8, P.y, 4, 0x9AA0C0, 50); }
            P.wallCling = true; P.swinging = false; P.webFlying = false; P.onGround = false;
            P.vx = 0; P.vy = P.vy < 0 ? clampValue(P.vy * 0.75f, -320.0f, 0.0f) : clampValue(P.vy * 0.6f, 0.0f, 280.0f);
            P.landT = 0; P.releaseT = 0; P.flipT = 0; P.slideT = 0; P.jumpBuf = 0; P.mantleT = 0; P.climbPhase = 0;
            return;
        }
    }
    if (P.x < (L + R) * 0.5f) P.x = L - 8; else P.x = R + 8;
    P.vx = std::min(P.vx, 0.0f) * 0.2f;
    if (P.swinging) releaseWeb(false, true);
}
static void collide() {
    for (auto& b : bld) {
        if (b.x + b.w < P.x - 20 || b.x > P.x + 20) continue;
        const float wallBottom = STREET_GROUND_Y - 56.0f;
        const bool aboveStreet = P.y + 26.0f < STREET_GROUND_Y - 40.0f;
        if (aboveStreet) {
            const bool crossedLeftFace = P.px + 8.0f <= b.x && P.x + 8.0f > b.x;
            const bool crossedRightFace = P.px - 8.0f >= b.x + b.w && P.x - 8.0f < b.x + b.w;
            if (crossedLeftFace) solidHit(b.x - 1.0f, b.roofY, b.x + 1.0f, wallBottom, false, false);
            else if (crossedRightFace) solidHit(b.x + b.w - 1.0f, b.roofY, b.x + b.w + 1.0f, wallBottom, false, false);
            if (!P.alive) return;
        }
        for (auto& o : b.obs) if (o.solid) { solidHit(o.x, b.roofY - o.h, o.x + o.w, b.roofY, true); if (!P.alive) return; }
    }
    if (P.y + 26.0f >= STREET_GROUND_Y && P.vy >= 0.0f) {
        P.y = STREET_GROUND_Y - 26.0f;
        P.vy = 0.0f;
        P.onGround = true;
    }
    for (const TrafficCar& car : trafficCars) {
        const float carL = car.x - car.width * 0.5f, carR = car.x + car.width * 0.5f;
        const float carBottom = STREET_GROUND_Y + (car.lane ? 8.0f : -5.0f), carTop = carBottom - car.height;
        if (P.x + 8.0f > carL && P.x - 8.0f < carR && P.y + 26.0f > carTop && P.y - 24.0f < carBottom) {
            killPlayer();
            return;
        }
    }
}

static const float WALL_GAP = 9.0f;
static const float CLIMB_UP = 215.0f, SLIDE_DOWN = 150.0f, CLIMB_ACC = 1700.0f, SLIDE_ACC = 900.0f;
static const float MANTLE_DUR = 0.2f;
static Building* wallBuilding() {
    for (auto& b : bld) { const float e = P.wallDir > 0 ? b.x : b.x + b.w; if (fabsf(e - P.wallEdge) < 0.5f) return &b; }
    return nullptr;
}
static void leaveWall(float vx, float vy, float cool) {
    P.wallCling = false; P.mantleT = 0;
    P.wallLastEdge = P.wallEdge; P.wallLastCool = 0.9f; P.wallCool = cool;
    P.vx = vx; P.vy = vy;
}
static void wallJump() {
    const float away = -P.wallDir;
    const float climb = clampValue(-P.vy, -150.0f, CLIMB_UP);
    const float vx = away * (340.0f + 0.15f * std::min(P.wallImpact, 600.0f));
    leaveWall(vx, -540.0f - 0.6f * climb, 0.3f);
    P.x = P.wallX + away * 2.0f;
    P.jumpBuf = 0; P.usedAir = true; P.trickReady = true; P.flipT = 0; P.wallJumpT = 0.28f; P.releaseT = 0;
    P.jumpStyle = wrng.range(0, 2); P.fallStyle = wrng.range(0, 1); P.jit = wrng.f() * 2 - 1;
    sfx(7); comboHit(combo::TRICK);
    burst(P.wallX, P.y, 4, 0xBFD8FF, 70);
    if (fullAssist()) autoCool = 0.18f;
    if (swingHeld) swingWas = false;
}
static void wallStep(float dt) {
    Player& p = P;
    Building* b = wallBuilding();
    if (!b) { leaveWall(0, 80, 0.15f); return; }
    const float roof = b->roofY;
    p.x = p.wallX;
    if (p.mantleT > 0) {
        p.mantleT -= dt;
        const float u = 1.0f - clampValue(p.mantleT / MANTLE_DUR, 0.0f, 1.0f), uy = 1.0f - (1.0f - u) * (1.0f - u), ux = u * u;
        p.x = lerpValue(p.mantleX0, p.mantleX1, ux); p.y = lerpValue(p.mantleY0, p.mantleY1, uy);
        p.vx = 0; p.vy = (p.mantleY1 - p.mantleY0) * 2.0f * (1.0f - u) / MANTLE_DUR;
        p.climbPhase += (-p.vy / 110.0f) * dt;
        if (p.mantleT <= 0) {
            p.wallCling = false; p.onGround = true; p.vx = p.wallDir * 180.0f; p.vy = 0; p.coyote = 0.1f; p.usedAir = false;
            p.px = p.x; p.py = p.y; p.wallCool = 0.2f; sfx(2);
        }
        return;
    }
    const bool climbing = swingHeld || fullAssist();
    const float tv = climbing ? -CLIMB_UP : SLIDE_DOWN, acc = (climbing ? CLIMB_ACC : SLIDE_ACC) * dt;
    p.vy += clampValue(tv - p.vy, -acc, acc);
    p.y += p.vy * dt;
    p.climbPhase += (-p.vy / 110.0f) * dt;
    if (p.vy < -20.0f && p.y <= roof + 22.0f) {
        const float x1 = p.wallDir > 0 ? b->x + 14.0f : b->x + b->w - 14.0f;
        bool blocked = false;
        for (auto& o : b->obs) if (o.solid && x1 + 9 > o.x - 2 && x1 - 9 < o.x + o.w + 2) { blocked = true; break; }
        if (blocked) { p.y = std::max(p.y, roof + 22.0f); p.vy = 0; }
        else {
            p.mantleT = MANTLE_DUR; p.mantleX0 = p.x; p.mantleY0 = p.y; p.mantleX1 = x1; p.mantleY1 = roof - 26.0f;
            return;
        }
    }
    if (p.y < roof + 8.0f) p.y = roof + 8.0f;
    if (p.y + 26.0f > 760.0f) { leaveWall(-p.wallDir * 220.0f, -300.0f, 0.4f); p.wallJumpT = 0.2f; return; }
}

static const float ZIP_MIN = 140.0f, ZIP_MAX = 560.0f, ZIP_COOL = 1.1f, ZIP_TOP = 1500.0f, ZIP_ACC = 3400.0f, ZIP_EXIT = 1250.0f;
static const float DIVE_ACC = 1500.0f, DIVE_VY = 1150.0f, DIVE_MAX = 1.3f, DIVE_COOL = 0.8f;
static bool zipCanStart() { return P.alive && !P.onGround && !P.wallCling && !P.zipping && P.zipCool <= 0 && P.mantleT <= 0; }
static bool zipRange(float tx, float ty) {
    const float dx = tx - P.x, dy = ty - (P.y - 10), d = hypotf(dx, dy);
    return d >= ZIP_MIN && d <= ZIP_MAX && dx > 40.0f && dy < 30.0f && !webBlocked(P.x, P.y - 10, tx, ty);
}
static bool beginZip(float tx, float ty) {
    if (!zipCanStart() || !zipRange(tx, ty)) return false;
    if (P.swinging) { P.swinging = false; markBad(P.ax, P.ay, 1.2f); }
    P.zipping = true; P.zipX = tx; P.zipY = ty; P.zipT = 0;
    P.diving = false; P.webFlying = false; P.trickType = 0; P.launchT = 0; P.shootT = 0.12f; P.releaseT = 0;
    sfx(0); burst(P.x, P.y - 10, 4, 0xDCEBFF, 80);
    return true;
}
static bool findZipTarget(float& ox, float& oy) {
    AssistQuery q = makeQuery();
    if (P.swinging) { q.hasEx = true; q.exX = P.ax; q.exY = P.ay; }
    if (pickAnchor(q, ox, oy) && zipRange(ox, oy)) return true;
    q.a = 1.0f;
    return pickAnchor(q, ox, oy) && zipRange(ox, oy);
}
static void zipEnd(bool arrived) {
    P.zipping = false; P.zipCool = arrived ? ZIP_COOL : 0.5f;
    if (!arrived) return;
    const float sp = hypotf(P.vx, P.vy);
    if (sp > ZIP_EXIT) { P.vx *= ZIP_EXIT / sp; P.vy *= ZIP_EXIT / sp; }
    P.vy -= 140.0f;
    P.trickReady = true; P.releaseT = 0.25f; P.releaseFlip = false; P.usedAir = false;
    gFlow = std::min(1.0f, gFlow + 0.08f);
    comboHit(combo::STUNT);
    markBad(P.zipX, P.zipY, 1.5f);
    burst(P.x, P.y - 10, 6, 0xFFFFFF, 110); sfx(8);
    if (fullAssist()) autoCool = 0.05f;
}
static void zipSteer(float dt) {
    P.zipT += dt;
    float dx = P.zipX - P.x, dy = P.zipY - (P.y - 10);
    const float d = std::max(hypotf(dx, dy), 1.0f);
    dx /= d; dy /= d;
    const float sp = clampValue(260.0f + ZIP_ACC * P.zipT, 260.0f, ZIP_TOP), k = std::min(1.0f, 16.0f * dt);
    P.vx += (dx * sp - P.vx) * k; P.vy += (dy * sp - P.vy) * k;
}
static void zipCheck() {
    if (P.wallCling || P.onGround) { zipEnd(false); return; }
    if (hypotf(P.zipX - P.x, P.zipY - (P.y - 10)) < 56.0f || P.zipT > 1.0f) { zipEnd(true); return; }
    if (webBlocked(P.x, P.y - 10, P.zipX, P.zipY)) zipEnd(false);
}

static float senseScan(float& hitAng) {
    const Player& p = P;
    if (!p.alive || p.wallCling || p.zipping) return 0.0f;
    const float horizon = p.swinging ? 0.35f : 0.8f, g = p.swinging ? 0.0f : GRAV;
    float prevB = p.y + 26.0f;
    for (float t = 0.05f; t <= horizon + 1e-4f; t += 0.05f) {
        const float x = p.x + p.vx * t, y = p.y + p.vy * t + 0.5f * g * t * t, vy = p.vy + g * t;
        const float pl = x - 8, pr = x + 8, pt = y - 24, pb = y + 26;
        bool hit = false;
        for (auto& b : bld) {
            if (b.x > pr + 4 || b.x + b.w < pl - 4) continue;
            for (auto& o : b.obs) {
                if (!o.solid) continue;
                const float T = b.roofY - o.h;
                if (!(pr > o.x && pl < o.x + o.w && pb > T && pt < b.roofY)) continue;
                if ((prevB <= T + 14 && vy >= 0) || (pb - T < 26 && vy >= -50)) return 0.0f;
                hit = true;
            }
            if (hit) break;
        }
        if (!hit) for (const TrafficCar& car : trafficCars) {
            const float cx = car.x + car.dir * car.speed * t;
            const float bottom = STREET_GROUND_Y + (car.lane ? 8.0f : -5.0f);
            if (fabsf(x - cx) < car.width * 0.5f + 12.0f && pb > bottom - car.height && pt < bottom) { hit = true; break; }
        }
        if (hit) { hitAng = atan2f(y - p.y, x - p.x); return clampValue(1.0f - (t - 0.05f) / horizon, 0.15f, 1.0f); }
        prevB = pb;
    }
    return 0.0f;
}
static void senseTick(float dt) {
    gSenseT -= dt;
    if (gSenseT <= 0) { gSenseTgt = senseScan(gSenseAng); gSenseT = 0.05f; }
    gSense += (gSenseTgt - gSense) * (1.0f - expf(-(gSenseTgt > gSense ? 18.0f : 5.0f) * dt));
    if (!P.alive) gSense = gSenseTgt = 0;
}
static void stepPhysics(float dt) {
    Player& p = P;
    if (!p.alive) {
        p.vy += GRAV * dt; p.x += p.vx * dt; p.y += p.vy * dt;
        return;
    }
    if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.vx) || !std::isfinite(p.vy)) {

        p.x = std::isfinite(p.px) ? p.px : 0.0f; p.y = std::isfinite(p.py) ? p.py : 0.0f; p.vx = p.vy = 0;
        if (p.swinging) releaseWeb(false, true);
    }
    p.vx = clampValue(p.vx, -4000.0f, 4000.0f); p.vy = clampValue(p.vy, -4000.0f, 4000.0f);
    const float rm = runMult(), sm = swingMult();
    float runSp = (230 + 230 * difficulty()) * rm;
    p.px = p.x; p.py = p.y;
    p.coyote -= dt; p.jumpBuf -= dt; p.wrapCool -= dt; p.vaultT -= dt;
    p.trickCool -= dt; p.trickDoneT -= dt;
    if (p.trickType) trickStep(dt);
    if (jumpEdge) { p.jumpBuf = 0.12f; jumpEdge = false; }
    p.slideBuf -= dt;
    if (slideEdge) { slideEdge = false; if (!tryTrick()) p.slideBuf = 0.15f; }
    p.boostT -= dt;
    float target = runSp + p.boostExtra * clampValue(p.boostT / p.boostDur, 0.0f, 1.0f);
    p.wallCool -= dt; p.wallLastCool -= dt; p.wallJumpT -= dt; p.zipCool -= dt; p.diveCool -= dt;
    if (p.zipping && p.jumpBuf > 0) zipEnd(false);
    if (p.diving && (p.onGround || p.swinging || p.wallCling || p.zipping)) p.diving = false;
    if (p.wallCling && p.jumpBuf > 0 && p.mantleT <= 0) wallJump();
    if (p.wallCling) {
        wallStep(dt);
        if (p.y > 900) killPlayer();
        return;
    }
    if (p.jumpBuf > 0 && !p.zipping) {
        if (p.swinging) { releaseWeb(true); p.vy -= 200; p.jumpBuf = 0; if (fullAssist()) autoCool = 0.55f; }
        else if (p.onGround || p.coyote > 0) {
            p.vy = -560; p.onGround = false; p.trickReady = true; p.coyote = 0; p.jumpBuf = 0; p.slideT = 0; p.jumpStyle = wrng.range(0, 2); p.fallStyle = wrng.range(0, 1); p.jit = wrng.f() * 2 - 1; sfx(7);
            for (int i = 0; i < 4; i++) spawnPart(p.x, p.y + 26, (i - 1.5f) * 25, -20, 0.3f, 0x8A90B0);
        } else if (!p.usedAir) { p.vy = -440; p.usedAir = true; p.trickReady = true; p.jumpBuf = 0; p.flipT = 0.55f; p.flipDir = wrng.f() < 0.8f ? 1.0f : -1.0f; sfx(7); comboHit(combo::TRICK); }
    }
    if (jumpRel) { if (p.vy < -250 && !p.swinging) p.vy *= 0.6f; jumpRel = false; }
    if (p.slideBuf > 0 && p.onGround && p.slideT <= 0) {
        p.slideBuf = 0; p.slideT = 0.7f; p.slideStyle = wrng.range(0, 2); p.jit = wrng.f() * 2 - 1;
        p.vx = std::min(std::max(p.vx, target) * 1.1f, 760.0f * rm);
        sfx(6); burst(p.x, p.y + 24, 5, 0x9AA0C0, 70);
    }
    if (p.onGround) {
        if (p.slideT > 0) p.vx *= expf(-0.45f * dt);
        else p.vx += (target - p.vx) * std::min(1.0f, 4 * dt);
    }
    p.slideT = p.onGround ? p.slideT - dt : 0;
    bool wasGround = p.onGround;
    p.onGround = false;
    if (p.zipping) zipSteer(dt);
    else p.vy += GRAV * (p.swinging ? sm : 1.0f) * dt;
    if (p.diving) {

        if (p.vy < DIVE_VY) p.vy = std::min(DIVE_VY, p.vy + DIVE_ACC * dt);
        p.diveT += dt;
        if (p.diveT > DIVE_MAX) { p.diving = false; p.diveCool = DIVE_COOL; }
    }
    const float preVy = p.vy;
    if (!wasGround && !p.swinging && fabsf(steer) > 0.01f && fabsf(p.vx) < 700 * rm) p.vx += steer * 240 * cfg.sens * dt;
    p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.swinging) {
        swingStep(p.x, p.y, p.vx, p.vy, p.ax, p.ay, p.rope, sm, steer * cfg.sens, dt);
        if (p.x - p.ax > swingMaxFwd(p.rope)) releaseWeb(false);
    } else {
        float dr = expf(-0.05f * dt); p.vx *= dr;
        if (p.launchT > 0) {
            const float g = 1.0f + p.launchK * dt / p.launchDur;
            p.vx *= g; p.vy *= g; p.launchT -= dt;
            const float sp = hypotf(p.vx, p.vy), cap = swingSpeedCap(sm);
            if (sp > cap) { p.vx *= cap / sp; p.vy *= cap / sp; }
        }
    }
    collide();
    if (!p.alive) return;
    if (p.zipping) zipCheck();
    if (wasGround && !p.onGround) p.trickReady = true;
    if (p.onGround) {
        p.wallCling = false;
        if (p.swinging) releaseWeb(false, true);
        p.coyote = 0.1f; p.usedAir = false; p.launchT = 0;
        if (!wasGround) {
            if (p.trickType) {
                p.trickType = 0; p.trickCool = 0.3f; p.trickDoneT = 0;
                p.vx *= 0.9f;
                snprintf(gTrickMsg, sizeof gTrickMsg, "SLOPPY"); gTrickBad = true; gTrickMsgT = 0.7f;
            }
            p.hero = preVy > 640.0f; p.landT = p.hero ? 0.42f : 0.14f + 0.10f * clampValue((preVy - 250.0f) / 390.0f, 0.0f, 1.0f); p.flipT = 0;
            if (gTrickBad && gTrickMsgT > 0.5f) p.landT = std::max(p.landT, 0.3f);
            float over = p.vx - runSp;
            if (p.chain >= 1 && over > 40) {
                p.boostExtra = clampValue(over * 0.6f, 60, 250);
                p.boostDur = p.boostT = 2.0f + 3.0f * clampValue(over / 400.0f, 0, 1);
                if (p.slideBuf > 0) { p.boostT += 1; p.boostDur += 1; }
            }
            p.landStyle = wrng.range(0, 2); p.runStyle = wrng.range(0, 2); p.jit = wrng.f() * 2 - 1;
            bonus += 25 + (p.chain >= 2 ? 10.0f * p.chain : 0);
            if (p.slideBuf > 0 && !p.hero) comboHit(combo::LAND);
            if (p.chain >= 5) comboHit(combo::LONGCHAIN, 20.0f * p.chain);
            if (p.chain >= 2) chainShowT = 1.6f;
            p.chain = 0;
            sfx(2); doShake(0.12f);
            for (int i = 0; i < 6; i++) spawnPart(p.x, p.y + 26, (i - 2.5f) * 35, -30 - wrng.f() * 30, 0.35f, 0x9AA0C0);
        }
    }
    if (p.y > 900) killPlayer();
}

enum { R_NONE, R_SWING, R_JUMP, R_PAUSE, R_UI, R_STEER, R_SLIDER, R_SLIDE, R_DRAG, R_AIM };
struct Touch { bool on = false; SDL_FingerID id = 0; float x = 0, y = 0, sx = 0, ox = 0, oy = 0; int role = 0; int btn = 0; };
static Touch tch[10];
enum { B_PLAY = 1, B_CONTROLS, B_SETTINGS, B_HOW, B_CREDITS, B_BACK, B_RESUME, B_RESTART, B_MENU, B_TRY,
       B_SHAKE, B_REDUCED, B_FULL, B_TARGET_HINTS, B_TAB_KEYS, B_TAB_TOUCH, B_EDIT_LAYOUT, B_RESET_TAB, B_LEFTY, B_DONE, B_RESET_LAYOUT, B_KEY,
       B_SKILLS, B_UP_RUN, B_UP_SWING, B_RB_RUN, B_RB_SWING,
       B_ASSIST_DEC, B_ASSIST_INC, S_MUSIC, S_SFX, S_SENS, S_SIZE, S_ALPHA, S_SWING_ASSIST };
struct Btn { int id, kind, x, y, w, h; const char* label; float* val; bool* flag; float vmin, vmax; int style = 0, act = 0; };
static std::vector<Btn> btns;
static Btn pauseBtn;
static int gFocus = -1;
static int gRebind = -1;
static int ctlTab = 0;
static float flashT = 0, uiAge = 0, noteT = 0;
static char gNote[48] = "";

static void setNote(const char* s) { snprintf(gNote, sizeof gNote, "%s", s); noteT = 2.5f; }
static bool hasGlyph(unsigned char ch) { if (ch >= 128) return false; for (int i = 0; i < 7; i++) if (gGl[ch][i]) return true; return false; }
static void keyLabel(SDL_Scancode sc, char* out, size_t n) {
    switch (sc) {
        case SDL_SCANCODE_LSHIFT: snprintf(out, n, "L SHIFT"); return;
        case SDL_SCANCODE_RSHIFT: snprintf(out, n, "R SHIFT"); return;
        case SDL_SCANCODE_LCTRL: snprintf(out, n, "L CTRL"); return;
        case SDL_SCANCODE_RCTRL: snprintf(out, n, "R CTRL"); return;
        case SDL_SCANCODE_LALT: snprintf(out, n, "L ALT"); return;
        case SDL_SCANCODE_RALT: snprintf(out, n, "R ALT"); return;
        case SDL_SCANCODE_RETURN: snprintf(out, n, "ENTER"); return;
        case SDL_SCANCODE_SPACE: snprintf(out, n, "SPACE"); return;
        case SDL_SCANCODE_UP: snprintf(out, n, "UP ARROW"); return;
        case SDL_SCANCODE_DOWN: snprintf(out, n, "DOWN ARROW"); return;
        case SDL_SCANCODE_LEFT: snprintf(out, n, "LEFT ARROW"); return;
        case SDL_SCANCODE_RIGHT: snprintf(out, n, "RIGHT ARROW"); return;
        default: break;
    }
    const char* nm = SDL_GetScancodeName(sc);
    bool ok = nm && *nm;
    for (const char* c = nm; ok && *c; ++c) { unsigned char u = (unsigned char)toupper((unsigned char)*c); if (u != ' ' && !hasGlyph(u)) ok = false; }
    if (ok) snprintf(out, n, "%.12s", nm); else snprintf(out, n, "KEY %d", (int)sc);
    for (char* c = out; *c; ++c) *c = (char)toupper((unsigned char)*c);
}

static void ctlPos(int i, float& x, float& y, float& r) {
    static const float R[3] = {46, 36, 28};
    float s = ctl.scale;
    r = R[i] * s;
    if (ctl.px[i] >= 0) { x = ctl.px[i] * uvzWorldWidth; y = ctl.py[i] * uvzWorldHeight; }
    else {
        float sr = R[0] * s, sx = uvzWorldWidth - uvzSafeRight - sr - 6, sy = uvzWorldHeight - uvzSafeBottom - sr - 4;
        float jx = sx - 125 * s, jy = sy + 10 * s;
        if (i == 0) { x = sx; y = sy; }
        else if (i == 1) { x = jx; y = jy; }
        else { x = jx - 80 * s; y = jy + 4 * s; }
        if (ctl.lefty) x = uvzWorldWidth - x;
    }
    float m = r + 2;
    x = clampValue(x, m, uvzWorldWidth - m); y = clampValue(y, m, uvzWorldHeight - m);
}
static void aimPos(float& x, float& y, float& r) {
    float sx, sy, sr; ctlPos(0, sx, sy, sr);
    r = 32 * ctl.scale;
    x = sx; y = sy - sr - 10 - r;
    if (y - r < uvzSafeTop + 40) y = sy + sr + 10 + r;
    float m = r + 2;
    x = clampValue(x, m, uvzWorldWidth - m); y = clampValue(y, m, uvzWorldHeight - m);
}
static bool aimStickVisible() { return !fullAssist(); }
static bool inSteerZone(float x) { return ctl.lefty ? x > uvzWorldWidth * 0.45f : x < uvzWorldWidth * 0.55f; }

static const int SKILL_ROW[4] = {-1, prog::RUN, prog::SWING, -1};
static const char* const SKILL_ROW_NAME[4] = {"JUMP", "RUN SPEED", "SWING SPEED", "ZIP"};
struct SkillLay { int rx, rw, rowY[4], rowH, bx[2], bw, bh, infoW, wcx, wcy, wr; };
static SkillLay skillLay(int px, int pw) {
    SkillLay L;
    int top = 62, bottom = uvzWorldHeight - 14 - 38 - 8, gap = 4;
    L.rowH = (int)clampValue((float)((bottom - top - 3 * gap) / 4), 40.0f, 64.0f);
    int total = 4 * L.rowH + 3 * gap, y0 = top + std::max(0, (bottom - top - total) / 2);
    for (int i = 0; i < 4; i++) L.rowY[i] = y0 + i * (L.rowH + gap);
    int leftW = std::min(170, (pw - 40) * 30 / 100);
    L.rx = px + 20 + leftW + 10; L.rw = px + pw - 20 - L.rx;
    L.bw = 88; L.bh = std::min(L.rowH - 8, 30);
    L.bx[1] = L.rx + L.rw - L.bw; L.bx[0] = L.bx[1] - L.bw - 6;
    L.infoW = L.bx[0] - L.rx - 8;
    L.wcx = px + 20 + leftW / 2; L.wcy = (top + bottom) / 2; L.wr = std::min(leftW / 2, (bottom - top) / 2) - 2;
    return L;
}

static void buildUI() {
    btns.clear();
    float bh = std::max(uvzMinimumTouchSize * 0.8f, 30.0f);
    pauseBtn = {0, 0, (int)(uvzWorldWidth / 2 - 22), (int)uvzSafeTop, 44, 44, "", nullptr, nullptr, 0, 1};
    int pw = std::min(uvzWorldWidth - (int)(uvzSafeLeft + uvzSafeRight), 560), px = (uvzWorldWidth - pw) / 2;
    int footY = uvzWorldHeight - 14 - 38;
    auto add = [&](int id, int kind, int x, int y, int w, int h, const char* label, float* v, bool* f, float lo, float hi, int style, int act) {
        Btn b = {id, kind, x, y, w, h, label, v, f, lo, hi, style, act};
        btns.push_back(b);
    };
    switch (gState) {
        case MAIN_MENU: {
            if (trans >= 0) break;
            int x = (int)uvzSafeLeft + 8, w = (int)std::min(230.0f, uvzWorldWidth * 0.42f);
            int top = 82, n = 5, gap = 5;
            int ih = (int)clampValue((float)((uvzWorldHeight - top - 34 - gap * (n - 1)) / n), 26.0f, bh + 4);
            int y = top;
            add(B_PLAY, 0, x, y, w, ih + 6, "PLAY", nullptr, nullptr, 0, 1, 2, 0); y += ih + 6 + gap;
            add(B_CONTROLS, 0, x, y, w, ih, "CONTROLS", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_SETTINGS, 0, x, y, w, ih, "SETTINGS", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_HOW, 0, x, y, w, ih, "HOW TO PLAY", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_CREDITS, 0, x, y, w, ih, "CREDITS", nullptr, nullptr, 0, 1, 0, 0);
            add(B_SKILLS, 4, uvzWorldWidth - (int)uvzSafeRight - 54, (int)uvzSafeTop + 10, 46, 46, "UPGRADES", nullptr, nullptr, 0, 1, 0, 0);
        } break;
        case SETTINGS: {
            int cw = (pw - 56) / 2, y = 74, c1 = px + 20, c2 = px + 36 + cw, th = 40;
            add(S_MUSIC, 1, c1, y, cw, th, "MUSIC", &cfg.music, nullptr, 0, 1, 0, 0);
            add(S_SFX, 1, c1, y + 46, cw, th, "EFFECTS", &cfg.sfx, nullptr, 0, 1, 0, 0);
            add(S_SENS, 1, c1, y + 92, cw, th, "STEERING", &cfg.sens, nullptr, 0.5f, 1.5f, 0, 0);
            add(S_SWING_ASSIST, 1, c1, y + 138, cw - 52, th, "SWING ASSIST", &cfg.swingAssist, nullptr, 0.0f, 1.0f, 0, 0);
            add(B_ASSIST_DEC, 5, c1 + cw - 46, y + 138 + 14, 22, 22, "-", nullptr, nullptr, 0, 1, 1, 0);
            add(B_ASSIST_INC, 5, c1 + cw - 22, y + 138 + 14, 22, 22, "+", nullptr, nullptr, 0, 1, 1, 0);
            add(B_SHAKE, 2, c2, y, cw, th, "CAMERA SHAKE", nullptr, &cfg.shake, 0, 1, 0, 0);
            add(B_REDUCED, 2, c2, y + 46, cw, th, "FEWER PARTICLES", nullptr, &cfg.reduced, 0, 1, 0, 0);
            add(B_FULL, 2, c2, y + 92, cw, th, "IMMERSIVE", nullptr, &cfg.full, 0, 1, 0, 0);
            add(B_TARGET_HINTS, 2, c2, y + 138, cw, th, "WEB TARGET HINTS", nullptr, &cfg.targetHints, 0, 1, 0, 0);
            add(B_BACK, 0, uvzWorldWidth / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case CONTROLS: {
            int cw = (pw - 56) / 2, c1 = px + 20, c2 = px + 36 + cw, gy = 96, th = 38, pitch = 42;
            add(B_TAB_KEYS, 0, c1, 60, 130, 26, "KEYBOARD", nullptr, nullptr, 0, 1, 1 | 8, 0);
            add(B_TAB_TOUCH, 0, c1 + 138, 60, 130, 26, "TOUCH", nullptr, nullptr, 0, 1, 1 | 8, 0);
            if (ctlTab == 0) {
                static const int L[3] = {A_LEFT, A_RIGHT, A_PAUSE}, R[3] = {A_JUMP, A_SLIDE, A_SWING};
                for (int i = 0; i < 3; i++) add(B_KEY, 3, c1, gy + i * pitch, cw, th, ACT_LABEL[L[i]], nullptr, nullptr, 0, 1, 0, L[i]);
                for (int i = 0; i < 3; i++) add(B_KEY, 3, c2, gy + i * pitch, cw, th, ACT_LABEL[R[i]], nullptr, nullptr, 0, 1, 0, R[i]);
            } else {
                add(S_SIZE, 1, c1, gy, cw, th, "BUTTON SIZE", &ctl.scale, nullptr, 0.7f, 1.4f, 0, 0);
                add(S_ALPHA, 1, c1, gy + pitch, cw, th, "BUTTON OPACITY", &ctl.alpha, nullptr, 0.2f, 1.0f, 0, 0);
                add(S_SENS, 1, c1, gy + 2 * pitch, cw, th, "STEERING", &cfg.sens, nullptr, 0.5f, 1.5f, 0, 0);
                add(B_LEFTY, 2, c2, gy, cw, th, "LEFT HANDED", nullptr, &ctl.lefty, 0, 1, 0, 0);
                add(B_EDIT_LAYOUT, 0, c2, gy + pitch + 4, cw, 32, "EDIT LAYOUT", nullptr, nullptr, 0, 1, 1 | 4, 0);
                add(B_RESET_LAYOUT, 0, c2, gy + 2 * pitch + 4, cw, 32, "RESET LAYOUT", nullptr, nullptr, 0, 1, 1 | 4, 0);
            }
            add(B_BACK, 0, uvzWorldWidth / 2 - 170, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(B_RESET_TAB, 0, uvzWorldWidth / 2 + 10, footY, 160, 30, "RESET TAB", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case LAYOUT_EDIT: {
            int bw = 104, gap = 12, left = (int)uvzSafeLeft + 8, right = uvzWorldWidth - (int)uvzSafeRight - 8;
            int sw = (int)clampValue((float)((right - left - 2 * bw - 4 * gap) / 2), 90.0f, 180.0f);
            int y = 10;
            add(B_DONE, 0, left, y, bw, 30, "DONE", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(S_SIZE, 1, left + bw + gap * 2, y - 2, sw, 40, "SIZE", &ctl.scale, nullptr, 0.7f, 1.4f, 0, 0);
            add(S_ALPHA, 1, left + bw + gap * 3 + sw, y - 2, sw, 40, "OPACITY", &ctl.alpha, nullptr, 0.2f, 1.0f, 0, 0);
            add(B_RESET_LAYOUT, 0, right - bw, y, bw, 30, "RESET", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case HOW_TO_PLAY: case CREDITS:
            add(B_BACK, 0, uvzWorldWidth / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            break;
        case PAUSED: {
            int w = 250, n = 5, gap = 5, top = (int)(uvzWorldHeight * 0.28f);
            int ih = (int)clampValue((float)((uvzWorldHeight - top - 16 - gap * (n - 1)) / n), 24.0f, bh);
            int x = uvzWorldWidth / 2 - w / 2, y = top;
            add(B_RESUME, 0, x, y, w, ih + 4, "RESUME", nullptr, nullptr, 0, 1, 1 | 2, 0); y += ih + 4 + gap;
            add(B_RESTART, 0, x, y, w, ih, "RESTART", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_CONTROLS, 0, x, y, w, ih, "CONTROLS", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_SETTINGS, 0, x, y, w, ih, "SETTINGS", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_MENU, 0, x, y, w, ih, "MAIN MENU", nullptr, nullptr, 0, 1, 1, 0);
        } break;
        case GAME_OVER: {
            int y = uvzWorldHeight - (int)uvzSafeBottom - 46;
            add(B_TRY, 0, uvzWorldWidth / 2 - 205, y, 200, 38, "TRY AGAIN", nullptr, nullptr, 0, 1, 1 | 2, 0);
            add(B_MENU, 0, uvzWorldWidth / 2 + 5, y, 200, 38, "MAIN MENU", nullptr, nullptr, 0, 1, 1, 0);
            add(B_SKILLS, 4, uvzWorldWidth - (int)uvzSafeRight - 54, (int)uvzSafeTop + 10, 46, 46, "UPGRADES", nullptr, nullptr, 0, 1, 0, 0);
        } break;
        case SKILLS: {
            SkillLay L = skillLay(px, pw);
            static char lb[4][28];
            const int ids[2][2] = {{B_UP_RUN, B_RB_RUN}, {B_UP_SWING, B_RB_SWING}};
            for (int k = 0; k < 2; k++) {
                const int sk = k == 0 ? prog::RUN : prog::SWING, row = k == 0 ? 1 : 2;
                char c[20];
                if (prog::atMaxLevel(gProg, sk)) snprintf(lb[k * 2], sizeof lb[0], "MAX LEVEL");
                else { fmtNum(prog::DEF[sk].upgradeCost, c, sizeof c); snprintf(lb[k * 2], sizeof lb[0], "UPGRADE %s", c); }
                if (prog::atMaxRebirth(gProg, sk)) snprintf(lb[k * 2 + 1], sizeof lb[0], "MAX REBIRTH");
                else { fmtNum(prog::DEF[sk].rebirthCost, c, sizeof c); snprintf(lb[k * 2 + 1], sizeof lb[0], "REBIRTH %s", c); }
                int by = L.rowY[row] + (L.rowH - L.bh) / 2;
                add(ids[k][0], 0, L.bx[0], by, L.bw, L.bh, lb[k * 2], nullptr, nullptr, 0, 1, 1 | 4 | (prog::canUpgrade(gProg, sk) ? 0 : 16), 0);
                add(ids[k][1], 0, L.bx[1], by, L.bw, L.bh, lb[k * 2 + 1], nullptr, nullptr, 0, 1, 1 | 4 | (prog::canRebirth(gProg, sk) ? 0 : 16), 0);
            }
            add(B_BACK, 0, uvzWorldWidth / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        default: break;
    }
}
static bool inRect(float x, float y, int rx, int ry, int rw, int rh, int pad = 0) {
    return x >= rx - pad && x <= rx + rw + pad && y >= ry - pad && y <= ry + rh + pad;
}
static void setSlider(const Btn& b, float x) {
    float t = clampValue((x - b.x) / (float)b.w, 0, 1);
    *b.val = b.vmin + (b.vmax - b.vmin) * t;
    if (b.id == S_SWING_ASSIST) *b.val = lroundf(*b.val * 100.0f) / 100.0f;
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void startAudio() {
    if (!audioStarted && gAud) { SDL_PauseAudioDevice(gAud, 0); audioStarted = true; aMode = 1; }
}
static void enterMenu() {
    startAudio();
    gState = MAIN_MENU; flashT = 0.5f; menuT = 0; sfx(7);
}
static void activate(int id) {
    sfx(4);
    switch (id) {
        case B_PLAY: trans = 0; break;
        case B_CONTROLS: openSub(CONTROLS); break;
        case B_SETTINGS: openSub(SETTINGS); break;
        case B_HOW: openSub(HOW_TO_PLAY); break;
        case B_CREDITS: openSub(CREDITS); break;
        case B_EDIT_LAYOUT: openSub(LAYOUT_EDIT); break;
        case B_SKILLS: openSub(SKILLS); break;
        case B_UP_RUN: case B_UP_SWING: {
            const int sk = id == B_UP_RUN ? prog::RUN : prog::SWING;
            if (prog::upgrade(gProg, sk)) { saveProg(); sfx(3); gNote[0] = 0; }
            else setNote(prog::atMaxLevel(gProg, sk) ? "ALREADY MAX LEVEL" : "NOT ENOUGH COINS");
        } break;
        case B_RB_RUN: case B_RB_SWING: {
            const int sk = id == B_RB_RUN ? prog::RUN : prog::SWING;
            if (prog::doRebirth(gProg, sk)) { saveProg(); sfx(7); setNote("REBIRTH COMPLETE"); }
            else if (prog::atMaxRebirth(gProg, sk)) setNote("MAX REBIRTH");
            else if (!prog::atMaxLevel(gProg, sk)) setNote("REACH MAX LEVEL FIRST");
            else setNote("NOT ENOUGH COINS");
        } break;
        case B_BACK: case B_DONE: goBack(); break;
        case B_RESUME: gState = PLAYING; break;
        case B_RESTART: case B_TRY: startRun(); break;
        case B_MENU: gState = MAIN_MENU; navStack.clear(); trans = -1; menuT = 0; aMode = 1; break;
        case B_SHAKE: cfg.shake = !cfg.shake; saveCfg(); break;
        case B_REDUCED: cfg.reduced = !cfg.reduced; saveCfg(); break;
        case B_TARGET_HINTS: cfg.targetHints = !cfg.targetHints; saveCfg(); break;
        case B_ASSIST_DEC: case B_ASSIST_INC: {
            const int np = std::max(0, std::min(100, assistPct() + (id == B_ASSIST_INC ? 1 : -1)));
            cfg.swingAssist = np / 100.0f; saveCfg();
        } break;
        case B_FULL:
            cfg.full = !cfg.full; saveCfg();
            SDL_SetWindowFullscreen(uvzWindow, cfg.full ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
            break;
        case B_TAB_KEYS: ctlTab = 0; gFocus = -1; gRebind = -1; break;
        case B_TAB_TOUCH: ctlTab = 1; gFocus = -1; gRebind = -1; break;
        case B_LEFTY:
            ctl.lefty = !ctl.lefty;
            for (int i = 0; i < 3; i++) if (ctl.px[i] >= 0) ctl.px[i] = 1.0f - ctl.px[i];
            saveControls();
            break;
        case B_RESET_LAYOUT:
            for (int i = 0; i < 3; i++) ctl.px[i] = ctl.py[i] = -1.0f;
            ctl.scale = 1.0f; ctl.alpha = 0.7f;
            saveControls(); setNote("LAYOUT RESET");
            break;
        case B_RESET_TAB:
            if (ctlTab == 0) ctl.resetKeys();
            else { ctl.resetTouch(); cfg.sens = 1.0f; saveCfg(); }
            saveControls(); setNote("RESET TO DEFAULTS");
            break;
        default: break;
    }
}
static void pressBtn(const Btn& b) {
    if (b.kind == 3) { gRebind = b.act; gNote[0] = 0; sfx(4); return; }
    if (b.kind == 1) return;
    activate(b.id);
}
static void assignKey(int a, SDL_Scancode sc) {
    gNote[0] = 0;
    for (int j = 0; j < A_N; j++) if (j != a && ctl.key[j] == sc) {
        ctl.key[j] = ctl.key[a];
        char b[48]; snprintf(b, sizeof b, "SWAPPED WITH %s", ACT_LABEL[j]); setNote(b);
    }
    ctl.key[a] = sc;
    saveControls(); sfx(3);
}
static void saveAll() { saveCfg(); saveControls(); }
static void releaseAll() {
    for (auto& t : tch) t = Touch();
    swingHeld = false; slideEdge = false; slideHeld = false; diveHeld = false; zipEdge = false; steer = 0; aimDown = false;
}
static void toInternal(float nx, float ny, float& x, float& y) {
    x = (nx * uvzOutputWidth - uvzOffsetX) / uvzScaleX; y = (ny * uvzOutputHeight - uvzOffsetY) / uvzScaleY;
}
static void fingerDown(const SDL_TouchFingerEvent& e) {
    startAudio();
    if (portrait) return;
    if (gState == TITLE) { enterMenu(); return; }
    if (gRebind >= 0) gRebind = -1;
    Touch* t = nullptr;
    for (auto& q : tch) if (!q.on) { t = &q; break; }
    if (!t) return;
    t->on = true; t->id = e.fingerId; toInternal(e.x, e.y, t->x, t->y); t->sx = t->x; t->role = R_NONE;
    if (gState == PLAYING) {
        float x[3], y[3], r[3];
        for (int i = 0; i < 3; i++) ctlPos(i, x[i], y[i], r[i]);
        if (inRect(t->x, t->y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 6)) t->role = R_PAUSE;
        else if (hypotf(t->x - x[0], t->y - y[0]) <= r[0] * 1.2f) t->role = R_SWING;
        else if (hypotf(t->x - x[1], t->y - y[1]) <= r[1] * 1.25f) { t->role = R_JUMP; jumpEdge = true; }
        else if (hypotf(t->x - x[2], t->y - y[2]) <= r[2] * 1.25f) { t->role = R_SLIDE; slideEdge = true; }
        else if (aimStickVisible()) {
            float cx, cy, r; aimPos(cx, cy, r);
            if (hypotf(t->x - cx, t->y - cy) <= r * 1.4f) t->role = R_AIM;
            else if (inSteerZone(t->x)) t->role = R_STEER;
        }
        else if (inSteerZone(t->x)) t->role = R_STEER;
    } else {
        if (gState == LAYOUT_EDIT) {
            for (int i = 0; i < 3; i++) {
                float x, y, r; ctlPos(i, x, y, r);
                if (hypotf(t->x - x, t->y - y) <= r * 1.15f) { t->role = R_DRAG; t->btn = i; t->ox = x - t->x; t->oy = y - t->y; return; }
            }
        }
        for (size_t i = 0; i < btns.size(); i++) {
            const Btn& b = btns[i];
            if (inRect(t->x, t->y, b.x, b.y, b.w, b.h, 4)) {
                t->btn = (int)i; t->role = b.kind == 1 ? R_SLIDER : R_UI; gFocus = (int)i;
                if (b.kind == 1) setSlider(b, t->x);
                break;
            }
        }
    }
}
static void fingerMove(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_SLIDER && t.btn >= 0 && t.btn < (int)btns.size()) setSlider(btns[t.btn], t.x);
        if (t.role == R_DRAG) { ctl.px[t.btn] = clampValue((t.x + t.ox) / uvzWorldWidth, 0, 1); ctl.py[t.btn] = clampValue((t.y + t.oy) / uvzWorldHeight, 0, 1); }
    }
}
static void fingerUp(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_JUMP) jumpRel = true;
        else if (t.role == R_PAUSE) { if (inRect(t.x, t.y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 10) && gState == PLAYING) { gState = PAUSED; sfx(4); } }
        else if (t.role == R_UI) {
            if (t.btn >= 0 && t.btn < (int)btns.size()) {
                Btn b = btns[t.btn];
                if (inRect(t.x, t.y, b.x, b.y, b.w, b.h, 6)) { t = Touch(); pressBtn(b); continue; }
            }
        }
        else if (t.role == R_SLIDER || t.role == R_DRAG) saveAll();
        t = Touch();
    }
}
static void pollHeld() {
    swingHeld = false; steer = 0; slideHeld = false; diveHeld = false;
    aimDown = false;
    float nax = 0, nay = 0;
    for (auto& t : tch) if (t.on) {
        if (t.role == R_SWING) swingHeld = true;
        if (t.role == R_SLIDE) slideHeld = true;
        if (t.role == R_STEER) steer = clampValue((t.x - t.sx) / 50.0f, -1, 1);
        if (t.role == R_AIM && aimStickVisible()) {
            float cx, cy, r; aimPos(cx, cy, r);
            nax = (t.x - cx) / r; nay = (t.y - cy) / r;
            const float m = hypotf(nax, nay);
            if (m > 1) { nax /= m; nay /= m; }
            aimDown = true;
        }
    }
    const Uint8* ks = SDL_GetKeyboardState(nullptr);
    if (aimStickVisible()) {
        float kx = (ks[SDL_SCANCODE_RIGHT] ? 1.0f : 0.0f) - (ks[SDL_SCANCODE_LEFT] ? 1.0f : 0.0f);
        float ky = (ks[SDL_SCANCODE_DOWN] ? 1.0f : 0.0f) - (ks[SDL_SCANCODE_UP] ? 1.0f : 0.0f);
        if (kx != 0 || ky != 0) { const float m = hypotf(kx, ky); nax = kx / m; nay = ky / m; aimDown = true; }
    }
    if (aimDown) { aimX = nax; aimY = nay; }
    if (ks[ctl.key[A_SWING]]) swingHeld = true;
    if (ks[ctl.key[A_SLIDE]]) slideHeld = true;
    if (ks[SDL_SCANCODE_X]) diveHeld = true;
    float kst = (ks[ctl.key[A_RIGHT]] ? 1.0f : 0.0f) - (ks[ctl.key[A_LEFT]] ? 1.0f : 0.0f);
    if (kst != 0) steer = kst;
}

static void mouseHover(int mx, int my) {
    if (gState == PLAYING || gState == TITLE || portrait) return;
    int ww = 1, wh = 1; SDL_GetWindowSize(uvzWindow, &ww, &wh);
    float x, y; toInternal((float)mx / std::max(1, ww), (float)my / std::max(1, wh), x, y);
    int f = -1;
    for (size_t i = 0; i < btns.size(); i++) if (inRect(x, y, btns[i].x, btns[i].y, btns[i].w, btns[i].h)) { f = (int)i; break; }
    gFocus = f;
}
static void menuKey(SDL_Scancode sc) {
    int n = (int)btns.size();
    if (n == 0) return;
    if (sc == SDL_SCANCODE_UP || sc == SDL_SCANCODE_DOWN) {
        int d = sc == SDL_SCANCODE_DOWN ? 1 : -1;
        gFocus = gFocus < 0 ? (d > 0 ? 0 : n - 1) : (gFocus + d + n) % n;
        sfx(6);
    } else if ((sc == SDL_SCANCODE_LEFT || sc == SDL_SCANCODE_RIGHT) && gFocus >= 0 && btns[gFocus].kind == 1) {
        const Btn& b = btns[gFocus];
        if (b.id == S_SWING_ASSIST) {
            const int np = std::max(0, std::min(100, assistPct() + (sc == SDL_SCANCODE_RIGHT ? 1 : -1)));
            *b.val = np / 100.0f;
        } else
        *b.val = clampValue(*b.val + (sc == SDL_SCANCODE_RIGHT ? 1 : -1) * (b.vmax - b.vmin) * 0.05f, b.vmin, b.vmax);
        aMusic = cfg.music; aSfx = cfg.sfx; saveAll();
    } else if (sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_KP_ENTER || sc == SDL_SCANCODE_SPACE) {
        if (gFocus < 0) gFocus = 0;
        else pressBtn(Btn(btns[gFocus]));
    }
}

static void drawHalo(int cx, int cy) {
    for (int i = 0; i < 3; i++) drawDisc(cx, cy, 34 - i * 8, 0x6A78FF, 9);
}
struct DayPalette { u32 top, mid, horizon; };
static u32 blendRgb(u32 a, u32 b, float t) {
    t = clampValue(t, 0.0f, 1.0f);
    const int r = (int)(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
    const int g = (int)(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
    const int bl = (int)((a & 255) + ((b & 255) - (a & 255)) * t);
    return (u32)((r << 16) | (g << 8) | bl);
}
static float dayPhase(double time) {
    float p = fmodf((float)time / 180.0f, 1.0f);
    return p < 0.0f ? p + 1.0f : p;
}
static float daylightAmount(double time) {
    return clampValue(0.5f + 0.5f * cosf((dayPhase(time) - 0.35f) * 2.0f * pi), 0.0f, 1.0f);
}
static DayPalette dayPalette(double time) {
    static const float stops[] = {0.0f, 0.14f, 0.32f, 0.51f, 0.64f, 0.82f, 1.0f};
    static const DayPalette colors[] = {
        {0x10182E, 0x26334D, 0x586177},
        {0x394A75, 0xA56D7A, 0xF2A26C},
        {0x4A98C8, 0x89CDE8, 0xDDF1EB},
        {0x4C83B3, 0xC88078, 0xF0BA77},
        {0x28385F, 0x9C6579, 0xE98768},
        {0x0D1428, 0x1D2941, 0x41485C},
        {0x10182E, 0x26334D, 0x586177}
    };
    const float p = dayPhase(time);
    int i = 0;
    while (i < 5 && p > stops[i + 1]) ++i;
    float u = (p - stops[i]) / (stops[i + 1] - stops[i]);
    u = u * u * (3.0f - 2.0f * u);
    return {blendRgb(colors[i].top, colors[i + 1].top, u),
            blendRgb(colors[i].mid, colors[i + 1].mid, u),
            blendRgb(colors[i].horizon, colors[i + 1].horizon, u)};
}
static void drawBackdrop(float cx, float cy, double t) {
    const DayPalette pal = dayPalette(t);
    const float night = 1.0f - daylightAmount(t);
    const int nb = 9;
    for (int i = 0; i < nb; i++) {
        const float u = (i + 0.5f) / nb;
        const u32 c = u < 0.58f ? blendRgb(pal.top, pal.mid, u / 0.58f) : blendRgb(pal.mid, pal.horizon, (u - 0.58f) / 0.42f);
        drawFilledRect(0, i * uvzWorldHeight / nb, uvzWorldWidth, uvzWorldHeight / nb + 1, c);
    }
    for (int i = 0; i < 80; i++) {
        u32 h = hashCoordinates(i, 77, 3);
        int sx = positiveModulo((int)(h % (u32)(uvzWorldWidth * 2)) - (int)(cx * 0.02f), uvzWorldWidth), sy = (int)((h >> 10) % (u32)(uvzWorldHeight * 0.6f));
        bool dim = ((int)(t * 2 + i)) % 7 == 0;
        drawFilledRect(sx, sy, 1, 1, 0xFFFFFF, (int)(night * (dim ? 90 : 220)));
    }
    const float phase = dayPhase(t);
    const float celestialX = 24.0f + phase * (uvzWorldWidth - 48.0f);
    const float celestialY = uvzWorldHeight * (0.18f + 0.11f * sinf(phase * 2.0f * pi));
    drawDisc((int)celestialX, (int)celestialY, 13, 0xFFE4A2, (int)(255 * daylightAmount(t)));
    drawDisc((int)celestialX + 6, (int)celestialY - 3, 12, pal.top, (int)(255 * daylightAmount(t)));
    const float moonPhase = fmodf(phase + 0.5f, 1.0f);
    const int moonX = 24 + (int)(moonPhase * (uvzWorldWidth - 48));
    drawDisc(moonX, (int)(uvzWorldHeight * 0.17f), 10, 0xE8ECFF, (int)(230 * night));
    for (int i = 0; i < 6; i++) {
        int x = positiveModulo((int)(i * 260 + t * (6 + i * 2) - cx * 0.05f), uvzWorldWidth + 300) - 150, y = 40 + (i * 47) % 120;
        const int a = (int)(55 + 35 * daylightAmount(t));
        drawFilledRect(x, y, 70, 8, blendRgb(0x3A3B72, 0xE7B7AA, daylightAmount(t)), a);
        drawFilledRect(x + 10, y - 6, 40, 6, blendRgb(0x3A3B72, 0xE7B7AA, daylightAmount(t)), a);
        drawFilledRect(x + 20, y + 8, 50, 5, blendRgb(0x3A3B72, 0xE7B7AA, daylightAmount(t)), a);
    }
    { int ax = uvzWorldWidth + 20 - (int)fmod(t * 28.0, (double)(uvzWorldWidth + 80)), ay = (int)(uvzWorldHeight * 0.22f);
      drawFilledRect(ax - 3, ay, 6, 2, 0xAAB4D8); drawFilledRect(ax + 4, ay, 18, 1, 0xAAB4D8, 60);
      if (((int)(t * 2)) & 1) drawFilledRect(ax, ay - 2, 2, 2, 0xFF3030); else drawFilledRect(ax, ay - 2, 2, 2, 0xFFFFFF); }
    static int farW[24], farH[24]; static int farP = 0;
    if (!farP) { Rng r(5); for (int i = 0; i < 24; i++) { farW[i] = (r.range(40, 90) / 8) * 8; farH[i] = r.range(60, 170); farP += farW[i]; } }
    float off = fmodf(cx * 0.10f, (float)farP);
    int x = (int)-off, idx = 0;
    while (x < uvzWorldWidth) {
        int bw = farW[idx % 24], top = (int)(uvzWorldHeight * 0.60f - farH[idx % 24] - (cy + 210) * 0.04f);
        if (x + bw > 0) {
            drawFilledRect(x, top, bw, uvzWorldHeight - top, blendRgb(0x4C5A6B, 0x141A3A, night));
            for (int ty = top; ty < uvzWorldHeight; ty += 32) for (int tx = 0; tx < bw; tx += 32) {
                SDL_Rect s = {0, 0, std::min(32, bw - tx), 32}, d = {x + tx, ty, s.w, 32};
                SDL_RenderCopy(uvzRenderer, gFar[hashCoordinates(idx, tx, ty) % 3], &s, &d);
            }
            drawFilledRect(x, top, bw, 2, 0x2A3260);
        }
        x += bw; idx++;
    }
    drawFilledRect(0, (int)(uvzWorldHeight * 0.45f), uvzWorldWidth, uvzWorldHeight, blendRgb(0xE9A07A, 0x1A2748, night), (int)(20 + 28 * daylightAmount(t)));
    static int midW[10], midH[10], midS[10], midP = 0;
    if (!midP) { Rng r(9); for (int i = 0; i < 10; i++) { midW[i] = (r.range(96, 176) / 16) * 16; midH[i] = r.range(0, 90); midS[i] = r.range(0, 5); midP += midW[i] + 10; } }
    tileMod(85, 92, 140);
    off = fmodf(cx * 0.30f, (float)midP);
    x = (int)-off; idx = 0;
    while (x < uvzWorldWidth) {
        int bw = midW[idx % 10], top = (int)(uvzWorldHeight * 0.30f + midH[idx % 10] - (cy + 210) * 0.12f);
        if (x + bw > 0) {
            for (int ty = top; ty < uvzWorldHeight; ty += 64) for (int tx = 0; tx < bw; tx += 64) {
                SDL_Rect s = {0, 0, std::min(64, bw - tx), 64}, d = {x + tx, ty, s.w, 64};
                SDL_RenderCopy(uvzRenderer, gTile[midS[idx % 10]][hashCoordinates(idx, tx, ty) % 3], &s, &d);
            }
            drawFilledRect(x - 1, top - 4, bw + 2, 4, 0x1B2048);
            drawFilledRect(x + bw / 2, top - 22, 2, 18, 0x1B2048);
            if (((int)(t * 1.3) + idx) & 1) drawFilledRect(x + bw / 2 - 1, top - 24, 4, 3, 0xFF3A3A, 200);
        }
        x += bw + 10; idx++;
    }
    tileMod(255, 255, 255);
    drawFilledRect(0, (int)(uvzWorldHeight * 0.5f), uvzWorldWidth, uvzWorldHeight, 0x3A3F80, 34);
}

static void drawObs(const Obs& o, int sx, int sy, double t) {
    int x = sx, y = sy;
    switch (o.type) {
        case 0:
            drawFilledRect(x, y - 20, 28, 20, 0x59606E); drawFilledRect(x, y - 20, 28, 2, 0x8A93A6);
            drawDisc(x + 8, y - 11, 5, 0x1B1F28);
            { int ph = (int)(t * 12) & 1; if (ph) { drawFilledRect(x + 3, y - 12, 10, 2, 0x4A5060); drawFilledRect(x + 7, y - 16, 2, 10, 0x4A5060); } else { drawLine(x + 4, y - 15, x + 12, y - 7, 0x4A5060); drawLine(x + 12, y - 15, x + 4, y - 7, 0x4A5060); } }
            for (int i = 0; i < 3; i++) drawFilledRect(x + 17, y - 16 + i * 4, 9, 2, 0x2B303B);
            break;
        case 1:
            drawFilledRect(x + 3, y - 18, 3, 18, 0x3B2A1E); drawFilledRect(x + 24, y - 18, 3, 18, 0x3B2A1E);
            drawLine(x + 4, y - 18, x + 25, y - 2, 0x3B2A1E);
            drawFilledRect(x, y - 42, 30, 24, 0x7A5236); drawFilledRect(x, y - 36, 30, 2, 0x4A301F); drawFilledRect(x, y - 26, 30, 2, 0x4A301F);
            drawFilledRect(x + 3, y - 40, 4, 20, 0x9A6B46); drawFilledRect(x + 4, y - 46, 22, 4, 0x4A301F); drawFilledRect(x + 9, y - 50, 12, 4, 0x4A301F);
            break;
        case 2:
            drawFilledRect(x, y - 14, 24, 14, 0xC9C3B5);
            for (int i = 0; i < 3; i++) drawFilledRect(x + 2 + i * 8, y - 12, 4, 10, 0xE0A81E);
            drawFilledRect(x, y - 14, 24, 2, 0xE8E3D5);
            break;
        case 3: {
            int h = (int)o.h;
            drawFilledRect(x, y - h, 2, h, 0x2A2F3F); drawFilledRect(x - 5, y - h + 20, 12, 1, 0x2A2F3F); drawFilledRect(x - 3, y - h + 30, 8, 1, 0x2A2F3F);
            if (((int)(t * 1.5) + (int)o.x) & 1) { drawDisc(x, y - h - 2, 4, 0xFF2A2A, 60); drawFilledRect(x - 1, y - h - 3, 4, 4, 0xFF4040); }
        } break;
        case 4: {
            int h = (int)o.h, jw = (int)o.w;
            drawFilledRect(x, y - h, 6, h, 0xC9A227);
            for (int i = 0; i < h; i += 10) { drawFilledRect(x, y - h + i, 6, 1, 0x6B5611); drawLine(x, y - h + i, x + 5, y - h + i + 9, 0x6B5611); }
            drawFilledRect(x - 30, y - h, 30 + jw, 4, 0xC9A227); drawFilledRect(x - 30, y - h + 4, 14, 10, 0x555B68);
            drawFilledRect(x - 6, y - h - 8, 12, 8, 0x3A4150);
            drawFilledRect(x + jw - 1, y - h + 4, 1, 26, 0x888888); drawFilledRect(x + jw - 3, y - h + 30, 5, 4, 0xD9481F);
            if (((int)(t * 2)) & 1) { drawDisc(x + 3, y - h - 10, 3, 0xFF4040, 70); drawFilledRect(x + 2, y - h - 11, 3, 3, 0xFF5050); }
            drawFilledRect(x + jw - 2, y - h + 1, 3, 3, 0xFFE9A0);
        } break;
        case 5: {
            static const char* ads[4] = {"NEON NOODLES", "CITY BANK", "SKY TV", "PIZZA 24/7"};
            static const u32 bg[4] = {0x3A1030, 0x103A50, 0x2A1050, 0x503A10};
            int w = (int)o.w;
            drawFilledRect(x + 8, y - 70, 4, 70, 0x2A2F3F); drawFilledRect(x + w - 12, y - 70, 4, 70, 0x2A2F3F);
            drawFilledRect(x, y - 114, w, 46, 0x1A1D28);
            drawFilledRect(x + 3, y - 111, w - 6, 40, bg[o.param & 3]);
            SDL_Rect clip = {x + 3, y - 111, w - 6, 40};
            SDL_RenderSetClipRect(uvzRenderer, &clip);
            { const char* s = ads[o.param & 3]; int tw = measureTextWidth(s, 2) + 40; int tx = x + 3 + w - 6 - (int)fmod(t * 30.0, (double)(tw + w));
              text(s, tx, y - 100, 2, 0xFFE9A0);
              drawFilledRect(x + 3, y - 80, w - 6, 3, 0xFF3A6A, 160 + (int)(60 * sinf((float)t * 4))); }
            SDL_RenderSetClipRect(uvzRenderer, nullptr);
            drawFilledRect(x, y - 114, w, 2, 0x6A7090);
        } break;
        default:
            drawFilledRect(x, y - 6, 2, 6, 0x4A5060); drawFilledRect(x - 6, y - 14, 12, 3, 0xB8BED0); drawFilledRect(x - 4, y - 11, 8, 2, 0x8A90A8); drawFilledRect(x - 1, y - 16, 2, 4, 0x6A7090);
            break;
    }
}
static void drawFacade(const Building& b, int sx, int sy) {
    u32 tm = (u32)(gTime * 0.4);
    const float night = 1.0f - daylightAmount(gTime);
    int y0 = sy + 8;
    int r0 = std::max(0, (int)floorf((0 - y0) / 64.0f));
    int cols = ((int)b.w + 63) / 64;
    for (int r = r0; y0 + r * 64 < uvzWorldHeight; r++) {
        for (int c = 0; c < cols; c++) {
            int tx = sx + c * 64;
            if (tx + 64 < 0 || tx > uvzWorldWidth) continue;
            int v = (int)(hashCoordinates(b.seed + c, r, 7) % 3);
            if (hashCoordinates(c + (u32)b.seed, r, tm) % 29 == 0) v = (v + 1) % 3;
            int sw = std::min(64, (int)b.w - c * 64);
            SDL_Rect s = {0, 0, sw, 64}, d = {tx, y0 + r * 64, sw, 64};
            SDL_RenderCopy(uvzRenderer, gTile[b.style][v], &s, &d);
            if (night > 0.03f) {
                drawFilledRect(tx, y0 + r * 64, sw, 64, 0x10182D, (int)(night * 72));
                const u32 glowSeed = hashCoordinates(b.seed + (u32)c, (u32)r, 0x57494Eu);
                if (glowSeed % 3u != 0u) {
                    const int wx = tx + 8 + (int)((glowSeed >> 5) % (u32)std::max(1, sw - 16));
                    const int wy = y0 + r * 64 + 18 + (int)((glowSeed >> 13) % 30u);
                    drawFilledRect(wx, wy, 4, 6, (glowSeed & 1u) ? 0xFFD884 : 0x9ADFFF, (int)(night * 225));
                }
            }
        }
    }
    int top = std::max(sy, 0);
    drawFilledRect(sx, top, 3, uvzWorldHeight - top, 0x05060F, 130);
    drawFilledRect(sx + (int)b.w - 3, top, 3, uvzWorldHeight - top, 0x6A78FF, 40);
    drawFilledRect(sx - 2, sy, (int)b.w + 4, 8, 0x4B5068);
    drawFilledRect(sx - 2, sy, (int)b.w + 4, 2, 0x8A93B0);
    drawFilledRect(sx, sy + 6, (int)b.w, 2, 0x1B1E2C);
}
static void drawCable(const Building& b, float cx, float cy) {
    if (!b.cable) return;
    float x0 = b.cx0 - cx, y0 = b.cy0 - cy, x1 = b.cx1 - cx, y1 = b.cy1 - cy;
    if (x1 < -20 || x0 > uvzWorldWidth + 20) return;
    float px = x0, py = y0;
    for (int i = 1; i <= 24; i++) {
        float u = i / 24.0f, qx = lerpValue(x0, x1, u), qy = lerpValue(y0, y1, u) + 22 * 4 * u * (1 - u);
        drawLine(px, py + 1, qx, qy + 1, 0x05060F, 200); drawLine(px, py, qx, qy, 0x9AA3C0);
        px = qx; py = qy;
    }
    float ax = (x0 + x1) / 2, ay = (y0 + y1) / 2 + 22;
    drawDisc((int)ax, (int)ay + 2, 8, 0xFFE8A0, 45);
    drawFilledRect((int)ax - 3, (int)ay - 2, 6, 6, 0xFFE8A0); drawFilledRect((int)ax - 1, (int)ay - 4, 2, 2, 0x4A5060);
}
static void drawMasts(const Building& b, int sx, int sy) {
    if (b.mastR) { int x = sx + (int)b.w - 12; drawFilledRect(x, sy - 280, 3, 280, 0x2A2F3F); drawFilledRect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) drawFilledRect(x, sy - 284, 3, 3, 0xFF4040); }
    if (b.mastL) { int x = sx + 9; drawFilledRect(x, sy - 280, 3, 280, 0x2A2F3F); drawFilledRect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) drawFilledRect(x, sy - 284, 3, 3, 0xFF4040); }
}
static void drawNYCRooftop(const Building& b, int sx, int sy) {
    if (hashCoordinates(b.seed, 21u, 8u) % 3u != 0u) return;
    const int x = sx + 34 + (int)(b.seed % (u32)std::max(1, (int)b.w - 92));
    drawFilledRect(x - 3, sy - 5, 42, 6, 0x292A32);
    drawFilledRect(x, sy - 24, 34, 19, 0x7D573F);
    drawFilledRect(x + 2, sy - 22, 30, 14, 0xA3734A);
    drawFilledRect(x + 1, sy - 25, 32, 3, 0x46352F);
    drawFilledRect(x + 5, sy - 7, 3, 5, 0x49362D);
    drawFilledRect(x + 25, sy - 7, 3, 5, 0x49362D);
    drawFilledRect(x + 11, sy - 19, 2, 12, 0x5D4336);
    drawFilledRect(x + 21, sy - 19, 2, 12, 0x5D4336);
}
static void drawFireEscape(const Building& b, int sx, int sy, int ground) {
    if (hashCoordinates(b.seed, 48u, 15u) % 3u == 0u) return;
    const int x = sx + 38 + (int)(hashCoordinates(b.seed, 51u, 2u) % (u32)std::max(1, (int)b.w - 86));
    const int top = std::max(8, sy + 32), bottom = std::min(ground - 58, uvzWorldHeight);
    if (bottom - top < 54) return;
    const int color = 0x343941;
    drawFilledRect(x, top, 2, bottom - top, (u32)color);
    drawFilledRect(x + 34, top, 2, bottom - top, (u32)color);
    for (int y = top + 24; y < bottom; y += 32) {
        drawFilledRect(x - 3, y, 42, 3, 0x515763);
        drawLine(x + 2, y + 3, x + 30, y + 25, 0x343941);
        drawFilledRect(x - 3, y - 4, 3, 7, 0x69717D);
        drawFilledRect(x + 39, y - 4, 3, 7, 0x69717D);
    }
    drawLine(x + 2, bottom - 12, x + 34, bottom - 12, 0x515763);
}

static int pickFrame() {
    Player& p = P;
    if (!p.alive) return p.deadT < 0.3f ? F_HIT : F_DEAD;
    if (p.wallCling) return (p.mantleT > 0 || fabsf(p.vy) > 35.0f) ? F_CLIMB : F_CLING;
    if (p.zipping) return F_ATTACH;
    if (p.swinging && !p.onGround) return p.attachT > 0 ? F_ATTACH : F_SWING;
    if (p.shootT > 0 && !p.onGround) return F_SHOOT;
    if (p.trickType && !p.onGround) return p.trickType == T_TWIST ? F_TWIST : (p.trickType == T_CART ? F_STAR : F_FLIP);
    if (p.diving && !p.onGround) return F_DIVE;
    if (p.releaseT > 0) return p.releaseFlip ? F_FLIP : F_RELEASE;
    if (p.slideT > 0 && p.onGround) return F_SLIDE;
    if (p.landT > 0) return p.hero ? F_HERO : F_LAND;
    if (p.onGround) return F_RUN;
    if (p.wallJumpT > 0 && !p.swinging) return F_WALLJUMP;
    if (p.flipT > 0) return F_FLIP;
    return p.vy < 0 ? F_JUMP : F_FALL;
}

static void drawWorldScene(float cx, float cy) {
    const int ground = (int)floorf(STREET_GROUND_Y - cy);
    for (auto& b : bld) {
        if (b.x + b.w < cx - 160 || b.x > cx + uvzWorldWidth + 160) continue;
        int sx = (int)floorf(b.x - cx), sy = (int)floorf(b.roofY - cy);
        for (auto& o : b.obs) if (!o.solid) drawObs(o, (int)floorf(o.x - cx), sy, gTime);
        drawFacade(b, sx, sy);
        drawMasts(b, sx, sy);
        drawNYCRooftop(b, sx, sy);
        drawFireEscape(b, sx, sy, ground);
        for (auto& o : b.obs) if (o.solid) drawObs(o, (int)floorf(o.x - cx), sy, gTime);
    }
    for (auto& b : bld) drawCable(b, cx, cy);
}
static void drawTrafficCar(const TrafficCar& car, float cx, float cy) {
    const float laneOffset = car.lane ? 8.0f : -5.0f;
    const int center = (int)floorf(car.x - cx);
    const int bottom = (int)floorf(STREET_GROUND_Y + laneOffset - cy);
    const int w = (int)car.width, h = (int)car.height;
    const int left = center - w / 2, top = bottom - h;
    const u32 outline = 0x20232B;
    drawFilledRect(left + 3, bottom - 5, w - 6, 3, outline);
    drawFilledRect(left + 2, top + 6, w - 4, h - 12, car.color);
    drawFilledRect(left + 7, top + 2, w - 14, 6, car.color);
    drawFilledRect(left + 7, top + 2, w - 14, 2, 0xE2D6C5, 180);
    if (car.type == 2) {
        drawFilledRect(left + 4, top + 3, w - 8, 4, 0xE5E2D7);
        for (int i = 0; i < 5; ++i) drawFilledRect(left + 7 + i * 14, top + 10, 10, 9, 0x94C8D9);
        drawFilledRect(left + 6, top + h - 13, w - 12, 3, 0xE9C544);
    } else if (car.type == 3) {
        drawFilledRect(left + (car.dir > 0 ? 4 : w - 22), top + 4, 18, h - 11, 0x7D858A);
        drawFilledRect(left + 8, top + 8, 16, 8, 0x9CC5D3);
        drawFilledRect(left + w - 26, top + 8, 16, 8, 0x9CC5D3);
    } else {
        const int windowY = top + 8;
        drawFilledRect(left + 9, windowY, w - 18, 9, 0x9CC5D3);
        drawFilledRect(left + w / 2 - 1, windowY, 2, 9, 0x445664);
        if (car.type == 0) {
            drawFilledRect(left + w / 2 - 6, top, 12, 5, 0xF8E7A1);
            drawFilledRect(left + w / 2 - 4, top + 1, 8, 3, 0xFFF5CF);
            for (int x = left + 9; x < left + w - 8; x += 8)
                drawFilledRect(x, top + h / 2 + 1, 4, 3, 0x262A2F);
        }
    }
    drawFilledRect(left + 3, bottom - 8, 9, 7, outline);
    drawFilledRect(left + w - 12, bottom - 8, 9, 7, outline);
    drawDisc(left + 8, bottom - 4, 3, 0x101216);
    drawDisc(left + w - 8, bottom - 4, 3, 0x101216);
    const int front = car.dir > 0 ? left + w - 2 : left + 1;
    const int rear = car.dir > 0 ? left + 1 : left + w - 2;
    drawFilledRect(front, top + h - 14, 3, 4, 0xFFF1B2);
    drawFilledRect(rear, top + h - 14, 3, 4, car.speed < 38.0f ? 0xFF3B3B : 0xAA3939);
    const float night = 1.0f - daylightAmount(gTime);
    if (night > 0.05f) {
        const int beam = (int)(night * 92.0f);
        const float endX = front + car.dir * 45.0f;
        drawLine((float)front, (float)(top + h - 14), endX, (float)(top + h - 22), 0xFFE8A0, beam);
        drawLine((float)front, (float)(top + h - 10), endX, (float)(top + h - 2), 0xFFE8A0, beam / 2);
    }
}
static void drawStorefronts(float cx, int ground) {
    static const char* names[] = {"BODEGA", "PIZZA", "DELI", "LAUNDRY", "MARKET"};
    static const u32 signs[] = {0xD6483D, 0xD28C29, 0x2E718C, 0x4B8C73, 0x8A4773};
    const float night = 1.0f - daylightAmount(gTime);
    for (const Building& b : bld) {
        if (b.x + b.w < cx - 40 || b.x > cx + uvzWorldWidth + 40) continue;
        const int left = (int)floorf(b.x - cx), right = left + (int)b.w;
        int shop = 0;
        for (int x = left + 12; x + 76 < right - 6; x += 112, ++shop) {
            const int y = ground - 52;
            const u32 sign = signs[(b.seed + (u32)shop) % 5u];
            drawFilledRect(x, y + 17, 76, 35, 0x282A30);
            drawFilledRect(x + 4, y + 19, 30, 27, 0x76A6B4);
            drawFilledRect(x + 39, y + 19, 31, 27, 0x3D424A);
            drawFilledRect(x + 4, y + 17, 66, 2, 0xD2C3A5);
            drawFilledRect(x, y + 5, 76, 11, sign, (int)(190 + 55 * night));
            text(names[(b.seed + (u32)shop) % 5u], x + 6, y + 7, 1, 0xFFF0C3, (int)(175 + 80 * night));
            for (int stripe = 0; stripe < 8; ++stripe)
                drawFilledRect(x + stripe * 10, y + 16, 5, 3, (stripe & 1) ? 0xF0D6A8 : sign);
            drawFilledRect(x + 34, y + 20, 3, 32, 0x574B42);
            if (night > 0.5f && ((shop + (int)b.seed) & 1))
                drawFilledRect(x + 5, y + 20, 28, 25, 0xFFE4A1, (int)(night * 44));
        }
    }
}
static void drawStreetScene(float cx, float cy) {
    const int ground = (int)floorf(STREET_GROUND_Y - cy);
    const int roadTop = ground + 10;
    const float night = 1.0f - daylightAmount(gTime);
    const u32 road = blendRgb(0x686A67, 0x242832, night);
    drawFilledRect(0, roadTop, uvzWorldWidth, uvzWorldHeight - roadTop, road);
    drawFilledRect(0, ground - 7, uvzWorldWidth, 18, blendRgb(0xB9AE94, 0x524D4A, night));
    drawFilledRect(0, ground + 8, uvzWorldWidth, 3, blendRgb(0xE0D2B6, 0x77716A, night));
    drawFilledRect(0, ground + 11, uvzWorldWidth, 2, 0x17191F);
    const int roadH = uvzWorldHeight - roadTop;
    const int laneY = roadTop + std::max(24, roadH / 2);
    const int dashOffset = positiveModulo((int)floorf(cx), 64);
    for (int x = -dashOffset; x < uvzWorldWidth; x += 64)
        drawFilledRect(x, laneY, 28, 2, blendRgb(0xE8D9A6, 0x73717A, night), 210);
    drawStorefronts(cx, ground);
    for (const TrafficSignal& signal : trafficSignals) {
        const int sx = (int)floorf(signal.x - cx);
        if (sx < -120 || sx > uvzWorldWidth + 120) continue;
        for (int x = sx - 42; x <= sx + 42; x += 12)
            drawFilledRect(x, roadTop + 12, 6, std::min(25, std::max(0, uvzWorldHeight - roadTop - 12)), 0xE7E0C8, 190);
        const int subX = sx - 92;
        drawFilledRect(subX, ground - 18, 48, 14, 0x343B43);
        drawFilledRect(subX + 2, ground - 17, 44, 3, 0xD6C9AB);
        for (int step = 0; step < 4; ++step) drawFilledRect(subX + 6 + step * 8, ground - 12 + step * 2, 7, 2, 0xAAA08E);
        drawFilledRect(subX + 9, ground - 33, 30, 12, 0x183B35);
        text("SUBWAY", subX + 11, ground - 30, 1, 0xC4E9A3);
        const bool eastGreen = trafficSignalGreen(signal, 1, gTime);
        const int poleX = sx + 30;
        drawFilledRect(poleX, ground - 86, 3, 82, 0x34383D);
        drawFilledRect(poleX - 6, ground - 90, 17, 28, 0x24262B);
        const u32 eastColor = eastGreen ? 0x43D17A : 0xED4A46;
        const u32 westColor = eastGreen ? 0xED4A46 : 0x43D17A;
        drawDisc(poleX + 2, ground - 84, 3, eastGreen ? 0x5A3E3C : 0xED4A46);
        drawDisc(poleX + 2, ground - 75, 3, 0xE6BA45);
        drawDisc(poleX + 2, ground - 66, 3, eastGreen ? 0x43D17A : 0x3D5543);
        drawFilledRect(poleX + 12, ground - 82, 7, 7, westColor);
        drawFilledRect(poleX + 13, ground - 81, 5, 5, 0xF7F1D8);
        if (night > 0.35f) {
            drawDisc(poleX + 2, ground - 84, 8, eastColor, (int)(night * 32));
            drawDisc(poleX + 13, ground - 78, 8, westColor, (int)(night * 28));
        }
        drawFilledRect(poleX - 2, ground - 4, 7, 4, 0x282B31);
    }
    for (int lane = 0; lane < 2; ++lane)
        for (const TrafficCar& car : trafficCars) if (car.lane == lane)
            drawTrafficCar(car, cx, cy);
}
static void drawParticles(float cx, float cy) {
    for (auto& p : parts) if (p.alive)
        drawFilledRect((int)(p.x - cx), (int)(p.y - cy), p.sz, p.sz, p.c, (int)(255 * clampValue(p.life / p.max, 0, 1)));
}

static float swingPoseT() {
    const Player& p = P;
    const float lean = clampValue(p.vx * 0.0001f, -0.1f, 0.15f);
    if (p.swinging && p.rope > 1.0f) return clampValue(0.5f + 0.5f * clampValue((p.x - p.ax) / (std::max(p.rope, 90.0f) * 0.8f), -1.0f, 1.0f) + lean, 0.0f, 1.0f);
    return clampValue(0.5f + (p.x - p.ax) / 80.0f + lean, 0.0f, 1.0f);
}
static void drawWindStreaks() {
    if (!P.alive || cfg.reduced) return;
    const float sp = hypotf(P.vx, P.vy);
    const float k = clampValue((sp - 650.0f) / 900.0f, 0.0f, 1.0f) * (P.onGround ? 0.0f : 1.0f);
    if (k <= 0.02f) return;
    const int n = 4 + (int)(8 * k);
    const float dx = -P.vx / std::max(sp, 1.0f), dy = -P.vy / std::max(sp, 1.0f);
    for (int i = 0; i < n; i++) {
        const u32 h = hashCoordinates((u32)i, (u32)(gTime * 24.0), 7u);
        const float fx = (float)(h & 1023) / 1023.0f, fy = (float)((h >> 10) & 1023) / 1023.0f;

        const float x = (i & 1) ? fx * uvzWorldWidth * 0.22f : uvzWorldWidth * (1.0f - 0.22f * fx);
        const float y = fy * uvzWorldHeight;
        const float len = 10.0f + 26.0f * k;
        drawLine(x, y, x + dx * len, y + dy * len, 0xFFFFFF, (int)(40 + 70 * k));
    }
}
static void drawSense(float cx, float cy) {
    if (gSense < 0.08f || !P.alive) return;
    const int sx = (int)floorf(P.x - cx), sy = (int)floorf(P.y - cy) - 8;
    const float pulse = cfg.reduced ? 1.0f : 0.65f + 0.35f * sinf((float)gTime * (14.0f + 16.0f * gSense));
    const int a = (int)(255.0f * clampValue(gSense * 1.2f, 0.0f, 1.0f) * pulse);
    const u32 c = gSense > 0.6f ? 0xFF5A4A : 0xFFF2A0;
    for (int k = -1; k <= 1; k++) {
        const float an = gSenseAng + k * 0.34f, r0 = 22.0f, r1 = r0 + 6.0f + 10.0f * gSense;
        drawLine(sx + cosf(an) * r0, sy + sinf(an) * r0, sx + cosf(an) * r1, sy + sinf(an) * r1, c, a);
    }
    if (gSense > 0.6f) {
        const int ea = (int)(70.0f * gSense * pulse);
        drawFilledRect(0, 0, uvzWorldWidth, 2, 0xFF3030, ea); drawFilledRect(0, uvzWorldHeight - 2, uvzWorldWidth, 2, 0xFF3030, ea); drawFilledRect(0, 0, 2, uvzWorldHeight, 0xFF3030, ea); drawFilledRect(uvzWorldWidth - 2, 0, 2, uvzWorldHeight, 0xFF3030, ea);
        drawFilledRect(sx - 1, sy - 44, 3, 7, c, a); drawFilledRect(sx - 1, sy - 35, 3, 3, c, a);
    }
}
static void drawPlayerAndWeb(float cx, float cy) {
    Player& p = P;
    int sx = (int)floorf(p.x - cx), sy = (int)floorf(p.y - cy);
    if (cfg.targetHints && haveTarget && !p.swinging && p.alive) {
        int ax = (int)(tgtX - cx), ay = (int)(tgtY - cy);
        int r = 5 + (int)(2 * sinf((float)gTime * 8));
        drawDisc(ax, ay, r + 2, 0x7FE0FF, 40); drawFilledRect(ax - 1, ay - 1, 3, 3, 0xFFFFFF);
    }
    if (aimStickVisible() && p.alive && !p.onGround && !p.swinging && !p.webFlying && !p.wallCling) {
        float dx, dy; bool st; currentAim(dx, dy, st);
        for (int k = 1; k <= 8; k++) drawFilledRect(sx + (int)(dx * (24 + k * 9)), sy - 10 + (int)(dy * (24 + k * 9)), 2, 2, st ? 0xFFFFFF : 0x7FE0FF, (st ? 230 : 150) - k * 16);
    }
    double target = 0;
    bool spin = false;
    if (p.swinging) {
        const float sp = hypotf(p.vx, p.vy);
        target = atan2((double)(p.ax - p.x), (double)(p.y - p.ay)) * 180.0 / pi * 0.85 + clampValue(sp * 0.012f, 0.0f, 16.0f) * (p.vx >= 0 ? 1.0f : -1.0f);
    }
    else if (p.zipping) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.5f, -40, 30);
    else if (p.diving && p.alive && !p.onGround) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.75f, 12, 60);
    else if (!p.alive) { target = gTime * 500; spin = true; }
    else if (p.trickType && !p.onGround) {
        const float u = clampValue(p.trickT / p.trickDur, 0.0f, 1.0f), e = u * u * (3.0f - 2.0f * u);
        if (p.trickType == T_TWIST) target = 0;
        else { target = e * 360.0 * (p.trickType == T_BACK ? -1.0 : 1.0); spin = true; }
    }
    else if (!p.onGround && ((p.releaseFlip && p.releaseT > 0) || p.flipT > 0)) {
        float u = p.releaseFlip && p.releaseT > 0 ? 1.0f - p.releaseT / 0.5f : 1.0f - p.flipT / 0.55f;
        u = clampValue(u, 0, 1);
        target = (u * u * (3 - 2 * u)) * 360.0 * p.flipDir;
        spin = true;
    }
    else if (!p.onGround && p.releaseT > 0) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.6f, -30, 42);
    else if (!p.onGround) {
        const float sp = hypotf(p.vx, p.vy);
        if (sp > 650.0f) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.45f, -32, 32);
        else target = clampValue(p.vy * 0.01f, -8, 14);
    }
    const int fr = pickFrame();
    int style = 0;
    if (fr == F_RUN) style = p.runStyle;
    else if (fr == F_JUMP) style = p.jumpStyle;
    else if (fr == F_FALL) style = p.fallStyle;
    else if (fr == F_LAND) style = p.landStyle;
    else if (fr == F_SHOOT) style = p.shootStyle;
    else if (fr == F_SLIDE) style = p.slideStyle;
    else if (fr == F_SWING || fr == F_ATTACH) style = p.swingStyle;
    const StkPose& pose = stkAdvance(gPlayerAnim, fr, p.wallCling ? p.climbPhase : gRunPhase, swingPoseT(), style, p.jit);
    double ang = stkAngle(gPlayerAnim, target, spin);
    float hfx, hfy;
    gStkMirror = p.wallCling && p.wallDir < 0;
    if (p.trickType == T_TWIST && !p.onGround) gStkMirror = ((int)(clampValue(p.trickT / p.trickDur, 0.0f, 0.99f) * 5.0f) & 1) != 0;
    stickHand(pose, sx, sy + 26, ang, hfx, hfy);
    if (p.swinging) {
        int hx = (int)hfx, hy = (int)hfy, ax = (int)(p.ax - cx), ay = (int)(p.ay - cy);
        drawLine((float)hx, (float)hy + 1, (float)ax, (float)ay + 1, 0x05060F, 220);
        drawLine((float)hx, (float)hy, (float)ax, (float)ay, 0xFFFFFF);
        drawLine((float)hx + 1, (float)hy, (float)ax + 1, (float)ay, 0xC8D8FF, 150);
    } else if (p.zipping && p.alive) {
        int wx = (int)(p.zipX - cx), wy = (int)(p.zipY - cy);
        drawLine(hfx, hfy + 1, wx, wy + 1, 0x05060F, 220); drawLine(hfx, hfy, wx, wy, 0xFFFFFF);
        drawLine(hfx + 1, hfy, wx + 1, wy, 0xC8D8FF, 150);
        drawDisc(wx, wy, 3, 0xDCEBFF);
    } else if (p.webFlying && p.alive) {
        int wx = (int)(p.webX - cx), wy = (int)(p.webY - cy);
        drawLine(hfx, hfy + 1, wx, wy + 1, 0x05060F, 220); drawLine(hfx, hfy, wx, wy, 0xFFFFFF);
        drawDisc(wx, wy, 3, 0xDCEBFF); drawFilledRect(wx - 1, wy - 1, 3, 3, 0xFFFFFF);
    } else if (p.shootT > 0 && p.alive) {
        float u = 1 - p.shootT / 0.14f;
        drawLine(hfx, hfy, hfx + 70 * u, hfy - 70 * u, 0xFFFFFF, 200);
    }
    for (auto& t : gTrail) if (t.t > 0) {
        const float u = clampValue(t.t / t.max, 0, 1);
        const int sz = u > 0.6f ? 3 : (u > 0.3f ? 2 : 1);
        drawFilledRect((int)(t.x - cx) - sz / 2, (int)(t.y - cy) - sz / 2, sz, sz, t.c, (int)(190 * u));
    }
    drawHalo(sx, sy - 6);
    drawStickman(pose, sx, sy + 26, ang);
    gStkMirror = false;
    if (p.vx > 420 && p.alive)
        for (int i = 0; i < 4; i++) drawFilledRect(sx - 40 - (int)hashCoordinates(i, (u32)(gTime * 20), 1) % 50, sy - 30 + i * 14, 20 + (int)hashCoordinates(i, 4, 4) % 20, 1, 0xFFFFFF, 70);
}

static const u32 UI_INK = 0x070A14, UI_WHITE = 0xF4F7FF, UI_DIM = 0x8C96B8, UI_RED = 0xE8262F, UI_RED_D = 0x6A0E16;

static void hline(int x, int y, int w, u32 c, int a) { drawFilledRect(x, y, w, 1, c, a); }
static void slantBar(int x, int y, int w, int h, int shear, u32 c, int a) {
    for (int r = 0; r < h; r++) {
        int off = (h - 1 - r) * shear / std::max(1, h - 1);
        drawFilledRect(x + off, y + r, w - shear, 1, c, a);
    }
}
static void ringDraw(int cx, int cy, int r, int th, u32 c, int a) {
    int ri = r - th;
    for (int dy = -r; dy <= r; dy++) {
        int xo = (int)sqrtf((float)(r * r - dy * dy));
        if (ri > 0 && std::abs(dy) < ri) {
            int xi = (int)sqrtf((float)(ri * ri - dy * dy));
            drawFilledRect(cx - xo, cy + dy, xo - xi, 1, c, a);
            drawFilledRect(cx + xi + 1, cy + dy, xo - xi, 1, c, a);
        } else drawFilledRect(cx - xo, cy + dy, xo * 2 + 1, 1, c, a);
    }
}
static void thickLine(float x0, float y0, float x1, float y1, int r, u32 c, int a = 255) {
    float dx = x1 - x0, dy = y1 - y0;
    int n = std::max(1, (int)hypotf(dx, dy));
    for (int i = 0; i <= n; i++) { float t = (float)i / n; drawDisc((int)lroundf(x0 + dx * t), (int)lroundf(y0 + dy * t), r, c, a); }
}
static void ellipseFill(int cx, int cy, int rx, int ry, u32 c) {
    ry = std::max(1, ry);
    for (int dy = -ry; dy <= ry; dy++) {
        int dx = (int)(rx * sqrtf(std::max(0.0f, 1.0f - (float)(dy * dy) / (float)(ry * ry))));
        drawFilledRect(cx - dx, cy + dy, dx * 2 + 1, 1, c);
    }
}
static void drawSpider(int cx, int cy, float s, u32 c) {
    static const float L[5][4][2] = {
        {{0.06f, -0.20f}, {0.26f, -0.60f}, {0.46f, -0.86f}, {0.80f, -1.00f}},
        {{0.09f, -0.10f}, {0.46f, -0.38f}, {0.82f, -0.44f}, {1.00f, -0.72f}},
        {{0.10f, 0.00f}, {0.56f, -0.04f}, {0.90f, 0.12f}, {1.04f, 0.42f}},
        {{0.11f, 0.14f}, {0.48f, 0.38f}, {0.74f, 0.68f}, {0.80f, 1.00f}},
        {{0.09f, 0.30f}, {0.26f, 0.68f}, {0.32f, 0.94f}, {0.26f, 1.14f}}};
    int r = std::max(0, (int)lroundf(s * 0.07f));
    for (int side = -1; side <= 1; side += 2)
        for (int i = 0; i < 5; i++)
            for (int k = 0; k < 3; k++)
                thickLine(cx + side * L[i][k][0] * s, cy + L[i][k][1] * s * 0.9f, cx + side * L[i][k + 1][0] * s, cy + L[i][k + 1][1] * s * 0.9f, r, c);
    ellipseFill(cx, cy + (int)(0.34f * s), std::max(1, (int)(0.17f * s)), (int)(0.38f * s), c);
    ellipseFill(cx, cy - (int)(0.10f * s), std::max(1, (int)(0.10f * s)), (int)(0.15f * s), c);
    ellipseFill(cx, cy - (int)(0.30f * s), std::max(1, (int)(0.06f * s)), (int)(0.07f * s), c);
}
static void drawWebIcon(int cx, int cy, float r, u32 c, int a = 255) {
    for (int i = 0; i < 8; i++) { float an = i * pi / 4; drawLine((float)cx, (float)cy, cx + cosf(an) * r, cy + sinf(an) * r, c, a); }
    for (int k = 1; k <= 3; k++) {
        float rr = r * k / 3.0f;
        for (int i = 0; i < 8; i++) {
            float a0 = i * pi / 4, a1 = (i + 1) * pi / 4;
            drawLine(cx + cosf(a0) * rr, cy + sinf(a0) * rr, cx + cosf(a1) * rr, cy + sinf(a1) * rr, c, a);
        }
    }
}
static int textWSp(const char* s, int sc, int gap) { int n = (int)strlen(s); return n <= 0 ? 0 : n * (6 * sc + gap) - gap - sc; }
static void textSp(const char* s, int x, int y, int sc, u32 c, int gap, int a = 255) {
    char b[2] = {0, 0};
    for (; *s; ++s) { b[0] = *s; text(b, x, y, sc, c, a); x += 6 * sc + gap; }
}
static void textSpC(const char* s, int cx, int y, int sc, u32 c, int gap, int a = 255) { textSp(s, cx - textWSp(s, sc, gap) / 2, y, sc, c, gap, a); }

static float easeOut(float t) { t = clampValue(t, 0, 1); return 1 - (1 - t) * (1 - t); }

static void drawButton(const Btn& b, int idx, bool foc, bool pr) {
    float e = easeOut((uiAge - idx * 0.05f) / 0.22f);
    if (e <= 0) return;
    int a = (int)(255 * e), ox = (int)((1 - e) * -22);
    bool hot = foc || pr;
    if (b.style & 16) { hot = false; a = a * 120 / 255; }
    int x = b.x + ox;
    if (b.kind == 5) {
        drawFilledRect(x, b.y, b.w, b.h, hot ? UI_RED : UI_WHITE, hot ? a : 70 * a / 255);
        drawFilledRect(x + 1, b.y + 1, b.w - 2, b.h - 2, UI_INK, a);
        int tw = measureTextWidth(b.label, 2);
        text(b.label, x + (b.w - tw) / 2, b.y + (b.h - 14) / 2, 2, UI_WHITE, a);
        return;
    }
    if (b.kind == 4) {
        int cx = x + b.w / 2, cy = b.y + b.h / 2, r = b.w / 2;
        drawDisc(cx, cy, r, hot ? UI_WHITE : UI_INK, hot ? 245 * a / 255 : 170 * a / 255);
        ringDraw(cx, cy, r, 2, hot ? UI_RED : UI_WHITE, a);
        drawWebIcon(cx, cy, (float)(r - 6), hot ? UI_INK : UI_WHITE, a);
        text(b.label, cx - measureTextWidth(b.label, 1) / 2, b.y + b.h + 4, 1, hot ? UI_WHITE : UI_DIM, a);
        return;
    }
    if (b.kind == 1) {
        char v[16];
        if (b.id == S_SWING_ASSIST) snprintf(v, sizeof v, "%d%%", (int)lroundf(clampValue(*b.val, 0, 1) * 100));
        else snprintf(v, sizeof v, "%d%%", (int)lroundf(*b.val * 100));
        text(b.label, x, b.y + 3, 1, hot ? UI_WHITE : UI_DIM, a);
        text(v, x + b.w - measureTextWidth(v, 1), b.y + 3, 1, UI_WHITE, a);
        int ty = b.y + 22, fw = (int)((*b.val - b.vmin) / (b.vmax - b.vmin) * b.w);
        drawFilledRect(x, ty + 1, b.w, 2, UI_WHITE, 55 * a / 255);
        drawFilledRect(x, ty, fw, 4, UI_WHITE, a);
        slantBar(x + fw - 4, ty - 5, 8, 14, 3, hot ? UI_WHITE : UI_RED, a);
        hline(x, b.y + b.h - 1, b.w, UI_WHITE, 26 * a / 255);
        if (hot) drawFilledRect(x - 7, b.y + 4, 2, b.h - 10, UI_RED, a);
        return;
    }
    if (b.kind == 2) {
        int sc = fitTextScale(b.label, b.w - 56, 2);
        text(b.label, x, b.y + (b.h - 7 * sc) / 2, sc, hot ? UI_WHITE : 0xC9D1EE, a);
        bool on = *b.flag;
        int tx = x + b.w - 34, ty = b.y + b.h / 2 - 7;
        drawFilledRect(tx, ty, 32, 14, on ? UI_RED : UI_WHITE, on ? a : 45 * a / 255);
        drawFilledRect(tx + (on ? 19 : 3), ty + 3, 10, 8, on ? UI_WHITE : UI_DIM, a);
        hline(x, b.y + b.h - 1, b.w, UI_WHITE, 26 * a / 255);
        if (hot) drawFilledRect(x - 7, b.y + 4, 2, b.h - 10, UI_RED, a);
        return;
    }
    if (b.kind == 3) {
        bool cap = gRebind == b.act && gRebind >= 0;
        text(b.label, x, b.y + 2, 1, hot || cap ? UI_WHITE : UI_DIM, a);
        int by = b.y + 14, bh2 = b.h - 16;
        if (cap) drawFilledRect(x, by, b.w, bh2, UI_RED, a);
        else drawFilledRect(x, by, b.w, bh2, UI_WHITE, (hot ? 38 : 14) * a / 255);
        int oa = (cap ? 255 : (hot ? 230 : 90)) * a / 255;
        hline(x, by, b.w, UI_WHITE, oa); hline(x, by + bh2 - 1, b.w, UI_WHITE, oa);
        drawFilledRect(x, by, 1, bh2, UI_WHITE, oa); drawFilledRect(x + b.w - 1, by, 1, bh2, UI_WHITE, oa);
        char k[24];
        if (cap) snprintf(k, sizeof k, "%s", (((int)(gTime * 3)) & 1) ? "PRESS A KEY" : "PRESS A KEY.");
        else keyLabel(ctl.key[b.act], k, sizeof k);
        int sc = fitTextScale(k, b.w - 12, 2);
        text(k, x + (b.w - measureTextWidth(k, sc)) / 2, by + (bh2 - 7 * sc) / 2, sc, UI_WHITE, a);
        return;
    }
    int w = b.w;
    if (b.style & 8) {
        bool act = b.id == (ctlTab == 0 ? B_TAB_KEYS : B_TAB_TOUCH);
        if (act) slantBar(x, b.y, w, b.h, b.h / 4, UI_WHITE, a);
        else if (hot) slantBar(x, b.y, w, b.h, b.h / 4, UI_WHITE, 60 * a / 255);
        int sc = fitTextScale(b.label, w - 24, 2);
        text(b.label, x + (w - measureTextWidth(b.label, sc)) / 2 + b.h / 8, b.y + (b.h - 7 * sc) / 2, sc, act ? UI_INK : UI_WHITE, a);
        return;
    }
    if (b.style & 4) {
        drawFilledRect(x, b.y, w, b.h, UI_WHITE, hot ? a : 0);
        int oa = (hot ? 255 : 100) * a / 255;
        hline(x, b.y, w, UI_WHITE, oa); hline(x, b.y + b.h - 1, w, UI_WHITE, oa);
        drawFilledRect(x, b.y, 1, b.h, UI_WHITE, oa); drawFilledRect(x + w - 1, b.y, 1, b.h, UI_WHITE, oa);
        int sc = fitTextScale(b.label, w - 16, 2);
        text(b.label, x + (w - measureTextWidth(b.label, sc)) / 2, b.y + (b.h - 7 * sc) / 2, sc, hot ? UI_INK : UI_WHITE, a);
        return;
    }
    int shear = b.h / 4;
    if (hot) slantBar(x, b.y, w, b.h, shear, UI_WHITE, 245 * a / 255);
    else hline(x, b.y + b.h - 1, w, UI_WHITE, 30 * a / 255);
    int sc = fitTextScale(b.label, w - 40, (b.style & 2) ? 3 : 2);
    int tw = measureTextWidth(b.label, sc), ty = b.y + (b.h - 7 * sc) / 2;
    int tx = (b.style & 1) ? x + (w - tw) / 2 : x + 16 + (hot ? 4 : 0);
    if (!hot && (b.style & 2)) drawFilledRect(x, b.y + 4, 3, b.h - 8, UI_RED, a);
    text(b.label, tx, ty, sc, hot ? UI_INK : UI_WHITE, a);
    if (hot) {
        int o = (int)(1 + 1.5f * sinf((float)gTime * 7));
        text(">", x + w - shear - 18 + o, b.y + (b.h - 14) / 2, 2, UI_RED);
    }
}
static void drawButtons() {
    for (size_t i = 0; i < btns.size(); i++) {
        bool pr = false;
        for (auto& t : tch) if (t.on && t.btn == (int)i && (t.role == R_UI || t.role == R_SLIDER)) pr = true;
        drawButton(btns[i], (int)i, gFocus == (int)i, pr);
    }
}
static void drawCtlButton(int i, bool pressed, bool editing) {
    float fx, fy, fr; ctlPos(i, fx, fy, fr);
    int cx = (int)fx, cy = (int)fy, r = (int)fr;
    float al = ctl.alpha, k = ctl.scale;
    int fillA = (int)(150 * al) + 20, ringA = (int)(255 * clampValue(al + 0.2f, 0, 1));
    drawDisc(cx, cy, r, pressed ? UI_WHITE : UI_INK, pressed ? 230 : fillA);
    ringDraw(cx, cy, r, 2, pressed ? UI_RED : UI_WHITE, pressed ? 255 : ringA);
    if (editing) ringDraw(cx, cy, r + 5, 1, UI_WHITE, 140);
    u32 ic = pressed ? UI_INK : UI_WHITE;
    if (i == 0) {
        drawSpider(cx, cy, 17 * k, ic);
    } else if (i == 1) {
        for (int j = 0; j < 2; j++) {
            float oy = (-3 + j * 8) * k;
            thickLine(cx - 9 * k, cy + oy + 6 * k, cx, cy + oy - 3 * k, 1, ic, 255);
            thickLine(cx, cy + oy - 3 * k, cx + 9 * k, cy + oy + 6 * k, 1, ic, 255);
        }
    } else {
        thickLine(cx - 10 * k, cy - 5 * k, cx + 8 * k, cy - 5 * k, 1, ic, 255);
        thickLine(cx + 3 * k, cy - 10 * k, cx + 9 * k, cy - 5 * k, 1, ic, 255);
        thickLine(cx + 3 * k, cy, cx + 9 * k, cy - 5 * k, 1, ic, 255);
        drawFilledRect(cx - (int)(10 * k), cy, (int)(8 * k), 1, ic, 128);
    }
}
static void drawRotateScreen() {
    drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x070A1E);
    int cx = uvzWorldWidth / 2, cy = uvzWorldHeight / 2 - 30;
    float a = sinf((float)gTime * 2.0f);
    drawFilledRect(cx - 12, cy - 20, 24, 40, 0xE8ECFF); drawFilledRect(cx - 10, cy - 17, 20, 30, 0x0E1432); drawFilledRect(cx - 3, cy + 15, 6, 2, 0xE8ECFF);
    int ax = cx + 36 + (int)(a * 6);
    text(">", ax, cy - 8, 3, UI_RED);
    drawCenteredText("ROTATE YOUR", cx, cy + 50, fitTextScale("ROTATE YOUR", uvzWorldWidth - 20, 3), 0xFFFFFF);
    drawCenteredText("DEVICE", cx, cy + 50 + 26, fitTextScale("DEVICE", uvzWorldWidth - 20, 3), 0xFFFFFF);
    drawCenteredText("TO LANDSCAPE", cx, cy + 50 + 52, fitTextScale("TO LANDSCAPE", uvzWorldWidth - 20, 2), UI_RED);
}
static void drawLogoBig() {
    int sc = (int)clampValue(uvzWorldWidth / 120.0f, 3, 6);
    float s = clampValue(uvzWorldHeight * 0.15f, 26, 54);
    int cy = (int)(uvzWorldHeight * 0.30f);
    drawHalo(uvzWorldWidth / 2, cy);
    drawSpider(uvzWorldWidth / 2 + 2, cy + 3, s, UI_RED_D);
    drawSpider(uvzWorldWidth / 2, cy, s, UI_WHITE);
    int ty = cy + (int)s + 16;
    textSpC("STICKMAN", uvzWorldWidth / 2 + 2, ty + 2, sc, UI_RED_D, sc);
    textSpC("STICKMAN", uvzWorldWidth / 2, ty, sc, UI_WHITE, sc);
    int y2 = ty + 7 * sc + 10, w2 = textWSp("STICKMAN", sc, sc);
    slantBar(uvzWorldWidth / 2 - w2 / 2, y2, w2, 3, 3, UI_RED, 255);
    textSpC("NYC STREETS", uvzWorldWidth / 2, y2 + 10, 2, 0xBFD0FF, 8);
}
static void drawLogoSmall(float e) {
    int x = (int)uvzSafeLeft + 8, y = 18;
    int a = (int)(255 * e);
    drawSpider(x + 17, y + 20, 16, UI_WHITE);
    int tx = x + 44;
    textSp("STICKMAN", tx + 1, y + 3, 3, UI_RED_D, 3, a);
    textSp("STICKMAN", tx, y + 2, 3, UI_WHITE, 3, a);
    slantBar(tx, y + 27, 54, 3, 3, UI_RED, a);
    textSp("NYC STREETS", tx, y + 35, 1, 0xBFD0FF, 5, a);
}
static void drawMenuScene(double dt) {
    menuT += (float)dt;
    drawBackdrop(menuT * 16.0f, -200, gTime);
    int roofY = (int)(uvzWorldHeight * 0.76f), sx0 = (int)(uvzWorldWidth * 0.50f), sw = uvzWorldWidth - sx0 + 20;
    Building mb; mb.x = (float)sx0; mb.w = (float)(sw / 16 * 16); mb.roofY = 0; mb.style = 1; mb.seed = 99;
    drawFacade(mb, sx0, roofY);
    int mx = (int)(uvzWorldWidth * 0.90f), mtop = (int)(uvzWorldHeight * 0.20f);
    drawFilledRect(mx, mtop, 3, roofY - mtop, 0x2A2F3F); drawFilledRect(mx - 5, mtop + 18, 13, 1, 0x2A2F3F);
    if (((int)(gTime * 1.5)) & 1) { drawDisc(mx + 1, mtop - 2, 4, 0xFF2A2A, 70); drawFilledRect(mx, mtop - 3, 3, 3, 0xFF4040); }
    int spx = (int)(uvzWorldWidth * 0.68f);
    float t = fmodf((float)gTime, 5.2f);
    int frame = F_IDLE;
    double ang = 0; int px = spx, py = roofY, fy = roofY;
    if (t < 0.9f) { frame = F_JUMP; float u = t / 0.9f; py = fy - (int)(105.0f * sinf(u * pi)); }
    else if (t < 3.5f) { float u = (t - 0.9f) / 2.6f; frame = u < 0.12f ? F_SHOOT : F_SWING; px = (int)lerpValue((float)spx, (float)(uvzWorldWidth + 60), u * u); py = fy - (int)(150 * sinf(u * pi)); ang = 40.0 * sinf(u * pi); }
    else { float u = (t - 3.5f) / 1.7f; frame = F_IDLE; px = (int)lerpValue((float)(uvzWorldWidth + 60), (float)spx, u); py = fy; ang = 0; }
    const StkPose& pose = stkAdvance(gMenuAnim, frame, (float)gTime * 0.83f, 0.5f);
    float hx, hy;
    stickHand(pose, px, py, ang, hx, hy);
    int handX = (int)hx, handY = (int)hy;
    float webLen = (t >= 0.9f && t < 1.25f) ? (t - 0.9f) / 0.35f : (t >= 1.25f && t < 3.5f ? 1.0f : 0.0f);
    float wx = lerpValue((float)handX, (float)mx + 1, webLen), wy = lerpValue((float)handY, (float)mtop, webLen);
    if (t >= 0.9f && t < 3.5f) {
        float px0 = (float)handX, py0 = (float)handY;
        for (int i = 1; i <= 16; i++) {
            float u = i / 16.0f, qx = lerpValue((float)handX, wx, u), qy = lerpValue((float)handY, wy, u);
            drawLine(px0, py0 + 1, qx, qy + 1, 0x05060F, 200); drawLine(px0, py0, qx, qy, 0xFFFFFF);
            px0 = qx; py0 = qy;
        }
    }
    drawHalo(px, py - 26);
    drawStickman(pose, px, py, ang);
}

static void drawAimStick() {
    float fx, fy, fr; aimPos(fx, fy, fr);
    const int cx = (int)fx, cy = (int)fy, r = (int)fr;
    const float al = ctl.alpha;
    const bool act = aimDown || hypotf(aimX, aimY) > 0.05f;
    const int fillA = (int)(120 * al) + 20, ringA = (int)(255 * clampValue(al + 0.2f, 0, 1));
    drawDisc(cx, cy, r, UI_INK, fillA);
    ringDraw(cx, cy, r, 2, act ? UI_RED : UI_WHITE, act ? 255 : ringA);
    drawFilledRect(cx + (int)(AIM_DEF_X * r * 0.78f) - 1, cy + (int)(AIM_DEF_Y * r * 0.78f) - 1, 3, 3, UI_RED, 200);
    const int kx = cx + (int)(aimX * r * 0.62f), ky = cy + (int)(aimY * r * 0.62f), kr = std::max(6, (int)(r * 0.36f));
    drawDisc(kx, ky, kr, act ? UI_WHITE : UI_INK, act ? 235 : fillA + 40);
    ringDraw(kx, ky, kr, 2, act ? UI_RED : UI_WHITE, act ? 255 : ringA);
    textSpC("AIM", cx, cy - r - 10, 1, UI_WHITE, 2, 150);
}
static void drawComboHUD(int x, int cy) {
    if (!P.alive) return;
    char b[48];
    const int t = gCombo.tier;
    const u32 c = COMBO_COL[t];
    if (gCombo.count > 0) {
        const bool drain = gCombo.draining;
        const int sc = gCombo.hitT > 0.12f ? 4 : 3;
        const u32 mc = drain && ((int)(gTime * 8) & 1) ? 0xD62839 : c;
        snprintf(b, sizeof b, "x%.1f", gCombo.mult);
        drawTextWithShadow(b, x, cy - (sc == 4 ? 4 : 0), sc, mc);
        if (gCombo.awardT > 0) {
            snprintf(b, sizeof b, "+%d", gCombo.lastAward);
            text(b, x + measureTextWidth("x0.0", 3) + 8, cy + 2, 2, 0xFFE9A0, (int)(255 * clampValue(gCombo.awardT / 0.4f, 0, 1)));
        }
        if (gCombo.awardT > 0 && gCombo.lastKindShown == combo::STUNT && gStuntName[0]) snprintf(b, sizeof b, "%s", gStuntName);
        else if (gCombo.awardT > 0 && gCombo.lastKindShown >= 0) snprintf(b, sizeof b, "%s", combo::kindName(gCombo.lastKindShown));
        else snprintf(b, sizeof b, drain ? "COMBO FADING" : "COMBO %d", gCombo.count);
        text(b, x, cy + 25, 1, gCombo.awardT > 0 ? 0xFFE9A0 : UI_DIM);
        const int bw = 56, by = cy + 36;
        drawFilledRect(x, by, bw, 3, UI_WHITE, 45);
        drawFilledRect(x, by, std::max(1, (int)(bw * combo::meter(gCombo))), 3, drain ? 0xD62839 : c);
        if (!cfg.reduced && t >= 3) {
            const int a = 28 + (int)(22 * (0.5f + 0.5f * sinf((float)gTime * (t >= 4 ? 9.0f : 6.0f))));
            drawFilledRect(0, 0, 2, uvzWorldHeight, c, a); drawFilledRect(uvzWorldWidth - 2, 0, 2, uvzWorldHeight, c, a);
        }
    }
    if (gTrickMsgT > 0 && gTrickMsg[0]) {
        const int a = (int)(255 * clampValue(gTrickMsgT / 0.35f, 0, 1));
        const int ty = (int)(uvzWorldHeight * 0.27f);
        textSpC(gTrickMsg, uvzWorldWidth / 2 + 1, ty + 1, 2, 0x05060F, 2, a);
        textSpC(gTrickMsg, uvzWorldWidth / 2, ty, 2, gTrickBad ? 0xFF6B6B : 0xFFE9A0, 2, a);
    }
    if (gCombo.tierPopT > 0) {
        const int tp = gCombo.tierPop;
        const char* nm = combo::tierName(tp);
        const float k = gCombo.tierPopT / 1.5f;
        const int sc = (k > 0.9f ? 4 : 3) + (tp >= 4 ? 1 : 0);
        const int a = (int)(255 * clampValue(gCombo.tierPopT / 0.5f, 0, 1));
        const int by = (int)(uvzWorldHeight * 0.36f);
        const int w = textWSp(nm, sc, 2);
        slantBar(uvzWorldWidth / 2 - w / 2 - 10, by - 4, w + 20, 7 * sc + 8, 4, COMBO_COL[tp], a / 6);
        textSpC(nm, uvzWorldWidth / 2 + 1, by + 1, sc, 0x05060F, 2, a);
        textSpC(nm, uvzWorldWidth / 2, by, sc, (tp >= 4 && ((int)(gTime * 10) & 1)) ? 0xFFFFFF : COMBO_COL[tp], 2, a);
    }
}
static void drawHUD() {
    char b[64];
    int x = (int)uvzSafeLeft, y = (int)uvzSafeTop;
    text("SCORE", x, y, 1, UI_DIM);
    snprintf(b, sizeof b, "%d", scoreVal());
    drawTextWithShadow(b, x, y + 10, 3, UI_WHITE);
    snprintf(b, sizeof b, "%dM", (int)distM);
    drawTextWithShadow(b, x, y + 35, 2, 0xBFD8FF);
    int rx = uvzWorldWidth - (int)uvzSafeRight;
    snprintf(b, sizeof b, "BEST %dM", (int)std::max(cfg.best, distM));
    text(b, rx - measureTextWidth(b, 1), y, 1, UI_DIM);
    { char cb[40]; fmtNum(gProg.coins, cb, sizeof cb); char t[48]; snprintf(t, sizeof t, "COINS %s", cb);
      drawTextWithShadow(t, rx - measureTextWidth(t, 1), y + 12, 1, 0xFFE9A0); }
    int pcx = pauseBtn.x + 22, pcy = pauseBtn.y + 20;
    drawDisc(pcx, pcy, 15, UI_INK, 110);
    ringDraw(pcx, pcy, 15, 1, UI_WHITE, 150);
    drawFilledRect(pcx - 5, pcy - 6, 3, 12, UI_WHITE); drawFilledRect(pcx + 2, pcy - 6, 3, 12, UI_WHITE);
    if (chainShowT > 0) {
        snprintf(b, sizeof b, "SWING CHAIN +%d", 10 * std::max(2, P.chain));
        textSpC(b, uvzWorldWidth / 2, (int)(uvzWorldHeight * 0.22f), 2, 0x7FE0FF, 2);
    }
    drawComboHUD(x, y + 54);
    if (gPerfectShowT > 0 && P.alive) {
        snprintf(b, sizeof b, gPerfectStreak >= 2 ? "PERFECT x%d" : "PERFECT", gPerfectStreak);
        textSpC(b, uvzWorldWidth / 2, (int)(uvzWorldHeight * 0.15f), 2, 0xFFE9A0, 2);
    }
    if (gFlow > 0.05f && P.alive) {
        int fw = 60, fy = (int)(uvzWorldHeight * 0.27f);
        drawFilledRect(uvzWorldWidth / 2 - fw / 2, fy, fw, 2, UI_WHITE, 40);
        drawFilledRect(uvzWorldWidth / 2 - fw / 2, fy, (int)(fw * gFlow), 2, 0x7FE0FF);
    }
    if (P.boostT > 0 && P.alive) {
        int bw = 90, by = (int)(uvzWorldHeight * 0.30f);
        textSpC("SWING BOOST", uvzWorldWidth / 2, by, 1, 0xFFE9A0, 3);
        drawFilledRect(uvzWorldWidth / 2 - bw / 2, by + 11, bw, 1, UI_WHITE, 50);
        drawFilledRect(uvzWorldWidth / 2 - bw / 2, by + 10, (int)(bw * clampValue(P.boostT / P.boostDur, 0, 1)), 3, 0xFFE9A0);
    }
    for (int i = 0; i < 3; i++) {
        bool pr = false;
        int role = i == 0 ? R_SWING : (i == 1 ? R_JUMP : R_SLIDE);
        for (auto& t : tch) if (t.on && t.role == role) pr = true;
        if (i == 0 && swingHeld) pr = true;
        drawCtlButton(i, pr, false);
    }
    if (aimStickVisible()) drawAimStick();
    else {
        float fx, fy, fr; ctlPos(0, fx, fy, fr);
        textSpC("AUTO WEB", (int)fx, (int)(fy - fr - 12), 1, 0x7FE0FF, 2, 170);
    }
}
static void dim(int a) { drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x03040C, a); }
static void shadeLeft(int w, int aMax) {
    for (int x = 0; x < w; x += 2) drawFilledRect(x, 0, 2, uvzWorldHeight, UI_INK, (int)(aMax * (1.0f - (float)x / w)));
}
static void shadeEdges(int h, int aMax) {
    for (int y = 0; y < h; y += 2) {
        int a = (int)(aMax * (1.0f - (float)y / h));
        drawFilledRect(0, y, uvzWorldWidth, 2, UI_INK, a); drawFilledRect(0, uvzWorldHeight - 2 - y, uvzWorldWidth, 2, UI_INK, a);
    }
}
static void sheet(int px, int pw, const char* title) {
    float e = easeOut(uiAge / 0.25f);
    drawFilledRect(px, 10, pw, uvzWorldHeight - 20, UI_INK, (int)(228 * e));
    hline(px, 10, pw, UI_WHITE, (int)(150 * e));
    slantBar(px + 20, 10, 46, 4, 4, UI_RED, 255);
    textSp(title, px + 20, 24, 3, UI_WHITE, 3, (int)(255 * e));
    hline(px + 20, 54, pw - 40, UI_WHITE, (int)(60 * e));
}
static void drawLines(const char* const* ls, int n, int cx, int y0, int maxW) {
    for (int i = 0; i < n; i++) {
        float e = easeOut((uiAge - 0.1f - i * 0.05f) / 0.22f);
        int sc = fitTextScale(ls[i], maxW, 2);
        int tw = measureTextWidth(ls[i], sc);
        text(ls[i], cx - tw / 2, y0 + i * 24 + (int)((1 - e) * 8), sc, 0xDDE6FF, (int)(255 * e));
    }
}

static void drawStatLine(const char* label, const char* val, int cx, int y, u32 vc) {
    textSpC(label, cx, y, 1, UI_DIM, 3);
    int sc = 3; while (sc > 1 && textWSp(val, sc, 2) > 140) sc--;
    textSpC(val, cx, y + 11 + (3 - sc) * 3, sc, vc, 2);
}
static void render(double dt) {
    SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
    SDL_SetRenderDrawBlendMode(uvzRenderer, SDL_BLENDMODE_BLEND);
    if (portrait) drawRotateScreen();
    else {
        static State prevS = (State)-1;
        if (gState != prevS) { uiAge = 0; gFocus = -1; gRebind = -1; prevS = gState; }
        uiAge += (float)dt; noteT -= (float)dt; if (flashT > 0) flashT -= (float)dt;
        bool world = gState == PLAYING || gState == PAUSED || gState == GAME_OVER || (isSub(gState) && (navRoot == PAUSED || navRoot == GAME_OVER));
        buildUI();
        if (gFocus >= (int)btns.size()) gFocus = -1;
        if (world) {
            float shx = 0, shy = 0;
            if (shakeT > 0 && cfg.shake) { shx = ((int)hashCoordinates((u32)(gTime * 90), 1, 2) % 5) - 2.0f; shy = ((int)hashCoordinates((u32)(gTime * 90), 3, 4) % 5) - 2.0f; }
            float cx = floorf(camX + shx), cy = floorf(camY + shy);
            drawBackdrop(cx, cy, gTime);
            drawWorldScene(cx, cy);
            drawStreetScene(cx, cy);
            drawParticles(cx, cy);
            drawPlayerAndWeb(cx, cy);
            drawSense(cx, cy);
            drawWindStreaks();
            drawFilledRect(0, (int)(uvzWorldHeight * 0.86f), uvzWorldWidth, uvzWorldHeight, 0x2A3060, 30);
            if (gState == PLAYING) drawHUD();
        } else drawMenuScene(dt);

        int pw = std::min(uvzWorldWidth - (int)(uvzSafeLeft + uvzSafeRight), 560), px = (uvzWorldWidth - pw) / 2;
        switch (gState) {
            case TITLE: {
                shadeEdges(70, 200); dim(115);
                drawLogoBig();
                int by0 = (int)(uvzWorldHeight * 0.80f) - 12;
                for (int i = 0; i < 28; i++) { int a = (int)(150 * sinf(pi * (i + 0.5f) / 28.0f)); drawFilledRect(0, by0 + i, uvzWorldWidth, 1, UI_INK, a); }
                if (uiAge > 0.9f) {
                    float pulse = 0.5f + 0.5f * sinf((float)gTime * 3.2f);
                    int a = (int)(90 + 165 * pulse), y = (int)(uvzWorldHeight * 0.80f);
                    textSpC("PRESS TO START", uvzWorldWidth / 2, y, 2, UI_WHITE, 4, a);
                    int half = textWSp("PRESS TO START", 2, 4) / 2 + 14;
                    hline(uvzWorldWidth / 2 - half - 70, y + 6, 70, UI_WHITE, a / 2); hline(uvzWorldWidth / 2 + half, y + 6, 70, UI_WHITE, a / 2);
                }
                textSpC("FAN-MADE TRIBUTE. NOT AFFILIATED.", uvzWorldWidth / 2, uvzWorldHeight - (int)uvzSafeBottom - 8, 1, UI_DIM, 2, 160);
                if (cfg.best > 0) { char b[40]; snprintf(b, sizeof b, "BEST %dM", (int)cfg.best); text(b, (int)uvzSafeLeft + 4, (int)uvzSafeTop + 2, 1, UI_DIM); }
                if (uiAge < 0.7f) drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x000000, (int)(255 * (1 - uiAge / 0.7f)));
            } break;
            case MAIN_MENU:
                shadeLeft((int)(uvzWorldWidth * 0.62f), 235);
                drawLogoSmall(easeOut(uiAge / 0.3f));
                drawButtons();
                if (cfg.best > 0) { char b[40]; snprintf(b, sizeof b, "BEST %dM", (int)cfg.best); text(b, (int)uvzSafeLeft + 10, uvzWorldHeight - (int)uvzSafeBottom - 12, 1, UI_DIM); }
                { char cb[32], t[48]; fmtNum(gProg.coins, cb, sizeof cb); snprintf(t, sizeof t, "COINS %s", cb);
                  drawTextWithShadow(t, uvzWorldWidth - (int)uvzSafeRight - 8 - measureTextWidth(t, 1), (int)uvzSafeTop + 10 + 46 + 16, 1, 0xFFE9A0); }
                break;
            case SKILLS: {
                dim(150); sheet(px, pw, "SKILL UPGRADES");
                SkillLay L = skillLay(px, pw);
                float e = easeOut((uiAge - 0.05f) / 0.25f);
                int A = (int)(255 * e);
                { char cb[32], t[48]; fmtNum(gProg.coins, cb, sizeof cb); snprintf(t, sizeof t, "COINS %s", cb);
                  int sc = fitTextScale(t, pw - 40 - 300, 2), tw = measureTextWidth(t, sc), tx = px + pw - 20 - tw;
                  drawDisc(tx - 13, 34, 6, 0xFFE9A0, A); ringDraw(tx - 13, 34, 6, 1, 0xB8862B, A);
                  text(t, tx, 34 - 7 * sc / 2, sc, 0xFFE9A0, A); }
                {
                    int cx = L.wcx, cy = L.wcy, r = L.wr;
                    for (int k = 1; k <= 3; k++) {
                        float rr = r * k / 3.0f; int al = (k == 3 ? 170 : 90) * A / 255;
                        drawLine(cx, cy - rr, cx + rr, cy, UI_WHITE, al); drawLine(cx + rr, cy, cx, cy + rr, UI_WHITE, al);
                        drawLine(cx, cy + rr, cx - rr, cy, UI_WHITE, al); drawLine(cx - rr, cy, cx, cy - rr, UI_WHITE, al);
                    }
                    drawLine(cx, cy - r, cx, cy + r, UI_WHITE, 120 * A / 255); drawLine(cx - r, cy, cx + r, cy, UI_WHITE, 120 * A / 255);
                    drawLine(cx - r / 2.0f, cy - r / 2.0f, cx + r / 2.0f, cy + r / 2.0f, UI_WHITE, 50 * A / 255);
                    drawLine(cx + r / 2.0f, cy - r / 2.0f, cx - r / 2.0f, cy + r / 2.0f, UI_WHITE, 50 * A / 255);
                    const float nx[4] = {0, -0.62f, 0.62f, 0}, ny[4] = {-0.62f, 0, 0, 0.62f};
                    const char* nl[4] = {"J", "R", "S", "Z"};
                    for (int i = 0; i < 4; i++) {
                        int ncx = cx + (int)(nx[i] * r), ncy = cy + (int)(ny[i] * r);
                        int sk = SKILL_ROW[i];
                        float fill = sk >= 0 ? gProg.level[sk] / (float)prog::MAX_LEVEL : 0.0f;
                        drawDisc(ncx, ncy, 10, UI_INK, 235 * A / 255);
                        if (fill > 0) drawDisc(ncx, ncy, 2 + (int)(7 * fill), UI_RED, A);
                        ringDraw(ncx, ncy, 10, 1, sk >= 0 ? UI_WHITE : UI_DIM, (sk >= 0 ? 230 : 120) * A / 255);
                        text(nl[i], ncx - 2, ncy - 3, 1, sk >= 0 ? UI_WHITE : UI_DIM, A);
                    }
                }
                for (int i = 0; i < 4; i++) {
                    float re = easeOut((uiAge - 0.08f - i * 0.05f) / 0.22f);
                    int ra = (int)(255 * re), y = L.rowY[i];
                    int sk = SKILL_ROW[i];
                    hline(L.rx, y + L.rowH, L.rw, UI_WHITE, 28 * ra / 255);
                    int lsc = fitTextScale(SKILL_ROW_NAME[i], L.infoW, 2);
                    text(SKILL_ROW_NAME[i], L.rx, y + 2, lsc, sk >= 0 ? UI_WHITE : UI_DIM, ra);
                    int barY = y + L.rowH - 8, barW = L.infoW;
                    if (sk < 0) {
                        text("COMING SOON", L.rx, y + 22, 1, UI_DIM, ra);
                        hline(L.rx, barY, barW, UI_WHITE, 50 * ra / 255); hline(L.rx, barY + 3, barW, UI_WHITE, 50 * ra / 255);
                        drawFilledRect(L.rx, barY, 1, 4, UI_WHITE, 50 * ra / 255); drawFilledRect(L.rx + barW - 1, barY, 1, 4, UI_WHITE, 50 * ra / 255);
                        continue;
                    }
                    char t[64];
                    snprintf(t, sizeof t, "LV %d/%d  REBIRTH %d/%d", gProg.level[sk], prog::MAX_LEVEL, gProg.rebirth[sk], prog::MAX_REBIRTH);
                    text(t, L.rx, y + 19, 1, UI_WHITE, ra);
                    snprintf(t, sizeof t, "BONUS +%.2fX  REB X%.1f", prog::totalBonus(gProg, sk), prog::rebirthMult(gProg, sk));
                    text(t, L.rx, y + 29, 1, 0xBFD8FF, ra);
                    drawFilledRect(L.rx, barY, barW, 4, UI_WHITE, 40 * ra / 255);
                    drawFilledRect(L.rx, barY, (int)(barW * gProg.level[sk] / (float)prog::MAX_LEVEL), 4, UI_RED, ra);
                }
                drawButtons();
                int fy = uvzWorldHeight - 14 - 38 + 12;
                if (noteT > 0 && gNote[0]) text(gNote, px + 20, fy, 1, UI_RED);
                if (prog::totalMult(gProg, prog::RUN) > PHYS_CAP || prog::totalMult(gProg, prog::SWING) > PHYS_CAP) {
                    const char* cap = "IN-GAME SPEED CAPS AT X8";
                    text(cap, px + pw - 20 - measureTextWidth(cap, 1), fy, 1, UI_DIM);
                }
            } break;
            case SETTINGS: {
                dim(110); sheet(px, pw, "SETTINGS");
                drawButtons();
                const int ap = assistPct();
                const char* m = ap == 0 ? "MANUAL: YOU AIM THE WEB WITH THE STICK"
                              : ap >= 100 ? "FULL AUTO: STICK HIDDEN, THE WEB AIMS ITSELF"
                              : ap < 50 ? "LIGHT ASSIST: THE STICK STILL DECIDES"
                              : ap < 75 ? "BALANCED: STICK AND AUTO AIM SHARE"
                              : "STRONG ASSIST: AUTO AIM LEADS, STICK NUDGES";
                textSpC(m, uvzWorldWidth / 2, 74 + 138 + 46 + 6, 1, UI_DIM, 1);
            } break;
            case CONTROLS: {
                dim(110); sheet(px, pw, "CONTROLS");
                drawButtons();
                int hy = 96 + 3 * 42 + 1;
                if (noteT > 0 && gNote[0]) textSpC(gNote, uvzWorldWidth / 2, hy, 1, UI_RED, 2);
                else textSpC(ctlTab == 0 ? "SELECT A BOX, THEN PRESS A NEW KEY. ESC CANCELS" : "TO MOVE THE BUTTONS USE EDIT LAYOUT", uvzWorldWidth / 2, hy, 1, UI_DIM, 2);
            } break;
            case LAYOUT_EDIT: {
                dim(140);
                int zx = ctl.lefty ? (int)(uvzWorldWidth * 0.45f) : 0, zw = (int)(uvzWorldWidth * 0.55f);
                drawFilledRect(zx, 0, zw, uvzWorldHeight, UI_WHITE, 12);
                int ex = ctl.lefty ? zx : zw;
                for (int y = 0; y < uvzWorldHeight; y += 8) drawFilledRect(ex, y, 1, 4, UI_WHITE, 70);
                textSpC("STEER ZONE", zx + zw / 2, uvzWorldHeight / 2 - 20, 2, UI_WHITE, 4, 80);
                textSpC("DRAG A FINGER HERE TO STEER", zx + zw / 2, uvzWorldHeight / 2 + 2, 1, UI_DIM, 2, 150);
                textSpC("DRAG THE BUTTONS INTO PLACE", uvzWorldWidth / 2, 50, 1, UI_WHITE, 3, 190);
                for (int i = 0; i < 3; i++) {
                    bool pr = false;
                    for (auto& t : tch) if (t.on && t.role == R_DRAG && t.btn == i) pr = true;
                    drawCtlButton(i, pr, true);
                }
                drawButtons();
            } break;
            case HOW_TO_PLAY: {
                dim(110); sheet(px, pw, "HOW TO PLAY");
                int c1 = px + 22, c2 = px + (int)(pw * 0.24f), c3 = px + (int)(pw * 0.60f), y0 = 66;
                textSp("ACTION", c1, y0, 1, UI_DIM, 3); textSp("TOUCH", c2, y0, 1, UI_DIM, 3); textSp("KEYBOARD", c3, y0, 1, UI_DIM, 3);
                hline(c1, y0 + 11, pw - 44, UI_WHITE, 45);
                char k[A_N][16];
                for (int i = 0; i < A_N; i++) keyLabel(ctl.key[i], k[i], sizeof k[i]);
                char steerK[40], pauseK[40];
                snprintf(steerK, sizeof steerK, "%s / %s", k[A_LEFT], k[A_RIGHT]);
                snprintf(pauseK, sizeof pauseK, "%s / ESC", k[A_PAUSE]);
                const char* rows[5][3] = {{"STEER", ctl.lefty ? "DRAG RIGHT SIDE" : "DRAG LEFT SIDE", steerK}, {"JUMP", "JUMP BUTTON", k[A_JUMP]},
                    {"SLIDE", "SLIDE BUTTON", k[A_SLIDE]}, {"SWING", "HOLD SWING", k[A_SWING]}, {"PAUSE", "PAUSE BUTTON", pauseK}};
                for (int i = 0; i < 5; i++) {
                    float e = easeOut((uiAge - 0.1f - i * 0.05f) / 0.22f);
                    int a = (int)(255 * e), y = y0 + 18 + i * 22 + (int)((1 - e) * 8);
                    int s1 = fitTextScale(rows[i][0], c2 - c1 - 8, 2), s2 = fitTextScale(rows[i][1], c3 - c2 - 8, 2), s3 = fitTextScale(rows[i][2], px + pw - 22 - c3, 2);
                    text(rows[i][0], c1, y, s1, UI_WHITE, a);
                    text(rows[i][1], c2, y, s2, 0xC9D1EE, a);
                    text(rows[i][2], c3, y, s3, UI_WHITE, a);
                    hline(c1, y + 17, pw - 44, UI_WHITE, 22 * a / 255);
                }
                static const char* tips[] = {"AIM WITH THE STICK, HOLD SWING IN THE AIR, RELEASE TO FLY.", "LAND FAST OUT OF A SWING FOR A SPEED BOOST. SLIDE TO KEEP IT.", "CHAIN SWINGS FOR BONUS POINTS."};
                for (int i = 0; i < 3; i++) textSpC(tips[i], uvzWorldWidth / 2, y0 + 18 + 5 * 22 + 8 + i * 12, 1, UI_DIM, 1);
                drawButtons();
            } break;
            case CREDITS: {
                dim(110); sheet(px, pw, "CREDITS");
                static const char* ls[] = {"NYC PIXEL RUNNER", "STICKMAN STYLE INSPIRED BY ALAN BECKER", "MENU STYLE INSPIRED BY MARVEL SPIDER-MAN GAMES",
                    "FAN-MADE TRIBUTE. NOT AFFILIATED.", "ALL ART AND AUDIO ARE GENERATED IN CODE", "BUILT WITH C++ AND SDL2"};
                drawLines(ls, 6, uvzWorldWidth / 2, 72, pw - 40);
                drawButtons();
            } break;
            case PAUSED: {
                dim(150); shadeEdges(60, 160);
                int ty = (int)(uvzWorldHeight * 0.10f);
                textSpC("PAUSED", uvzWorldWidth / 2 + 2, ty + 2, 5, UI_RED_D, 6);
                textSpC("PAUSED", uvzWorldWidth / 2, ty, 5, UI_WHITE, 6);
                slantBar(uvzWorldWidth / 2 - 30, ty + 7 * 5 + 8, 60, 3, 3, UI_RED, 255);
                drawButtons();
            } break;
            case GAME_OVER: {
                dim(165); shadeEdges(60, 160);
                int ty = (int)(uvzWorldHeight * 0.10f);
                textSpC("GAME OVER", uvzWorldWidth / 2 + 2, ty + 2, 5, UI_RED_D, 6);
                textSpC("GAME OVER", uvzWorldWidth / 2, ty, 5, UI_WHITE, 6);
                slantBar(uvzWorldWidth / 2 - 30, ty + 7 * 5 + 8, 60, 3, 3, UI_RED, 255);
                char b[64];
                int sy = ty + 7 * 5 + 28;
                snprintf(b, sizeof b, "%d", scoreVal()); drawStatLine("SCORE", b, uvzWorldWidth / 2 - 150, sy, UI_WHITE);
                snprintf(b, sizeof b, "%dM", (int)distM); drawStatLine("DISTANCE", b, uvzWorldWidth / 2, sy, 0xBFD8FF);
                { char cb[32]; fmtNum(runCoins, cb, sizeof cb); drawStatLine("COINS EARNED", cb, uvzWorldWidth / 2 + 168, sy, 0xFFE9A0); }
                snprintf(b, sizeof b, "BEST %dM", (int)cfg.best);
                int by = sy + 42;
                if (newBest) {
                    int bw = textWSp(b, 2, 3) + 90;
                    textSp(b, uvzWorldWidth / 2 - bw / 2, by, 2, 0xFFE9A0, 3);
                    int nx = uvzWorldWidth / 2 - bw / 2 + textWSp(b, 2, 3) + 14;
                    slantBar(nx, by - 3, 62, 19, 5, UI_RED, 255);
                    text("NEW!", nx + 9, by + 1, 2, UI_WHITE);
                } else textSpC(b, uvzWorldWidth / 2, by, 2, 0xBFD8FF, 3);
                if (gCombo.runBestCount > 0) {
                    snprintf(b, sizeof b, "BEST COMBO THIS RUN  %d HITS  x%.1f", gCombo.runBestCount, gCombo.runBestMult);
                    textSpC(b, uvzWorldWidth / 2, by + 26, 1, COMBO_COL[combo::tierFor(gCombo.runBestMult)], 1);
                }
                if (gCombo.best.count > 0) {
                    snprintf(b, sizeof b, "RECORD COMBO  %d HITS  x%.1f", gCombo.best.count, gCombo.best.mult);
                    textSpC(b, uvzWorldWidth / 2, by + 38, 1, UI_DIM, 1);
                }
                drawButtons();
            } break;
            default: break;
        }
        if (flashT > 0) { float f = clampValue(flashT / 0.5f, 0, 1); drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, UI_WHITE, (int)(230 * f * f)); }
        if (fadeIn > 0) drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x000000, (int)(255 * clampValue(fadeIn / 0.5f, 0, 1)));
        if (trans > 0.7f) drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x000000, (int)(255 * clampValue((trans - 0.7f) / 0.3f, 0, 1)));
    }
    SDL_SetRenderTarget(uvzRenderer, nullptr);
    SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255);
    SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight};
    SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
    SDL_RenderPresent(uvzRenderer);
}

static void updateGame(double dt) {
    pollHeld();
    Player& p = P;
    const bool full = fullAssist();
    const float fdt = (float)dt;
    updateTraffic(fdt);
    if (full) { aimX = aimY = 0; aimHoldT = 0; aimDown = false; }
    else if (aimDown) aimHoldT = AIM_HOLD;
    else if (aimHoldT > 0) aimHoldT -= fdt;
    else if (aimX != 0 || aimY != 0) {
        const float k = expf(-14.0f * fdt);
        aimX *= k; aimY *= k;
        if (hypotf(aimX, aimY) < 0.02f) aimX = aimY = 0;
    }
    badTick(fdt); autoCool -= fdt; hintT -= fdt; nextT -= fdt;
    gAirT = (p.onGround || !p.alive) ? 0.0f : gAirT + fdt;
    const bool autoHold = full && p.alive && !p.wallCling && !p.onGround;
    const bool webHold = swingHeld || autoHold;
    const bool canShoot = !p.wallCling && p.alive && !p.onGround && !p.swinging && !p.webFlying;
    const bool pressed = swingHeld && !swingWas;
    const bool autoFire = full && autoCool <= 0 && gAirT > 0.08f;
    if (canShoot && (pressed || autoFire)) {
        float fx = 0, fy = 0;
        if (findAnchor(fx, fy)) {
            tgtX = fx; tgtY = fy;
            sfx(0);
            p.shootT = 0.14f; p.shootStyle = wrng.range(0, 1);
            if (full) { attachWeb(tgtX, tgtY); autoCool = 0.12f; }
            else {
            p.webFlying = true;
            p.webStartX = p.webX = p.x;
            p.webStartY = p.webY = p.y - 10;
            p.webT = 0;
            { const float sm = swingMult(); p.webDur = clampValue(hypotf(tgtX - p.webStartX, tgtY - p.webStartY) / (1900.0f * sm), 0.12f / sm, 0.65f); }
            }
        } else if (!full) {
            sfx(0);
            p.shootT = 0.14f; p.shootStyle = wrng.range(0, 1);
            float dx, dy; bool st; currentAim(dx, dy, st);
            for (int i = 0; i < 3; i++) spawnPart(p.x + dx * 80, p.y - 10 + dy * 80, dx * 40 + (wrng.f() - 0.5f) * 60, dy * 40 + (wrng.f() - 0.5f) * 60, 0.3f, 0xBFD8FF, 1);
        } else autoCool = 0.12f;
    }
    swingWas = swingHeld;
    haveTarget = false;
    if (p.alive && !p.onGround && !p.swinging && !p.webFlying) {
        if (hintT <= 0) { hintFound = findAnchor(hintX, hintY); hintT = 0.05f; }
        haveTarget = hintFound;
        if (haveTarget) { tgtX = hintX; tgtY = hintY; }
    } else hintT = 0;

    if (p.webFlying) {
        p.webT += fdt;
        const float progress = clampValue(p.webT / p.webDur, 0, 1);

        p.webStartX = p.x; p.webStartY = p.y - 10;
        p.webX = lerpValue(p.webStartX, tgtX, progress);
        p.webY = lerpValue(p.webStartY, tgtY, progress);

        if (!webHold || p.onGround || !p.alive) {
            p.webFlying = false;
        } else if (full && p.x > tgtX - 15.0f && progress < 1.0f) {
            markBad(tgtX, tgtY, 3.0f);
            p.webFlying = false; autoCool = 0;
        } else if (progress >= 1.0f && p.y - 10 < tgtY + 20.0f) {

            markBad(tgtX, tgtY, 1.5f);
            p.webFlying = false; autoCool = 0.1f;
        } else if (webBlocked(p.x, p.y - 10, tgtX, tgtY)) {
            markBad(tgtX, tgtY, 1.5f);
            p.webFlying = false; autoCool = 0.1f;
        } else if (progress >= 1.0f) {
            p.webFlying = false;
            attachWeb(tgtX, tgtY);
        }
    }
    if (p.swinging) p.swingT += fdt;
    if (p.swinging && !webHold) releaseWeb(false);
    if (full && p.swinging && p.alive) {
        if (nextT <= 0) {
            AssistQuery q = makeQuery();
            q.hasEx = true; q.exX = p.ax; q.exY = p.ay;
            float nx, ny; nextOk = pickAnchor(q, nx, ny); nextT = 0.06f;
        }
        const float dxp = p.x - p.ax;
        if (nextOk && autoLetGo(dxp, p.rope, p.swingT, p.vx, p.vy)) { releaseWeb(true); autoCool = 0.08f; nextOk = false; }
        else if (p.swingT > 2.4f) { releaseWeb(false); autoCool = 0.05f; nextOk = false; }
    }

    if (slideEdge && p.swinging && p.alive) { slideEdge = false; zipEdge = true; }
    if (zipEdge) {
        zipEdge = false;
        float zx, zy;
        if (zipCanStart() && findZipTarget(zx, zy)) beginZip(zx, zy);
    }
    gSlideHoldT = slideHeld ? gSlideHoldT + fdt : 0.0f;
    const bool diveWant = (diveHeld || gSlideHoldT > 0.22f) && p.alive && !p.onGround && !p.swinging && !p.wallCling &&
                          !p.zipping && !p.trickType && p.diveCool <= 0 && gAirT > 0.12f;
    if (diveWant && !p.diving) { p.diving = true; p.diveT = 0; }
    else if (!diveWant && p.diving) p.diving = false;
    static double acc = 0;
    acc += dt;
    int guard = 0;
    const int sub = (int)clampValue(ceilf(std::max(fabsf(p.vx), fabsf(p.vy)) / 1100.0f), 1.0f, 4.0f);
    const double h = 1.0 / (120.0 * sub);
    while (acc >= h && guard++ < 12 * sub) { stepPhysics((float)h); acc -= h; }
    if (guard >= 12 * sub) acc = 0;
    p.landT -= (float)dt; p.shootT -= (float)dt; p.attachT -= (float)dt; p.releaseT -= (float)dt; p.flipT -= (float)dt;
    if (p.alive && p.onGround) gRunPhase += (float)dt * 1.44f * clampValue(p.vx / 230.0f, 0.6f, 2.2f);
    chainShowT -= (float)dt; shakeT -= (float)dt;
    gPerfectShowT -= (float)dt; p.perfectT -= (float)dt;
    gTrickHeat = std::max(0.0f, gTrickHeat - (float)dt * 0.35f); gTrickMsgT -= (float)dt;
    camPunch *= expf(-5.0f * (float)dt);
    gFlow = std::max(0.0f, gFlow - (float)dt * (p.onGround ? 0.25f : 0.04f) * (gCombo.count > 0 && !gCombo.draining ? 0.5f : 1.0f));
    senseTick(fdt);
    if (p.alive) { combo::update(gCombo, (float)dt, p.onGround); nearMissTick(); }
    else combo::update(gCombo, (float)dt, true);
    saveComboBest();
    for (auto& t : gTrail) if (t.t > 0) t.t -= (float)dt;
    if (p.alive) {
        const float spd = hypotf(p.vx, p.vy);
        gTrailTick -= (float)dt;
        if (!p.onGround && spd > 650.0f && gTrailTick <= 0) {
            gTrailTick = cfg.reduced ? 0.05f : 0.025f;
            const u32 c = p.perfectT > 0 ? 0xFFE9A0 : (gCombo.tier >= 2 ? COMBO_COL[gCombo.tier] : (spd > 1000.0f ? 0xFFFFFF : 0x7FE0FF));
            gTrail[gTrailHead] = {p.x, p.y + 2, 0.32f, 0.32f, c};
            gTrailHead = (gTrailHead + 1) % 16;
        }
        distM = std::max(distM, (p.x - startX) / 16.0f);
        int earned = prog::coinsForDistance(distM, coinMilestones);
        if (earned > 0) { gProg.coins += earned; runCoins += earned; sfx(3); saveProg(); }
        if (p.vx > 420) speedBonus += (float)dt * 20.0f;
        if (p.slideT > 0 && p.onGround && ((int)(gTime * 40)) % 2 == 0)
            spawnPart(p.x - 10, p.y + 26, -60 - wrng.f() * 60, -20 - wrng.f() * 40, 0.3f, 0xB0B6D0);
        if (p.swinging || p.vx > 350) {
            if (((int)(gTime * 30)) % 3 == 0) spawnPart(p.x - 6, p.y - 8, -30, 10, 0.25f, 0x7FA8FF, 1);
        }
    } else {
        p.deadT += (float)dt;
        if (p.deadT > 1.1f && gState == PLAYING) {
            if (distM > cfg.best) { cfg.best = distM; newBest = true; }
            saveCfg();
            gState = GAME_OVER;
        }
    }
    for (auto& q : parts) if (q.alive) {
        q.life -= (float)dt; if (q.life <= 0) { q.alive = false; continue; }
        q.x += q.vx * (float)dt; q.y += q.vy * (float)dt; q.vy += 300 * (float)dt;
    }
    const float fast = p.wallCling ? 0.0f : clampValue((hypotf(p.vx, p.vy) - 600.0f) / 900.0f, 0.0f, 1.0f);
    float tx = p.x - uvzWorldWidth * 0.30f + clampValue(p.vx * 0.12f, -20, 100) + 14.0f * fast + 25.0f * camPunch;
    float ty = p.y - uvzWorldHeight * 0.58f + clampValue(p.vy * 0.05f, -30, 40) * fast;

    static float camSwing = 0, camWall = 0;
    camSwing += ((p.swinging ? 1.0f : 0.0f) - camSwing) * (1 - expf(-6.0f * (float)dt));
    camWall += ((p.wallCling ? 1.0f : 0.0f) - camWall) * (1 - expf(-6.0f * (float)dt));
    ty = lerpValue(ty, lerpValue(p.y, p.ay, 0.3f) - uvzWorldHeight * 0.55f, camSwing);
    ty = lerpValue(ty, p.y - uvzWorldHeight * 0.52f, camWall);
    if (p.diving) ty += clampValue(p.vy * 0.06f, 0.0f, 60.0f);
    if (!p.onGround && !p.swinging && !p.wallCling && p.vy > 350.0f) ty += clampValue((p.vy - 350.0f) * 0.07f, 0.0f, 45.0f);
    tx += clampValue((hypotf(p.vx, p.vy) - 700.0f) * 0.05f, 0.0f, 40.0f);
    if (p.zipping) tx += 30.0f;
    if (p.alive || p.deadT < 0.6f) {
        camX += (tx - camX) * (1 - expf(-(6.0f + 2.0f * fast) * (float)dt));
        camY += (ty - camY) * (1 - expf(-4.0f * (float)dt));
    }
    ensureWorld();
    aWind = clampValue((hypotf(p.vx, p.vy) - 250.0f) / 900.0f, 0, 1) * (p.onGround ? 0.4f : 1.0f) * (p.alive ? 1.0f : 0.0f);
}

int main(int, char**) {
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
    SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
    SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "1");
    SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");
    SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }
    loadCfg();
    loadControls();
    Uint32 flags = SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
#ifdef __ANDROID__
    flags |= SDL_WINDOW_FULLSCREEN;
#endif
    uvzWindow = SDL_CreateWindow("NYC Pixel Runner", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 600, flags);
    uvzRenderer = uvzWindow ? SDL_CreateRenderer(uvzWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC) : nullptr;
    if (!uvzRenderer) {
        fprintf(stderr, "Could not create window/renderer: %s\n", SDL_GetError());
        return 1;
    }
    SDL_SetRenderDrawBlendMode(uvzRenderer, SDL_BLENDMODE_BLEND);
#ifndef __ANDROID__
    if (cfg.full) SDL_SetWindowFullscreen(uvzWindow, SDL_WINDOW_FULLSCREEN_DESKTOP);
#endif
    initFont();
    recalculateDisplayLayout();
    buildArt();
    initAudio();
    startRun();
    gState = TITLE; aMode = 1; menuT = 0;

    bool running = true;
    Uint64 last = SDL_GetPerformanceCounter();
    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_QUIT: running = false; break;
                case SDL_WINDOWEVENT:
                    if (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED || e.window.event == SDL_WINDOWEVENT_RESIZED) { recalculateDisplayLayout(); releaseAll(); }
                    if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST) { releaseAll(); if (gState == PLAYING) gState = PAUSED; }
                    break;
                case SDL_APP_WILLENTERBACKGROUND:
                    releaseAll(); if (gState == PLAYING) gState = PAUSED; saveCfg();
                    if (gAud) SDL_PauseAudioDevice(gAud, 1);
                    break;
                case SDL_APP_DIDENTERFOREGROUND:
                    if (gAud && audioStarted) SDL_PauseAudioDevice(gAud, 0);
                    break;
                case SDL_FINGERDOWN: fingerDown(e.tfinger); break;
                case SDL_FINGERMOTION: fingerMove(e.tfinger); break;
                case SDL_FINGERUP: fingerUp(e.tfinger); break;
                case SDL_KEYDOWN: {
                    SDL_Scancode sc = e.key.keysym.scancode;
                    startAudio();
                    if (gState == TITLE) { if (!e.key.repeat) enterMenu(); break; }
                    if (gRebind >= 0) {
                        if (e.key.repeat) break;
                        if (sc == SDL_SCANCODE_ESCAPE) { gRebind = -1; sfx(4); }
                        else { assignKey(gRebind, sc); gRebind = -1; }
                        break;
                    }
                    if (sc == SDL_SCANCODE_AC_BACK || sc == SDL_SCANCODE_ESCAPE) {
                        if (e.key.repeat) break;
                        if (gState == PLAYING) gState = PAUSED;
                        else if (gState == PAUSED) gState = PLAYING;
                        else if (isSub(gState)) activate(B_BACK);
                        break;
                    }
                    if (gState == PLAYING) {
                        if (e.key.repeat) break;
                        if (sc == ctl.key[A_JUMP]) jumpEdge = true;
                        if (sc == ctl.key[A_SLIDE]) slideEdge = true;
                        if (sc == SDL_SCANCODE_Z) zipEdge = true;
                        if (sc == ctl.key[A_PAUSE]) { gState = PAUSED; sfx(4); }
                    } else if (gState == PAUSED && sc == ctl.key[A_PAUSE]) gState = PLAYING;
                    else menuKey(sc);
                } break;
                case SDL_KEYUP:
                    if (gState == PLAYING && e.key.keysym.scancode == ctl.key[A_JUMP]) jumpRel = true;
                    break;
                case SDL_MOUSEMOTION: mouseHover(e.motion.x, e.motion.y); break;
                default: break;
            }
        }
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = (double)(now - last) / (double)SDL_GetPerformanceFrequency();
        last = now;
        dt = std::min(dt, 0.05);
        gTime += dt;
        if (fadeIn > 0) fadeIn -= (float)dt;
        if (!portrait) {
            if (gState == PLAYING) updateGame(dt);
            else if (gState == GAME_OVER) {
                for (auto& q : parts) if (q.alive) { q.life -= (float)dt; if (q.life <= 0) q.alive = false; }
            }
            if (gState == MAIN_MENU && trans >= 0) {
                trans += (float)dt;
                if (trans >= 1.0f) { trans = -1; startRun(); fadeIn = 0.5f; }
            }
        }
        render(dt);
    }
    saveCfg();
    SDL_Quit();
    return 0;
}
