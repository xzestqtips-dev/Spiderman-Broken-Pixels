#pragma once
// Endless difficulty progression: pure logic, no SDL. Distance (metres) -> tier + smooth ramp + per-system knobs.
#include <algorithm>
#include <cmath>

namespace diff {

enum Tier { BEGINNER, INTERMEDIATE, ADVANCED, EXPERT, MASTER, TIER_COUNT };
static const float TIER_START_M[TIER_COUNT] = {0.0f, 400.0f, 1000.0f, 2000.0f, 3500.0f};
static const char* const TIER_NAME[TIER_COUNT] = {"BEGINNER", "INTERMEDIATE", "ADVANCED", "EXPERT", "MASTER"};

inline int tierFor(float m) {
    int t = 0;
    for (int i = 1; i < TIER_COUNT; i++) if (m >= TIER_START_M[i]) t = i;
    return t;
}
// Fraction of the way through the current tier (1.0 forever inside MASTER).
inline float tierProgress(float m) {
    const int t = tierFor(m);
    if (t >= TIER_COUNT - 1) return 1.0f;
    return std::min(1.0f, std::max(0.0f, (m - TIER_START_M[t]) / (TIER_START_M[t + 1] - TIER_START_M[t])));
}

// Continuous difficulty: 0 at the start, 1.0 at the start of MASTER, then it keeps creeping up (+0.05 per km) to 1.25 so the game stays endless
// but never becomes unfair. Piecewise linear, so there are no jumps when a tier changes.
inline float ramp(float m) {
    static const float M[6] = {0.0f, 400.0f, 1000.0f, 2000.0f, 3500.0f, 8500.0f};
    static const float D[6] = {0.0f, 0.15f, 0.40f, 0.70f, 1.00f, 1.25f};
    if (!(m > 0.0f)) return 0.0f;
    for (int i = 1; i < 6; i++) if (m < M[i]) return D[i - 1] + (D[i] - D[i - 1]) * (m - M[i - 1]) / (M[i] - M[i - 1]);
    return D[5];
}
inline float cityRamp(float m) { return std::min(1.0f, ramp(m)); }   // building generator tuning stops at 1.0 (keeps every gap swingable)

// ---- Traffic ----
inline float trafficSpacingScale(float m) { return 1.0f - 0.40f * std::min(1.0f, ramp(m)); }      // multiplies the gap between vehicles: 1.0 -> 0.6
inline float trafficSpeedScale(float m)   { return 1.0f + 0.30f * ramp(m); }   // 1.0 -> 1.375 at the ramp's end
// Vehicle types: 0 taxi, 1 car, 2 bus, 3 truck, 4 motorcycle. Heavier / faster types unlock with the tier.
inline int trafficTypeCount(int tier) { return tier <= 0 ? 2 : (tier == 1 ? 3 : (tier == 2 ? 4 : 5)); }
inline int pickTrafficType(int tier, float r01) {
    const int n = trafficTypeCount(tier);
    return std::min(n - 1, (int)(std::min(0.9999f, std::max(0.0f, r01)) * n));
}

// ---- Street obstacles (crates the runner vaults or jumps) ----
inline float runSpeedBase(float m) { return 230.0f + 230.0f * ramp(m); }   // px/s before upgrades
inline bool  crateEnabled(float m) { return m >= 120.0f; }
inline int   crateVariants(int tier) { return std::min(4, 1 + tier); }     // 0 small crate, 1 wide crate, 2 tall crate, 3 double crate
inline float crateMaxHeight(int tier) { return 24.0f + 4.0f * std::min(tier, 3); }   // always below what a normal jump (~110 px apex) clears
// Distance between two obstacles. Always more than one full jump (airtime ~0.8 s) plus a landing margin, so no combination is impossible.
inline float crateMinGap(float m) { return runSpeedBase(m) * 1.0f + 140.0f; }
inline float crateGap(float m, float r01) {
    const float lo = std::max(crateMinGap(m), 900.0f - 480.0f * std::min(1.0f, ramp(m)));
    return lo + r01 * 260.0f;
}

}
