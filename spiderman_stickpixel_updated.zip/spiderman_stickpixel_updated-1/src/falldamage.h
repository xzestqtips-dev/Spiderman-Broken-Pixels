#pragma once
// Fall damage when landing on the street (pure logic). Impact is the downward speed (px/s) at touchdown.
// Safe: nothing. Hard: you survive but stumble (speed loss, combo broken). Fatal: the run ends.
// A roll (SLIDE pressed just before touchdown, or finishing an air trick) absorbs part of the impact.
namespace fall {
static const float SAFE_VY = 760.0f;       // ~2 storeys of free fall
static const float FATAL_VY = 1150.0f;     // ~5 storeys of free fall
static const float ROLL_MIN_VY = 480.0f;   // below this a normal landing is already soft
static const float ROLL_RELIEF = 0.82f;    // a roll scales the effective impact by this
enum Result { NONE = 0, HARD = 1, FATAL = 2 };
// tolerance >= 1 scales the thresholds (stronger legs from the Jump Height upgrade, so jumping higher never means landing harder).
inline float effective(float vy, bool rolled, float tolerance = 1.0f) { return (rolled ? vy * ROLL_RELIEF : vy) / (tolerance < 1.0f ? 1.0f : tolerance); }
inline Result classify(float vy, bool rolled, float tolerance = 1.0f) {
    const float e = effective(vy, rolled, tolerance);
    return e >= FATAL_VY ? FATAL : (e >= SAFE_VY ? HARD : NONE);
}
inline bool canRoll(float vy, bool slideBuffered, bool trickJustDone) { return vy >= ROLL_MIN_VY && (slideBuffered || trickJustDone); }
}
