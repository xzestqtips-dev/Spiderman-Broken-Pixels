#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    initFont(); window = nullptr;
    const int sizes[][2] = {{1280,720},{1920,1080},{2400,1080},{2340,1080},{1600,720},{2560,1600},{1024,768},{800,600},{854,480},{3200,1440},{2960,1440},{1280,600},{4000,1080},{1080,2400}};
    for (auto& z : sizes) {
        uvzOutputWidth = z[0]; uvzOutputHeight = z[1]; portrait = uvzOutputHeight > uvzOutputWidth;
        const int minD = std::min(uvzOutputWidth, uvzOutputHeight); pixelScale = std::max(1, (int)lroundf(minD / 360.0f));
        uvzScaleX = uvzScaleY = (float)pixelScale; uvzWorldWidth = (uvzOutputWidth + pixelScale - 1) / pixelScale; uvzWorldHeight = (uvzOutputHeight + pixelScale - 1) / pixelScale;
        displayWidth = uvzWorldWidth * pixelScale; displayHeight = uvzWorldHeight * pixelScale; offsetX = (uvzOutputWidth - displayWidth) / 2; offsetY = (uvzOutputHeight - displayHeight) / 2;
        CHECK(uvzScaleX == uvzScaleY && pixelScale == (int)pixelScale && pixelScale >= 1);
        CHECK(offsetX <= 0 && offsetY <= 0 && displayWidth >= uvzOutputWidth && displayHeight >= uvzOutputHeight);
        CHECK(displayWidth - uvzOutputWidth < pixelScale && displayHeight - uvzOutputHeight < pixelScale);
        if (!portrait) CHECK(uvzWorldHeight >= 240 && uvzWorldHeight <= 480);
        float x, y; toInternal(0.5f, 0.5f, x, y); CHECK(fabsf(x - uvzWorldWidth / 2.0f) < 0.6f && fabsf(y - uvzWorldHeight / 2.0f) < 0.6f);
    }
    printf("[fit_screen] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
