// Headless playability bot for the fixed (no-assist, no-stick) web picker.
// g++ -std=c++17 -O1 -w -Itests/stub_gfx -DMAIN_SRC='"../src/main.cpp"' tests/bot_swing.cpp -o /tmp/bot && /tmp/bot [seconds] [seeds]
#define main game_main
#include MAIN_SRC
#undef main
int main(int argc, char** argv) {
    const int seconds = argc > 1 ? atoi(argv[1]) : 40, N = argc > 2 ? atoi(argv[2]) : 20;
    if (system("rm -rf /tmp/pcity_bot && mkdir -p /tmp/pcity_bot")) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_bot/", 1);
    g_outW = 1280; g_outH = 720; g_screen.assign((size_t)g_outW * g_outH, 0);
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();
    int alive = 0; double sumDist = 0, sw = 0, tot = 0, walls = 0;
    for (unsigned seed = 1; seed <= (unsigned)N; seed++) {
        gProg = prog::Data();
        startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
        P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - uvzWorldWidth * 0.30f;
        ensureWorld(); gState = PLAYING; swingWas = false; gTime = 0;
        double s = 0, t = 0, w = 0; float relT = 0;
        for (int i = 0; i < 60 * seconds; i++) {
            gTime += 1.0 / 60;
            bool want = false;
            if (P.alive) {
                if (P.onGround) { float edge = 1e9f; for (auto& b : bld) if (P.x >= b.x && P.x <= b.x + b.w) edge = b.x + b.w - P.x; 
                    for (auto& c : trafficCars) { const float d = c.x - c.width * 0.5f - P.x; if (d > 0 && d < 150) jumpEdge = true; } }
                else {
                    want = (P.swinging || P.webFlying) ? true : ((i / 4) % 2 == 0);   // keep tapping until a web catches
                    if (P.swinging) { const float rope = std::max(P.rope, 1.0f); if (P.x - P.ax > 0.55f * rope && P.vy < 0) relT = 0.22f; }
                    if (relT > 0) { relT -= 1.0f / 60; want = false; }
                }
            }
            tch[0] = Touch(); tch[0].on = want; tch[0].role = R_SWING;
            updateGame(1.0 / 60);
            camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); ensureTraffic();
            t++; if (P.swinging) s++; if (P.wallCling) w++;
            if (!P.alive) break;
        }
        if (!P.alive) { for (auto& c : trafficCars) if (fabsf(c.x - P.x) < 150) printf("  car x=%.0f w=%.0f h=%.0f type=%d\n", c.x, c.width, c.height, c.type); for (auto& b : bld) printf("  bld x=%.0f w=%.0f\n", b.x, b.w); }
        if (!P.alive) printf("  died x=%.0f y=%.1f vx=%.0f vy=%.0f onGround=%d swinging=%d\n", P.x, P.y, P.vx, P.vy, (int)P.onGround, (int)P.swinging);
        if (P.alive) alive++; sumDist += distM; sw += s; tot += t; walls += w;
        printf("seed %2u: alive=%d dist=%5.0f m swinging=%2.0f%% wall=%2.0f%%\n", seed, (int)P.alive, distM, 100 * s / t, 100 * w / t);
    }
    printf("SUMMARY: survived %d/%d, avg dist %.0f m, swinging %.0f%%, wall %.0f%%\n", alive, N, sumDist / N, 100 * sw / tot, 100 * walls / tot);
}
