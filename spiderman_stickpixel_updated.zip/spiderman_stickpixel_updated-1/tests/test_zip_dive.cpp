#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void floor_world() {
    bld.clear();
    Building b; b.x = -3000; b.w = 12000; b.roofY = 900; b.style = 0; b.seed = 1;
    bld.push_back(b);
}
static void air(float x, float y, float vx, float vy) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = false; zipEdge = false; gFlow = 0;
}

int main() {
    if (system("rm -rf /tmp/pcity_zd && mkdir -p /tmp/pcity_zd") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_zd/", 1);
    loadCfg(); loadControls();
    window = nullptr; renderer = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun();
    gProg = prog::Data();
    const float dt = 1.0f / 120.0f;

    floor_world();
    air(0, 200, 250, 0);
    const float tx = 380, ty = 60;
    CHECK(beginZip(tx, ty));
    CHECK(P.zipping && !P.swinging);
    float maxStep = 0, px = P.x, py = P.y; int n = 0;
    while (P.zipping && n++ < 400) {
        stepPhysics(dt);
        maxStep = std::max(maxStep, hypotf(P.x - px, P.y - py)); px = P.x; py = P.y;
    }
    CHECK(!P.zipping && P.alive);
    CHECK(maxStep < ZIP_TOP * dt * 1.15f);
    CHECK(hypotf(P.x - tx, P.y - 10 - ty) < 90);
    CHECK(n * dt < 1.0f);
    CHECK(hypotf(P.vx, P.vy) > 300 && P.vx > 0);
    CHECK(hypotf(P.vx, P.vy) <= ZIP_EXIT + 200);
    CHECK(P.zipCool > 0.5f);
    CHECK(!beginZip(tx + 100, ty));
    CHECK(P.trickReady);

    air(0, 200, 250, 0);
    CHECK(!beginZip(30, 100));
    CHECK(!beginZip(900, 100));
    CHECK(!beginZip(-300, 100));
    CHECK(!beginZip(300, 400));

    air(0, 200, 300, -50);
    P.swinging = true; P.ax = 60; P.ay = -100; P.rope = hypotf(P.x - P.ax, P.y - P.ay);
    CHECK(beginZip(420, 40));
    CHECK(!P.swinging && P.vx == 300 && P.vy == -50);

    bld.clear();
    { Building b; b.x = -3000; b.w = 3000 + 250; b.roofY = 300; b.style = 0; b.seed = 1; bld.push_back(b); }
    { Building b; b.x = 250; b.w = 600; b.roofY = 100; b.style = 0; b.seed = 2; bld.push_back(b); }
    air(0, 150, 250, 0);
    P.zipCool = 0;
    CHECK(!beginZip(520, 60) || true);
    for (int i = 0; i < 600 && P.alive; i++) stepPhysics(dt);
    CHECK(!P.zipping);

    floor_world();
    air(0, -2000, 300, 0);
    float vyPlain = 0; { for (int i = 0; i < 60; i++) stepPhysics(dt); vyPlain = P.vy; }
    air(0, -2000, 300, 0); P.diving = true;
    for (int i = 0; i < 60; i++) stepPhysics(dt);
    CHECK(P.vy > vyPlain + 200);
    CHECK(P.vx > 270);
    int k = 60;
    while (P.diving && k++ < 400) stepPhysics(dt);
    const float vyDive = P.vy;
    air(0, -4000, 300, 0); for (int i = 0; i < k; i++) stepPhysics(dt);

    CHECK(vyDive > P.vy && vyDive - P.vy <= DIVE_ACC * DIVE_MAX);
    air(0, -4000, 300, 0); P.diving = true; for (int i = 0; i < k; i++) stepPhysics(dt);
    CHECK(!P.diving && P.diveCool > 0);

    air(0, 700, 300, 600); P.diving = true;
    for (int i = 0; i < 120 && P.alive; i++) stepPhysics(dt);
    CHECK(P.alive && P.onGround && !P.diving);

    floor_world();
    float ang = 0;
    air(0, 0, 300, 0);
    CHECK(senseScan(ang) == 0.0f);
    bld.clear();
    { Building b; b.x = -3000; b.w = 3000 + 200; b.roofY = 300; b.style = 0; b.seed = 1; bld.push_back(b); }
    { Building b; b.x = 200; b.w = 600; b.roofY = -400; b.style = 0; b.seed = 2; bld.push_back(b); }
    air(0, 100, 600, 0); swingHeld = false;
    const float near1 = senseScan(ang);
    CHECK(near1 > 0.15f);
    CHECK(fabsf(ang) < 1.2f);
    air(-600, 100, 600, 0);
    CHECK(senseScan(ang) == 0.0f);
    air(150, 100, 600, 0);
    CHECK(senseScan(ang) > near1);
    swingHeld = true; air(0, 100, 600, 0); swingHeld = true;
    CHECK(senseScan(ang) == 0.0f);
    swingHeld = false;

    cfg.swingAssist = 0.37f; saveCfg(); cfg.swingAssist = 0; loadCfg();
    CHECK(assistPct() == 37);

    printf("[zip_dive] %d checks, %d failed\n", checks, fails);
    if (!fails) puts("ALL ZIP/DIVE TESTS PASSED");
    return fails ? 1 : 0;
}
