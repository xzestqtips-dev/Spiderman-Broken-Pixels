// Swing Assist tests: compiles the real src/main.cpp against the stub SDL (tests/stub).
// Run: g++ -std=c++17 -O1 -Itests/stub -o /tmp/tsa tests/test_swing_assist.cpp && /tmp/tsa
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void shot(const char* name) {
    char p[128]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); if (!f) return;
    fprintf(f, "P6\n%d %d\n255\n", g_fbW, g_fbH); fwrite(g_fb.data(), 1, g_fb.size(), f); fclose(f);
}
static void setPct(int p) { cfg.swingAssist = p / 100.0f; }
static void touchDown(float x, float y, SDL_FingerID id) {
    SDL_TouchFingerEvent e{}; e.fingerId = id; e.x = (x * SC + OFFX) / OUTW; e.y = (y * SC + OFFY) / OUTH; fingerDown(e);
}
static void touchUp(float x, float y, SDL_FingerID id) {
    SDL_TouchFingerEvent e{}; e.fingerId = id; e.x = (x * SC + OFFX) / OUTW; e.y = (y * SC + OFFY) / OUTH; fingerUp(e);
}
static void renderPlaying() { gState = PLAYING; trans = -1; render(0.016); render(0.016); }
static std::vector<uint8_t> grab() { return g_fb; }
static int diffInRect(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b, int x0, int y0, int x1, int y1) {
    int n = 0;
    for (int y = std::max(0, y0); y < std::min(g_fbH, y1); y++)
        for (int x = std::max(0, x0); x < std::min(g_fbW, x1); x++) {
            size_t i = ((size_t)y * g_fbW + x) * 3;
            if (a[i] != b[i] || a[i + 1] != b[i + 1] || a[i + 2] != b[i + 2]) n++;
        }
    return n;
}
// ---- synthetic world helpers
static void towerWorld() {
    bld.clear();
    { Building street; street.x = -3000; street.w = 12000; street.roofY = 600; street.style = 0; street.seed = 1; bld.push_back(street); }
    { Building tower; tower.x = 600; tower.w = 600; tower.roofY = -1000; tower.style = 0; tower.seed = 2; bld.push_back(tower); }
}
static void airborne(float x, float y, float vx, float vy) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.onGround = false; P.alive = true;
    badClear(); gLastPickX = gLastPickY = 1e9f; aimX = aimY = 0;
}
static bool pick(int pct, float sx, float sy, float& ox, float& oy) {   // sx,sy = stick deflection (0,0 = idle)
    setPct(pct); aimX = sx; aimY = sy; gLastPickX = gLastPickY = 1e9f;
    return findAnchor(ox, oy);
}

int main() {
    mkdir("/tmp/shots", 0777);
    if (system("rm -rf /tmp/pcity_sa && mkdir -p /tmp/pcity_sa") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_sa/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = MAIN_MENU;

    // ============ 1. every value 0..100 is saved and restored after a restart ============
    int persistBad = 0;
    for (int p = 0; p <= 100; p++) {
        setPct(p); saveCfg();
        cfg = Settings(); loadCfg();
        if (assistPct() != p) persistBad++;
    }
    CHECK(persistBad == 0);
    setPct(37); saveCfg(); cfg = Settings(); loadCfg(); CHECK(assistPct() == 37);

    // ============ 2. settings slider: 1% steps, percentage shown ============
    gState = SETTINGS; buildUI();
    const Btn* sl = nullptr; const Btn* dec = nullptr; const Btn* inc = nullptr;
    for (auto& b : btns) { if (b.id == S_SWING_ASSIST) sl = &b; if (b.id == B_ASSIST_DEC) dec = &b; if (b.id == B_ASSIST_INC) inc = &b; }
    CHECK(sl && dec && inc);
    int sliderBad = 0, textBad = 0;
    for (int p = 0; p <= 100; p++) {
        Btn b = *sl;
        setSlider(b, b.x + b.w * (p / 100.0f));
        if (assistPct() != p) sliderBad++;
        char v[16]; snprintf(v, sizeof v, "%d%%", (int)lroundf(clampf(*b.val, 0, 1) * 100));
        char w[16]; snprintf(w, sizeof w, "%d%%", p);
        if (strcmp(v, w) != 0) textBad++;
    }
    CHECK(sliderBad == 0 && textBad == 0);
    CHECK(sl->w >= 100);                                          // wide enough to drag precisely
    int nudgeBad = 0;
    for (int p = 0; p <= 100; p++) {                              // + / - buttons: exactly one percent
        setPct(p); activate(B_ASSIST_INC); if (assistPct() != std::min(100, p + 1)) nudgeBad++;
        setPct(p); activate(B_ASSIST_DEC); if (assistPct() != std::max(0, p - 1)) nudgeBad++;
    }
    CHECK(nudgeBad == 0);
    { gFocus = (int)(sl - &btns[0]); int keyBad = 0;              // keyboard left/right: exactly one percent
      for (int p = 0; p <= 100; p++) {
          setPct(p); menuKey(SDL_SCANCODE_RIGHT); if (assistPct() != std::min(100, p + 1)) keyBad++;
          setPct(p); menuKey(SDL_SCANCODE_LEFT); if (assistPct() != std::max(0, p - 1)) keyBad++;
      }
      CHECK(keyBad == 0); gFocus = -1; }
    setPct(50); gState = SETTINGS; trans = -1; render(0.016); uiAge = 5; render(0.016); shot("sa_settings_50");
    setPct(100); render(0.016); shot("sa_settings_100");
    setPct(0); render(0.016); shot("sa_settings_0");
    // the touch zone of +/- does not overlap the slider
    CHECK(inc->x >= sl->x + sl->w && dec->x >= sl->x + sl->w);

    // ============ 3. the aim stick: visible at 0..99, hidden only at 100, restored at once ============
    startRun(); gState = PLAYING; releaseAll();
    P.onGround = false; P.y = -150; P.py = P.y;
    float scx, scy, sr; aimPos(scx, scy, sr);
    int visBad = 0, touchBad = 0;
    for (int p = 0; p <= 100; p++) {
        setPct(p);
        const bool vis = aimStickVisible();
        if (vis != (p < 100)) visBad++;
        releaseAll(); touchDown(scx, scy, 1);
        bool gotAim = false; for (auto& t : tch) if (t.on && t.role == R_AIM) gotAim = true;
        if (gotAim != (p < 100)) touchBad++;
        touchUp(scx, scy, 1);
    }
    CHECK(visBad == 0 && touchBad == 0);
    // pixels: stick drawn at 99, gone at 100, back immediately at 99; the other three buttons are identical either way
    setPct(99); renderPlaying(); auto f99 = grab(); shot("sa_hud_99");
    setPct(100); renderPlaying(); auto f100 = grab(); shot("sa_hud_100");
    setPct(0); renderPlaying(); auto f0 = grab(); shot("sa_hud_0");
    setPct(99); renderPlaying(); auto f99b = grab();
    const int R = (int)sr + 3;
    CHECK(diffInRect(f99, f100, (int)scx - R, (int)scy - R, (int)scx + R, (int)scy + R) > 150);   // stick vanishes at 100
    CHECK(diffInRect(f99, f99b, 0, 0, g_fbW, g_fbH) == 0);                                         // and is back when leaving 100 (same picture)
    CHECK(diffInRect(f99, f0, (int)scx - R, (int)scy - R, (int)scx + R, (int)scy + R) < 40);       // 0..99 look alike (stick there)
    for (int i = 0; i < 3; i++) {                                                                   // SWING / JUMP / SLIDE untouched
        float x, y, r; ctlPos(i, x, y, r);
        CHECK(diffInRect(f99, f100, (int)(x - r), (int)(y - r), (int)(x + r) + 1, (int)(y + r) + 1) == 0);
    }
    setPct(100); releaseAll(); touchDown(scx, scy, 2);
    { bool aim = false; for (auto& t : tch) if (t.on && t.role == R_AIM) aim = true; CHECK(!aim); }
    touchUp(scx, scy, 2);
    // stick input moves the aim; jump / swing / steer zone still reachable at 99
    setPct(99); releaseAll();
    touchDown(scx, scy, 3);
    { const float k = 0.5f * sr; for (auto& t : tch) if (t.on && t.id == 3) { t.x = scx; t.y = scy - k; } pollHeld(); CHECK(aimDown && aimY < -0.4f && fabsf(aimX) < 0.05f); }
    touchUp(scx, scy, 3);
    { float jx, jy, jr; ctlPos(1, jx, jy, jr); touchDown(jx, jy, 4); bool j = false; for (auto& t : tch) if (t.on && t.role == R_JUMP) j = true; CHECK(j); touchUp(jx, jy, 4); jumpEdge = false; }
    { float sx2, sy2, sr2; ctlPos(0, sx2, sy2, sr2); touchDown(sx2, sy2, 5); pollHeld(); CHECK(swingHeld); touchUp(sx2, sy2, 5); }
    { touchDown(W * 0.2f, H * 0.5f, 6); bool st = false; for (auto& t : tch) if (t.on && t.role == R_STEER) st = true; CHECK(st); touchUp(W * 0.2f, H * 0.5f, 6); }
    // left-handed layout: the stick mirrors with the buttons
    ctl.lefty = true; { float lx, ly, lr; aimPos(lx, ly, lr); CHECK(lx < W * 0.5f); } ctl.lefty = false;
    // aim holds a moment after the stick is let go, then eases back to the default
    startRun(); gState = PLAYING; setPct(50); aimX = aimY = 0; aimHoldT = 0;
    g_keys[SDL_SCANCODE_UP] = 1; updateGame(0.016); CHECK(aimDown && aimY < -0.99f && aimHoldT > 1.2f);   // arrow key aims straight up
    g_keys[SDL_SCANCODE_UP] = 0;
    for (int i = 0; i < 60; i++) updateGame(0.016);               // ~1 s later: still where it was left
    CHECK(!aimDown && aimY < -0.99f);
    for (int i = 0; i < 80; i++) updateGame(0.016);               // then back to neutral
    CHECK(aimX == 0 && aimY == 0);
    setPct(100); g_keys[SDL_SCANCODE_UP] = 1; aimX = 0.5f; aimY = -0.5f; updateGame(0.016); g_keys[SDL_SCANCODE_UP] = 0;
    CHECK(aimX == 0 && aimY == 0 && !aimDown);                    // 100%: arrow keys / stick state are ignored entirely

    // ============ 4. every percentage changes the assist ============
    int tuneBad = 0;
    for (int p = 0; p < 100; p++) {
        AssistTune a = assistTune(p / 100.0f, false), b = assistTune((p + 1) / 100.0f, false);
        if (!(b.w > a.w && b.tolRad > a.tolRad && b.reach > a.reach && b.maxUp > a.maxUp && b.maxLen > a.maxLen && b.behindMin > a.behindMin)) tuneBad++;
        if (b.tolRad - a.tolRad < 0.3f * PI / 180.0f) tuneBad++;                                      // at least 0.3 degrees wider every step
    }
    CHECK(tuneBad == 0);
    { AssistTune t0 = assistTune(0, false), t50 = assistTune(0.5f, false), t99 = assistTune(0.99f, false);
      CHECK(t0.w == 0 && fabsf(t50.w - 0.5f) < 1e-6f && t99.w > 0.95f);                                // manual / balanced / strong
      CHECK(t0.tolRad < 10 * PI / 180 && t99.tolRad > 75 * PI / 180); }

    // ============ 5. selection behaviour on a synthetic city (surface attachment) ============
    // 0% is manual: the web goes exactly where the stick points, to the first surface along that ray
    {
        towerWorld(); airborne(0, -300, 300, 0); float ox, oy;
        const float ang = atan2f(700.0f, 700.0f);                          // 45 deg up, straight at the tower's face
        CHECK(pick(0, cosf(ang), -sinf(ang), ox, oy) && fabsf(ox - 600) < 1.5f && oy < -325);   // sticks to the face
        CHECK(!pick(0, 1.0f, 0.0f, ox, oy));                                // horizon: the hit is not above you: a miss
        CHECK(!pick(0, 0.17f, -0.985f, ox, oy));                            // nearly straight up: sky, a miss
        CHECK(!pick(0, 0, 0, ox, oy) || true);                              // idle stick = default 35 deg aim (may or may not hit)
        CHECK(pick(100, 0, 0, ox, oy) && ox >= 590);                        // 100%: auto pick, stick state irrelevant
        CHECK(pick(100, 0.17f, -0.985f, ox, oy) && ox >= 590);
        // assist rises gradually: aim 15 deg below the horizon, the cone has to grow before an upward ray is inside it
        int first = -1, backs = 0; bool had = false;
        for (int p = 0; p <= 100; p++) {
            const bool ok = pick(p, cosf(-15.0f * PI / 180), -sinf(-15.0f * PI / 180), ox, oy);
            if (ok && first < 0) first = p;
            if (had && !ok) backs++;
            had = had || ok;
        }
        CHECK(first > 0 && first < 60 && backs == 0);
        printf("aim 15 deg below the horizon starts attaching at %d%%\n", first);
    }
    // never through a building: a far tower is only reachable over the nearer wall's roof, never through it
    {
        bld.clear();
        { Building street; street.x = -3000; street.w = 12000; street.roofY = 600; street.style = 0; street.seed = 1; bld.push_back(street); }
        { Building wall; wall.x = 200; wall.w = 200; wall.roofY = -300; wall.style = 0; wall.seed = 2; bld.push_back(wall); }
        { Building far; far.x = 800; far.w = 600; far.roofY = -1000; far.style = 0; far.seed = 3; bld.push_back(far); }
        int through = 0, picks = 0;
        for (int p : {0, 25, 50, 75, 100}) for (float deg = 20; deg <= 70; deg += 5) {
            airborne(0, -110, 300, 0); float ox, oy;
            if (pick(p, cosf(deg * PI / 180), -sinf(deg * PI / 180), ox, oy)) {
                picks++;                      // a pick past the wall is fine only if the line really clears its roof
                float tw; if (webBlocked(P.x, P.y - 10, ox, oy) || (segBox(P.x, P.y - 10, ox, oy, 200, -300, 400, 3000, &tw) && tw < 0.97f)) through++;
            }
        }
        CHECK(picks > 0 && through == 0);
    }
    // ahead / behind
    {
        bld.clear();
        { Building street; street.x = -3000; street.w = 12000; street.roofY = 600; street.style = 0; street.seed = 1; bld.push_back(street); }
        { Building back; back.x = -900; back.w = 500; back.roofY = -900; back.style = 0; back.seed = 2; bld.push_back(back); }
        airborne(0, -300, 300, 0); float ox, oy;
        CHECK(!pick(100, 0, 0, ox, oy) && !pick(90, 0, 0, ox, oy));       // only a building behind: strong assist does not use it
        CHECK(pick(0, -0.7071f, -0.7071f, ox, oy) && ox < -300);           // manual: you may aim backwards if you want to
    }
    // recently used / failed spots are not picked again; expire; manual ignores the list
    {
        towerWorld(); airborne(0, -300, 300, 0); float ox, oy;
        CHECK(pick(80, 0, 0, ox, oy)); const float firstX = ox, firstY = oy;
        markBad(ox, oy, 2.0f);
        CHECK(!pick(80, 0, 0, ox, oy) || hypotf(ox - firstX, oy - firstY) >= BAD_R);
        const float a0 = atan2f(-firstY - 310.0f, firstX);
        CHECK(pick(0, cosf(a0), -sinf(a0), ox, oy));                        // 0%: no help at all (list ignored)
        for (int i = 0; i < 100; i++) badTick(0.03f);                       // 3 s later
        CHECK(pick(80, 0, 0, ox, oy));
        P.swinging = true; P.ax = 600; P.ay = -650; P.swingT = 0.2f; releaseWeb(false, true);
        for (int i = 0; i < 100; i++) badTick(0.05f);                      // 5 s
        CHECK(isBad(600, -650));
        for (int i = 0; i < 40; i++) badTick(0.05f);
        CHECK(!isBad(600, -650));
        P.swinging = true; P.ax = 620; P.ay = -700; P.swingT = 1.5f; releaseWeb(false, false);
        for (int i = 0; i < 30; i++) badTick(0.05f);                       // 1.5 s
        CHECK(!isBad(620, -700));
    }

    // ============ 6. 100% in a real run: aims, attaches, releases, re-targets, never teleports ============
    {
        int totalAttach = 0, repeats = 0, teleports = 0, nan = 0, chains = 0, seedsWithSwing = 0, stickSeen = 0;
        float bestDist = 0;
        for (unsigned seed = 1; seed <= 10; seed++) {
            gProg = prog::Data(); setPct(100);
            startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
            P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - W * 0.30f; ensureWorld(); gState = PLAYING; swingWas = false;
            bool was = false; float px = P.x, py = P.y, lastAx = 1e9f, lastAy = 1e9f; double lastAt = -10, now = 0; int attaches = 0;
            for (int i = 0; i < 60 * 80; i++) {
                if (P.onGround && P.alive) { float edge = 1e9f; for (auto& b : bld) if (P.x >= b.x && P.x <= b.x + b.w) edge = b.x + b.w - P.x; if (edge < 90) jumpEdge = true; }
                updateGame(1.0 / 60); now += 1.0 / 60;
                if (aimStickVisible()) stickSeen++;
                if (P.swinging && !was) {
                    attaches++;
                    if (hypotf(P.ax - lastAx, P.ay - lastAy) < BAD_R && now - lastAt < 2.5) repeats++;
                    lastAx = P.ax; lastAy = P.ay; lastAt = now;
                }
                was = P.swinging;
                if (!std::isfinite(P.x) || !std::isfinite(P.y) || !std::isfinite(P.vx) || !std::isfinite(P.vy)) nan++;
                if (P.alive && hypotf(P.x - px, P.y - py) > 60) teleports++;
                px = P.x; py = P.y; chains = std::max(chains, P.chain);
                if (!P.alive) break;
            }
            totalAttach += attaches; if (attaches > 0) seedsWithSwing++; bestDist = std::max(bestDist, distM);
        }
        printf("100%% auto: %d attaches over 10 runs, best chain %d, best run %.0f m\n", totalAttach, chains, bestDist);
        CHECK(totalAttach >= 15 && seedsWithSwing >= 8);
        CHECK(repeats == 0 && teleports == 0 && nan == 0 && stickSeen == 0);
        CHECK(chains >= 2);                                               // swings chained without touching the roof
    }
    // 100%: web follows a manual jump-release, the SWING button still climbs walls, JUMP still releases
    {
        setPct(100); startRun(); bld.clear(); wrng = Rng(77); addBuilding(true); ensureWorld(); gState = PLAYING;
        towerWorld();
        P = Player(); P.x = 300; P.y = -250; P.px = P.x; P.py = P.y; P.vx = 300; P.vy = -100; P.onGround = false; startX = 200;
        for (int i = 0; i < 90 && !P.swinging; i++) updateGame(1.0 / 60);
        CHECK(P.swinging && !P.onGround);                                  // attached with no button held
        const float ax0 = P.ax; jumpEdge = true; updateGame(1.0 / 60); for (int i = 0; i < 3; i++) updateGame(1.0 / 60);
        CHECK(!P.swinging && autoCool > 0.3f);                              // JUMP releases and holds the auto web back briefly
        (void)ax0;
    }
    // ============ 7. partial assist in a run: SWING behaves as before ============
    {
        setPct(50); startRun(); bld.clear(); wrng = Rng(5); addBuilding(true); ensureWorld(); gState = PLAYING;
        towerWorld();
        P = Player(); P.x = 0; P.y = -300; P.px = P.x; P.py = P.y; P.vx = 300; P.vy = 0; P.onGround = false; startX = 0;
        swingWas = false; updateGame(1.0 / 60); CHECK(!P.webFlying && !P.swinging);            // no button, no web (not automatic below 100%)
        g_keys[ctl.key[A_SWING]] = 1; updateGame(1.0 / 60); CHECK(P.webFlying);              // pressed: web shot toward an anchor
        for (int i = 0; i < 60 && !P.swinging; i++) updateGame(1.0 / 60);
        CHECK(P.swinging);
        g_keys[ctl.key[A_SWING]] = 0; updateGame(1.0 / 60); CHECK(!P.swinging);               // release flies
    }
    printf("%d checks, %d failed\n", checks, fails);
    if (fails == 0) printf("ALL SWING ASSIST TESTS PASSED\n");
    return fails ? 1 : 0;
}
