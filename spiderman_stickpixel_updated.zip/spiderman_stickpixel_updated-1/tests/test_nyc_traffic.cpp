#define main game_main
#include "../src/main.cpp"
#undef main

static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static TrafficCar carAt(float x, int dir, int type = 1) {
    TrafficCar c;
    c.x = x; c.speed = 0; c.maxSpeed = 200;
    c.width = trafficWidth(type); c.height = trafficHeight(type);
    c.type = type; c.lane = dir > 0 ? 0 : 1; c.dir = dir; c.color = 0xD0B040;
    return c;
}

int main() {
    gTime = 0;
    TrafficSignal light{100.0f, 0.0f};
    CHECK(trafficSignalGreen(light, 1, 0.0));
    CHECK(!trafficSignalGreen(light, -1, 0.0));
    CHECK(!trafficSignalGreen(light, 1, 7.0));
    CHECK(trafficSignalGreen(light, -1, 7.0));
    CHECK(dayPhase(180.0) == dayPhase(0.0));
    CHECK(daylightAmount(63.0) > 0.95f);
    CHECK(dayPalette(0.0).top != dayPalette(63.0).top);

    trafficCars.clear(); trafficSignals.clear(); nextTrafficSpawnX = 0; trafficSerial = 0;
    const int oldWorldWidth = uvzWorldWidth;
    uvzWorldWidth = 2000; camX = 0; P.x = 200;
    ensureTraffic();
    bool vehicleTypeSeen[5] = {false, false, false, false, false};
    bool yellowTaxiSeen = false;
    for (const TrafficCar& car : trafficCars) {
        vehicleTypeSeen[car.type] = true;
        if (car.type == 0 && car.color == 0xE8B72D) yellowTaxiSeen = true;
    }
    CHECK(vehicleTypeSeen[0] && vehicleTypeSeen[1] && vehicleTypeSeen[2] && vehicleTypeSeen[3] && vehicleTypeSeen[4]);
    CHECK(yellowTaxiSeen);
    uvzWorldWidth = oldWorldWidth;

    trafficCars.clear(); trafficSignals.clear();
    trafficSignals.push_back({100.0f, 7.0f}); // Eastbound red at t=0.
    trafficCars.push_back(carAt(0.0f, 1));
    nextTrafficSpawnX = 100000.0f;
    for (int i = 0; i < 600; ++i) updateTraffic(1.0f / 60.0f);
    CHECK(trafficCars.front().x + trafficCars.front().width * 0.5f < trafficSignals.front().x);
    CHECK(trafficCars.front().speed < 3.0f);

    trafficCars.clear(); trafficSignals.clear();
    trafficSignals.push_back({100.0f, 0.0f});
    TrafficCar greenCar = carAt(50.0f, 1);
    trafficCars.push_back(greenCar);
    nextTrafficSpawnX = 100000.0f;
    for (int i = 0; i < 180; ++i) updateTraffic(1.0f / 60.0f);
    CHECK(trafficCars.front().x > 100.0f);

    trafficCars.clear(); trafficSignals.clear();
    TrafficCar leader = carAt(130.0f, 1);
    TrafficCar follower = carAt(0.0f, 1);
    follower.speed = 220.0f;
    trafficCars.push_back(leader);
    trafficCars.push_back(follower);
    nextTrafficSpawnX = 100000.0f;
    for (int i = 0; i < 600; ++i) updateTraffic(1.0f / 60.0f);
    const float spacing = trafficCars[0].x - trafficCars[1].x;
    CHECK(trafficCars[1].x < trafficCars[0].x);
    CHECK(spacing >= (trafficCars[0].width + trafficCars[1].width) * 0.5f + 12.0f);

    bld.clear(); trafficCars.clear();
    P = Player(); P.x = 100.0f; P.px = P.x; P.y = P.py = -26.0f;
    trafficCars.push_back(carAt(100.0f, 1));
    collide();
    CHECK(!P.alive);

    P = Player(); P.x = 100.0f; P.px = P.x; P.y = P.py = -80.0f;
    trafficCars.clear(); trafficCars.push_back(carAt(100.0f, 1));
    collide();
    CHECK(P.alive);

    trafficCars.clear();
    // Falling onto the street is now deadly (it used to be a safe landing)...
    P = Player(); P.y = -10.0f; P.py = -30.0f; P.vy = 120.0f;
    collide();
    CHECK(!P.alive && P.deadGround && fabsf(P.y + 26.0f) < 0.001f);
    // ...but a runner who is already on the street stays safe.
    P = Player(); P.y = -26.0f; P.py = -26.0f; P.vy = 12.0f; P.groundedPrev = true;
    collide();
    CHECK(P.alive && P.onGround);

    bld.clear(); trafficSignals.clear(); wrng = Rng(123); distM = 0;
    addBuilding(true);
    for (int i = 0; i < 40; ++i) addBuilding(false);
    CHECK(trafficSignals.size() == 40);
    CHECK(bld.front().roofY < STREET_GROUND_Y);
    CHECK(trafficSignals.front().x < trafficSignals.back().x);

    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
