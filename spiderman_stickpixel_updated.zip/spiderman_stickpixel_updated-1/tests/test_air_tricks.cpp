#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void world() {
    bld.clear();
    Building a; a.x = -3000; a.w = 4000; a.roofY = 0; a.seed = 1; a.style = 0;
    Building b; b.x = 1100; b.w = 4000; b.roofY = 0; b.seed = 2; b.style = 1;
    bld.push_back(a); bld.push_back(b);
}
static void fresh() { startRun(); world(); gState = PLAYING; gTrickHeat = 0; gTrickMsgT = 0; }
static void air(float x, float y, float vx, float vy) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false; P.trickReady = true;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = false; swingWas = false; badClear(); gFlow = 0;
}
static void run(int n, float dt) { for (int i = 0; i < n && P.alive; i++) stepPhysics(dt); }
static void press() { slideEdge = true; stepPhysics(1.0f / 120.0f); }

int main() {
    if (system("rm -rf /tmp/pcity_at && mkdir -p /tmp/pcity_at") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_at/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = PLAYING;
    gProg = prog::Data();
    cfg.swingAssist = 0.0f;
    const float dt = 1.0f / 120.0f;

    { fresh(); P = Player(); P.x = 100; P.y = -26; P.px = 100; P.py = -26; P.vx = 300; P.onGround = true; P.alive = true; P.trickReady = true;
      slideEdge = true; stepPhysics(dt); CHECK(P.trickType == T_NONE && (P.slideT > 0 || P.slideBuf > 0)); }

    { fresh(); air(300, -500, 500, -300); press();
      CHECK(P.trickType == T_FRONT && P.slideBuf <= 0 && pickFrame() == F_FLIP);
      const float b0 = bonus; const int c0 = gCombo.count; const float f0 = gFlow;
      run(40, dt); CHECK(P.trickType == T_FRONT && bonus == b0 && gCombo.count == c0);
      run(40, dt); CHECK(P.trickType == T_NONE && gCombo.count == c0 + 1 && bonus > b0 && gFlow > f0 && gCombo.lastKindShown == combo::STUNT);
      CHECK(strstr(gStuntName, "FRONT FLIP") != nullptr);
      const float h1 = gTrickHeat; P.y = -900; P.vy = -300; P.onGround = false;
      for (int i = 0; i < 30; i++) { press(); P.y = -900; P.vy = 0; run(2, dt); }
      CHECK(P.trickType == T_NONE && gTrickHeat == h1);
      P.y = -900; P.vy = -300; P.flipT = 0; P.usedAir = false; jumpEdge = true; stepPhysics(dt); P.flipT = 0; P.trickCool = 0; P.vy = -300;
      press(); CHECK(P.trickType != T_NONE); }

    { fresh(); air(300, -500, 500, -300); steer = -1; press(); CHECK(P.trickType == T_BACK && pickFrame() == F_FLIP); }
    { fresh(); air(300, -500, 500, 20); press(); CHECK(P.trickType == T_TWIST && pickFrame() == F_TWIST && P.trickApexQ > 0.7f); }
    { fresh(); air(300, -500, 500, 300); press(); CHECK(P.trickType == T_CART && pickFrame() == F_STAR); }

    { fresh(); air(300, -60, 400, 300); press(); CHECK(P.trickType == T_NONE && P.slideBuf > 0); }
    { fresh(); air(1000, -100, 400, 400); press(); CHECK(P.trickType == T_NONE); }

    { fresh(); air(300, -500, 0, -300); press(); CHECK(P.trickType == T_FRONT);
      const float h0 = gTrickHeat; P.y = -30; P.vy = 400; run(10, dt);
      CHECK(P.onGround && P.trickType == T_NONE && gTrickHeat == h0 && strcmp(gTrickMsg, "SLOPPY") == 0 && P.landT >= 0.3f); }

    { fresh(); bld.clear(); Building a; a.x = -3000; a.w = 3000; a.roofY = 2500; a.seed = 1; Building b; b.x = 560; b.w = 3000; b.roofY = 0; b.seed = 2; bld.push_back(a); bld.push_back(b);
      air(300, -300, 600, -250); press(); CHECK(P.trickType != T_NONE); P.vy = 0; P.y = 200; P.vx = 700; run(60, dt); CHECK(!P.alive && P.trickType == T_NONE); }
    { fresh(); bld[0].obs.push_back({1, 400.0f, 30.0f, 46.0f, true, 0}); air(380, -140, 300, 60); P.vy = -300; P.y = -400;
      press(); P.y = -30; P.vy = 100; P.x = 408; run(30, dt); CHECK(!P.alive); }

    { fresh(); air(300, -900, 450, -300); press(); const float b0 = bonus; run(80, dt); const float slow = bonus - b0;
      fresh(); air(300, -900, 1100, -300); press(); const float c0 = bonus; run(80, dt); const float fast = bonus - c0;
      printf("trick pay: slow %.0f, fast %.0f\n", slow, fast); CHECK(slow > 0 && fast > slow * 1.3f); }

    { fresh(); air(300, -500, 500, -300); press(); trickOnNearMiss(); CHECK(P.trickNear); const float b0 = bonus; run(80, dt); const float withNear = bonus - b0;
      fresh(); air(300, -500, 500, -300); press(); const float c0 = bonus; run(80, dt); const float plain = bonus - c0;
      printf("near-miss trick: %.0f vs %.0f\n", withNear, plain); CHECK(withNear > plain * 1.3f && strstr(gStuntName, "FRONT") != nullptr);
      fresh(); air(300, -500, 500, -300); press(); run(80, dt); CHECK(P.trickDoneT > 0);
      const float d0 = bonus; trickOnNearMiss(); CHECK(bonus > d0 && P.trickDoneT <= 0); const float d1 = bonus; trickOnNearMiss(); CHECK(bonus == d1); }

    { fresh(); bld.clear(); Building a; a.x = -3000; a.w = 4000; a.roofY = 0; a.seed = 1; Building b; b.x = 1000; b.w = 4000; b.roofY = 0; b.seed = 2; bld.push_back(a); bld.push_back(b);
      air(700, -45, 700, -400); gComboNm = -1; gComboNmPrev = -2; bool near = false; int started = 0;
      for (int i = 0; i < 170 && P.alive; i++) { if (i == 3 && tryTrick()) started = 1; stepPhysics(dt); const int c = gCombo.count; nearMissTick(); if (gCombo.count > c) near = true; }
      printf("integrated: started %d near %d\n", started, (int)near); CHECK(started && near && P.alive); }

    { fresh(); air(300, -900, 500, -300); press(); float b0 = bonus; run(80, dt); const float first = bonus - b0;
      P.trickReady = true; P.trickCool = 0; P.vy = -300; P.y = -900; press(); b0 = bonus; gCombo.cd[combo::STUNT] = 0; run(80, dt); const float second = bonus - b0;
      printf("heat: first %.0f second %.0f\n", first, second); CHECK(second < first); }

    { fresh(); air(300, -500, 500, -300); press(); const float b0 = bonus; P.swinging = true; P.ax = 400; P.ay = -800; P.rope = 400; stepPhysics(dt);
      CHECK(P.trickType == T_NONE && bonus == b0); }

    { startRun(); gState = PLAYING; bool bad = false; Rng r(7);
      for (int i = 0; i < 20000 && P.alive; i++) {
          if (r.f() < 0.02f) jumpEdge = true;
          if (r.f() < 0.05f) slideEdge = true;
          swingHeld = r.f() < 0.3f ? !swingHeld : swingHeld; steer = r.f() * 2 - 1;
          stepPhysics(dt); ensureWorld();
          if (!(P.x == P.x) || !(P.y == P.y)) bad = true;
          if (P.trickType && (P.onGround || P.trickT > P.trickDur + 0.05f)) bad = true;
      }
      CHECK(!bad); }

    printf("[air_tricks] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
