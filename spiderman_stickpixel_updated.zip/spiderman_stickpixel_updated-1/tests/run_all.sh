#!/bin/bash
# Build and run every test against the headless SDL stub. Usage: tests/run_all.sh [name-filter]
# Prints PASS / FAIL / COMPILE-ERROR per test (decided by each test's exit code) and exits non-zero if any did not pass.
cd "$(dirname "$0")/.."
mkdir -p /tmp/ttbin
run() { n=$(basename "$1" .cpp)
  if g++ -std=c++17 -O1 -w -Itests/stub "$1" -o /tmp/ttbin/$n 2>/tmp/ttbin/$n.err; then
    out=$(timeout 300 /tmp/ttbin/$n 2>&1); rc=$?
    if [ $rc -eq 0 ]; then st=PASS; else st=FAIL; fi
    echo "$st $n rc=$rc :: $(echo "$out" | grep -c '^FAIL') failed checks :: $(echo "$out" | tail -1 | cut -c1-80)"
  else echo "COMPILE-ERROR $n :: $(grep -m1 error /tmp/ttbin/$n.err | cut -c1-120)"; fi; }
export -f run
res=$(ls tests/test_*.cpp | grep "${1:-.}" | xargs -P 6 -I{} bash -c 'run {}' | sort -k2)
echo "$res"
p=$(echo "$res" | grep -c '^PASS'); t=$(echo "$res" | grep -c .)
echo "---- $p / $t passed"
[ "$p" -eq "$t" ]
