#!/bin/bash
# Build and run every test against the headless SDL stub. Usage: tests/run_all.sh [name-filter]
cd "$(dirname "$0")/.."
mkdir -p /tmp/ttbin
run() { n=$(basename "$1" .cpp)
  if g++ -std=c++17 -O1 -w -Itests/stub "$1" -o /tmp/ttbin/$n 2>/tmp/ttbin/$n.err; then
    out=$(timeout 300 /tmp/ttbin/$n 2>&1); rc=$?
    echo "$n rc=$rc :: $(echo "$out" | grep -ci fail) fail-lines :: $(echo "$out" | tail -1 | cut -c1-90)"
  else echo "$n COMPILE-ERROR :: $(head -2 /tmp/ttbin/$n.err | tr '\n' ' ' | cut -c1-120)"; fi; }
export -f run
ls tests/test_*.cpp | grep "${1:-.}" | xargs -P 6 -I{} bash -c 'run {}' | sort
