#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void airborne(float x, float y, float vx, float vy) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.onGround = false; P.alive = true;
    badClear(); gLastPickX = gLastPickY = 1e9f; gAirT = 1; swingWas = false; swingHeld = false;
}
// pickAnchor() chooses the target itself (no aim stick / Swing Assist any more), so these tests check that the
// automatic pick is always a real, reachable surface that is not behind a wall.
static bool pick(float& ox, float& oy) { gLastPickX = gLastPickY = 1e9f; return findAnchor(ox, oy); }
static bool inBox(float x, float y, float L, float T, float R, float B, float pad) { return x >= L - pad && x <= R + pad && y >= T - pad && y <= B + pad; }
static bool onSurface(float x, float y) {
    for (auto& b : bld) {
        if (inBox(x, y, b.x, b.roofY, b.x + b.w, b.roofY + 3200, 1.5f)) return true;
        for (auto& o : b.obs) {
            const float top = b.roofY - o.h;
            if (o.type <= 3 && inBox(x, y, o.x, top, o.x + o.w, b.roofY, 1.5f)) return true;
            if (o.type == 4 && (inBox(x, y, o.x, top, o.x + 6, b.roofY, 1.5f) || inBox(x, y, o.x - 30, top, o.x + o.w, top + 4, 1.5f))) return true;
            if (o.type == 5 && inBox(x, y, o.x, b.roofY - 114, o.x + o.w, b.roofY - 68, 1.5f)) return true;
        }
        if (b.cable) for (int i = 0; i < 8; i++) {
            const float u0 = i / 8.0f, u1 = (i + 1) / 8.0f;
            const float x0 = lerpValue(b.cx0, b.cx1, u0), y0 = lerpValue(b.cy0, b.cy1, u0) + 88 * u0 * (1 - u0), x1 = lerpValue(b.cx0, b.cx1, u1), y1 = lerpValue(b.cy0, b.cy1, u1) + 88 * u1 * (1 - u1);
            if (inBox(x, y, std::min(x0, x1), std::min(y0, y1), std::max(x0, x1), std::max(y0, y1), 1.5f)) return true;
        }
    }
    return false;
}
static void street() { bld.clear(); Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }

int main() {
    if (system("rm -rf /tmp/pcity_wa && mkdir -p /tmp/pcity_wa") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_wa/", 1);
    loadCfg(); loadControls();
    uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gState = MAIN_MENU;

    auto roof = [&](float x, float w) -> Building& { bld.clear(); Building s; s.x = -3000; s.w = 3000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s);
        Building r; r.x = x; r.w = w; r.roofY = 0; r.style = 0; r.seed = 2; bld.push_back(r); return bld.back(); };
    float ox, oy;

    // each anchor kind alone on a roof: the pick must land on that object
    roof(500, 1200).obs.push_back({4, 600, 110, 240, false, 0});     // water tower
    airborne(0, 100, 300, 0);
    CHECK(pick(ox, oy) && onSurface(ox, oy) && !webBlocked(P.x, P.y - 10, ox, oy));
    roof(500, 1200).obs.push_back({5, 900, 96, 114, false, 1});      // billboard
    airborne(0, 100, 300, 0);
    CHECK(pick(ox, oy) && onSurface(ox, oy) && !webBlocked(P.x, P.y - 10, ox, oy));
    roof(500, 1200).obs.push_back({3, 1200, 3, 400, false, 0});      // mast
    airborne(0, 100, 300, 0);
    CHECK(pick(ox, oy) && onSurface(ox, oy) && !webBlocked(P.x, P.y - 10, ox, oy));

    // a lone mast ahead is found and is the chosen anchor
    bld.clear();
    { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
    { Building r; r.x = 600; r.w = 800; r.roofY = 0; r.style = 0; r.seed = 2; r.obs.push_back({3, 1000, 3, 330, false, 0}); bld.push_back(r); }
    airborne(0, 100, 300, 0);
    CHECK(pick(ox, oy) && fabsf(ox - 1000) < 4);

    // nothing in reach: no pick (the game shows the "missed shot" puff)
    bld.clear(); { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
    airborne(0, 100, 300, 0);
    CHECK(!pick(ox, oy));

    // a wall between the player and a mast: the pick never goes through the wall
    {
        bld.clear();
        { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
        { Building w; w.x = 300; w.w = 300; w.roofY = -100; w.style = 0; w.seed = 2; bld.push_back(w); }
        { Building f; f.x = 900; f.w = 300; f.roofY = -100; f.style = 0; f.seed = 3; f.obs.push_back({3, 1000, 3, 600, false, 0}); bld.push_back(f); }
        int bad = 0, picks = 0;
        for (float y = 100; y <= 300; y += 20) for (float vx : {200.0f, 400.0f, 700.0f}) {
            airborne(0, y, vx, 0);
            if (pick(ox, oy)) {
                picks++;
                float t; bool blockedByWall = segBox(P.x, P.y - 10, ox, oy, 300, -100, 600, 3000, &t) && t < 0.97f;
                if (blockedByWall || webBlocked(P.x, P.y - 10, ox, oy) || !onSurface(ox, oy)) bad++;
            }
        }
        printf("wall test: %d picks, %d through/invalid\n", picks, bad);
        CHECK(picks > 0 && bad == 0);
    }

    // holding SWING while a web is in flight does not attach a new web by itself after a release
    {
        bld.clear();
        { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
        { Building r; r.x = 500; r.w = 3000; r.roofY = 0; r.style = 0; r.seed = 2; r.obs.push_back({3, 900, 3, 500, false, 0}); r.obs.push_back({3, 1300, 3, 500, false, 0}); bld.push_back(r); }
        airborne(150, 60, 300, 0); g_keys[ctl.key[A_SWING]] = 1; swingWas = true;
        P.swinging = true; P.ax = 400; P.ay = -400; P.rope = hypotf(P.x - P.ax, P.y - P.ay);
        releaseWeb(true);
        int webs = 0;
        for (int i = 0; i < 90 && P.alive && !P.onGround; i++) { updateGame(1.0 / 60); if (P.webFlying || P.swinging) webs++; }
        g_keys[ctl.key[A_SWING]] = 0;
        CHECK(webs == 0);
    }

    // pressing SWING in the air shoots a web that reaches a real surface and attaches
    {
        bld.clear();
        { Building s; s.x = -3000; s.w = 3000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
        { Building r; r.x = 500; r.w = 1500; r.roofY = 0; r.style = 0; r.seed = 2; r.obs.push_back({3, 700, 3, 500, false, 0}); bld.push_back(r); }
        airborne(0, 100, 300, 0);
        g_keys[ctl.key[A_SWING]] = 1; swingWas = false; updateGame(1.0 / 60);
        CHECK(P.webFlying || P.swinging);
        for (int i = 0; i < 60 && !P.swinging; i++) updateGame(1.0 / 60);
        CHECK(P.swinging && onSurface(P.ax, P.ay));
        g_keys[ctl.key[A_SWING]] = 0;
    }

    // generated cities: every pick is reachable, unobstructed and at least the minimum rope length
    {
        int bad = 0, picks = 0;
        for (unsigned seed = 1; seed <= 6; seed++) {
            bld.clear(); wrng = Rng(seed * 6007u); addBuilding(true); for (int i = 0; i < 12; i++) addBuilding(false);
            for (int k = 0; k < 6; k++) for (int j = 0; j < 4; j++) {
                const Building& b0 = bld[1 + k];
                airborne(b0.x - 150, b0.roofY - 200 + 40 * k, 300 + 40 * j, -50);
                if (pick(ox, oy)) {
                    picks++;
                    if (webBlocked(P.x, P.y - 10, ox, oy) || !onSurface(ox, oy) || hypotf(ox - P.x, oy - P.y) < 89) bad++;
                }
            }
        }
        printf("city sweep: %d picks, %d invalid\n", picks, bad);
        CHECK(picks > 50 && bad == 0);
    }

    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL WEB ATTACH TESTS PASSED\n");
    return fails ? 1 : 0;
}
