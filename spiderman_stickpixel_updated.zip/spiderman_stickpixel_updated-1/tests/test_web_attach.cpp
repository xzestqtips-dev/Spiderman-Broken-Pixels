// Surface attachment tests: no stored anchors, the web sticks to real things (buildings, masts, cranes, signs, cables)
// along the stick direction; 100 % attaches instantly. Run: g++ -std=c++17 -O1 -Itests/stub -o /tmp/twa tests/test_web_attach.cpp && /tmp/twa
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void setPct(int p) { cfg.swingAssist = p / 100.0f; }
static void airborne(float x, float y, float vx, float vy) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.onGround = false; P.alive = true;
    badClear(); gLastPickX = gLastPickY = 1e9f; aimX = aimY = 0; autoCool = 0; gAirT = 1; swingWas = false; swingHeld = false;
}
static bool pickDeg(int pct, float deg, float& ox, float& oy) {      // stick pointing deg above the horizon, forward
    setPct(pct); aimX = cosf(deg * PI / 180); aimY = -sinf(deg * PI / 180); gLastPickX = gLastPickY = 1e9f;
    return findAnchor(ox, oy);
}
static bool inBox(float x, float y, float L, float T, float R, float B, float pad) { return x >= L - pad && x <= R + pad && y >= T - pad && y <= B + pad; }
// is (x,y) on a real object? (building face, solid block, mast, crane, sign or cable)
static bool onSurface(float x, float y) {
    for (auto& b : bld) {
        if (inBox(x, y, b.x, b.roofY, b.x + b.w, b.roofY + 3200, 1.5f)) return true;
        for (auto& o : b.obs) {
            const float top = b.roofY - o.h;
            if (o.type <= 3 && inBox(x, y, o.x, top, o.x + o.w, b.roofY, 1.5f)) return true;
            if (o.type == 4 && (inBox(x, y, o.x, top, o.x + 6, b.roofY, 1.5f) || inBox(x, y, o.x - 30, top, o.x + o.w, top + 4, 1.5f))) return true;
            if (o.type == 5 && inBox(x, y, o.x, b.roofY - 114, o.x + o.w, b.roofY - 68, 1.5f)) return true;
        }
        if (b.cable) for (int i = 0; i < 8; i++) {
            const float u0 = i / 8.0f, u1 = (i + 1) / 8.0f;
            const float x0 = lerpf(b.cx0, b.cx1, u0), y0 = lerpf(b.cy0, b.cy1, u0) + 88 * u0 * (1 - u0), x1 = lerpf(b.cx0, b.cx1, u1), y1 = lerpf(b.cy0, b.cy1, u1) + 88 * u1 * (1 - u1);
            if (inBox(x, y, std::min(x0, x1), std::min(y0, y1), std::max(x0, x1), std::max(y0, y1), 1.5f)) return true;
        }
    }
    return false;
}
static void street() { bld.clear(); Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
static void addProp(int type, float x, float w, float h, int param = 0) { Building b; b.x = 0; b.w = 0; (void)b; bld.back().obs.push_back({type, x, w, h, false, param}); }

int main() {
    if (system("rm -rf /tmp/pcity_wa && mkdir -p /tmp/pcity_wa") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_wa/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = MAIN_MENU;

    // ===== 1. the joystick attaches to things: crane, sign, mast, building face (one prop per roof, nothing in front of it) =====
    {
        float ox, oy;
        auto roof = [&](float x, float w) -> Building& { bld.clear(); Building s; s.x = -3000; s.w = 3000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s);
            Building r; r.x = x; r.w = w; r.roofY = 0; r.style = 0; r.seed = 2; bld.push_back(r); return bld.back(); };
        // crane: stick at the tower top / jib (top at y=-240): the web lands on the crane
        roof(500, 1200).obs.push_back({4, 600, 110, 240, false, 0});
        airborne(0, 100, 300, 0);
        float ang = atan2f(90.0f + 238.0f, 600.0f) * 180.0f / PI;
        CHECK(pickDeg(0, ang, ox, oy) && onSurface(ox, oy) && ox >= 570 && ox <= 710 && oy < -150);
        // sign
        roof(500, 1200).obs.push_back({5, 900, 96, 114, false, 1});
        airborne(0, 100, 300, 0);
        ang = atan2f(90.0f + 100.0f, 900.0f) * 180.0f / PI;
        CHECK(pickDeg(0, ang, ox, oy) && onSurface(ox, oy) && ox >= 880 && ox <= 996);
        // mast
        roof(500, 1200).obs.push_back({3, 1200, 3, 400, false, 0});
        airborne(0, 100, 300, 0);
        ang = atan2f(90.0f + 300.0f, 1200.0f) * 180.0f / PI;
        CHECK(pickDeg(0, ang, ox, oy) && onSurface(ox, oy) && fabsf(ox - 1200) < 4);
        // building wall: player low in the gap, stick up-forward: the wall face above the player
        roof(500, 1200); airborne(0, 600, 300, 0);
        CHECK(pickDeg(0, 40.0f, ox, oy) && onSurface(ox, oy) && fabsf(ox - 500) < 2 && oy < 590);
    }

    // ===== 2. 0 % is exact, assistance opens the cone gradually =====
    {
        street();
        bld.push_back(Building()); Building& r = bld.back(); r.x = 600; r.w = 800; r.roofY = 0; r.style = 0; r.seed = 2;
        r.obs.push_back({3, 1000, 3, 330, false, 0});             // one thin 330 px mast
        airborne(0, 100, 300, 0);
        float ox, oy;
        const float exact = atan2f(90.0f + 300.0f, 1000.0f) * 180.0f / PI;   // 300 up the mast
        CHECK(pickDeg(0, exact, ox, oy) && fabsf(ox - 1000) < 4);
        const float off = exact + 8.0f;                                       // 8 degrees too high: sails over the mast top
        int first = -1; bool backs = false, had = false;
        for (int p = 0; p <= 40; p++) {                                       // aim still dominates here; at 100 % auto may prefer another surface
            const bool ok = pickDeg(p, off, ox, oy) && fabsf(ox - 1000) < 4;
            if (ok && first < 0) first = p;
            if (had && !ok) backs = true;
            had = had || ok;
        }
        printf("mast 8 deg off-aim attaches from %d%%\n", first);
        CHECK(!(pickDeg(0, off, ox, oy) && fabsf(ox - 1000) < 4));            // 0 %: no help at all
        CHECK(first > 0 && first < 40 && !backs);                             // help grows with the percentage and stays
    }

    // ===== 3. never through a building =====
    {
        bld.clear();
        { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
        { Building w; w.x = 300; w.w = 300; w.roofY = -100; w.style = 0; w.seed = 2; bld.push_back(w); }
        { Building f; f.x = 900; f.w = 300; f.roofY = -100; f.style = 0; f.seed = 3; f.obs.push_back({3, 1000, 3, 600, false, 0}); bld.push_back(f); }
        int bad = 0, picks = 0;
        for (int pct : {0, 25, 50, 75, 100}) for (float deg = 10; deg <= 80; deg += 2) {
            airborne(0, 200, 300, 0); float ox, oy;
            if (pickDeg(pct, deg, ox, oy)) {
                picks++;
                float t; bool blockedByWall = segBox(P.x, P.y - 10, ox, oy, 300, -100, 600, 3000, &t) && t < 0.97f;
                if (blockedByWall || webBlocked(P.x, P.y - 10, ox, oy) || !onSurface(ox, oy)) bad++;
            }
        }
        printf("wall test: %d picks, %d through/invalid\n", picks, bad);
        CHECK(picks > 0 && bad == 0);
        // a building that appears between player and target cancels the web in flight
        setPct(50); airborne(0, 200, 300, 0);
        P.webFlying = true; tgtX = 1000; tgtY = -400; P.webStartX = P.webX = P.x; P.webStartY = P.webY = P.y - 10; P.webT = 0; P.webDur = 0.6f;
        g_keys[ctl.key[A_SWING]] = 1; swingWas = true;
        int flew = 0; for (int i = 0; i < 45; i++) { updateGame(1.0 / 60); if (P.webFlying) flew++; }
        g_keys[ctl.key[A_SWING]] = 0;
        CHECK(!P.swinging && !P.webFlying && flew <= 2);      // cancelled almost at once, never attached
    }

    // ===== 4. 100 %: attaches instantly (no flight), no stick, saved between sessions =====
    {
        for (int pct : {0, 1, 37, 50, 99, 100}) {
            setPct(pct); saveCfg(); cfg.swingAssist = 0.123f; loadCfg();
            CHECK(assistPct() == pct);
            CHECK(aimStickVisible() == (pct < 100));
        }
        setPct(100);
        bld.clear();
        { Building s; s.x = -3000; s.w = 3000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
        { Building r; r.x = 500; r.w = 1500; r.roofY = 0; r.style = 0; r.seed = 2; r.obs.push_back({3, 700, 3, 500, false, 0}); bld.push_back(r); }
        airborne(0, 100, 300, 0); gAirT = 0;
        bool everFlew = false, attached = false; int frames = 0;
        for (int i = 0; i < 60 && !attached; i++) { updateGame(1.0 / 60); frames++; if (P.webFlying) everFlew = true; if (P.swinging) attached = true; }
        printf("100%%: attached after %d frames, flight seen=%d\n", frames, (int)everFlew);
        CHECK(attached && !everFlew && frames <= 12);               // instant: only the short air-time gate
        CHECK(onSurface(P.ax, P.ay));
    }

    // ===== 5. a manual press shoots a web that flies, then attaches; miss fizzles =====
    {
        setPct(30); bld.clear();
        { Building s; s.x = -3000; s.w = 3000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
        { Building r; r.x = 500; r.w = 1500; r.roofY = 0; r.style = 0; r.seed = 2; r.obs.push_back({3, 700, 3, 500, false, 0}); bld.push_back(r); }
        airborne(0, 100, 300, 0);
        const float ang = atan2f(90.0f + 300.0f, 700.0f) * 180.0f / PI;
        setPct(30); aimX = cosf(ang * PI / 180); aimY = -sinf(ang * PI / 180); aimDown = false; aimHoldT = 5;
        g_keys[ctl.key[A_SWING]] = 1; swingWas = false; updateGame(1.0 / 60);
        CHECK(P.webFlying || P.swinging);
        for (int i = 0; i < 60 && !P.swinging; i++) updateGame(1.0 / 60);
        CHECK(P.swinging && onSurface(P.ax, P.ay));
        g_keys[ctl.key[A_SWING]] = 0;
        // sky: nothing to hit
        airborne(0, 100, 300, 0); setPct(0); aimX = 0.05f; aimY = -1.0f; aimDown = false; aimHoldT = 5; g_keys[ctl.key[A_SWING]] = 1; swingWas = false;
        updateGame(1.0 / 60);
        g_keys[ctl.key[A_SWING]] = 0;
        CHECK(!P.webFlying && !P.swinging);
    }

    // ===== 6. no automatic re-attach after a release (except the 100 % behaviour) =====
    {
        for (int pct : {0, 25, 50, 75, 99}) {
            setPct(pct); bld.clear();
            { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); }
            { Building r; r.x = 500; r.w = 3000; r.roofY = 0; r.style = 0; r.seed = 2; r.obs.push_back({3, 900, 3, 500, false, 0}); r.obs.push_back({3, 1300, 3, 500, false, 0}); bld.push_back(r); }
            airborne(150, 60, 300, 0); g_keys[ctl.key[A_SWING]] = 1; swingWas = true;       // finger already down: not a fresh press
            P.swinging = true; P.ax = 400; P.ay = -400; P.rope = hypotf(P.x - P.ax, P.y - P.ay);
            releaseWeb(true);
            int webs = 0;
            for (int i = 0; i < 90 && P.alive && !P.onGround; i++) { updateGame(1.0 / 60); if (P.webFlying || P.swinging) webs++; }
            g_keys[ctl.key[A_SWING]] = 0;
            CHECK(webs == 0);                                     // holding is not enough: a new press is needed
        }
        setPct(100);
        airborne(150, 60, 300, 0); P.swinging = true; P.ax = 400; P.ay = -400; P.rope = hypotf(P.x - P.ax, P.y - P.ay);
        jumpEdge = true; updateGame(1.0 / 60);
        CHECK(!P.swinging && autoCool > 0.3f);                                   // jump-release holds the auto web back
    }

    // ===== 7. real generated city, every level: each pick is on a real thing and unobstructed =====
    {
        int bad = 0, picks = 0;
        for (unsigned seed = 1; seed <= 6; seed++) {
            bld.clear(); wrng = Rng(seed * 6007u); addBuilding(true); for (int i = 0; i < 12; i++) addBuilding(false);
            for (int pct = 0; pct <= 100; pct += 5) for (int k = 0; k < 6; k++) {
                const Building& b0 = bld[1 + k];
                airborne(b0.x - 150, b0.roofY - 200 + 40 * k, 300 + 40 * k, -50);
                float ox, oy;
                for (float deg : {25.0f, 45.0f, 65.0f}) if (pickDeg(pct, deg, ox, oy)) {
                    picks++;
                    if (webBlocked(P.x, P.y - 10, ox, oy) || !onSurface(ox, oy) || hypotf(ox - P.x, oy - P.y) < 89) bad++;
                }
            }
        }
        printf("city sweep: %d picks, %d invalid\n", picks, bad);
        CHECK(picks > 100 && bad == 0);
    }

    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL WEB ATTACH TESTS PASSED\n");
    return fails ? 1 : 0;
}
