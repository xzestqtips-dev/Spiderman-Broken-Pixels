#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    P = Player(); P.alive = true; P.swinging = true; P.ax = 0; P.ay = -300; P.rope = 300; P.vx = 0;
    float prev = -1, maxStep = 0, mn = 9, mx = -9; int distinct = 0;
    for (int x = -240; x <= 240; x += 10) {
        P.x = (float)x; const float t = swingPoseT();
        if (prev >= 0) { maxStep = std::max(maxStep, fabsf(t - prev)); if (fabsf(t - prev) > 1e-4f) distinct++; }
        mn = std::min(mn, t); mx = std::max(mx, t); prev = t;
    }
    printf("pose t over arc: %.2f..%.2f, biggest step per 10 px %.3f, distinct steps %d\n", mn, mx, maxStep, distinct);
    CHECK(maxStep < 0.1f);
    CHECK(distinct >= 40);
    CHECK(mn < 0.2f && mx > 0.8f);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
