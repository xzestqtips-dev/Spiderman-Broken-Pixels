#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void world() {
    bld.clear();
    Building b; b.x = -3000; b.w = 14000; b.roofY = 2500; b.style = 0; b.seed = 1;
    bld.push_back(b);
}
static void startSwing(float x, float y, float vx, float vy, float ax, float ay) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    P.swinging = true; P.ax = ax; P.ay = ay; P.rope = hypotf(x - ax, y - ay);
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true; swingWas = true;
    gFlow = 0; gPerfectStreak = 0; gPerfectShowT = 0; camPunch = 0; bonus = 0; badClear();
}
static void setPct(int p) { cfg.swingAssist = p / 100.0f; }

int main() {
    if (system("rm -rf /tmp/pcity_sf && mkdir -p /tmp/pcity_sf") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_sf/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = PLAYING;
    gProg = prog::Data(); cfg.shake = true; cfg.reduced = false;
    const float dt = 1.0f / 120.0f;
    const float rad = PI / 180.0f;

    {
        auto at = [](float deg, float sp) { return releaseEval(sp * cosf(deg * PI / 180), -sp * sinf(deg * PI / 180)); };
        CHECK(at(40, 900).perfect && at(40, 900).extra > 0.15f);
        CHECK(at(30, 600).perfect && at(52, 600).perfect);
        CHECK(!at(0, 900).perfect && !at(80, 900).perfect && !at(-40, 900).perfect);
        CHECK(!at(40, 250).perfect && at(40, 250).extra == 0);
        CHECK(!releaseEval(-900, -500).perfect);
        float worst = 0;
        for (int d = -60; d <= 90; d += 3) for (int sp = 100; sp <= 2400; sp += 100) { auto r = at((float)d, (float)sp); worst = std::max(worst, r.base + r.extra); }
        printf("biggest possible release boost: +%.0f%%\n", worst * 100);
        CHECK(worst <= 0.34f);
        CHECK(releaseBoostK(100, 0) == 0.0f && releaseBoostK(1200, 0) > 0.13f);
    }

    {
        world(); startSwing(-250, 60, 420, 0, 150, -300);
        for (int i = 0; i < 1200 && P.swinging; i++) {
            stepPhysics(dt); P.swingT += dt;
            if (P.swinging && P.swingT > 0.4f && releaseEval(P.vx, P.vy).perfect) break;
        }
        const float v0 = hypotf(P.vx, P.vy);
        printf("perfect moment found at %.0f px/s, swingT %.2f\n", v0, P.swingT);
        CHECK(P.swinging && releaseEval(P.vx, P.vy).perfect);
        releaseWeb(true);
        CHECK(gPerfectStreak == 1 && gPerfectShowT > 1.0f && P.perfectT > 0.6f && gFlow >= 0.25f);
        CHECK(bonus >= 15.0f && camPunch > 0.99f && shakeT > 0);
        CHECK(P.launchDur > 0.3f && P.launchK > 0.12f);
        int sparks = 0; for (auto& q : parts) if (q.alive && q.c == 0xFFE9A0) sparks++;
        CHECK(sparks >= 5);
        const Player released = P;
        float pv = v0, worstStep = 0;
        for (int i = 0; i < 48; i++) { stepPhysics(dt); const float v = hypotf(P.vx, P.vy); worstStep = std::max(worstStep, fabsf(v - pv)); pv = v; if (!P.alive) break; }
        const float boosted = pv;
        P = released; P.launchK = 0; P.launchT = 0;
        for (int i = 0; i < 48; i++) stepPhysics(dt);
        const float plain = hypotf(P.vx, P.vy);
        printf("release at %.0f px/s: 0.4 s later %.0f px/s boosted vs %.0f plain (+%.0f%%), biggest step %.1f\n", v0, boosted, plain, (boosted / plain - 1) * 100, worstStep);
        CHECK(boosted > plain * 1.10f);
        CHECK(worstStep < 25.0f);
        CHECK(boosted <= swingSpeedCap(swingMult()) + 1.0f);
    }

    {
        world(); startSwing(-200, 100, 120, 0, 150, -300);
        gPerfectStreak = 3;
        for (int i = 0; i < 40; i++) { stepPhysics(dt); P.swingT += dt; }
        releaseWeb(false);
        CHECK(gPerfectStreak == 0 && P.perfectT <= 0);
        world(); startSwing(0, 0, 900 * cosf(40 * rad), -900 * sinf(40 * rad), 0, -300);
        P.swingT = 0.05f; releaseWeb(true);
        CHECK(gPerfectStreak == 0 && P.launchK <= 0.141f);
    }

    {
        world(); startSwing(0, 0, 500, 0, 100, -300); gFlow = 0.8f; gPerfectStreak = 2;
        releaseWeb(false, true);
        CHECK(fabsf(gFlow - 0.4f) < 1e-4f && gPerfectStreak == 0);
    }

    {
        float end[2];
        for (int pass = 0; pass < 2; pass++) {
            world(); startSwing(-180, 60, 200, 0, 0, -260); gFlow = pass == 0 ? 0.0f : 1.0f;
            float peak = 0;
            for (int i = 0; i < 600 && P.swinging; i++) { stepPhysics(dt); gFlow = pass == 0 ? 0.0f : 1.0f; peak = std::max(peak, hypotf(P.vx, P.vy)); if (P.swingT > 2.0f) break; P.swingT += dt; }
            end[pass] = peak;
        }
        printf("peak speed: no flow %.0f, full flow %.0f\n", end[0], end[1]);
        CHECK(end[1] > end[0] + 30.0f);
        CHECK(end[1] <= swingSpeedCap(swingMult()) + 1.0f);
        gFlow = 0;
    }

    {
        world(); P = Player(); P.x = 0; P.y = 0; P.px = 0; P.py = 0; P.alive = true; P.onGround = false; P.vx = 900; P.vy = 0;
        startX = 0; for (auto& t : gTrail) t.t = 0; gTrailTick = 0; gState = PLAYING;
        for (int i = 0; i < 40; i++) { P.vx = 900; P.vy = 0; P.y = 0; updateGame(1.0 / 60); }
        int live = 0; for (auto& t : gTrail) if (t.t > 0) live++;
        printf("trail points alive at speed: %d / 16\n", live);
        CHECK(live >= 6 && live <= 16);
        for (auto& t : gTrail) t.t = 0;
        gTrailTick = 0;
        for (int i = 0; i < 40; i++) { P.vx = 250; P.vy = 0; P.y = 0; updateGame(1.0 / 60); }
        live = 0; for (auto& t : gTrail) if (t.t > 0) live++;
        CHECK(live == 0);
        for (int i = 0; i < 40; i++) { P.vx = 900; P.vy = 0; P.y = 0; updateGame(1.0 / 60); }
        for (int i = 0; i < 40; i++) { P.vx = 250; P.vy = 0; P.y = 0; updateGame(1.0 / 60); }
        live = 0; for (auto& t : gTrail) if (t.t > 0) live++;
        CHECK(live == 0);
    }

    {
        float lead[2];
        for (int pass = 0; pass < 2; pass++) {
            world(); P = Player(); P.x = 0; P.y = 0; P.px = 0; P.py = 0; P.alive = true; P.onGround = false; startX = 0;
            camX = -W * 0.3f; camY = -H * 0.58f; camPunch = 0;
            for (int i = 0; i < 240; i++) { P.vx = pass == 0 ? 250.0f : 1400.0f; P.vy = 0; P.x = 0; P.y = 0; P.px = 0; P.py = 0; updateGame(1.0 / 60); }
            lead[pass] = P.x - camX;
        }
        printf("camera: player sits %.0f px (slow) vs %.0f px (fast) from the left edge\n", lead[0], lead[1]);
        CHECK(lead[1] < lead[0] - 30.0f && lead[1] > 40.0f);
        float prev, worst = 0;
        for (int i = 0; i < 180; i++) { P.vx = 900; P.vy = 0; P.x = 0; P.y = 0; P.px = 0; P.py = 0; updateGame(1.0 / 60); }
        camPunch = 1.0f; prev = camX;
        for (int i = 0; i < 90; i++) { P.vx = 900; P.vy = 0; P.x = 0; P.y = 0; P.px = 0; P.py = 0; updateGame(1.0 / 60); worst = std::max(worst, fabsf(camX - prev)); prev = camX; }
        printf("camera: biggest move per frame %.2f px\n", worst);
        CHECK(worst < 4.0f);
    }

    {
        world(); startSwing(-200, 100, 700, -300, 150, -300); P.swingT = 1.0f;
        gPerfectStreak = 3; gPerfectShowT = 1.0f; gFlow = 0.7f;
        for (auto& t : gTrail) t = {P.x - 20, P.y, 0.3f, 0.32f, 0xFFE9A0};
        camX = P.x - 200; camY = P.y - 150; gState = PLAYING; trans = -1;
        render(0.016); render(0.016);
        int lit = 0; for (size_t i = 0; i < g_fb.size(); i += 3) if (g_fb[i] > 200 && g_fb[i + 1] > 200 && g_fb[i + 2] < 190) lit++;
        CHECK(lit > 0);
        sfx(8); sfx(7); sfx(6);
    }

    {
        for (int pct : {0, 40, 75, 99}) {
            setPct(pct);
            bld.clear();
            Building a; a.x = -3000; a.w = 3000; a.roofY = 600; a.seed = 1; a.style = 0;
            Building t; t.x = 700; t.w = 1500; t.roofY = -400; t.seed = 2; t.style = 1;
            bld.push_back(a); bld.push_back(t);
            startSwing(100, 0, 700, -500, 400, -500); P.swingT = 1.0f; gAirT = 1; autoCool = 0;
            swingHeld = true; swingWas = true;
            releaseWeb(true);
            int webs = 0;
            for (int i = 0; i < 120; i++) { updateGame(1.0 / 60); if (P.webFlying || P.swinging) webs++; if (!P.alive) break; }
            CHECK(webs == 0);
        }
    }

    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL SWING FEEL TESTS PASSED\n");
    return fails ? 1 : 0;
}
