// The run opens on the starting rooftop (the street is deadly); the main menu shows that same scene and PLAY pans the camera to the player.
#define main game_main
#include "../src/main.cpp"
#undef main

static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();

    // 1. A normal run starts on the rooftop, not the street, and is stable there.
    startRun();
    const float roofY = bld.front().roofY - START_ROOF_LIFT;   // standing surface
    CHECK(gState == PLAYING && P.alive && P.onGround);
    CHECK(fabsf(P.y + 26.0f - roofY) < 0.01f && roofY < STREET_GROUND_Y - 300.0f);
    P.vx = 0; steer = -1;
    for (int i = 0; i < 240; i++) stepPhysics(1.0f / 120);
    CHECK(P.alive && P.onGround && fabsf(P.y + 26.0f - roofY) < 0.6f);

    // 2. Running off the roof edge drops you, and the street below is still deadly.
    startRun(); steer = 0; trafficCars.clear(); nextTrafficSpawnX = 1e9f;
    for (int i = 0; i < 120 * 12 && P.alive; i++) stepPhysics(1.0f / 120);
    CHECK(!P.alive && P.deadGround);

    // 3. Menu mode: the same rooftop, idle, no movement, no run state.
    startRun(true); gState = MAIN_MENU; trans = -1; steer = 0;
    CHECK(gMenuIdle && P.vx == 0 && P.onGround && gState == MAIN_MENU);
    CHECK(pickFrame() == F_IDLE);
    const float px = P.x, py = P.y;
    for (int i = 0; i < 120; i++) { updateTraffic(1.0f / 60); }
    CHECK(P.x == px && P.y == py);

    // 4. The menu camera frames the player on the right; the pan ends on the normal gameplay framing.
    float cx0, cy0, cx1, cy1;
    trans = -1; menuCamera(cx0, cy0);
    CHECK(fabsf((P.x - cx0) - uvzWorldWidth * 0.68f) < 0.5f);
    trans = 1.0f; menuCamera(cx1, cy1);
    CHECK(fabsf((P.x - cx1) - uvzWorldWidth * 0.30f) < 0.5f && fabsf((P.y - cy1) - uvzWorldHeight * 0.58f) < 0.5f);
    trans = 0.5f; float cxm, cym; menuCamera(cxm, cym);
    CHECK(cxm > std::min(cx0, cx1) && cxm < std::max(cx0, cx1));
    trans = -1;

    // 5. PLAY: the pan runs for MENU_SEQ_SECS, then the run begins on the spot (no rebuild, no teleport).
    activate(B_PLAY);
    CHECK(trans >= 0);
    for (int i = 0; i < 60 * 5 && gState == MAIN_MENU; i++) { trans += (1.0f / 60) / MENU_SEQ_SECS; if (trans >= 1.0f) { trans = -1; beginRunFromMenu(); } }
    CHECK(gState == PLAYING && P.alive && P.onGround && !gMenuIdle);
    CHECK(P.x == px && fabsf(P.y - py) < 0.01f && P.vx > 0);

    // 6. Every building is a web anchor candidate, the opening one included: from a jump off the roof a web always finds an anchor.
    startRun(); trafficCars.clear(); nextTrafficSpawnX = 1e9f;
    CHECK(!bld.front().obs.empty());
    P.x = 600; P.y = roofY - 200; P.px = P.x; P.py = P.y; P.vx = 250; P.vy = 0; P.onGround = false;
    float ax, ay;
    CHECK(findAnchor(ax, ay));

    printf("[rooftop_start] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
