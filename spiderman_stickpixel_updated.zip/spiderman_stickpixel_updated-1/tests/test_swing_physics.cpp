#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void world() {
    bld.clear();
    Building b; b.x = -3000; b.w = 12000; b.roofY = 900; b.style = 0; b.seed = 1;
    bld.push_back(b);
}
static void startSwing(float x, float y, float vx, float vy, float ax, float ay) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    P.swinging = true; P.ax = ax; P.ay = ay; P.rope = hypotf(x - ax, y - ay);
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true;
}

int main() {
    if (system("rm -rf /tmp/pcity_sp && mkdir -p /tmp/pcity_sp") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_sp/", 1);
    loadCfg(); loadControls();
    window = nullptr; renderer = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun();
    gProg = prog::Data();

    world();
    startSwing(0, 0, 150, 0, 150, -250);
    P.x = -40; P.y = -250 + 250; P.px = P.x; P.py = P.y; P.rope = hypotf(P.x - P.ax, P.y - P.ay);
    const float dt = 1.0f / 120.0f;
    float maxJump = 0, maxStretch = 0, peak = 0, prevV = hypotf(P.vx, P.vy);
    for (int i = 0; i < 720 && P.alive; i++) {
        stepPhysics(dt);
        const float v = hypotf(P.vx, P.vy);
        maxJump = std::max(maxJump, fabsf(v - prevV)); prevV = v; peak = std::max(peak, v);
        if (P.swinging) maxStretch = std::max(maxStretch, hypotf(P.x - P.ax, P.y - P.ay) - P.rope);
        else break;
    }
    printf("swing: peak %.0f px/s, max speed change per step %.1f, max rope stretch %.3f\n", peak, maxJump, maxStretch);
    CHECK(maxJump < 25.0f);
    CHECK(maxStretch < 0.01f);
    CHECK(peak > 300.0f);

    world();
    startSwing(-150, 0, 0, 0, 0, -250);
    float vBottom = 0, vTop = 1e9f;
    for (int i = 0; i < 360 && P.swinging; i++) {
        stepPhysics(dt);
        const float v = hypotf(P.vx, P.vy);
        if (fabsf(P.x - P.ax) < 20) vBottom = std::max(vBottom, v);
        if (P.x - P.ax > 100) vTop = std::min(vTop, v);
    }
    printf("arc: bottom %.0f px/s, far end %.0f px/s\n", vBottom, vTop);
    CHECK(vBottom > vTop + 50.0f);

    float vR, vL;
    for (int pass = 0; pass < 2; pass++) {
        world(); startSwing(-100, 40, 120, 0, 0, -200);
        steer = pass == 0 ? 1.0f : -1.0f;
        for (int i = 0; i < 90 && P.swinging; i++) stepPhysics(dt);
        (pass == 0 ? vR : vL) = P.vx;
    }
    printf("steer: right %.0f vs left %.0f px/s\n", vR, vL);
    CHECK(vR > vL + 20.0f);
    steer = 0;

    CHECK(releaseBoostK(100, 0) == 0.0f);
    CHECK(releaseBoostK(1200, 0) > 0.07f);
    world(); startSwing(0, 100, 900, 0, 0, -100);
    releaseWeb(true);
    const float v0 = hypotf(P.vx, P.vy);
    float worstStep = 0, pv = v0;
    for (int i = 0; i < 40; i++) { P.vy = 0; stepPhysics(dt); const float v = hypotf(P.vx, P.vy); worstStep = std::max(worstStep, fabsf(v - pv)); pv = v; }
    printf("release: %.0f -> %.0f px/s, biggest step %.1f\n", v0, pv, worstStep);
    CHECK(pv > v0 * 1.02f);
    CHECK(worstStep < 15.0f);

    world();
    bld.clear();
    { Building b; b.x = 300; b.w = 400; b.roofY = 100; b.style = 0; b.seed = 2; bld.push_back(b); }
    startSwing(0, 250, 1500, 0, 100, 0);
    int inside = 0;
    for (int i = 0; i < 480 && P.alive; i++) {
        stepPhysics(dt);
        if (P.swinging) CHECK(hypotf(P.vx, P.vy) <= swingSpeedCap(swingMult()) + 1.0f);
        const Building& b = bld[0];
        if (P.alive && P.x + 8 > b.x + 6 && P.x - 8 < b.x + b.w - 6 && P.y + 26 > b.roofY + 20 && P.y - 24 < b.roofY + 3000) inside++;
    }
    printf("wall test: frames inside building %d, alive %d\n", inside, (int)P.alive);
    CHECK(inside == 0);

    world();
    startSwing(0, 0, 450, 0, 0, -200);
    float x = 0; int attaches = 1;
    float ax = 0;
    for (int i = 0; i < 4000 && P.alive && P.x < 7000; i++) {
        stepPhysics(dt);
        if (P.swinging && P.x - P.ax > 80 && P.swingT > 0.2f) releaseWeb(true);
        if (P.swinging) P.swingT += dt;
        if (!P.swinging && P.vy > 100 && P.y > -20) {
            ax = P.x + 150; attachWeb(ax, P.y - 220); attaches++;
        }
        x = P.x;
    }
    printf("chain: %d attaches, reached x=%.0f, alive %d, speed %.0f\n", attaches, x, (int)P.alive, hypotf(P.vx, P.vy));
    CHECK(P.alive); CHECK(attaches >= 6); CHECK(x > 1500 && hypotf(P.vx, P.vy) > 150.0f);

    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL SWING PHYSICS TESTS PASSED\n");
    return fails ? 1 : 0;
}
