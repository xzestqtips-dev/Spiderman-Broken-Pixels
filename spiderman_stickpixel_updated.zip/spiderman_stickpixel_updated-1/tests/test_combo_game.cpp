// Flow combo wired into the real game code: score, crash, near miss, save, caps, real runs.
// Run: g++ -std=c++17 -O1 -Itests/stub -o /tmp/tcg tests/test_combo_game.cpp && /tmp/tcg
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main() {
    if (system("rm -rf /tmp/pcity_cb && mkdir -p /tmp/pcity_cb") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_cb/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = PLAYING;
    gProg = prog::Data();

    // 1. a skill goes into the normal score and the flow meter
    {
        startRun(); P.onGround = false; gFlow = 0; const int s0 = scoreVal();
        comboHit(combo::PERFECT, 20.0f);
        CHECK(gCombo.count == 1 && gCombo.mult > 1.0f && scoreVal() > s0 && gFlow > 0);
        const float f1 = bonus; comboHit(combo::TRICK);
        CHECK(bonus > f1 && gCombo.mult > 1.25f);
        CHECK(!std::isnan(bonus));
    }
    // 2. a crash ends the combo at once and the record is saved + reloaded
    {
        startRun(); for (int i = 0; i < 4; i++) { comboHit((combo::Kind)i); gCombo.cd[i] = 0; }
        const int c = gCombo.count; CHECK(c == 4);
        killPlayer();
        CHECK(gCombo.count == 0 && gCombo.mult == 1.0f && gCombo.tier == 0 && gCombo.best.count == c);
        combo::Best b; CHECK(combo::loadFile(comboPath, b) && b.count == c);
        startRun(); CHECK(gCombo.best.count == c && gCombo.count == 0);        // survives a new run
        loadCfg(); CHECK(gCombo.best.count == c);                              // ...and a restart
    }
    // 3. near miss: skim a roof at speed and clear its far edge = scored; flying high = not
    {
        for (int pass = 0; pass < 2; pass++) {
            startRun(); bld.clear();
            Building a; a.x = -3000; a.w = 3500; a.roofY = 0; a.seed = 1; a.style = 0;
            Building b; b.x = 500; b.w = 700; b.roofY = 0; b.seed = 2; b.style = 0;
            Building c; c.x = 1200; c.w = 2000; c.roofY = 0; c.seed = 3; c.style = 0;
            bld.push_back(a); bld.push_back(b); bld.push_back(c);
            P = Player(); P.alive = true; P.onGround = false; P.vx = 700; P.vy = 0;
            const float y = pass == 0 ? -26.0f - 12.0f : -26.0f - 220.0f;
            for (float x = 460; x < 1260; x += 6) { P.x = x; P.y = y; nearMissTick(); }
            if (pass == 0) CHECK(gCombo.count == 1 && gCombo.lastKindShown == combo::NEAR_MISS);
            else CHECK(gCombo.count == 0);
        }
        // landing on the roof is not a near miss
        startRun(); P = Player(); P.alive = true; P.vx = 700;
        for (float x = 460; x < 700; x += 6) { P.x = x; P.y = -38; P.onGround = false; nearMissTick(); }
        P.onGround = true; nearMissTick(); P.onGround = false; P.x = 1250; nearMissTick();
        CHECK(gCombo.count == 0);
    }
    // 4. cap holds and decay works in the real update loop
    {
        startRun();
        for (int i = 0; i < 300; i++) { comboHit((combo::Kind)(i % 5)); for (auto& q : gCombo.cd) q = 0; }
        CHECK(gCombo.mult <= combo::MAX_MULT + 1e-4f && gCombo.tier == 4);
        P.onGround = true; for (int i = 0; i < 60 * 14 && gCombo.count > 0; i++) combo::update(gCombo, 1.0f / 60, true);
        CHECK(gCombo.count == 0 && gCombo.mult == 1.0f);
    }
    // 5. releases in the real swing code: perfect, fast, too slow, too quick
    {
        auto swingNow = [&](float vx, float vy, float swT) {
            P = Player(); P.alive = true; P.onGround = false; P.x = 0; P.y = -300; P.px = P.x; P.py = P.y; P.vx = vx; P.vy = vy;
            P.swinging = true; P.ax = 200; P.ay = -500; P.rope = 280; P.swingT = swT; P.chain = 1;
        };
        startRun(); gProg = prog::Data();
        const float s0 = bonus;
        swingNow(460, -386, 1.0f); releaseWeb(true);                                   // 600 px/s at 40 degrees = perfect
        CHECK(gCombo.count == 1 && gCombo.lastKindShown == combo::PERFECT && bonus > s0);
        for (auto& q : gCombo.cd) q = 0;
        swingNow(fastSwingSpeed() + 60.0f, -30, 1.0f); releaseWeb(true);               // fast but flat = not perfect, still a fast swing
        CHECK(gCombo.count == 2 && gCombo.lastKindShown == combo::FAST && gCombo.mult > 1.5f);
        for (auto& q : gCombo.cd) q = 0;
        const int c2 = gCombo.count;
        swingNow(300, -30, 1.0f); releaseWeb(true);                                    // slow let-go: nothing
        swingNow(460, -386, 0.1f); releaseWeb(true);                                   // instant let-go: not timing
        CHECK(gCombo.count == c2);
        CHECK(fastSwingSpeed() >= 450.0f);
        gProg.level[prog::SWING] = 25; const float hiFast = fastSwingSpeed(); gProg = prog::Data(); CHECK(hiFast > fastSwingSpeed());   // scales with upgrades
        // air trick through the real jump code
        for (auto& q : gCombo.cd) q = 0;
        bld.clear(); Building a; a.x = -3000; a.w = 9000; a.roofY = 0; a.seed = 1; a.style = 0; bld.push_back(a);
        P = Player(); P.alive = true; P.onGround = false; P.x = 100; P.y = -400; P.px = P.x; P.py = P.y; P.vx = 300; P.vy = 100;
        jumpEdge = true; const int c3 = gCombo.count; stepPhysics(1.0f / 120);
        CHECK(gCombo.count == c3 + 1 && gCombo.lastKindShown == combo::TRICK);
        // perfect landing (slide pressed just before touchdown) + a long swing sequence finished
        for (auto& q : gCombo.cd) q = 0;
        P = Player(); P.alive = true; P.onGround = false; P.x = 100; P.y = -26 - 6; P.px = P.x; P.py = P.y; P.vx = 300; P.vy = 200; P.chain = 6; P.slideBuf = 0.15f;
        const int c4 = gCombo.count; const float s4 = bonus;
        for (int i = 0; i < 60 && !P.onGround; i++) stepPhysics(1.0f / 120);
        CHECK(P.onGround && gCombo.count == c4 + 2 && bonus > s4 + 100);               // LAND + LONGCHAIN
        CHECK(gCombo.mult > 2.0f && gCombo.tier >= 1);
        // with no slide and a short chain a landing is only the old flat bonus (no combo)
        for (auto& q : gCombo.cd) q = 0;
        P = Player(); P.alive = true; P.onGround = false; P.x = 100; P.y = -26 - 6; P.px = P.x; P.py = P.y; P.vx = 300; P.vy = 200; P.chain = 1;
        const int c5 = gCombo.count; for (int i = 0; i < 60 && !P.onGround; i++) stepPhysics(1.0f / 120);
        CHECK(P.onGround && gCombo.count == c5);
    }
    // 6. full real runs stay stable: cap holds, score finite, no crashes of the HUD maths
    {
        int bad = 0;
        for (unsigned seed = 1; seed <= 8; seed++) {
            cfg.swingAssist = 1.0f;
            startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
            P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - W * 0.30f; ensureWorld(); gState = PLAYING; swingWas = false;
            for (int i = 0; i < 60 * 60; i++) {
                if (P.onGround && P.alive) { float edge = 1e9f; for (auto& b : bld) if (P.x >= b.x && P.x <= b.x + b.w) edge = b.x + b.w - P.x; if (edge < 90) jumpEdge = true; }
                updateGame(1.0 / 60);
                if (gCombo.mult > combo::MAX_MULT + 1e-4f || gCombo.mult < 1.0f - 1e-4f || !std::isfinite(bonus) || gCombo.tier < 0 || gCombo.tier > 4) bad++;
                if (!P.alive) break;
            }
        }
        CHECK(bad == 0);
    }
    printf("[combo_game] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
