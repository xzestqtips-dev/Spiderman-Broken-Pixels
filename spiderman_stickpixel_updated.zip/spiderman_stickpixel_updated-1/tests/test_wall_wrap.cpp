#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void world() {
    bld.clear();
    Building a; a.x = -3000; a.w = 3000; a.roofY = 2500; a.seed = 1; a.style = 0;
    Building b; b.x = 500; b.w = 3000; b.roofY = 0; b.seed = 2; b.style = 1;
    bld.push_back(a); bld.push_back(b);
}
static void swingAt(float x, float y, float vx, float vy, float ax, float ay) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    P.swinging = true; P.ax = ax; P.ay = ay; P.rope = hypotf(x - ax, y - ay); P.swingT = 1.0f;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true; swingWas = true; badClear(); gFlow = 0;
}

int main() {
    if (system("rm -rf /tmp/pcity_ww && mkdir -p /tmp/pcity_ww") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_ww/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = PLAYING;
    gProg = prog::Data();
    const float dt = 1.0f / 120.0f;

    {
        world(); swingAt(470, 90, 520, -420, 200, -300);
        bool vaulted = false;
        for (int i = 0; i < 20 && !vaulted; i++) { stepPhysics(dt); if (!P.swinging) vaulted = true; }
        CHECK(vaulted && !P.wallCling && P.alive && P.vy < -400);
        for (int i = 0; i < 600 && P.alive && !P.onGround; i++) stepPhysics(dt);
        printf("mantle: landed at x=%.0f y=%.0f alive=%d onGround=%d\n", P.x, P.y, (int)P.alive, (int)P.onGround);
        CHECK(P.alive && P.onGround && P.x > 500 && fabsf(P.y + 26) < 2);
    }

    {
        world(); swingAt(420, 500, 450, -100, 200, 100);
        int guard = 0; while (P.swinging && P.wrapN == 0 && guard++ < 400) stepPhysics(dt);
        printf("wrap: wraps %d, anchor (%.0f, %.0f), swinging %d, cling %d\n", P.wrapN, P.ax, P.ay, (int)P.swinging, (int)P.wallCling);
        CHECK(P.wrapN == 1 && P.swinging && !P.wallCling && P.alive);
        CHECK(fabsf(P.ax - 497) < 1 && fabsf(P.ay + 2) < 1);
        const float rope = P.rope; float worst = 0;
        for (int i = 0; i < 360 && P.alive; i++) {
            stepPhysics(dt);
            if (P.swinging) worst = std::max(worst, hypotf(P.x - P.ax, P.y - P.ay) - rope);
            if (!P.swinging || P.wallCling) break;
        }
        CHECK(worst < 0.5f);
        CHECK(P.alive && std::isfinite(P.x) && std::isfinite(P.y));
    }

    {
        world(); swingAt(420, 500, 450, -100, 200, 100); P.wrapN = 2;
        int guard = 0; while (P.swinging && guard++ < 400) stepPhysics(dt);
        CHECK(P.wallCling && P.wrapN == 2);
    }

    {
        world(); bld[1].roofY = 900;
        swingAt(420, 500, 450, -100, 200, 100);
        int guard = 0; while (P.swinging && P.y < 880 && guard++ < 600) stepPhysics(dt);
        CHECK(P.wrapN == 0);
    }

    {
        world();
        const float pen = simSwing(300, 400, 500, -100, 200, 0, 1.0f);
        printf("look-ahead penalty for a swing into the face: %.0f\n", pen);
        CHECK(pen <= 120.0f);
    }

    {
        int nan = 0, attaches = 0, clings = 0, wraps = 0, vaults = 0; double sum = 0; const int N = 30;
        for (unsigned seed = 1; seed <= (unsigned)N; seed++) {
            gProg = prog::Data(); cfg.swingAssist = 1.0f;
            startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
            P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - W * 0.30f; ensureWorld(); gState = PLAYING; swingWas = false;
            bool was = false, wc = false; int lastWrap = 0;
            for (int i = 0; i < 60 * 80; i++) {
                if (P.onGround && P.alive) { float e = 1e9f; for (auto& b : bld) if (P.x >= b.x && P.x <= b.x + b.w) e = b.x + b.w - P.x; if (e < 90) jumpEdge = true; }
                updateGame(1.0 / 60);
                if (P.swinging && !was) attaches++;
                if (P.swinging && !was) lastWrap = 0;
                if (P.swinging && P.wrapN > lastWrap) { wraps++; lastWrap = P.wrapN; }

                if (P.wallCling && !wc) clings++;
                wc = P.wallCling; was = P.swinging;
                if (!std::isfinite(P.x) || !std::isfinite(P.y) || !std::isfinite(P.vx) || !std::isfinite(P.vy)) nan++;
                if (!P.alive) break;
            }
            sum += distM;
        }
        printf("auto, %d seeds: mean %.0f m, attaches %d, wraps %d, clings %d\n", N, sum / N, attaches, wraps, clings);
        CHECK(nan == 0 && attaches > 100);
        (void)vaults;
    }

    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL WALL WRAP TESTS PASSED\n");
    return fails ? 1 : 0;
}
