// Playability smoke test on the REAL street (y = 0): a simple bot taps SWING in the air, jumps for traffic and
// swings through generated cities. Catches regressions in web picking / swinging / traffic / wall handling that
// the focused unit tests (which use synthetic worlds) can miss. It does not assert that the bot survives,
// only that the simulation stays finite and the web / swing systems actually engage.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main() {
    if (system("rm -rf /tmp/pcity_bs && mkdir -p /tmp/pcity_bs") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_bs/", 1);
    loadCfg(); loadControls();
    uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt();
    int nan = 0, attaches = 0, alive = 0; double sumDist = 0; const int N = 12, SECONDS = 40;
    for (unsigned seed = 1; seed <= (unsigned)N; seed++) {
        gProg = prog::Data();
        startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
        P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - uvzWorldWidth * 0.30f;
        ensureWorld(); gState = PLAYING; swingWas = false; gTime = 0;
        bool was = false; float relT = 0;
        for (int i = 0; i < 60 * SECONDS; i++) {
            gTime += 1.0 / 60;
            bool want = false;
            if (P.alive) {
                if (P.onGround) for (auto& c : trafficCars) { const float d = c.x - c.width * 0.5f - P.x; if (d > 0 && d < 150) jumpEdge = true; }
                else {
                    want = (P.swinging || P.webFlying) ? true : ((i / 4) % 2 == 0);
                    if (P.swinging) { const float rope = std::max(P.rope, 1.0f); if (P.x - P.ax > 0.55f * rope && P.vy < 0) relT = 0.22f; }
                    if (relT > 0) { relT -= 1.0f / 60; want = false; }
                }
            }
            tch[0] = Touch(); tch[0].on = want; tch[0].role = R_SWING;
            updateGame(1.0 / 60);
            camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); ensureTraffic();
            if (P.swinging && !was) attaches++;
            was = P.swinging;
            if (!std::isfinite(P.x) || !std::isfinite(P.y) || !std::isfinite(P.vx) || !std::isfinite(P.vy)) nan++;
            if (!P.alive) break;
        }
        if (P.alive) alive++;
        sumDist += distM;
    }
    printf("bot: %d seeds, survived %d, mean %.0f m, attaches %d, non-finite %d\n", N, alive, sumDist / N, attaches, nan);
    CHECK(nan == 0);
    // Baseline measured on the unmodified game (also what tests/bot_swing.cpp reports): about 2/12 survive, mean ~53 m, 7 attaches.
    // The bot is naive (it jumps over cars and lands on the deadly street), so thresholds are loose floors, not goals.
    CHECK(attaches >= 3);          // the web picker + swing engage across generated cities
    CHECK(sumDist / N > 20.0);     // the run actually progresses
    printf("[bot_smoke] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
