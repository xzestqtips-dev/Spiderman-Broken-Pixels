#define main game_main
#include "../src/main.cpp"
#undef main
int main(int argc, char** argv) {
    const int seconds = argc > 1 ? atoi(argv[1]) : 60;
    if (system("rm -rf /tmp/pcity_sim && mkdir -p /tmp/pcity_sim") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_sim/", 1);
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt();
    int alive = 0, runs = 0; double sumDist = 0, ground = 0, swing = 0, total = 0, sumMinGround = 0;
    const int N = 20;
    for (unsigned seed = 1; seed <= (unsigned)N; seed++) {
        gProg = prog::Data();
        startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
        P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); gState = PLAYING; swingWas = false;
        double g = 0, s = 0, t = 0;
        for (int i = 0; i < 60 * seconds; i++) {
            if (P.onGround && P.alive) { float edge = 1e9f; for (auto& b : bld) if (P.x >= b.x && P.x <= b.x + b.w) edge = b.x + b.w - P.x; if (edge < 90) jumpEdge = true; }
            updateGame(1.0 / 60);
            t++; if (P.onGround) g++; if (P.swinging) s++;
            if (!P.alive) break;
        }
        runs++; if (P.alive) alive++; sumDist += distM; ground += g; swing += s; total += t;
        printf("seed %2u: alive=%d dist=%5.0f m ground=%2.0f%% swinging=%2.0f%%\n", seed, (int)P.alive, distM, 100 * g / t, 100 * s / t);
    }
    printf("SUMMARY: survived %d/%d, avg dist %.0f m, on ground %.0f%%, swinging %.0f%%\n", alive, runs, sumDist / runs, 100 * ground / total, 100 * swing / total);
}
