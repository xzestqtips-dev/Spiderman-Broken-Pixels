#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void shot(const char* name) {
    char p[128]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); if (!f) return;
    fprintf(f, "P6\n%d %d\n255\n", g_fbW, g_fbH); fwrite(g_fb.data(), 1, g_fb.size(), f); fclose(f);
}
static const Btn* findBtn(int id) { for (auto& b : btns) if (b.id == id) return &b; return nullptr; }
static void frame(State s) { gState = s; trans = -1; render(0.016); uiAge = 5; render(0.016); }
static void freshSession() {
    gProg = prog::Data(); cfg = Settings(); loadCfg();
}
static float maxSpeedSwing(float sm_level_run, int swingLevel) {
    gProg = prog::Data(); gProg.level[prog::SWING] = swingLevel; (void)sm_level_run;
    startRun(); P.x = 300; P.y = -250; P.px = P.x; P.py = P.y; P.vx = 250; P.vy = 0; P.onGround = false;
    P.swinging = true; P.ax = 420; P.ay = -620; P.rope = hypotf(P.x - P.ax, P.y - P.ay);
    float peak = 0;
    for (int i = 0; i < 120 * 2 && P.alive && P.swinging; i++) { stepPhysics(1.0f / 120); peak = std::max(peak, hypotf(P.vx, P.vy)); }
    return peak;
}

int main() {
    mkdir("/tmp/shots", 0777);
    if (system("rm -rf /tmp/pcity_t && mkdir -p /tmp/pcity_t") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = MAIN_MENU;
    printf("internal resolution %dx%d scale %d\n", W, H, SC);

    CHECK(gProg.coins == 0 && gProg.level[0] == 0 && gProg.level[1] == 0);
    CHECK(fabsf(runMult() - 1.0f) < 1e-4f && fabsf(swingMult() - 1.0f) < 1e-4f);

    startRun(); gState = PLAYING;
    P.x = startX + 16.0f * 199.0f; updateGame(0.016);
    CHECK(gProg.coins == 0 && runCoins == 0);
    P.alive = true; P.x = startX + 16.0f * 200.5f; updateGame(0.016);
    CHECK(gProg.coins == 15 && runCoins == 15);
    P.alive = true; updateGame(0.016); CHECK(gProg.coins == 15);
    P.alive = true; P.x = startX + 16.0f * 1000.5f; updateGame(0.016);
    CHECK(gProg.coins == 75 && runCoins == 75);
    { prog::Data d; CHECK(prog::loadFile(progPath, d) && d.coins == 75); }

    killPlayer();
    for (int i = 0; i < 200 && gState == PLAYING; i++) updateGame(0.016);
    CHECK(gState == GAME_OVER);
    frame(GAME_OVER); shot("1_gameover");
    CHECK(findBtn(B_SKILLS) != nullptr);
    CHECK(runCoins == 75 && gProg.coins == 75);

    activate(B_SKILLS);
    CHECK(gState == SKILLS && navRoot == GAME_OVER);
    frame(SKILLS); shot("2_skills_gameover_75coins");
    CHECK(findBtn(B_UP_RUN) && findBtn(B_UP_SWING) && findBtn(B_RB_RUN) && findBtn(B_RB_SWING));
    CHECK(findBtn(B_UP_RUN)->style & 16);
    int c0 = (int)gProg.coins;
    activate(B_UP_RUN); CHECK(gProg.level[0] == 0 && gProg.coins == c0 && strstr(gNote, "NOT ENOUGH"));
    activate(B_UP_SWING); CHECK(gProg.level[1] == 0 && gProg.coins == c0);
    activate(B_RB_RUN); CHECK(gProg.rebirth[0] == 0 && gProg.coins == c0);

    gProg.coins = 500; buildUI();
    CHECK(!(findBtn(B_UP_RUN)->style & 16));
    activate(B_UP_RUN); CHECK(gProg.level[0] == 1 && gProg.coins == 0);
    CHECK(fabsf(runMult() - 1.25f) < 1e-4f && fabsf(swingMult() - 1.0f) < 1e-4f);
    buildUI(); CHECK(strcmp(findBtn(B_UP_RUN)->label, "UPGRADE 500") == 0 && (findBtn(B_UP_RUN)->style & 16));
    gProg.coins = 749; activate(B_UP_SWING); CHECK(gProg.level[1] == 0 && gProg.coins == 749);
    gProg.coins = 750; activate(B_UP_SWING); CHECK(gProg.level[1] == 1 && gProg.coins == 0);
    CHECK(fabsf(swingMult() - 1.2f) < 1e-4f);
    { prog::Data d; CHECK(prog::loadFile(progPath, d) && d.level[0] == 1 && d.level[1] == 1 && d.coins == 0); }
    frame(SKILLS); shot("3_skills_after_buy");
    activate(B_BACK); CHECK(gState == GAME_OVER);

    gState = MAIN_MENU; trans = -1; buildUI(); CHECK(findBtn(B_SKILLS) != nullptr);
    frame(MAIN_MENU); shot("4_mainmenu");
    activate(B_SKILLS); CHECK(gState == SKILLS && navRoot == MAIN_MENU);
    gProg.coins = 123456; frame(SKILLS); shot("5_skills_mainmenu");
    activate(B_BACK); CHECK(gState == MAIN_MENU);

    gState = GAME_OVER; activate(B_SKILLS);
    gProg = prog::Data(); gProg.coins = 1000000; gProg.level[0] = 49;
    activate(B_UP_RUN); CHECK(gProg.level[0] == 50);
    long long c1 = gProg.coins; activate(B_UP_RUN); CHECK(gProg.level[0] == 50 && gProg.coins == c1);
    buildUI(); CHECK(strcmp(findBtn(B_UP_RUN)->label, "MAX LEVEL") == 0);
    CHECK(!(findBtn(B_RB_RUN)->style & 16));
    CHECK(findBtn(B_RB_SWING)->style & 16);
    activate(B_RB_SWING); CHECK(gProg.rebirth[1] == 0 && gProg.coins == c1);
    frame(SKILLS); shot("6_skills_run_maxed");
    gProg.coins = 999; activate(B_RB_RUN); CHECK(gProg.rebirth[0] == 0 && gProg.level[0] == 50 && gProg.coins == 999);
    gProg.coins = 1000; activate(B_RB_RUN); CHECK(gProg.rebirth[0] == 1 && gProg.level[0] == 0 && gProg.coins == 0);
    CHECK(fabsf(runMult() - 1.1f) < 1e-4f);
    CHECK(gProg.level[1] == 0 && gProg.rebirth[1] == 0);
    gProg.level[1] = 50; gProg.coins = 5000; activate(B_RB_SWING);
    CHECK(gProg.rebirth[1] == 1 && gProg.level[1] == 0 && gProg.coins == 0 && fabsf(swingMult() - 1.1f) < 1e-4f && gProg.rebirth[0] == 1);
    gProg.rebirth[0] = 49; gProg.level[0] = 50; gProg.coins = 1000; activate(B_RB_RUN);
    CHECK(gProg.rebirth[0] == 50 && gProg.level[0] == 0);
    gProg.level[0] = 50; gProg.coins = 99999; buildUI();
    CHECK(strcmp(findBtn(B_RB_RUN)->label, "MAX REBIRTH") == 0 && (findBtn(B_RB_RUN)->style & 16));
    activate(B_RB_RUN); CHECK(gProg.rebirth[0] == 50 && gProg.coins == 99999 && gProg.level[0] == 50);
    frame(SKILLS); shot("7_skills_max_rebirth");
    gProg.level[0] = 0; gProg.rebirth[0] = 3; gProg.level[1] = 12; gProg.rebirth[1] = 7; gProg.coins = 98765;

    saveCfg();
    freshSession();
    CHECK(gProg.coins == 98765 && gProg.level[0] == 0 && gProg.rebirth[0] == 3 && gProg.level[1] == 12 && gProg.rebirth[1] == 7);
    { FILE* f = fopen(progPath.c_str(), "w"); fputs("garbage!!", f); fclose(f); }
    prog::Data keep = gProg; gProg = prog::Data(); loadCfg();
    CHECK(gProg.coins == 0 && gProg.level[0] == 0);
    gProg = keep; saveProg();

    auto groundSpeed = [&](int runLevel, int runReb) {
        gProg = prog::Data(); gProg.level[0] = runLevel; gProg.rebirth[0] = runReb;
        startRun(); gState = PLAYING; float peak = 0;
        for (int i = 0; i < 150 && P.alive && P.onGround; i++) { updateGame(1.0 / 60); peak = std::max(peak, P.vx); }
        return peak;
    };
    float v0 = groundSpeed(0, 0), v1 = groundSpeed(4, 0), v2 = groundSpeed(4, 5);
    printf("run speed  lv0 %.0f  lv4 %.0f  lv4+5reb %.0f px/s\n", v0, v1, v2);
    CHECK(v0 > 200 && v0 < 260);
    CHECK(v1 > v0 * 1.9f && v1 < v0 * 2.1f);
    CHECK(v2 > v1 * 1.4f);
    float s0 = maxSpeedSwing(0, 0), s1 = maxSpeedSwing(0, 10), s2 = maxSpeedSwing(0, 25);
    printf("swing peak speed  lv0 %.0f  lv10 %.0f  lv25 %.0f px/s\n", s0, s1, s2);
    CHECK(s1 > s0 * 1.3f && s2 > s1 * 1.1f);
    auto webTime = [&](int lv) {
        gProg = prog::Data(); gProg.level[1] = lv; startRun(); gState = PLAYING;
        P.onGround = false; P.y = -80; P.py = P.y; P.x = 260; P.px = P.x; P.vy = -50;
        g_keys[ctl.key[A_SWING]] = 1; swingWas = false; updateGame(1.0 / 120); g_keys[ctl.key[A_SWING]] = 0;
        return P.webFlying ? P.webDur : -1.0f;
    };
    float w0 = webTime(0), w1 = webTime(25);
    printf("web flight time lv0 %.3f  lv25 %.3f s\n", w0, w1);
    CHECK(w0 > 0 && w1 > 0 && w1 < w0);
    gProg = prog::Data(); gProg.level[0] = 50; gProg.rebirth[0] = 50; gProg.level[1] = 50; gProg.rebirth[1] = 50;
    CHECK(runMult() <= PHYS_CAP && swingMult() <= PHYS_CAP);
    startRun(); gState = PLAYING;
    for (int i = 0; i < 60 * 20; i++) { updateGame(1.0 / 60); if (gState != PLAYING) break; if (!P.alive) break; }
    CHECK(std::isfinite(P.x) && std::isfinite(P.y) && std::isfinite(P.vx));
    gProg.coins = 1234567890123LL; frame(GAME_OVER); frame(SKILLS); shot("8_skills_huge_numbers"); frame(PLAYING); shot("9_hud");

    for (State s : {TITLE, MAIN_MENU, SETTINGS, CONTROLS, HOW_TO_PLAY, CREDITS, PAUSED}) { frame(s); }
    shot("10_howto");
    printf("%d checks, %d failed\n", checks, fails);
    return fails != 0;
}
