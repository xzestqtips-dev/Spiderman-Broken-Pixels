// New abilities (jump height, air control, web control): prices, levels, caps, save compatibility, and their effect on the real physics.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void blank() { bld.clear(); trafficCars.clear(); trafficSignals.clear(); gCrates.clear(); nextTrafficSpawnX = 1e9f; nextCrateX = 1e9f; addBuilding(true); P = Player(); P.alive = true; steer = 0; swingHeld = false; jumpEdge = slideEdge = jumpRel = false; gTime = 100; gSafeLandUntil = 0; distM = 0; gFlow = 0; }
static void streetRunner() { P.x = 1400; P.px = 1400; P.y = P.py = -26.0f; P.vx = 230; P.vy = 0; P.onGround = true; P.groundedPrev = true; }
static const Btn* findBtn(int id) { for (auto& b : btns) if (b.id == id) return &b; return nullptr; }
static long long totalCost(int s) { prog::Data d; long long t = 0; while (d.level[s] < prog::maxLevel(s)) { t += prog::upgradeCostAt(d, s); d.level[s]++; } return t; }

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); initFont(); recalculateDisplayLayout(); buildArt();

    // ---- Logic: levels, prices, maximums ----
    CHECK(prog::SKILL_COUNT == 5 && prog::RUN == 0 && prog::SWING == 1);           // original indices are stable
    CHECK(prog::upgradeCostAt(prog::Data(), prog::RUN) == 500 && prog::upgradeCostAt(prog::Data(), prog::SWING) == 750);   // original prices unchanged
    { prog::Data d; d.level[prog::RUN] = 30; CHECK(prog::upgradeCostAt(d, prog::RUN) == 500); }                              // still flat
    for (int s : {(int)prog::JUMP, (int)prog::AIR, (int)prog::WEB}) {
        prog::Data d;
        CHECK(prog::maxLevel(s) >= 20 && prog::maxLevel(s) <= 50 && prog::maxRebirth(s) == 0);
        CHECK(prog::upgradeCostAt(d, s) < 500);                                      // cheap to start
        d.level[5 - s > 0 ? s : s] = 10; CHECK(prog::upgradeCostAt(d, s) > prog::DEF[s].upgradeCost);   // prices rise with level
        const long long t = totalCost(s);
        CHECK(t >= 10000 && t <= 26000);                                              // comparable to maxing Run Speed (25,000)
        prog::Data m; m.coins = 1000000; m.level[s] = prog::maxLevel(s) - 1;
        CHECK(prog::upgrade(m, s) && prog::atMaxLevel(m, s) && !prog::canUpgrade(m, s));
        const long long c = m.coins; CHECK(!prog::upgrade(m, s) && m.coins == c && m.level[s] == prog::maxLevel(s));
        CHECK(!prog::canRebirth(m, s) && !prog::doRebirth(m, s) && m.rebirth[s] == 0);
        prog::Data poor; poor.coins = prog::DEF[s].upgradeCost - 1; CHECK(!prog::upgrade(poor, s) && poor.level[s] == 0);
    }
    { prog::Data d; d.coins = 5000; prog::upgrade(d, prog::JUMP); CHECK(d.level[prog::JUMP] == 1 && d.coins == 5000 - 300 && d.level[prog::RUN] == 0); }

    // ---- Save compatibility ----
    { prog::Data d; d.coins = 12345; d.level[0] = 7; d.level[1] = 8; d.level[2] = 9; d.level[3] = 10; d.level[4] = 11; d.rebirth[0] = 2; d.rebirth[1] = 3;
      prog::Data r; CHECK(prog::parse(prog::serialize(d).c_str(), r));
      CHECK(r.coins == 12345 && r.level[0] == 7 && r.level[1] == 8 && r.level[2] == 9 && r.level[3] == 10 && r.level[4] == 11 && r.rebirth[0] == 2 && r.rebirth[1] == 3);
      CHECK(strncmp(prog::serialize(d).c_str(), "PROG2 ", 6) == 0);
      const std::string path = "/tmp/pcity_t/ab_roundtrip.txt"; prog::Data f; CHECK(prog::saveFile(path, d) && prog::loadFile(path, f) && f.level[4] == 11 && f.coins == 12345); }
    { prog::Data r; r.coins = 5; CHECK(prog::parse("PROG1 75 3 2 1 0\n", r)); CHECK(r.coins == 75 && r.level[0] == 3 && r.level[1] == 2 && r.rebirth[0] == 1 && r.rebirth[1] == 0);
      CHECK(r.level[prog::JUMP] == 0 && r.level[prog::AIR] == 0 && r.level[prog::WEB] == 0); }                       // an old save loads, new skills start at 0
    { FILE* f = fopen("/tmp/pcity_t/old_progress.txt", "w"); fputs("PROG1 600 50 4 3 2\n", f); fclose(f); prog::Data r; CHECK(prog::loadFile("/tmp/pcity_t/old_progress.txt", r) && r.coins == 600 && r.level[0] == 50 && r.level[1] == 4 && r.rebirth[0] == 3 && r.rebirth[1] == 2); }
    { prog::Data r; r.coins = 99; r.level[0] = 4;
      CHECK(!prog::parse("", r) && !prog::parse("garbage", r) && !prog::parse("PROG2 10 1 2", r) && !prog::parse("PROG2", r) && !prog::parse("PROG9 1 2 3", r) && !prog::parse(nullptr, r));
      CHECK(r.coins == 99 && r.level[0] == 4); }                                                                      // bad files never change the data
    { prog::Data r; CHECK(prog::parse("PROG2 -50 999 999 999 999 999 999 999 -5 -5 -5 -5 -5", r));
      CHECK(r.coins == 0 && r.level[0] == 50 && r.level[2] == prog::maxLevel(2) && r.level[3] == prog::maxLevel(3) && r.level[4] == prog::maxLevel(4) && r.rebirth[0] == 50 && r.rebirth[1] == 50 && r.rebirth[2] == 0 && r.rebirth[3] == 0 && r.rebirth[4] == 0);
      CHECK(prog::parse("PROG2 1 0 0 0 0 0 99 99 99 99 99", r) && r.rebirth[0] == 50 && r.rebirth[2] == 0 && r.rebirth[3] == 0); }   // new skills cannot be rebirthed via a doctored file
    { gProg = prog::Data(); gProg.level[prog::JUMP] = 5; gProg.level[prog::WEB] = 3; gProg.coins = 77; saveProg(); prog::Data d; gProg = prog::Data(); loadCfg(); CHECK(gProg.level[prog::JUMP] == 5 && gProg.level[prog::WEB] == 3 && gProg.coins == 77); }

    // ---- Multipliers and caps ----
    gProg = prog::Data(); CHECK(jumpMult() == 1.0f && airMult() == 1.0f && webMult() == 1.0f);
    gProg.level[prog::JUMP] = prog::maxLevel(prog::JUMP); gProg.level[prog::AIR] = prog::maxLevel(prog::AIR); gProg.level[prog::WEB] = prog::maxLevel(prog::WEB);
    CHECK(jumpMult() > 1.2f && jumpMult() <= JUMP_CAP + 1e-4f && airMult() > 1.8f && airMult() <= AIR_CAP + 1e-4f && webMult() > 1.5f && webMult() <= WEB_CAP + 1e-4f);
    // Run / Swing are untouched by the new skills.
    CHECK(fabsf(runMult() - 1.0f) < 1e-5f && fabsf(swingMult() - 1.0f) < 1e-5f);

    // ---- Jump height: real physics ----
    auto apex = [&](int level, bool dbl) {
        gProg = prog::Data(); gProg.level[prog::JUMP] = level; blank(); streetRunner();
        jumpEdge = true; float top = 0; bool used = false;
        for (int i = 0; i < 240 && P.alive; i++) {
            stepPhysics(1.0f / 120); top = std::min(top, P.y + 26.0f);
            if (dbl && !used && P.vy > 0 && !P.onGround) { jumpEdge = true; used = true; }
        }
        return -top;
    };
    const float h0 = apex(0, false), h1 = apex(prog::maxLevel(prog::JUMP), false);
    CHECK(h0 > 90 && h0 < 130);
    CHECK(h1 > h0 * 1.4f && h1 < h0 * 2.0f);                                       // clearly higher, never absurd
    CHECK(apex(prog::maxLevel(prog::JUMP), true) > apex(0, true));
    // Even the highest jump, with a double jump at the top, lands safely on the street (no fall damage from your own jumps).
    { gProg = prog::Data(); gProg.level[prog::JUMP] = prog::maxLevel(prog::JUMP); blank(); streetRunner(); jumpEdge = true; bool used = false, hardMsg = false;
      for (int i = 0; i < 600 && P.alive; i++) { stepPhysics(1.0f / 120); if (!used && P.vy > 0 && !P.onGround) { jumpEdge = true; used = true; }
        if (strcmp(gTrickMsg, "HARD LANDING") == 0 && gTrickMsgT > 0) hardMsg = true; }
      CHECK(used && P.alive && P.onGround && !hardMsg); }
    // ...and that tolerance only comes from the jump upgrade.
    CHECK(fall::classify(900, false, 1.3f) == fall::NONE && fall::classify(900, false) == fall::HARD && fall::classify(900, false, 0.5f) == fall::HARD);

    { gProg = prog::Data(); gProg.level[prog::JUMP] = prog::maxLevel(prog::JUMP); blank(); streetRunner(); jumpEdge = true; bool hardMsg = false;
      for (int i = 0; i < 480 && P.alive; i++) { stepPhysics(1.0f / 120); if (strcmp(gTrickMsg, "HARD LANDING") == 0 && gTrickMsgT > 0) hardMsg = true; }
      CHECK(P.alive && P.onGround && !hardMsg); }
    // The jump still clears the tallest crate at every level, and a vault still works.
    for (int lv : {0, 12, 25}) { gProg = prog::Data(); gProg.level[prog::JUMP] = lv; blank(); gCrates.push_back({1700.0f, 28, 36, 2}); streetRunner(); P.x = P.px = 1450; bool anyJump = false;
        for (int i = 0; i < 900 && P.alive && P.x < 1900; i++) { if (P.x > 1585 && P.x < 1590 && !anyJump) { jumpEdge = true; anyJump = true; } stepPhysics(1.0f / 120); }
        CHECK(P.alive && P.x >= 1900); }

    // ---- Air control ----
    auto airDv = [&](int level) {
        gProg = prog::Data(); gProg.level[prog::AIR] = level; blank(); P.x = P.px = 1400; P.y = P.py = -400; P.vx = 100; P.vy = -50; P.onGround = false; steer = 1.0f;
        const float v0 = P.vx; for (int i = 0; i < 36; i++) stepPhysics(1.0f / 120); steer = 0; return P.vx - v0; };
    const float a0 = airDv(0), a1 = airDv(prog::maxLevel(prog::AIR));
    CHECK(a0 > 20 && a1 > a0 * 1.8f && a1 < a0 * 3.2f);
    // On the ground the steering feel is unchanged by the Air Control level.
    auto groundV = [&](int level) { gProg = prog::Data(); gProg.level[prog::AIR] = level; blank(); streetRunner(); steer = 1.0f; for (int i = 0; i < 120; i++) stepPhysics(1.0f / 120); steer = 0; return P.vx; };
    CHECK(fabsf(groundV(0) - groundV(prog::maxLevel(prog::AIR))) < 1e-3f);

    // ---- Web control: more steering force on the rope, still bounded by the swing speed cap ----
    auto swingDv = [&](int level) {
        gProg = prog::Data(); gProg.level[prog::WEB] = level; blank();
        P.x = P.px = 1400; P.y = P.py = -600; P.ax = 1400; P.ay = -800; P.rope = 200; P.swinging = true; P.onGround = false; P.vx = 250; P.vy = 0; P.swingT = 1.0f;
        steer = 1.0f; const float sp0 = hypotf(P.vx, P.vy);
        for (int i = 0; i < 24 && P.alive; i++) stepPhysics(1.0f / 120);
        steer = 0; return hypotf(P.vx, P.vy) - sp0; };
    const float w0 = swingDv(0), w1 = swingDv(prog::maxLevel(prog::WEB));
    CHECK(w1 > w0 + 1.0f);
    { gProg = prog::Data(); gProg.level[prog::WEB] = prog::maxLevel(prog::WEB); blank();
      P.x = P.px = 1400; P.y = P.py = -600; P.ax = 1400; P.ay = -800; P.rope = 200; P.swinging = true; P.onGround = false; P.vx = 250; P.vy = 0; steer = 1.0f;
      float vmax = 0; for (int i = 0; i < 600 && P.swinging && P.alive; i++) { stepPhysics(1.0f / 120); vmax = std::max(vmax, hypotf(P.vx, P.vy)); }
      steer = 0; CHECK(std::isfinite(vmax) && vmax <= swingSpeedCap(swingMult()) + 1.0f); }

    // ---- Everything maxed together stays sane (existing mechanics keep working) ----
    gProg = prog::Data(); for (int s = 0; s < prog::SKILL_COUNT; s++) { gProg.level[s] = prog::maxLevel(s); gProg.rebirth[s] = prog::maxRebirth(s); }
    startRun(); gState = PLAYING;
    for (int i = 0; i < 60 * 15; i++) { updateGame(1.0 / 60); if (gState != PLAYING || !P.alive) break; }
    CHECK(std::isfinite(P.x) && std::isfinite(P.y) && std::isfinite(P.vx) && std::isfinite(P.vy));
    // UI: five rows with working buttons.
    gProg = prog::Data(); gProg.coins = 100000; gState = GAME_OVER; activate(B_SKILLS); buildUI();
    CHECK(findBtn(B_UP_JUMP) && findBtn(B_UP_AIR) && findBtn(B_UP_WEB) && findBtn(B_UP_RUN) && findBtn(B_UP_SWING));
    CHECK(strcmp(findBtn(B_UP_JUMP)->label, "UPGRADE 300") == 0 && strcmp(findBtn(B_UP_AIR)->label, "UPGRADE 250") == 0 && strcmp(findBtn(B_UP_WEB)->label, "UPGRADE 400") == 0);
    activate(B_UP_JUMP); CHECK(gProg.level[prog::JUMP] == 1 && gProg.coins == 100000 - 300);
    buildUI(); CHECK(strcmp(findBtn(B_UP_JUMP)->label, "UPGRADE 335") == 0);
    activate(B_UP_AIR); activate(B_UP_WEB); CHECK(gProg.level[prog::AIR] == 1 && gProg.level[prog::WEB] == 1);
    for (int w : {640, 568, 960}) for (int h : {300, 360, 450}) { uvzWorldWidth = w; uvzWorldHeight = h; buildUI(); for (auto& b : btns) CHECK(b.y >= 0 && b.y + b.h <= h + 1); }
    printf("[abilities] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
