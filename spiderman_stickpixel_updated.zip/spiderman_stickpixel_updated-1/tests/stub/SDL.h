#pragma once
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
typedef uint8_t Uint8; typedef uint16_t Uint16; typedef int16_t Sint16; typedef uint32_t Uint32; typedef int32_t Sint32; typedef int64_t Sint64; typedef uint64_t Uint64;
typedef int64_t SDL_FingerID; typedef uint32_t SDL_AudioDeviceID;
struct SDL_Rect { int x, y, w, h; };
struct SDL_Window; struct SDL_Renderer; struct SDL_Texture;
enum SDL_Scancode { SDL_SCANCODE_UNKNOWN = 0, SDL_SCANCODE_A = 4, SDL_SCANCODE_D = 7, SDL_SCANCODE_P = 19, SDL_SCANCODE_S = 22, SDL_SCANCODE_X = 27, SDL_SCANCODE_Z = 29, SDL_SCANCODE_RETURN = 40, SDL_SCANCODE_ESCAPE = 41,
  SDL_SCANCODE_SPACE = 44, SDL_SCANCODE_RIGHT = 79, SDL_SCANCODE_LEFT = 80, SDL_SCANCODE_DOWN = 81, SDL_SCANCODE_UP = 82, SDL_SCANCODE_KP_ENTER = 88,
  SDL_SCANCODE_LCTRL = 224, SDL_SCANCODE_LSHIFT = 225, SDL_SCANCODE_LALT = 226, SDL_SCANCODE_RCTRL = 228, SDL_SCANCODE_RSHIFT = 229, SDL_SCANCODE_RALT = 230,
  SDL_SCANCODE_AC_BACK = 270, SDL_NUM_SCANCODES = 512 };
enum { SDL_BLENDMODE_BLEND = 1 };
enum { SDL_INIT_TIMER = 1, SDL_INIT_AUDIO = 16, SDL_INIT_VIDEO = 32 };
enum { SDL_WINDOW_SHOWN = 4, SDL_WINDOW_FULLSCREEN = 1, SDL_WINDOW_FULLSCREEN_DESKTOP = 4097, SDL_WINDOW_RESIZABLE = 32, SDL_WINDOW_ALLOW_HIGHDPI = 8192 };
enum { SDL_WINDOWPOS_CENTERED = 0x2FFF0000 };
enum { SDL_RENDERER_ACCELERATED = 2, SDL_RENDERER_PRESENTVSYNC = 4 };
enum { SDL_TEXTUREACCESS_STATIC = 0, SDL_TEXTUREACCESS_STREAMING = 1, SDL_TEXTUREACCESS_TARGET = 2 };
enum { SDL_PIXELFORMAT_RGBA8888 = 1, SDL_PIXELFORMAT_ARGB8888 = 2, SDL_PIXELFORMAT_ABGR8888 = 3 };
enum { SDL_QUIT = 256, SDL_APP_WILLENTERBACKGROUND = 260, SDL_APP_DIDENTERFOREGROUND = 262, SDL_WINDOWEVENT = 512, SDL_KEYDOWN = 768, SDL_KEYUP = 769, SDL_MOUSEMOTION = 1024,
  SDL_FINGERDOWN = 1792, SDL_FINGERUP = 1793, SDL_FINGERMOTION = 1794 };
enum { SDL_WINDOWEVENT_RESIZED = 5, SDL_WINDOWEVENT_SIZE_CHANGED = 6, SDL_WINDOWEVENT_FOCUS_LOST = 13 };
#define SDL_HINT_RENDER_SCALE_QUALITY "a"
#define SDL_HINT_ORIENTATIONS "b"
#define SDL_HINT_TOUCH_MOUSE_EVENTS "c"
#define SDL_HINT_MOUSE_TOUCH_EVENTS "d"
#define SDL_HINT_ANDROID_TRAP_BACK_BUTTON "e"
struct SDL_Keysym { SDL_Scancode scancode; };
struct SDL_KeyboardEvent { Uint32 type; Uint8 repeat; SDL_Keysym keysym; };
struct SDL_WindowEvent { Uint32 type; Uint8 event; Sint32 data1, data2; };
struct SDL_TouchFingerEvent { Uint32 type; SDL_FingerID touchId, fingerId; float x, y, dx, dy, pressure; };
struct SDL_MouseMotionEvent { Uint32 type; Sint32 x, y, xrel, yrel; };
union SDL_Event { Uint32 type; SDL_KeyboardEvent key; SDL_WindowEvent window; SDL_TouchFingerEvent tfinger; SDL_MouseMotionEvent motion; };
struct SDL_AudioSpec { int freq; Uint16 format; Uint8 channels; Uint8 silence; Uint16 samples; Uint32 size; void (*callback)(void*, Uint8*, int); void* userdata; };
#define SDL_zero(x) memset(&(x), 0, sizeof(x))
#define AUDIO_F32SYS 0
inline int SDL_Init(Uint32) { return 0; }
inline void SDL_Quit() {}
inline const char* SDL_GetError() { return ""; }
inline void SDL_SetHint(const char*, const char*) {}
inline Uint32 SDL_GetTicks() { return 1234; }
inline Uint64 SDL_GetPerformanceCounter() { return 0; }
inline Uint64 SDL_GetPerformanceFrequency() { return 1; }
inline char* SDL_GetPrefPath(const char*, const char*) { static const char* d = getenv("PCITY_PREF"); char* r = (char*)malloc(256); snprintf(r, 256, "%s", d ? d : "/tmp/pcity_pref/"); return r; }
inline void SDL_free(void* p) { free(p); }
inline SDL_Window* SDL_CreateWindow(const char*, int, int, int, int, Uint32) { return nullptr; }
inline SDL_Renderer* SDL_CreateRenderer(SDL_Window*, int, Uint32) { return nullptr; }
inline int SDL_GetRendererOutputSize(SDL_Renderer*, int* w, int* h) { *w = 1280; *h = 720; return 0; }
inline void SDL_GetWindowSize(SDL_Window*, int* w, int* h) { *w = 1280; *h = 720; }
inline int SDL_GetDisplayDPI(int, float* a, float* b, float* c) { if (a) *a = 400; if (b) *b = 400; if (c) *c = 400; return 0; }
inline int SDL_SetWindowFullscreen(SDL_Window*, Uint32) { return 0; }
#include <vector>
#include <algorithm>
#include <cmath>
inline std::vector<uint8_t> g_fb; inline int g_fbW = 0, g_fbH = 0; inline bool g_drawOn = false;
inline uint8_t g_cr = 0, g_cg = 0, g_cb = 0, g_ca = 255;
inline Uint8 g_keys[512];
inline SDL_Texture* SDL_CreateTexture(SDL_Renderer*, Uint32, int, int w, int h) { static int t; if (w > 1000 || h > 1000) {} else if (w >= 300) { g_fbW = w; g_fbH = h; g_fb.assign((size_t)w * h * 3, 0); } return (SDL_Texture*)&t; }
inline void SDL_DestroyTexture(SDL_Texture*) {}
inline int SDL_UpdateTexture(SDL_Texture*, const SDL_Rect*, const void*, int) { return 0; }
inline int SDL_SetTextureBlendMode(SDL_Texture*, int) { return 0; }
inline int SDL_SetTextureColorMod(SDL_Texture*, Uint8, Uint8, Uint8) { return 0; }
inline int SDL_SetRenderTarget(SDL_Renderer*, SDL_Texture* t) { g_drawOn = t != nullptr; return 0; }
inline int SDL_SetRenderDrawColor(SDL_Renderer*, Uint8 r, Uint8 g, Uint8 b, Uint8 a) { g_cr = r; g_cg = g; g_cb = b; g_ca = a; return 0; }
inline int SDL_SetRenderDrawBlendMode(SDL_Renderer*, int) { return 0; }
inline int SDL_RenderCopy(SDL_Renderer*, SDL_Texture*, const SDL_Rect*, const SDL_Rect*) { return 0; }
inline int SDL_RenderClear(SDL_Renderer*) { return 0; }
inline void g_px(int x, int y) { if (!g_drawOn || x < 0 || y < 0 || x >= g_fbW || y >= g_fbH) return; uint8_t* p = &g_fb[((size_t)y * g_fbW + x) * 3]; int a = g_ca; p[0] = (uint8_t)((g_cr * a + p[0] * (255 - a)) / 255); p[1] = (uint8_t)((g_cg * a + p[1] * (255 - a)) / 255); p[2] = (uint8_t)((g_cb * a + p[2] * (255 - a)) / 255); }
inline void SDL_RenderPresent(SDL_Renderer*) {}
inline int SDL_RenderFillRect(SDL_Renderer*, const SDL_Rect* r) { for (int y = r->y; y < r->y + r->h; y++) for (int x = r->x; x < r->x + r->w; x++) g_px(x, y); return 0; }
inline int SDL_RenderFillRects(SDL_Renderer* r, const SDL_Rect* rs, int n) { for (int i = 0; i < n; i++) SDL_RenderFillRect(r, rs + i); return 0; }
inline int SDL_RenderDrawLine(SDL_Renderer*, int x0, int y0, int x1, int y1) { int n = std::max(std::abs(x1 - x0), std::abs(y1 - y0)); for (int i = 0; i <= n; i++) { float t = n ? (float)i / n : 0; g_px((int)std::lround(x0 + (x1 - x0) * t), (int)std::lround(y0 + (y1 - y0) * t)); } return 0; }
inline int SDL_RenderSetClipRect(SDL_Renderer*, const SDL_Rect*) { return 0; }
inline int SDL_PollEvent(SDL_Event*) { return 0; }
inline const Uint8* SDL_GetKeyboardState(int*) { return g_keys; }
inline const char* SDL_GetScancodeName(SDL_Scancode) { return ""; }
inline SDL_AudioDeviceID SDL_OpenAudioDevice(const char*, int, const SDL_AudioSpec*, SDL_AudioSpec*, int) { return 0; }
inline void SDL_PauseAudioDevice(SDL_AudioDeviceID, int) {}
inline void SDL_LockAudioDevice(SDL_AudioDeviceID) {}
inline void SDL_UnlockAudioDevice(SDL_AudioDeviceID) {}
