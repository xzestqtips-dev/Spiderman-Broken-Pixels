// Difficulty tiers and ramp (pure logic), plus the generators that read them (traffic mix, street crates).
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); initFont(); recalculateDisplayLayout();
    // Tiers: five of them, in order, named, starting at distance 0.
    CHECK(diff::TIER_COUNT == 5 && strcmp(diff::TIER_NAME[0], "BEGINNER") == 0 && strcmp(diff::TIER_NAME[4], "MASTER") == 0);
    CHECK(diff::tierFor(0) == diff::BEGINNER && diff::tierFor(399) == diff::BEGINNER && diff::tierFor(400) == diff::INTERMEDIATE);
    CHECK(diff::tierFor(1000) == diff::ADVANCED && diff::tierFor(2000) == diff::EXPERT && diff::tierFor(3500) == diff::MASTER && diff::tierFor(1e6f) == diff::MASTER);
    CHECK(diff::tierFor(-5.0f) == 0 && diff::ramp(-5.0f) == 0.0f && diff::ramp(0) == 0.0f);
    // The ramp is monotonic, continuous (no jumps at tier edges), bounded, and endless-but-capped.
    bool mono = true, smooth = true; float prev = 0, prevRun = 0, prevSp = 1, prevSpd = 1;
    for (float m = 0; m <= 30000; m += 10) {
        const float r = diff::ramp(m);
        if (r < prev - 1e-6f) mono = false;
        if (r - prev > 0.01f) smooth = false;
        if (diff::runSpeedBase(m) < prevRun - 1e-3f) mono = false;
        if (diff::trafficSpacingScale(m) > prevSp + 1e-6f) mono = false;
        if (diff::trafficSpeedScale(m) < prevSpd - 1e-6f) mono = false;
        prev = r; prevRun = diff::runSpeedBase(m); prevSp = diff::trafficSpacingScale(m); prevSpd = diff::trafficSpeedScale(m);
    }
    CHECK(mono && smooth);
    CHECK(fabsf(diff::ramp(3500) - 1.0f) < 1e-4f && diff::ramp(1e6f) <= 1.25f + 1e-4f && diff::ramp(6000) > diff::ramp(3500));
    CHECK(diff::cityRamp(1e6f) <= 1.0f);
    CHECK(diff::trafficSpacingScale(1e6f) >= 0.6f - 1e-4f && diff::trafficSpeedScale(1e6f) <= 1.4f);
    CHECK(diff::runSpeedBase(0) == 230.0f && diff::runSpeedBase(3500) > diff::runSpeedBase(400));
    for (int t = 1; t < diff::TIER_COUNT; t++) CHECK(diff::TIER_START_M[t] > diff::TIER_START_M[t - 1]);
    // Obstacle variety grows with the tier and every obstacle stays clearable.
    CHECK(diff::trafficTypeCount(0) == 2 && diff::trafficTypeCount(1) == 3 && diff::trafficTypeCount(2) == 4 && diff::trafficTypeCount(4) == 5);
    for (int t = 0; t < diff::TIER_COUNT; t++) {
        CHECK(diff::crateVariants(t) >= 1 && diff::crateVariants(t) <= 4 && (t == 0 || diff::crateVariants(t) >= diff::crateVariants(t - 1)));
        CHECK(diff::crateMaxHeight(t) < 60.0f);   // a normal jump apex is ~112 px
        for (float r : {0.0f, 0.5f, 0.999f}) CHECK(diff::pickTrafficType(t, r) >= 0 && diff::pickTrafficType(t, r) < diff::trafficTypeCount(t));
    }
    CHECK(!diff::crateEnabled(0) && !diff::crateEnabled(119) && diff::crateEnabled(120));
    bool gapsOk = true;
    for (float m = 0; m <= 20000; m += 50) for (float r : {0.0f, 0.3f, 0.99f}) if (diff::crateGap(m, r) < diff::crateMinGap(m)) gapsOk = false;
    CHECK(gapsOk);
    CHECK(diff::crateGap(3500, 0.0f) < diff::crateGap(0, 0.0f));   // denser later

    // The game uses it: Beginner traffic is taxis and cars only; Master has the full mix.
    const int oldW = uvzWorldWidth; uvzWorldWidth = 8000;
    for (int pass = 0; pass < 2; pass++) {
        trafficCars.clear(); nextTrafficSpawnX = 0; trafficSerial = 0; camX = 0; P.x = 200; distM = pass ? 5000.0f : 0.0f;
        ensureTraffic();
        bool seen[5] = {false, false, false, false, false};
        for (const TrafficCar& c : trafficCars) seen[c.type] = true;
        if (pass == 0) CHECK(seen[0] && seen[1] && !seen[2] && !seen[3] && !seen[4]);
        else CHECK(seen[0] && seen[1] && seen[2] && seen[3] && seen[4]);
        if (pass == 0) CHECK((int)trafficCars.size() > 4);
    }
    // Later tiers are busier: the same stretch of road holds more vehicles.
    trafficCars.clear(); nextTrafficSpawnX = 0; trafficSerial = 0; distM = 0; ensureTraffic(); const size_t nEasy = trafficCars.size();
    trafficCars.clear(); nextTrafficSpawnX = 0; trafficSerial = 0; distM = 5000; ensureTraffic(); const size_t nHard = trafficCars.size();
    CHECK(nHard > nEasy);
    uvzWorldWidth = oldW;

    // Street crates: none early, then fair spacing and heights at every tier; never right next to a vehicle.
    for (float m : {0.0f, 100.0f}) { gCrates.clear(); nextCrateX = 0; trafficCars.clear(); distM = m; camX = 0; P.x = 200; ensureCrates(); CHECK(gCrates.empty()); }
    for (float m : {150.0f, 700.0f, 1500.0f, 2500.0f, 4000.0f, 9000.0f}) {
        gCrates.clear(); nextCrateX = 0; trafficCars.clear(); distM = m; camX = 0; P.x = 200;
        for (int k = 0; k < 40; k++) { camX = k * 400.0f; ensureCrates(); }
        const int tier = diff::tierFor(m);
        bool fair = gCrates.size() >= 2;
        for (size_t i = 0; i < gCrates.size(); i++) {
            if (gCrates[i].h > diff::crateMaxHeight(tier) + 1e-3f || gCrates[i].variant >= diff::crateVariants(tier)) fair = false;
            if (i && gCrates[i].x - (gCrates[i - 1].x + gCrates[i - 1].w) < diff::crateMinGap(m) - 1.0f) fair = false;
        }
        CHECK(fair);
    }
    gCrates.clear(); nextCrateX = 0; distM = 2000; camX = 0; P.x = 200; trafficCars.clear();
    { TrafficCar c; c.x = 1100; c.speed = 0; c.maxSpeed = 0; c.width = 60; c.height = 30; c.type = 1; c.lane = 0; c.dir = 1; c.color = 0; c.id = 5; trafficCars.push_back(c); }
    nextCrateX = 1000.0f; camX = 300; ensureCrates();
    bool clear = true; for (auto& k : gCrates) if (fabsf(k.x - 1100.0f) < 220.0f) clear = false;
    CHECK(clear);
    printf("[difficulty] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
