// Software-render harness: renders real game frames with the SDL shim and dumps PPMs.
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>

static void present() {  // identical to the tail of render(): composite target -> window
    SDL_SetRenderTarget(uvzRenderer, nullptr);
    SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255);
    SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight};
    SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
}
static void dump(const char* name) {
    char p[160]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); fprintf(f, "P6\n%d %d\n255\n", g_outW, g_outH);
    for (uint32_t c : g_screen) { unsigned char b[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c}; fwrite(b, 1, 3, f); }
    fclose(f);
}
int main(int argc, char** argv) {
    mkdir("/tmp/shots", 0777);
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    int W = argc > 1 ? atoi(argv[1]) : 1280, H = argc > 2 ? atoi(argv[2]) : 720;
    const char* tag = argc > 3 ? argv[3] : "menu";
    double t0 = argc > 4 ? atof(argv[4]) : 0;
    g_outW = W; g_outH = H; g_screen.assign((size_t)W * H, 0xFF00FF00u);  // magenta-green = "never drawn"
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt(); startRun(true);
    gState = MAIN_MENU; trans = -1; menuT = argc > 5 ? (float)atof(argv[5]) : 0.0f; gTime = t0; uiAge = 5;
    int mode = argc > 6 ? atoi(argv[6]) : 0;
    if (mode == 1) {   // backdrop only, no UI
        SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget); SDL_SetRenderDrawBlendMode(uvzRenderer, SDL_BLENDMODE_BLEND);
        drawBackdrop(menuT * 16.0f, -200, MENU_SKY_TIME); present();
    } else if (mode == 3) {  // standing on a vehicle roof, between buildings
        gState = PLAYING; startRun(); gRunT0 = 0;
        P.x = bld[2].x - 260; P.y = -200; P.py = P.y; P.px = P.x; P.onGround = false; camX = P.x - uvzWorldWidth * 0.3f; camY = P.y - uvzWorldHeight * 0.58f;
        trafficCars.clear(); nextTrafficSpawnX = P.x + 40; ensureTraffic();
        for (int i = 0; i < 4 && i < (int)trafficCars.size(); i++) { trafficCars[i].x = P.x - 150 + i * 120; trafficCars[i].speed = 20; }
        trafficCars[1].x = P.x; steer = -1;
        for (int i = 0; i < 40; i++) { gTime += 0.016; updateGame(0.016); }
        gTime += 0.016; render(0.016); present();
    } else if (mode == 4) {  // menu mid-pan: argv[7] = trans (0..1)
        trans = argc > 7 ? (float)atof(argv[7]) : 0.5f; gTime = t0;
        for (int i = 0; i < 3; i++) { gTime += 0.016; render(0.016); present(); }
    } else if (mode == 2) {  // gameplay frame
        gState = PLAYING; for (int i = 0; i < 30; i++) { gTime += 0.016; updateGame(0.016); } render(0.016); present();
    } else { for (int i = 0; i < 3; i++) { gTime += 0.016; render(0.016); present(); } uiAge = 5; gTime += 0.016; render(0.016); present(); }
    char n[128]; snprintf(n, sizeof n, "%s_%dx%d", tag, W, H); dump(n);
    printf("%s: world %dx%d scale %d off(%d,%d) display %dx%d\n", n, uvzWorldWidth, uvzWorldHeight, uvzPixelScale, uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight);
    return 0;
}
