// Street = fall damage (huge falls are fatal, small ones are free); vehicle roofs = safe, carrying platforms; death -> GAME OVER -> RESTART.
#define main game_main
#include "../src/main.cpp"
#undef main

static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static TrafficCar mkCar(float x, int dir, int type, float speed) {
    TrafficCar c;
    c.x = x; c.speed = speed; c.maxSpeed = speed;
    c.width = trafficWidth(type); c.height = trafficHeight(type);
    c.type = type; c.dir = dir; c.lane = dir > 0 ? 0 : 1; c.color = 0xD0B040; c.id = 1000 + type * 10 + (dir > 0 ? 0 : 1);
    return c;
}
static void blank() {
    bld.clear(); trafficCars.clear(); trafficSignals.clear(); nextTrafficSpawnX = 1e9f;
    addBuilding(true);
    P = Player(); P.alive = true; steer = 0; swingHeld = false; jumpEdge = slideEdge = jumpRel = false;
    gImpactT = 0; gState = PLAYING;
}
static void step(int n) { for (int i = 0; i < n && P.alive; i++) { updateTraffic(1.0f / 120); stepPhysics(1.0f / 120); } }
static void dropOnto(float x, float y, float vy) { P.x = x; P.y = y; P.px = x; P.py = y; P.vx = 0; P.vy = vy; P.onGround = false; }

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();

    // 1. The run starts standing on the street; running along it is fine (no cars around).
    blank(); P.x = 200; P.y = -26; P.py = -26; P.px = 200; P.vx = 230; P.onGround = true;
    step(240);
    CHECK(P.alive && P.onGround && !P.deadGround);

    // 2. A huge fall onto the street kills, with the ground-death flag + effect.
    blank(); dropOnto(1000, -700, 0);
    step(240);
    CHECK(!P.alive && P.deadGround);
    CHECK(gImpactT > 0);
    CHECK(fabsf(P.y - (STREET_GROUND_Y - 26.0f)) < 0.01f);
    // ...and a fast fall can't tunnel through the asphalt.
    blank(); dropOnto(300, -450, 2600); step(120);   // (starts below the opening rooftop, which is solid)
    CHECK(!P.alive && P.deadGround);

    // 3. Jumping up and coming back down onto the street is a tiny drop: safe now.
    blank(); P.x = 200; P.y = -26; P.py = -26; P.px = 200; P.vx = 230; P.onGround = true;
    jumpEdge = true; step(240);
    CHECK(P.alive && !P.deadGround);

    // 4. Every vehicle type, both lanes: landing on the roof is safe and rides it.
    for (int type = 0; type < 4; type++) for (int dir : {1, -1}) {
        blank(); steer = -1.0f;   // stand still on the roof
        TrafficCar car = mkCar(400, dir, type, 0.0f);
        trafficCars.push_back(car);
        dropOnto(400, carTopY(car) - 140, 0);
        step(120);
        CHECK(P.alive);
        CHECK(P.onGround && !P.deadGround);
        CHECK(P.rideId == car.id);
        CHECK(fabsf(P.y + 26.0f - carTopY(car)) < 0.6f);
    }

    // 4b. With no steering the roof run is slow enough to react (bus: > 0.8s before the edge).
    blank(); steer = 0; trafficCars.push_back(mkCar(500, 1, 2, 0.0f));
    dropOnto(500, carTopY(trafficCars[0]) - 40, 0); step(100);
    CHECK(P.alive && P.onGround);

    // 5. A hard, fast landing on a bus roof neither kills nor tunnels through.
    blank(); steer = -1.0f; trafficCars.push_back(mkCar(500, 1, 2, 0.0f));
    dropOnto(500, -450, 1800); step(240);
    CHECK(P.alive && P.rideId >= 0);

    // 6. Standing on a *moving* vehicle: the player is carried along with it.
    blank(); trafficCars.push_back(mkCar(300, 1, 2, 160.0f));
    dropOnto(300, carTopY(trafficCars[0]) - 20, 0);
    steer = -1.0f;                                   // stand still relative to the roof
    step(60);                                        // settle for half a second
    const float x0 = P.x, c0 = trafficCars[0].x;
    step(240);                                       // two more seconds
    CHECK(P.alive && P.onGround);
    CHECK(trafficCars[0].x - c0 > 250.0f);           // the bus really moved ~320px
    CHECK(fabsf((P.x - x0) - (trafficCars[0].x - c0)) < 30.0f);   // ...and so did the rider
    CHECK(fabsf(P.x - trafficCars[0].x) < trafficCars[0].width * 0.5f);   // still on the roof

    // 6b. Same for a westbound vehicle.
    blank(); trafficCars.push_back(mkCar(1500, -1, 3, 140.0f));   // well clear of the first building's east face (a rider that tall would scrape along it)
    dropOnto(1500, carTopY(trafficCars[0]) - 20, 0); steer = -1.0f; step(60);
    const float wx0 = P.x, wc0 = trafficCars[0].x; step(180);
    CHECK(P.alive && P.onGround && trafficCars[0].x < wc0 - 150.0f && fabsf((P.x - wx0) - (trafficCars[0].x - wc0)) < 30.0f);
    steer = 0;

    // 7. Running off the end of a vehicle roof is a short drop to the street: safe.
    blank(); trafficCars.push_back(mkCar(300, 1, 1, 0.0f));
    dropOnto(300, carTopY(trafficCars[0]) - 20, 0); steer = 1.0f;   // run forward
    step(600);
    CHECK(P.alive && !P.deadGround);
    steer = 0;

    // 8. Running into a vehicle's side at street level is still fatal.
    blank(); P.x = 100; P.px = 100; P.y = P.py = -26.0f; P.onGround = true;
    trafficCars.push_back(mkCar(100, 1, 1, 0.0f));
    collide();
    CHECK(!P.alive && !P.deadGround);

    // 9. You can jump from a roof onto the next vehicle and keep going.
    blank(); steer = -1.0f;
    trafficCars.push_back(mkCar(300, 1, 2, 0.0f)); trafficCars.push_back(mkCar(390, 1, 1, 0.0f));
    dropOnto(300, carTopY(trafficCars[0]) - 40, 0); step(40);
    CHECK(P.alive && P.rideId == trafficCars[0].id);
    P.vx = 150.0f; jumpEdge = true; steer = 0; step(120);
    CHECK(P.alive);
    steer = 0;

    // 10. Death -> GAME OVER -> restart, all in-process.
    startRun(); gState = PLAYING;
    P.x = 400; P.y = -700; P.py = P.y; P.px = P.x; P.vy = 0; P.onGround = false; trafficCars.clear(); nextTrafficSpawnX = 1e9f;
    for (int i = 0; i < 400 && gState == PLAYING; i++) updateGame(1.0 / 60.0);
    CHECK(gState == GAME_OVER);
    CHECK(P.deadGround);
    buildUI();
    bool hasRestart = false; for (auto& b : btns) if (b.id == B_TRY && b.label && strcmp(b.label, "RESTART") == 0) hasRestart = true;
    CHECK(hasRestart);
    menuKey(SDL_SCANCODE_R);                                   // keyboard shortcut
    CHECK(gState == PLAYING && P.alive && !P.deadGround && P.onGround);
    CHECK(P.x == 200.0f && !bld.empty() && gImpactT <= 0.55f);
    // ...and via the on-screen button too.
    P.x = 400; P.y = -700; P.py = P.y; P.px = P.x; P.vy = 0; P.onGround = false; trafficCars.clear(); nextTrafficSpawnX = 1e9f;
    for (int i = 0; i < 400 && gState == PLAYING; i++) updateGame(1.0 / 60.0);
    CHECK(gState == GAME_OVER);
    activate(B_TRY);
    CHECK(gState == PLAYING && P.alive);

    // 11. Restarted runs keep working: the player survives running for a while.
    for (int i = 0; i < 60 && P.alive; i++) updateGame(1.0 / 60.0);
    CHECK(P.alive);

    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
