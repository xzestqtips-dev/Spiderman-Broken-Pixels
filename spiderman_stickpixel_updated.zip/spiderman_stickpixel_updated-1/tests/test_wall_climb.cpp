// Wall climbing: attach (web held), climb, slide, mantle, wall jump, no re-grab, edges, endless city.
// Run: g++ -std=c++17 -O1 -Itests/stub -o /tmp/twc tests/test_wall_climb.cpp && /tmp/twc
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void world() {   // street far below, tall block with its left face at x=500 and right face at x=1500, roof at y=0
    bld.clear();
    Building a; a.x = -3000; a.w = 9000; a.roofY = 2500; a.seed = 1; a.style = 0;
    Building b; b.x = 500; b.w = 1000; b.roofY = 0; b.seed = 2; b.style = 1;
    bld.push_back(a); bld.push_back(b);
}
static void air(float x, float y, float vx, float vy) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = false; swingWas = false; badClear(); gFlow = 0;
}
static void run(int n, float dt) { for (int i = 0; i < n && P.alive; i++) stepPhysics(dt); }
static void toWall(float dt) { for (int i = 0; i < 120 && P.alive && !P.wallCling; i++) stepPhysics(dt); }   // until the web catches the wall

int main() {
    if (system("rm -rf /tmp/pcity_wc && mkdir -p /tmp/pcity_wc") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_wc/", 1);
    loadCfg(); loadControls();
    gWin = nullptr; gRen = nullptr;
    initFont(); recalcDisplay(); buildArt(); startRun(); gState = PLAYING;
    gProg = prog::Data();
    cfg.swingAssist = 0.0f;
    const float dt = 1.0f / 120.0f;

    // 1. touching the wall WITHOUT the web button: no attach (slow = bounce, fast = the old lethal crash)
    { world(); air(485, 300, 90, 0); run(30, dt); CHECK(!P.wallCling && P.alive);
      world(); air(485, 300, 400, 0); run(30, dt); CHECK(!P.alive); }

    // 2. web held: attaches, aligned with the facade, no clipping / floating, fall absorbed smoothly
    { world(); air(485, 300, 400, 250); swingHeld = true; swingWas = true; run(12, dt);
      CHECK(P.wallCling && P.alive && P.wallDir > 0);
      CHECK(fabsf(P.x - (500 - WALL_GAP)) < 0.01f);
      CHECK(P.vx == 0);
      float lastVy = P.vy, maxStep = 0;
      for (int i = 0; i < 120; i++) { stepPhysics(dt); maxStep = std::max(maxStep, fabsf(P.vy - lastVy)); lastVy = P.vy; CHECK(fabsf(P.x - (500 - WALL_GAP)) < 0.01f); }
      CHECK(P.vy < -150 && P.vy >= -CLIMB_UP - 0.01f);          // climbing up
      CHECK(maxStep < 1700.0f * dt + 0.01f);                    // smooth acceleration, no jump in speed
      CHECK(pickFrame() == F_CLIMB); }

    // 3. release: descends, stays attached, aligned
    { world(); air(485, 300, 100, 0); swingHeld = true; swingWas = true; toWall(dt); CHECK(P.wallCling);
      run(60, dt); const float y0 = P.y; swingHeld = false; run(90, dt);
      CHECK(P.wallCling && P.y > y0 && fabsf(P.vy - SLIDE_DOWN) < 5 && fabsf(P.x - (500 - WALL_GAP)) < 0.01f); CHECK(pickFrame() == F_CLIMB);
      float ph = P.climbPhase; run(30, dt); CHECK(P.climbPhase < ph);   // limb cycle runs backwards going down
      swingHeld = true; run(120, dt); CHECK(P.vy < 0); }               // pressing again turns back up smoothly

    // 4. climb to the roof: eased mantle, ends standing on the roof, no teleport
    { world(); air(485, 200, 100, 0); swingHeld = true; swingWas = true; toWall(dt); CHECK(P.wallCling);
      bool mant = false, ground = false; float maxJump = 0; 
      for (int i = 0; i < 600 && P.alive; i++) { const float x0 = P.x, y0 = P.y; stepPhysics(dt); maxJump = std::max(maxJump, hypotf(P.x - x0, P.y - y0));
          if (P.mantleT > 0) mant = true; if (P.onGround && !P.wallCling) { ground = true; break; } }
      CHECK(mant && ground && P.alive); CHECK(fabsf(P.y - (0 - 26)) < 1.0f && P.x > 500 && P.x < 540);
      CHECK(maxJump < 12.0f);                                        // never more than a few px per 1/120 s
      run(120, dt); CHECK(P.onGround && !P.wallCling && P.vx > 150 && P.alive); }   // keeps running after

    // 5. wall jump: leaves the wall, launched away, upward, no re-attach while still holding web / steering into it
    { world(); air(485, 300, 100, 0); swingHeld = true; swingWas = true; toWall(dt); run(60, dt); CHECK(P.wallCling);
      jumpEdge = true; stepPhysics(dt);
      CHECK(!P.wallCling && P.vx < -300 && P.vy < -500 && P.usedAir); CHECK(pickFrame() == F_WALLJUMP);
      CHECK(swingWas == false);                                       // held web becomes a fresh press: flows into a swing
      swingWas = true; steer = 1; bool re = false;
      for (int i = 0; i < 240 && P.alive; i++) { stepPhysics(dt); if (P.wallCling) re = true; swingWas = true; }
      CHECK(!re);
      // an ordinary jump later still works as before (no wall contact): ground jump unaffected
    }
    // 5b. climbing gives a higher wall-jump than sliding
    { world(); air(485, 300, 100, 0); swingHeld = true; swingWas = true; toWall(dt); run(60, dt); jumpEdge = true; stepPhysics(dt); float up = P.vy;
      world(); air(485, 300, 100, 0); swingHeld = true; swingWas = true; toWall(dt); swingHeld = false; run(60, dt); jumpEdge = true; stepPhysics(dt); float dn = P.vy;
      CHECK(up < dn); }

    // 6. right-hand facade (wall on the right of a gap): mirror attach, climb, jump away to the right
    { world(); air(1515, 300, -400, 200); swingHeld = true; swingWas = true; run(12, dt);
      CHECK(P.wallCling && P.wallDir < 0 && fabsf(P.x - (1500 + WALL_GAP)) < 0.01f);
      run(30, dt); CHECK(P.vy < 0);
      jumpEdge = true; stepPhysics(dt); CHECK(!P.wallCling && P.vx > 300);
      swingWas = true; run(240, dt); CHECK(!P.wallCling); }

    // 7. slide to street level: kicked off, never dies in the street by clinging
    { bld.clear(); Building a; a.x = -3000; a.w = 9000; a.roofY = 900; a.seed = 1; Building b; b.x = 500; b.w = 1000; b.roofY = 600; b.seed = 2; bld.push_back(a); bld.push_back(b);
      air(485, 700, 100, 0); swingHeld = true; swingWas = true; toWall(dt); CHECK(P.wallCling); swingHeld = false;
      bool left = false; for (int i = 0; i < 600 && P.alive; i++) { stepPhysics(dt); if (!P.wallCling) { left = true; break; } }
      CHECK(left && P.alive && P.vx < 0 && P.vy < 0); }

    // 8. swing slap still sticks (existing behaviour), and full auto assist attaches by itself and climbs
    { world(); air(470, 300, 500, 100); P.swinging = true; P.ax = 600; P.ay = 120; P.rope = hypotf(P.x - P.ax, P.y - P.ay); swingHeld = true; swingWas = true;
      run(60, dt); CHECK(P.wallCling || !P.swinging || P.alive); }
    { cfg.swingAssist = 1.0f; world(); air(485, 300, 400, 100); run(20, dt); CHECK(P.wallCling && P.alive); run(60, dt); CHECK(P.vy < -100); cfg.swingAssist = 0.0f; }

    // 9. wall corner / roof edge: attach just under the lip then mantle (no kill), and a lethal roof block is never grabbed
    { world(); air(485, 30, 300, 0); swingHeld = true; swingWas = true; run(120, dt); CHECK(P.alive && (P.onGround || P.mantleT > 0 || P.wallCling)); }
    { world(); bld[1].obs.push_back({0, 600.0f, 28.0f, 20.0f, true, 0}); air(590, -10, 300, 0); swingHeld = true; swingWas = true; run(30, dt); CHECK(!P.wallCling); }

    // 10. endless city: bot climbs/jumps through many generated buildings without crashing the sim or leaving the wall misaligned
    { bld.clear(); Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s);
      Building f; f.x = -300; f.w = 1100; f.roofY = 0; f.seed = 5; bld.push_back(f);
      for (int i = 0; i < 14; i++) addBuilding(false);
      int attaches = 0; bool wasC = false, bad = false; float worst = 0;
      for (int trial = 0; trial < 40; trial++) {
          const Building& b = bld[2 + trial % 10];
          air(b.x - 60, b.roofY + 60 + (trial * 37) % 300, 250 + trial * 5, 0);
          swingHeld = true; swingWas = true; wasC = false;
          for (int i = 0; i < 900 && P.alive; i++) {
              if (i == 200 + trial * 3) jumpEdge = true;
              if (i % 90 == 45) swingHeld = !swingHeld;
              stepPhysics(dt);
              if (P.wallCling && !wasC) attaches++;
              wasC = P.wallCling;
              if (P.wallCling && P.mantleT <= 0) { worst = std::max(worst, fabsf(P.x - P.wallX)); if (!(P.y + 26 < 900) || !(P.y == P.y)) bad = true; }
              if (!(P.x == P.x) || !(P.y == P.y)) bad = true;
          }
      }
      printf("endless: %d attaches, worst misalignment %.3f\n", attaches, worst);
      CHECK(!bad && worst < 0.01f && attaches > 5); }

    // 11. the facade after a world recycle: no building under us -> falls, no crash
    { world(); air(485, 300, 100, 0); swingHeld = true; swingWas = true; run(10, dt); CHECK(P.wallCling); bld.erase(bld.begin() + 1); run(10, dt); CHECK(!P.wallCling); }

    printf("[wall_climb] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
