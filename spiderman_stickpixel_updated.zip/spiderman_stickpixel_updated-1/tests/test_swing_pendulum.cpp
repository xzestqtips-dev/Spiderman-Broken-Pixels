#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main() {
    const float dt = 1.0f / 120.0f, rope = 250.0f, ax = 0, ay = 0, sm = 1.0f;

    float x = -rope, y = 0, vx = 0, vy = 0;
    float vBottom = 0, maxStretch = 0, maxRisingGain = 0, prev = 0;
    bool passed = false;
    for (int i = 0; i < 600; i++) {
        vy += GRAV * dt; x += vx * dt; y += vy * dt;
        swingStep(x, y, vx, vy, ax, ay, rope, sm, 0.0f, dt);
        const float v = hypotf(vx, vy);
        maxStretch = std::max(maxStretch, hypotf(x - ax, y - ay) - rope);
        if (!passed && x > 0) { passed = true; vBottom = v; }
        if (passed && vy < 0 && v > prev) maxRisingGain = std::max(maxRisingGain, v - prev);
        prev = v;
        if (passed && vy >= 0) break;
    }
    printf("bottom %.0f px/s, rope stretch %.4f, biggest speed gain while rising %.3f\n", vBottom, maxStretch, maxRisingGain);
    CHECK(vBottom > 600.0f);
    CHECK(maxStretch < 0.01f);
    CHECK(maxRisingGain < 0.5f);
    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL SWING PENDULUM TESTS PASSED\n");
    return fails ? 1 : 0;
}
