// Renders the city at a chosen camera: g++ -std=c++17 -O1 -Itests/stub_gfx tests/shot_city.cpp -o /tmp/shotc
// usage: /tmp/shotc W H tag camXoffset camY seed
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static void present() {
    SDL_SetRenderTarget(uvzRenderer, nullptr);
    SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255);
    SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight};
    SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
}
static void dump(const char* name) {
    char p[160]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); fprintf(f, "P6\n%d %d\n255\n", g_outW, g_outH);
    for (uint32_t c : g_screen) { unsigned char b[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c}; fwrite(b, 1, 3, f); }
    fclose(f);
}
int main(int argc, char** argv) {
    mkdir("/tmp/shots", 0777);
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); if (system("mkdir -p /tmp/pcity_t")) {}
    int W = argc > 1 ? atoi(argv[1]) : 1280, H = argc > 2 ? atoi(argv[2]) : 720;
    const char* tag = argc > 3 ? argv[3] : "city";
    float dx = argc > 4 ? (float)atof(argv[4]) : 0, camy = argc > 5 ? (float)atof(argv[5]) : -235;
    g_outW = W; g_outH = H; g_screen.assign((size_t)W * H, 0xFF00FF00u);
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt(); startRun();
    const char* ui = argc > 6 ? argv[6] : "";
    gState = PLAYING; gTime = 10; gSkyTime = 20;
    for (int i = 0; i < 20; i++) { gTime += 0.016; updateGame(0.016); }
    camX = P.x + dx - uvzWorldWidth * 0.3f; camY = camy;
    ensureWorld(); ensureTraffic();
    if (!strcmp(ui, "settings")) { gState = SETTINGS; trans = -1; uiAge = 60; }
    if (!strcmp(ui, "howto")) { gState = HOW_TO_PLAY; trans = -1; uiAge = 60; }
    SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
    for (int i = 0; i < 60; i++) { render(0.016); present(); }
    char n[128]; snprintf(n, sizeof n, "%s_%dx%d", tag, W, H); dump(n);
    return 0;
}
