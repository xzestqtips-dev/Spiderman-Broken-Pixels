// Regression tests for the sky bug (corrupted blendRgb) and the sky/skyline renderer.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int ch(u32 c, int s) { return (int)((c >> s) & 255); }
int main() {
    // blendRgb: every result is a valid 24-bit colour and lies between its endpoints, in both directions
    // (the original wrapped unsigned channel differences, so any channel getting darker was corrupted).
    const u32 cols[] = {0x000000, 0xFFFFFF, 0x4C5A6B, 0x141A3A, 0xE98768, 0x28385F, 0x10FF80, 0xFF0010};
    for (u32 a : cols) for (u32 b : cols) for (int i = 0; i <= 20; i++) {
        const u32 c = blendRgb(a, b, i / 20.0f);
        CHECK((c & 0xFF000000u) == 0);
        for (int s : {0, 8, 16}) CHECK(ch(c, s) >= std::min(ch(a, s), ch(b, s)) - 1 && ch(c, s) <= std::max(ch(a, s), ch(b, s)) + 1);
    }
    CHECK(blendRgb(0x4C5A6B, 0x141A3A, 0.0f) == 0x4C5A6B && blendRgb(0x4C5A6B, 0x141A3A, 1.0f) == 0x141A3A);
    // The palette is valid and continuous over the whole day cycle (no flicker).
    u32 prev[3] = {0, 0, 0}; bool first = true; int maxStep = 0;
    for (double t = 0; t <= 360.0; t += 0.25) {
        const DayPalette p = dayPalette(t);
        CHECK((p.top | p.mid | p.horizon) <= 0xFFFFFF);
        const u32 now[3] = {p.top, p.mid, p.horizon};
        if (!first) for (int k = 0; k < 3; k++) for (int s : {0, 8, 16}) maxStep = std::max(maxStep, abs(ch(now[k], s) - ch(prev[k], s)));
        for (int k = 0; k < 3; k++) prev[k] = now[k];
        first = false;
    }
    CHECK(maxStep <= 20);                                   // smooth: at most a few levels per quarter second
    CHECK(sunsetAmount(MENU_SKY_TIME) > 0.95f);             // the menu is pinned to golden hour
    CHECK(dayPalette(63.0).top != dayPalette(0.0).top);
    // Resizing: the sky texture and layers rebuild for any size/aspect ratio without issue.
    initFont();
    const int sizes[][2] = {{1280, 600}, {1920, 1080}, {2560, 1080}, {800, 480}, {1366, 768}, {3440, 1440}, {640, 360}};
    for (auto& sz : sizes) {
        uvzOutputWidth = sz[0]; uvzOutputHeight = sz[1];
        uvzPixelScale = std::max(1, (int)lroundf(std::min(sz[0], sz[1]) / 360.0f));
        uvzWorldWidth = (sz[0] + uvzPixelScale - 1) / uvzPixelScale; uvzWorldHeight = (sz[1] + uvzPixelScale - 1) / uvzPixelScale;
        drawBackdrop(1234.0f, -200.0f, MENU_SKY_TIME);
        CHECK(gSkyW == uvzWorldWidth && gSkyH == uvzWorldHeight);
        drawBackdrop(-99999.0f, -3000.0f, 5.0);              // extreme camera positions must not misbehave
        drawBackdrop(99999.0f, 4000.0f, 100.0);
    }
    for (int l = 0; l < 3; l++) CHECK(gSkyLayer[l].body != nullptr);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
