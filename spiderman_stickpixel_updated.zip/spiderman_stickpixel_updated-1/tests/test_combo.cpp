// Flow combo logic: variety, cap, tiers, decay, crash, save/load.   g++ -std=c++17 -O1 -o /tmp/tc tests/test_combo.cpp && /tmp/tc
#include "../src/combo.h"
#include <cmath>
#include <cstdio>
static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static bool nearf(float a, float b) { return fabsf(a - b) < 1e-3f; }
using combo::State; using namespace combo;
static void wait(State& s, float sec, bool ground = false) { for (float t = 0; t < sec; t += 0.01f) update(s, 0.01f, ground); }

int main() {
    // first skill: starts a combo, 1.3x
    { State s; int p = event(s, PERFECT, 20); CHECK(s.count == 1 && nearf(s.mult, 1.3f) && p == 26 + 0); CHECK(s.tier == 0); }
    // variety beats repetition
    { State a, b;
      Kind mix[6] = {PERFECT, TRICK, NEAR_MISS, FAST, LAND, PERFECT};
      for (int i = 0; i < 6; i++) { event(a, mix[i]); wait(a, 1.0f); }
      for (int i = 0; i < 6; i++) { event(b, PERFECT); wait(b, 1.0f); }
      CHECK(a.mult > b.mult + 1.0f); CHECK(a.pts > b.pts * 2);
      CHECK(nearf(b.mult, 1.0f + 0.30f + 5 * 0.05f)); }
    // spam on the same skill inside the cooldown scores nothing
    { State s; event(s, TRICK); int p = event(s, TRICK); CHECK(p == 0 && s.count == 1); }
    // cap
    { State s; for (int i = 0; i < 200; i++) { event(s, (Kind)(i % 5)); wait(s, 1.0f); } CHECK(nearf(s.mult, MAX_MULT) && s.tier == 4); }
    // tiers climb with the multiplier; every milestone (GOOD..LEGENDARY) is announced once, in order
    { State s; int seen = 0, last = 0; bool ordered = true;
      for (int i = 0; i < 30; i++) {
          event(s, (Kind)(i % 5)); wait(s, 1.0f);
          if (s.tierUp) { s.tierUp = false; seen |= 1 << s.tier; if (s.tier != last + 1) ordered = false; last = s.tier; }
      }
      CHECK(seen == 0x1E && ordered); CHECK(std::string(tierName(1)) == "GOOD" && std::string(tierName(4)) == "LEGENDARY"); }
    // inactivity: window, then drain to 1.0x, then the combo is over and recorded
    { State s; event(s, PERFECT); event(s, TRICK); float m0 = s.mult;
      wait(s, 3.0f); CHECK(!s.draining && nearf(s.mult, m0));
      wait(s, 0.85f); CHECK(s.draining && s.mult < m0 && s.mult > 1.0f);
      wait(s, 3.0f); CHECK(s.count == 0 && nearf(s.mult, 1.0f) && s.best.count == 2); }
    // ground rush: the window runs out faster on foot
    { State a, b; event(a, PERFECT); event(b, PERFECT); wait(a, 2.8f, true); wait(b, 2.8f, false); CHECK(a.draining && !b.draining); }
    // a new skill while draining picks the combo back up
    { State s; event(s, PERFECT); event(s, TRICK); wait(s, 3.8f); CHECK(s.draining); float m = s.mult; event(s, NEAR_MISS); CHECK(!s.draining && s.mult > m && s.count == 3); }
    // crash resets at once, keeps the record
    { State s; for (int i = 0; i < 4; i++) { event(s, (Kind)i); wait(s, 1); } int c = s.count; crash(s);
      CHECK(s.count == 0 && nearf(s.mult, 1.0f) && s.tier == 0 && s.best.count == c && s.bestDirty); }
    // new run keeps only the record
    { State s; event(s, PERFECT); event(s, TRICK); crash(s); resetRun(s); CHECK(s.best.count == 2 && s.runBestCount == 0 && s.count == 0); }
    // save / load / bad input
    { Best b; b.count = 14; b.pts = 1234; b.mult = 4.25f; Best o; CHECK(parse(serialize(b).c_str(), o));
      CHECK(o.count == 14 && o.pts == 1234 && nearf(o.mult, 4.25f));
      std::string path = "/tmp/combo_test.txt"; CHECK(saveFile(path, b)); Best l; CHECK(loadFile(path, l) && l.count == 14);
      Best z; CHECK(!parse("garbage", z) && !parse(nullptr, z) && !loadFile("/nonexistent/x", z));
      CHECK(parse("COMBO1 -5 -9 99999", z) && z.count == 0 && z.pts == 0 && nearf(z.mult, MAX_MULT)); }
    printf(fails ? "%d FAILED\n" : "combo tests OK\n", fails);
    return fails ? 1 : 0;
}
