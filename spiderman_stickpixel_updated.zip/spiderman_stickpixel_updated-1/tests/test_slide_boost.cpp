// Sliding gives a +0.1x speed boost (x1.1) that is held for the whole slide.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();
    startRun(); trafficCars.clear(); nextTrafficSpawnX = 1e9f; steer = 1.0f;
    for (int i = 0; i < 120; i++) stepPhysics(1.0f / 120);   // settle at run speed
    P.vx = 400.0f;   // above run speed, so the boost applies to the speed you carry in
    const float before = P.vx;
    slideEdge = true; stepPhysics(1.0f / 120);
    CHECK(P.slideT > 0);
    CHECK(fabsf(P.vx / before - 1.001f) < 0.004f);
    const float boosted = P.vx;
    for (int i = 0; i < 60; i++) stepPhysics(1.0f / 120);    // half a second in: speed is held (only the tiny global air drag applies)
    CHECK(P.slideT > 0 && P.vx >= boosted * 0.95f);
    printf("[slide_boost] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
