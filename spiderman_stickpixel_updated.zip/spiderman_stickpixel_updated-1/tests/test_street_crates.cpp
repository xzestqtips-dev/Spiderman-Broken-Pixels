// Street crates: the runner vaults them one-handed, can land on them, and they never kill.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void blank() { bld.clear(); trafficCars.clear(); trafficSignals.clear(); gCrates.clear(); nextTrafficSpawnX = 1e9f; nextCrateX = 1e9f; addBuilding(true); P = Player(); P.alive = true; steer = 0; swingHeld = false; jumpEdge = slideEdge = jumpRel = false; gTime = 100; gSafeLandUntil = 0; distM = 0; }
static void runner(float x, float vx) { P.x = x; P.px = x; P.y = P.py = -26.0f; P.vx = vx; P.vy = 0; P.onGround = true; P.groundedPrev = true; }

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); initFont(); recalculateDisplayLayout(); buildArt();
    const float W[4] = {28, 46, 28, 60}, H[4] = {22, 24, 36, 24};
    // Every crate shape, at a range of run speeds, is cleared automatically without dying.
    for (int v = 0; v < 4; v++) for (float spd : {230.0f, 330.0f, 460.0f, 700.0f}) {
        blank(); gCrates.push_back({1500.0f, W[v], H[v], v}); runner(1200, spd);
        bool vaulted = false, vaultFrame = false;
        for (int i = 0; i < 1200 && P.alive && P.x < 1500 + W[v] + 120; i++) {
            stepPhysics(1.0f / 120);
            if (P.vaultOneT > 0) { vaulted = true; if (pickFrame() == F_VAULT) vaultFrame = true; }
        }
        CHECK(P.alive && !P.deadGround);
        CHECK(vaulted && vaultFrame);
        CHECK(P.x > 1500 + W[v] + 8.0f);
    }
    // After the vault the runner is back on the street running normally, and a double jump is still available.
    blank(); gCrates.push_back({1500.0f, 28, 22, 0}); runner(1250, 230);
    for (int i = 0; i < 1200 && P.alive && P.x < 1800; i++) stepPhysics(1.0f / 120);
    CHECK(P.alive && P.onGround && !P.usedAir && P.vaultOneT <= 0 && P.vx > 150);
    // A normal jump over a crate works too, and doesn't trigger the vault.
    blank(); gCrates.push_back({1500.0f, 28, 22, 0}); runner(1250, 230); bool anyVault = false;
    for (int i = 0; i < 1200 && P.alive && P.x < 1800; i++) { if (P.x > 1380 && P.x < 1385) jumpEdge = true; stepPhysics(1.0f / 120); if (P.vaultOneT > 0) anyVault = true; }
    CHECK(P.alive && P.x >= 1800 && !anyVault);
    // Landing from above puts you on top of the crate.
    blank(); gCrates.push_back({1500.0f, 46, 24, 1}); P.x = 1520; P.px = 1520; P.y = P.py = -150; P.vx = 0; P.vy = 0; P.onGround = false;
    for (int i = 0; i < 240 && !P.onGround; i++) stepPhysics(1.0f / 120);
    CHECK(P.alive && P.onGround && fabsf(P.y + 26.0f - (STREET_GROUND_Y - 24.0f)) < 0.5f);
    // Clipping a crate in mid-air bumps you off; it never kills.
    blank(); gCrates.push_back({1500.0f, 60, 24, 3}); P.x = 1480; P.px = 1480; P.y = P.py = -30; P.vx = 300; P.vy = -100; P.onGround = false; P.groundedPrev = false;
    for (int i = 0; i < 20; i++) stepPhysics(1.0f / 120);
    CHECK(P.alive && P.x <= 1500.0f);
    for (int i = 0; i < 600; i++) stepPhysics(1.0f / 120);   // it then lands and vaults the crate like any other: still alive
    CHECK(P.alive);
    // Crates don't break air tricks: a trick won't start if it would end inside one.
    blank(); gCrates.push_back({1500.0f, 28, 36, 2});
    P.x = 1400; P.px = 1400; P.y = P.py = -60; P.vx = 300; P.vy = 100; P.onGround = false; P.trickReady = true;
    CHECK(!trickFits(0.5f));
    // Poses: vault progresses through distinct poses and every new frame has a finite pose.
    for (int f : {(int)F_VAULT, (int)F_ROLL, (int)F_BACKFLIP, (int)F_FLIPOPEN}) for (float ph : {0.0f, 0.25f, 0.5f, 0.75f, 1.0f}) {
        StkPose p = stkMakePose(f, ph, 0.5f, 0, 0);
        bool fin = true; for (auto m : STK_F) if (!std::isfinite(p.*m)) fin = false;
        CHECK(fin);
    }
    CHECK(stkMakePose(F_VAULT, 0.0f, 0, 0, 0).upF != stkMakePose(F_VAULT, 0.5f, 0, 0, 0).upF);
    // Crate collisions leave street vehicles alone: running into a car's side is still fatal.
    blank(); runner(100, 230); { TrafficCar c; c.x = 160; c.speed = 0; c.maxSpeed = 0; c.width = 70; c.height = 30; c.type = 1; c.lane = 0; c.dir = 1; c.color = 0; c.id = 9; trafficCars.push_back(c); }
    for (int i = 0; i < 240 && P.alive; i++) stepPhysics(1.0f / 120);
    CHECK(!P.alive);
    printf("[street_crates] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
