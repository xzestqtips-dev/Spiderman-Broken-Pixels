// Fall damage on the street: small drops free, big drops hurt (stumble), huge drops fatal; a roll absorbs some impact.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void blank() { bld.clear(); trafficCars.clear(); trafficSignals.clear(); gCrates.clear(); nextTrafficSpawnX = 1e9f; nextCrateX = 1e9f; addBuilding(true); P = Player(); P.alive = true; steer = 0; swingHeld = false; jumpEdge = slideEdge = jumpRel = false; gTime = 100; gSafeLandUntil = 0; gTrickMsg[0] = 0; gTrickMsgT = 0; gTrickBad = false; }
static void step(int n) { for (int i = 0; i < n && P.alive; i++) { updateTraffic(1.0f / 120); stepPhysics(1.0f / 120); } }
// Drop from a height (px of free fall above the street) well clear of the opening rooftop.
static void drop(float h, float vx = 0) { P.x = 1400; P.y = -h - 26.0f; P.px = P.x; P.py = P.y; P.vx = vx; P.vy = 0; P.onGround = false; P.groundedPrev = false; }

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); initFont(); recalculateDisplayLayout(); buildArt();
    // Pure logic.
    CHECK(fall::classify(0, false) == fall::NONE && fall::classify(fall::SAFE_VY - 1, false) == fall::NONE);
    CHECK(fall::classify(fall::SAFE_VY, false) == fall::HARD && fall::classify(fall::FATAL_VY - 1, false) == fall::HARD);
    CHECK(fall::classify(fall::FATAL_VY, false) == fall::FATAL && fall::classify(4000, true) == fall::FATAL);
    CHECK(fall::classify(900, true) == fall::NONE && fall::classify(900, false) == fall::HARD);   // a roll helps
    CHECK(fall::classify(1300, true) == fall::HARD && fall::classify(1300, false) == fall::FATAL);
    CHECK(fall::canRoll(600, true, false) && fall::canRoll(600, false, true) && !fall::canRoll(600, false, false) && !fall::canRoll(300, true, true));
    CHECK(fall::classify(1300, false, 1.3f) == fall::HARD && fall::classify(1500, false, 1.3f) == fall::FATAL);   // tolerance scales both thresholds
    CHECK(fall::SAFE_VY < fall::FATAL_VY && fall::ROLL_RELIEF < 1.0f);

    // Game: a short drop is free.
    blank(); drop(120); step(240);
    CHECK(P.alive && P.onGround && !P.deadGround && strcmp(gTrickMsg, "HARD LANDING") != 0);
    // A mid-size drop hurts: you survive, lose speed, the combo is broken.
    blank(); drop(320, 300); P.vx = 300; combo::resetRun(gCombo); step(400);
    CHECK(P.alive && P.onGround && !P.deadGround);
    CHECK(strcmp(gTrickMsg, "HARD LANDING") == 0 || gTrickMsgT <= 0);   // message may have faded by now
    blank(); drop(320, 300);
    bool hard = false; float vxBefore = 300;
    for (int i = 0; i < 400 && P.alive; i++) { updateTraffic(1.0f / 120); const bool air = !P.onGround; stepPhysics(1.0f / 120); if (air && P.onGround && P.landT > 0.5f) { hard = true; CHECK(P.vx < vxBefore * 0.6f); break; } }
    CHECK(hard && P.alive);
    // A huge drop is fatal, with the ground-death flag.
    blank(); drop(700); step(400);
    CHECK(!P.alive && P.deadGround);
    // A roll (SLIDE buffered before touchdown) absorbs enough to turn a hard landing into a clean one.
    blank(); drop(250); P.slideBuf = 3.0f; step(400);
    CHECK(P.alive && !P.deadGround);
    bool rolled = false;
    blank(); drop(250); P.slideBuf = 3.0f;
    for (int i = 0; i < 400 && P.alive; i++) { updateTraffic(1.0f / 120); stepPhysics(1.0f / 120); if (P.rollT > 0) { rolled = true; CHECK(pickFrame() == F_ROLL); break; } }
    CHECK(rolled);
    // ...and it can also turn a fatal fall into a survivable hard landing.
    blank(); drop(520); P.slideBuf = 3.0f; step(500);
    CHECK(P.alive);
    // Landing on a vehicle roof and on the opening rooftop never hurts, however high the drop.
    blank(); { TrafficCar c; c.x = 1400; c.speed = 0; c.maxSpeed = 0; c.width = 70; c.height = 30; c.type = 1; c.lane = 0; c.dir = 1; c.color = 0; c.id = 7; trafficCars.push_back(c); }
    drop(500); for (int i = 0; i < 400 && P.alive && !P.onGround; i++) { updateTraffic(1.0f / 120); stepPhysics(1.0f / 120); }
    CHECK(P.alive && P.onGround && P.rideId == 7);
    blank(); P.x = 300; P.y = -900; P.px = 300; P.py = -900; P.vx = 0; P.vy = 0;
    for (int i = 0; i < 600 && P.alive && !P.onGround; i++) stepPhysics(1.0f / 120);
    CHECK(P.alive && P.onGround && P.y < -500.0f);   // standing on the opening roof, not the street
    // Menu hand-off forgiveness is unchanged: no damage in the first landing.
    blank(); gSafeLandUntil = gTime + 5; drop(700); step(400);
    CHECK(P.alive);
    printf("[fall_damage] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
