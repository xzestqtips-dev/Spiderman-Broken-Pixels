# Stickman: Pixel City

A small C++17 endless-runner built with SDL2. The game runs in landscape, with a procedurally generated night-time city, rooftop running, jumping, and rope-swinging.

The character is drawn from simple shapes at runtime, so the game does not need a sprite sheet.

![Stickman poses](docs/stickman-poses.png)

![Run cycle](docs/run-cycle.gif)

## Features

- Rooftops and a scrolling city skyline
- Running, jumping, double-jumping, and rope swings
- Touch controls for phones; mouse controls for desktop testing
- Pause screen and saved high score
- Pixel-art visuals generated in code

## Controls

| Action | Touch | Desktop |
| --- | --- | --- |
| Move | Drag on the left side of the screen | Click and drag on the left side |
| Jump / double jump | Tap **JUMP** | Click **JUMP** |
| Swing | Hold **SWING** while airborne near an anchor | Hold the mouse button on **SWING** |
| Pause | Device back button | `Esc` |

## Build on desktop

You need a C++17 compiler, CMake 3.16 or newer, and SDL2 development files.

On Ubuntu or Debian:

```bash
sudo apt update
sudo apt install build-essential cmake libsdl2-dev
cmake -S . -B build
cmake --build build
./build/stickman_pixel_city
```

On macOS, install CMake and SDL2 with Homebrew, then run the same CMake commands.

## Build an Android APK with GitHub Actions

This repository includes a workflow at `.github/workflows/android-release.yml`. It builds an installable debug APK on GitHub's hosted runner, so you do not need to install the Android SDK locally.

1. Create a new repository on GitHub.
2. Upload these project files to the repository and push them to the default branch.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Android APK** and choose **Run workflow**.
5. When the run finishes successfully, open that run and download the `stickman-pixel-city-apk` artifact. Extract the downloaded ZIP to find the APK.

You can also trigger a build by pushing a commit. The workflow uses SDL's Android project and downloads the SDL source during the build.

The workflow currently produces a **debug-signed APK** for testing. Before publishing on Google Play, configure a release signing key securely with GitHub Actions secrets and build a properly signed release APK. Never commit a keystore or its password to the repository.

## Customising the character

The character drawing and pose code is in `src/main.cpp`. Search for the `STICKMAN BEGIN` and `STICKMAN END` markers to find the main customisation section.

## Credits

The stick-figure presentation takes inspiration from *Animator vs. Animation* by Alan Becker. This is an unofficial fan project and is not affiliated with or endorsed by Alan Becker or Alan Becker Productions.

## License

See [LICENSE](LICENSE).
