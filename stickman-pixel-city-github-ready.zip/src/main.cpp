// ============================================================================
//  STICKMAN: PIXEL CITY  -  mobile landscape pixel-art endless runner
//  C++17 + SDL2.  Single file.  World art, fonts, audio and the stickman player are all
//  generated in code, so there are no asset files to ship.  The stickman is drawn in the
//  style of Alan Becker's Animator vs. Animation.  Fan-made tribute, not affiliated.
// ============================================================================
#include <SDL.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <string>
#include <vector>

typedef uint32_t u32;
static const float PI = 3.14159265f;
static float clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float lerpf(float a, float b, float t) { return a + (b - a) * t; }
static int pmod(int a, int m) { a %= m; return a < 0 ? a + m : a; }
static u32 hash3(u32 a, u32 b, u32 c) {
    u32 h = a * 374761393u + b * 668265263u + c * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}
struct Rng {
    u32 s;
    explicit Rng(u32 seed = 1) : s(seed ? seed : 1) {}
    u32 next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float f() { return (next() & 0xFFFFFF) / 16777216.0f; }
    int range(int a, int b) { if (b < a) b = a; return a + (int)(f() * (b - a + 1)); }
};

// ============================================================================
//  DISPLAY  (pixel-perfect integer scaling, adapts to any phone resolution)
// ============================================================================
static SDL_Window* gWin = nullptr;
static SDL_Renderer* gRen = nullptr;
static SDL_Texture* gTarget = nullptr;
static int OUTW = 1280, OUTH = 720;   // real output pixels
static int W = 640, H = 360, SC = 3;  // internal resolution + integer scale
static int OFFX = 0, OFFY = 0;        // letterbox offset in output pixels
static bool portrait = false;
static float safeL = 14, safeR = 14, safeT = 8, safeB = 10;
static float minTouch = 40;           // >= ~48dp expressed in internal pixels

static void recalcDisplay() {
    SDL_GetRendererOutputSize(gRen, &OUTW, &OUTH);
    portrait = OUTH > OUTW;
    int minD = std::min(OUTW, OUTH);
    SC = std::max(1, (int)lroundf(minD / 360.0f));
    W = std::max(1, OUTW / SC);
    H = std::max(1, OUTH / SC);
    OFFX = (OUTW - W * SC) / 2;
    OFFY = (OUTH - H * SC) / 2;
    if (gTarget) SDL_DestroyTexture(gTarget);
    gTarget = SDL_CreateTexture(gRen, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, W, H);
    // mobile safe area (notches / rounded corners): conservative margins
    safeL = safeR = std::max(14.0f, W * 0.035f);
    safeT = 8; safeB = 10;
    float ddpi = 0;
    if (SDL_GetDisplayDPI(0, &ddpi, nullptr, nullptr) != 0 || ddpi < 80) ddpi = 400;
    minTouch = clampf(48.0f * ddpi / 160.0f / (float)SC, 36.0f, 56.0f);
}

// ============================================================================
//  DRAW HELPERS
// ============================================================================
static void col(u32 c, int a = 255) {
    SDL_SetRenderDrawColor(gRen, (c >> 16) & 255, (c >> 8) & 255, c & 255, (Uint8)a);
}
static void rect(int x, int y, int w, int h, u32 c, int a = 255) {
    if (w <= 0 || h <= 0) return;
    col(c, a);
    SDL_Rect r = {x, y, w, h};
    SDL_RenderFillRect(gRen, &r);
}
static void disc(int cx, int cy, int r, u32 c, int a = 255) {
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        rect(cx - dx, cy + dy, dx * 2 + 1, 1, c, a);
    }
}
static void line(float x0, float y0, float x1, float y1, u32 c, int a = 255) {
    col(c, a);
    SDL_RenderDrawLine(gRen, (int)x0, (int)y0, (int)x1, (int)y1);
}

// ---- 5x7 bitmap font ----
struct Glyph { char c; uint8_t r[7]; };
static const Glyph FONT[] = {
    {'A',{0x0E,0x11,0x11,0x1F,0x11,0x11,0x11}}, {'B',{0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E}},
    {'C',{0x0E,0x11,0x10,0x10,0x10,0x11,0x0E}}, {'D',{0x1E,0x11,0x11,0x11,0x11,0x11,0x1E}},
    {'E',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}}, {'F',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x10}},
    {'G',{0x0E,0x11,0x10,0x17,0x11,0x11,0x0F}}, {'H',{0x11,0x11,0x11,0x1F,0x11,0x11,0x11}},
    {'I',{0x0E,0x04,0x04,0x04,0x04,0x04,0x0E}}, {'J',{0x07,0x02,0x02,0x02,0x02,0x12,0x0C}},
    {'K',{0x11,0x12,0x14,0x18,0x14,0x12,0x11}}, {'L',{0x10,0x10,0x10,0x10,0x10,0x10,0x1F}},
    {'M',{0x11,0x1B,0x15,0x15,0x11,0x11,0x11}}, {'N',{0x11,0x11,0x19,0x15,0x13,0x11,0x11}},
    {'O',{0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'P',{0x1E,0x11,0x11,0x1E,0x10,0x10,0x10}},
    {'Q',{0x0E,0x11,0x11,0x11,0x15,0x12,0x0D}}, {'R',{0x1E,0x11,0x11,0x1E,0x14,0x12,0x11}},
    {'S',{0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E}}, {'T',{0x1F,0x04,0x04,0x04,0x04,0x04,0x04}},
    {'U',{0x11,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'V',{0x11,0x11,0x11,0x11,0x11,0x0A,0x04}},
    {'W',{0x11,0x11,0x11,0x15,0x15,0x15,0x0A}}, {'X',{0x11,0x11,0x0A,0x04,0x0A,0x11,0x11}},
    {'Y',{0x11,0x11,0x11,0x0A,0x04,0x04,0x04}}, {'Z',{0x1F,0x01,0x02,0x04,0x08,0x10,0x1F}},
    {'0',{0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}}, {'1',{0x04,0x0C,0x04,0x04,0x04,0x04,0x0E}},
    {'2',{0x0E,0x11,0x01,0x02,0x04,0x08,0x1F}}, {'3',{0x1F,0x02,0x04,0x02,0x01,0x11,0x0E}},
    {'4',{0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}}, {'5',{0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E}},
    {'6',{0x06,0x08,0x10,0x1E,0x11,0x11,0x0E}}, {'7',{0x1F,0x01,0x02,0x04,0x08,0x08,0x08}},
    {'8',{0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}}, {'9',{0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C}},
    {'.',{0,0,0,0,0,0x0C,0x0C}}, {':',{0,0x0C,0x0C,0,0x0C,0x0C,0}},
    {'-',{0,0,0,0x1F,0,0,0}}, {'/',{0x01,0x02,0x02,0x04,0x08,0x08,0x10}},
    {'!',{0x04,0x04,0x04,0x04,0x04,0,0x04}}, {'?',{0x0E,0x11,0x01,0x02,0x04,0,0x04}},
    {'+',{0,0x04,0x04,0x1F,0x04,0x04,0}}, {',',{0,0,0,0,0x0C,0x04,0x08}},
    {'<',{0x02,0x04,0x08,0x10,0x08,0x04,0x02}}, {'>',{0x08,0x04,0x02,0x01,0x02,0x04,0x08}},
};
static uint8_t gGl[128][7];
static void initFont() {
    memset(gGl, 0, sizeof(gGl));
    for (const Glyph& g : FONT) memcpy(gGl[(int)g.c], g.r, 7);
}
static int textW(const char* s, int sc) { return (int)strlen(s) * 6 * sc - sc; }
static void text(const char* s, int x, int y, int sc, u32 c, int a = 255) {
    static std::vector<SDL_Rect> rs;
    rs.clear();
    int cx = x;
    for (; *s; ++s) {
        unsigned char ch = (unsigned char)toupper((unsigned char)*s);
        if (ch < 128) {
            for (int r = 0; r < 7; r++) {
                uint8_t bits = gGl[ch][r];
                for (int b = 0; b < 5; b++)
                    if (bits & (16 >> b)) rs.push_back({cx + b * sc, y + r * sc, sc, sc});
            }
        }
        cx += 6 * sc;
    }
    col(c, a);
    if (!rs.empty()) SDL_RenderFillRects(gRen, rs.data(), (int)rs.size());
}
static void textShadow(const char* s, int x, int y, int sc, u32 c, u32 sh = 0x05060F) {
    text(s, x + std::max(1, sc / 2), y + std::max(1, sc / 2), sc, sh, 220);
    text(s, x, y, sc, c);
}
static void textC(const char* s, int cx, int y, int sc, u32 c) { textShadow(s, cx - textW(s, sc) / 2, y, sc, c); }
static int fitScale(const char* s, int maxW, int maxSc) {
    int sc = maxSc;
    while (sc > 1 && textW(s, sc) > maxW) sc--;
    return sc;
}

// ============================================================================
//  PIXEL IMAGES / PROCEDURAL ART
// ============================================================================
struct Img {
    int w, h;
    std::vector<u32> p;
    Img(int w_, int h_) : w(w_), h(h_), p((size_t)w_ * h_, 0) {}
    void set(int x, int y, u32 c) { if (x >= 0 && y >= 0 && x < w && y < h) p[(size_t)y * w + x] = c; }
    u32 get(int x, int y) const { return (x >= 0 && y >= 0 && x < w && y < h) ? p[(size_t)y * w + x] : 0; }
    void fill(int x, int y, int ww, int hh, u32 c) {
        for (int yy = y; yy < y + hh; yy++) for (int xx = x; xx < x + ww; xx++) set(xx, yy, c);
    }
};
static SDL_Texture* mkTex(const Img& im) {
    SDL_Texture* t = SDL_CreateTexture(gRen, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC, im.w, im.h);
    SDL_UpdateTexture(t, nullptr, im.p.data(), im.w * 4);
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    return t;
}

// ---- facade tiles (6 architectural styles x 3 window-light variants) ----
static SDL_Texture* gTile[6][3];
static SDL_Texture* gFar[3];

static u32 litColor(Rng& r, u32 off) {
    float f = r.f();
    if (f < 0.28f) return 0xFFFFD98A;
    if (f < 0.36f) return 0xFF8FE3FF;
    if (f < 0.40f) return 0xFFFF9CB8;
    return off;
}
static void windowRect(Img& im, Rng& r, int x, int y, int w, int h, u32 off, u32 frame) {
    im.fill(x - 1, y - 1, w + 2, h + 2, frame);
    u32 c = litColor(r, off);
    im.fill(x, y, w, h, c);
    if (c != off) im.fill(x, y + h - 2, w, 2, 0xFFE0B060);  // warm floor glow
    else im.fill(x, y, w, 1, off + 0x00080808);
}
static Img makeTile(int st, int var) {
    Img im(64, 64);
    Rng r(1234u + st * 97u + var * 7919u);
    switch (st) {
        case 0:  // glass tower
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                u32 c = 0xFF23405E;
                if (((x + y) >> 3) % 7 == 0) c = 0xFF2C5070;
                if (x % 16 == 0 || y % 16 == 0) c = 0xFF111F32;
                im.set(x, y, c);
            }
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) {
                u32 l = litColor(r, 0);
                if (l) { im.fill(i * 16 + 1, j * 16 + 1, 15, 15, l); im.fill(i * 16 + 1, j * 16 + 12, 15, 4, 0xFFC89A50); }
            }
            break;
        case 1:  // office tower
            im.fill(0, 0, 64, 64, 0xFF3A3D4F);
            for (int x = 0; x < 64; x += 16) im.fill(x, 0, 1, 64, 0xFF2E3141);
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++)
                windowRect(im, r, 3 + i * 16, 3 + j * 16, 10, 12, 0xFF1B2030, 0xFF22242F);
            break;
        case 2:  // brick apartments
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                int row = y / 4; u32 c = 0xFF6B3A35;
                if (y % 4 == 3 || (x + (row % 2) * 4) % 8 == 7) c = 0xFF4A2826;
                else if ((x * 7 + y * 13) % 11 == 0) c = 0xFF7A433C;
                im.set(x, y, c);
            }
            for (int j = 0; j < 2; j++) for (int i = 0; i < 4; i++) {
                int x = i * 16 + 4, y = j * 32 + 6;
                im.fill(x - 1, y - 2, 10, 2, 0xFF9A8A7A);
                windowRect(im, r, x, y, 8, 16, 0xFF1A1620, 0xFF2A1A1A);
                im.fill(x - 1, y + 17, 10, 2, 0xFF9A8A7A);
            }
            break;
        case 3:  // residential high-rise
            im.fill(0, 0, 64, 64, 0xFF4F4866);
            for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) {
                windowRect(im, r, 4 + i * 16, 3 + j * 16, 8, 9, 0xFF221E30, 0xFF2B263A);
                im.fill(i * 16 + 1, j * 16 + 13, 14, 2, 0xFF2B263A);
                im.fill(i * 16 + 1, j * 16 + 12, 14, 1, 0xFF7A7298);
            }
            break;
        case 4:  // industrial
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                u32 c = (x % 4 < 2) ? 0xFF313745 : 0xFF2A2F3B;
                if (y >= 28 && y < 32) c = (((x + y) / 4) % 2) ? 0xFFB8872A : 0xFF1A1A1A;
                im.set(x, y, c);
            }
            windowRect(im, r, 6, 10, 12, 6, 0xFF14171F, 0xFF1E222C);
            windowRect(im, r, 38, 10, 12, 6, 0xFF14171F, 0xFF1E222C);
            windowRect(im, r, 6, 44, 12, 6, 0xFF14171F, 0xFF1E222C);
            windowRect(im, r, 38, 44, 12, 6, 0xFF14171F, 0xFF1E222C);
            break;
        default:  // construction frame
            im.fill(0, 0, 64, 64, 0xFF121828);
            for (int k = 0; k < 2; k++) {
                im.fill(k * 32 + 3, 3, 29, 3, 0xFF4A4E5C);
                for (int i = 0; i < 29; i++) { im.set(k * 32 + 3 + i, 6 + i, 0xFF7A4818); im.set(k * 32 + 31 - i, 6 + i, 0xFF7A4818); }
            }
            for (int x : {0, 32}) { im.fill(x, 0, 3, 64, 0xFF9A5B22); im.fill(x, 0, 1, 64, 0xFFC9822F); }
            for (int y : {0, 32}) { im.fill(0, y, 64, 3, 0xFF9A5B22); im.fill(0, y, 64, 1, 0xFFC9822F); }
            if (r.f() < 0.7f) { im.fill(12, 14, 3, 3, 0xFFFFE9A0); im.fill(11, 17, 5, 1, 0xFF8A7430); }
            if (r.f() < 0.5f) { im.fill(46, 46, 3, 3, 0xFFFFE9A0); im.fill(45, 49, 5, 1, 0xFF8A7430); }
            break;
    }
    return im;
}
static Img makeFar(int var) {
    Img im(32, 32);
    Rng r(777u + var * 31u);
    im.fill(0, 0, 32, 32, 0xFF1B2144);
    for (int gy = 0; gy < 5; gy++) for (int gx = 0; gx < 5; gx++) {
        float f = r.f();
        u32 c = f < 0.22f ? 0xFFB8A56A : (f < 0.30f ? 0xFF6A92B8 : 0xFF161B38);
        im.fill(gx * 6 + 2, gy * 6 + 3, 2, 2, c);
    }
    return im;
}

// ==== STICKMAN BEGIN ====
// ---- Stickman player (Animator-vs-Animation style, Spider-Man moveset) -----------------
//  No sprite files: the player is a skeleton posed from joint angles every frame.
//  Smoothness comes from three things:
//    1. continuous cycles - run / idle / swing poses are computed from a continuous phase,
//       not picked from a handful of stepped frames;
//    2. pose smoothing - the displayed pose chases the target pose with critically-damped
//       exponential easing, so every state change (jump -> fall -> swing -> dive -> land)
//       flows into the next instead of snapping;
//    3. anti-aliased capsule rendering - limbs are rasterised with analytic coverage into a
//       small RGBA texture, so rotated limbs and the round head have soft, clean edges.
//  Coordinates are relative to the body centre (Player::y), +x = facing direction, y grows
//  downward; the soles sit STK_FEET_Y pixels below the body centre.
//  Change STK_BODY / STK_OUTLINE to recolour him (orange 0xFF8A1E is the "Second Coming").
enum Frame {
    F_IDLE,      // breathing loop (phase driven)
    F_RUN,       // run cycle (phase driven)
    F_SHOOT,     // thwip: web arm thrown up and forward
    F_ATTACH,    // web caught, body snaps taut
    F_SWING,     // swing, blended between "trailing" and "reaching" by swing position
    F_JUMP,      // rising, lead knee up
    F_FALL,      // dropping, limbs spread
    F_FLIP,      // double-jump tuck somersault
    F_RELEASE,   // let go of the web: superhero dive
    F_LAND,      // normal landing squash
    F_HERO,      // hard fall: three-point superhero landing
    F_HIT,       // knocked back
    F_DEAD,      // limp
    F_COUNT
};
static const int STK_FEET_Y = 26;               // soles, relative to the body centre
static const u32 STK_BODY = 0x0B0B12;           // limb colour
static const u32 STK_OUTLINE = 0xE8ECFF;        // thin light rim so he reads on the night sky

enum StkJoint { J_HIP, J_NECK, J_HEAD, J_KNF, J_FTF, J_KNB, J_FTB, J_ELF, J_HNF, J_ELB, J_HNB, J_N };
struct StkPose {            // angles in degrees measured from "straight down", + = toward facing side
    float hipX = 0, hipY = 2, lean = 0, tilt = 0;
    float thF = 0, shF = 0, thB = 0, shB = 0;   // F = front/near limbs, B = back/far limbs
    float upF = 0, foF = 0, upB = 0, foB = 0;
    bool snap = false;                           // true: lower the hips until the lowest foot touches the ground
};
static const float STK_TORSO = 16, STK_THIGH = 12, STK_SHIN = 12, STK_UARM = 8, STK_FARM = 8, STK_HEADD = 6;

static void stkSolve(const StkPose& p, float jx[J_N], float jy[J_N]) {
    auto dir = [](float deg, float len, float& dx, float& dy) { float a = deg * PI / 180.0f; dx = sinf(a) * len; dy = cosf(a) * len; };
    float dx, dy, hy = p.hipY;
    for (int pass = 0; pass < 2; pass++) {
        jx[J_HIP] = p.hipX; jy[J_HIP] = hy;
        dir(p.thF, STK_THIGH, dx, dy); jx[J_KNF] = jx[J_HIP] + dx; jy[J_KNF] = jy[J_HIP] + dy;
        dir(p.shF, STK_SHIN, dx, dy);  jx[J_FTF] = jx[J_KNF] + dx; jy[J_FTF] = jy[J_KNF] + dy;
        dir(p.thB, STK_THIGH, dx, dy); jx[J_KNB] = jx[J_HIP] + dx; jy[J_KNB] = jy[J_HIP] + dy;
        dir(p.shB, STK_SHIN, dx, dy);  jx[J_FTB] = jx[J_KNB] + dx; jy[J_FTB] = jy[J_KNB] + dy;
        if (p.snap && pass == 0) hy += (float)STK_FEET_Y - std::max(jy[J_FTF], jy[J_FTB]);
        else break;
    }
    dir(180.0f - p.lean, STK_TORSO, dx, dy);
    jx[J_NECK] = jx[J_HIP] + dx; jy[J_NECK] = jy[J_HIP] + dy;
    dir(180.0f - p.lean - p.tilt, STK_HEADD, dx, dy);
    jx[J_HEAD] = jx[J_NECK] + dx; jy[J_HEAD] = jy[J_NECK] + dy;
    dir(p.upF, STK_UARM, dx, dy); jx[J_ELF] = jx[J_NECK] + dx; jy[J_ELF] = jy[J_NECK] + dy;
    dir(p.foF, STK_FARM, dx, dy); jx[J_HNF] = jx[J_ELF] + dx;  jy[J_HNF] = jy[J_ELF] + dy;
    dir(p.upB, STK_UARM, dx, dy); jx[J_ELB] = jx[J_NECK] + dx; jy[J_ELB] = jy[J_NECK] + dy;
    dir(p.foB, STK_FARM, dx, dy); jx[J_HNB] = jx[J_ELB] + dx;  jy[J_HNB] = jy[J_ELB] + dy;
}

// linear blend of two poses (also used by the smoother)
static StkPose stkBlend(const StkPose& a, const StkPose& b, float t) {
    StkPose o;
    o.hipX = lerpf(a.hipX, b.hipX, t); o.hipY = lerpf(a.hipY, b.hipY, t);
    o.lean = lerpf(a.lean, b.lean, t); o.tilt = lerpf(a.tilt, b.tilt, t);
    o.thF = lerpf(a.thF, b.thF, t); o.shF = lerpf(a.shF, b.shF, t);
    o.thB = lerpf(a.thB, b.thB, t); o.shB = lerpf(a.shB, b.shB, t);
    o.upF = lerpf(a.upF, b.upF, t); o.foF = lerpf(a.foF, b.foF, t);
    o.upB = lerpf(a.upB, b.upB, t); o.foB = lerpf(a.foB, b.foB, t);
    o.snap = t < 0.5f ? a.snap : b.snap;
    return o;
}

// one leg of the run cycle: phase in radians (0 = thigh vertical, moving forward)
static void stkRunLeg(float ph, float& thigh, float& shin) {
    thigh = 46.0f * sinf(ph);
    float k = std::max(0.0f, cosf(ph));
    shin = thigh - (12.0f + 88.0f * powf(k, 1.4f));
}
// phase = cycles (continuous, any value);  swing = 0 (behind the anchor) .. 1 (past the anchor)
static StkPose stkMakePose(int f, float phase, float swing) {
    StkPose p;
    switch (f) {
        case F_IDLE: {   // slow breathing, weight shifting, loose arms
            float b = sinf(phase * 2.0f * PI), s = sinf(phase * PI);
            p.snap = true; p.lean = 3 + 1.5f * b; p.tilt = -2 + b;
            p.thF = 9 + s; p.shF = 7; p.thB = -9 - s; p.shB = -7;
            p.upF = 14 + 3 * b; p.foF = 50 + 4 * b; p.upB = -6 - 2 * b; p.foB = 14 + 2 * b;
            break; }
        case F_RUN: {    // Alan Becker-style loose, forward-leaning run: big arm swing, high knee, long stride
            float ph = phase * 2.0f * PI;
            p.snap = true; p.lean = 14 + 1.5f * sinf(ph * 2.0f); p.tilt = -6;
            stkRunLeg(ph, p.thF, p.shF);
            stkRunLeg(ph + PI, p.thB, p.shB);
            p.upF = 50.0f * sinf(ph + PI);  p.foF = p.upF + 85;     // arms swing against the legs, elbows bent
            p.upB = 50.0f * sinf(ph);       p.foB = p.upB + 85;
            break; }
        case F_SHOOT:   // thwip: airborne, web arm thrown up and forward, free arm back for balance
            p.hipY = 0; p.lean = 8; p.thF = 62; p.shF = 8; p.thB = -22; p.shB = -68;
            p.upF = 146; p.foF = 150; p.upB = -55; p.foB = -25; break;
        case F_ATTACH:  // web caught: arm straight up, legs hang, body stretched
            p.hipY = 3; p.lean = 0; p.thF = 18; p.shF = 6; p.thB = -12; p.shB = -42;
            p.upF = 176; p.foF = 176; p.upB = 35; p.foB = 65; break;
        case F_SWING: { // lerp between "swinging up to the anchor" (legs trail) and "past it" (legs reach)
            StkPose a, b;
            a.hipY = 3; a.lean = 4; a.thF = -8; a.shF = -26; a.thB = -24; a.shB = -48;
            a.upF = 177; a.foF = 177; a.upB = -42; a.foB = -62;
            b.hipY = 3; b.lean = -4; b.thF = 40; b.shF = 12; b.thB = 14; b.shB = -10;
            b.upF = 177; b.foF = 177; b.upB = 75; b.foB = 105;
            p = stkBlend(a, b, clampf(swing, 0.0f, 1.0f)); break; }
        case F_JUMP:    // rising: lead knee up, trailing leg kicked back
            p.hipY = -2; p.lean = 10; p.thF = 78; p.shF = 6; p.thB = -24; p.shB = -76;
            p.upF = 118; p.foF = 138; p.upB = -68; p.foB = -30; break;
        case F_FALL:    // dropping: limbs spread
            p.hipY = 0; p.lean = 0; p.thF = 32; p.shF = 6; p.thB = -22; p.shB = -34;
            p.upF = 112; p.foF = 100; p.upB = -104; p.foB = -112; break;
        case F_FLIP:    // double-jump somersault: tight tuck, arms hugging the shins
            p.hipY = 2; p.lean = 38; p.tilt = -10; p.thF = 112; p.shF = -30; p.thB = 98; p.shB = -42;
            p.upF = 70; p.foF = 118; p.upB = 55; p.foB = 108; break;
        case F_RELEASE: // let go of the web: superhero dive
            p.hipX = -3; p.hipY = 3; p.lean = 55; p.thF = -50; p.shF = -60; p.thB = -58; p.shB = -62;
            p.upF = 128; p.foF = 130; p.upB = 122; p.foB = 125; break;
        case F_LAND:    // squash on landing
            p.snap = true; p.lean = 36; p.tilt = -12; p.thF = 78; p.shF = -32; p.thB = 56; p.shB = -58;
            p.upF = 55; p.foF = 92; p.upB = 28; p.foB = 70; break;
        case F_HERO:    // three-point landing: one knee down, one fist on the ground, other arm cocked back
            p.snap = true; p.lean = 44; p.tilt = -24; p.thF = 88; p.shF = -4; p.thB = -34; p.shB = -118;
            p.upF = 52; p.foF = 22; p.upB = -48; p.foB = -78; break;
        case F_HIT:     // knocked back
            p.hipY = 1; p.lean = -22; p.tilt = 10; p.thF = 40; p.shF = 12; p.thB = -30; p.shB = -8;
            p.upF = 140; p.foF = 162; p.upB = 98; p.foB = 122; break;
        default:        // F_DEAD: limp, spread out (the game spins him)
            p.hipY = 1; p.lean = 0; p.tilt = 12; p.thF = 36; p.shF = 40; p.thB = -36; p.shB = -40;
            p.upF = 100; p.foF = 78; p.upB = -100; p.foB = -78; break;
    }
    return p;
}

// ---- pose smoothing --------------------------------------------------------------------
struct StkAnim { StkPose cur; bool init = false; double last = 0; int lastFrame = -1; };
static double stkNow() { return (double)SDL_GetTicks() / 1000.0; }
// how fast the displayed pose chases the target (1/seconds); cycles must track tightly, one-shots can float
static float stkRate(int from, int to) {
    if (to == F_RUN || to == F_IDLE) return (from == to) ? 60.0f : 22.0f;
    if (to == F_SWING) return 30.0f;
    if (to == F_SHOOT || to == F_ATTACH || to == F_RELEASE || to == F_HIT) return 34.0f;
    if (to == F_HERO || to == F_LAND) return 38.0f;
    return 20.0f;
}
static const StkPose& stkAdvance(StkAnim& an, int frame, float phase, float swing) {
    StkPose tgt = stkMakePose(frame, phase, swing);
    double now = stkNow();
    float dt = (float)clampf((float)(now - an.last), 0.0f, 0.05f);
    an.last = now;
    if (!an.init) { an.cur = tgt; an.init = true; }
    else an.cur = stkBlend(an.cur, tgt, 1.0f - expf(-stkRate(an.lastFrame, frame) * dt));
    an.cur.snap = tgt.snap;
    an.lastFrame = frame;
    return an.cur;
}

// joints of a pose rotated about the body centre and placed on screen
static void stkPlace(const StkPose& pose, float cx, float feetY, double angleDeg, float X[J_N], float Y[J_N]) {
    float jx[J_N], jy[J_N];
    stkSolve(pose, jx, jy);
    float a = (float)(angleDeg * PI / 180.0), c = cosf(a), s = sinf(a);
    float ox = cx, oy = feetY - (float)STK_FEET_Y;
    for (int i = 0; i < J_N; i++) { X[i] = ox + jx[i] * c - jy[i] * s; Y[i] = oy + jx[i] * s + jy[i] * c; }
}

// ---- anti-aliased capsule renderer ------------------------------------------------------
static const int STK_TEX = 112;                 // texture side; joints stay well inside +-56 px of the body centre
static SDL_Texture* gStkTex = nullptr;
static float gStkBuf[STK_TEX * STK_TEX * 4];    // premultiplied-ready float RGBA scratch
struct StkBone { int a, b; };
static float stkDistSeg(float px, float py, float x0, float y0, float x1, float y1) {
    float vx = x1 - x0, vy = y1 - y0, wx = px - x0, wy = py - y0;
    float l2 = vx * vx + vy * vy, t = l2 > 1e-6f ? clampf((wx * vx + wy * vy) / l2, 0.0f, 1.0f) : 0.0f;
    float dx = wx - vx * t, dy = wy - vy * t;
    return sqrtf(dx * dx + dy * dy);
}
// composite a coloured "distance field" layer (union of capsules / disc) over the scratch buffer
static void stkLayer(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float rLimb, float rHead, u32 c, float ox, float oy) {
    float cr = ((c >> 16) & 255) / 255.0f, cg = ((c >> 8) & 255) / 255.0f, cb = (c & 255) / 255.0f;
    float r = rLimb + 0.5f;
    float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
    auto grow = [&](float x, float y, float pad) { minX = std::min(minX, x - pad); maxX = std::max(maxX, x + pad); minY = std::min(minY, y - pad); maxY = std::max(maxY, y + pad); };
    for (int i = 0; i < n; i++) { grow(X[bones[i].a] - ox, Y[bones[i].a] - oy, r + 1); grow(X[bones[i].b] - ox, Y[bones[i].b] - oy, r + 1); }
    if (head) grow(X[J_HEAD] - ox, Y[J_HEAD] - oy, rHead + 1.5f);
    int x0 = std::max(0, (int)floorf(minX)), x1 = std::min(STK_TEX - 1, (int)ceilf(maxX));
    int y0 = std::max(0, (int)floorf(minY)), y1 = std::min(STK_TEX - 1, (int)ceilf(maxY));
    for (int py = y0; py <= y1; py++) for (int px = x0; px <= x1; px++) {
        float fx = px + 0.5f + ox, fy = py + 0.5f + oy, d = 1e9f;
        for (int i = 0; i < n; i++) d = std::min(d, stkDistSeg(fx, fy, X[bones[i].a], Y[bones[i].a], X[bones[i].b], Y[bones[i].b]) - rLimb);
        if (head) d = std::min(d, hypotf(fx - X[J_HEAD], fy - Y[J_HEAD]) - rHead);
        float cov = clampf(0.5f - d, 0.0f, 1.0f);
        if (cov <= 0) continue;
        float* q = &gStkBuf[(py * STK_TEX + px) * 4];
        float inv = 1.0f - cov;                        // "over" operator, straight alpha stored premultiplied
        q[0] = cr * cov + q[0] * inv; q[1] = cg * cov + q[1] * inv; q[2] = cb * cov + q[2] * inv; q[3] = cov + q[3] * inv;
    }
}
static void stkDrawBones(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float ox, float oy) {
    stkLayer(X, Y, bones, n, head, 2.35f, 5.9f, STK_OUTLINE, ox, oy);   // thin light rim ...
    stkLayer(X, Y, bones, n, head, 1.5f, 4.95f, STK_BODY, ox, oy);      // ... then the uniform-width body
}
static void drawStickman(const StkPose& pose, int cx, int feetY, double angleDeg) {
    if (!gStkTex) {
        gStkTex = SDL_CreateTexture(gRen, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STREAMING, STK_TEX, STK_TEX);
        if (!gStkTex) return;
        SDL_SetTextureBlendMode(gStkTex, SDL_BLENDMODE_BLEND);
    }
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    const float ox = (float)cx - STK_TEX / 2, oy = (float)(feetY - STK_FEET_Y) - STK_TEX / 2;
    memset(gStkBuf, 0, sizeof(gStkBuf));
    static const StkBone farSet[] = { {J_NECK, J_ELB}, {J_ELB, J_HNB}, {J_HIP, J_KNB}, {J_KNB, J_FTB}, {J_HIP, J_NECK} };
    static const StkBone nearLeg[] = { {J_HIP, J_KNF}, {J_KNF, J_FTF} };
    static const StkBone nearArm[] = { {J_NECK, J_ELF}, {J_ELF, J_HNF} };
    stkDrawBones(X, Y, farSet, 5, true, ox, oy);   // far limbs + torso + head form one silhouette
    stkDrawBones(X, Y, nearLeg, 2, false, ox, oy); // near limbs get their own rim so they separate from it
    stkDrawBones(X, Y, nearArm, 2, false, ox, oy);
    static Uint32 px[STK_TEX * STK_TEX];
    for (int i = 0; i < STK_TEX * STK_TEX; i++) {
        const float* q = &gStkBuf[i * 4];
        float a = q[3];
        if (a <= 0.001f) { px[i] = 0; continue; }
        // un-premultiply: the blend mode expects straight alpha
        Uint32 r = (Uint32)clampf(q[0] / a * 255.0f + 0.5f, 0, 255), g = (Uint32)clampf(q[1] / a * 255.0f + 0.5f, 0, 255);
        Uint32 b = (Uint32)clampf(q[2] / a * 255.0f + 0.5f, 0, 255), al = (Uint32)clampf(a * 255.0f + 0.5f, 0, 255);
        px[i] = r | (g << 8) | (b << 16) | (al << 24);   // ABGR8888 -> bytes R,G,B,A in memory
    }
    SDL_UpdateTexture(gStkTex, nullptr, px, STK_TEX * (int)sizeof(Uint32));
    SDL_Rect dst = { (int)floorf(ox), (int)floorf(oy), STK_TEX, STK_TEX };
    SDL_RenderCopy(gRen, gStkTex, nullptr, &dst);
}
// where the web hand of a pose ends up on screen
static void stickHand(const StkPose& pose, int cx, int feetY, double angleDeg, float& hx, float& hy) {
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    hx = X[J_HNF]; hy = Y[J_HNF];
}
// ==== STICKMAN END ====
static float gRunPhase = 0;                    // run-cycle phase in cycles, advanced with ground speed
static StkAnim gPlayerAnim, gMenuAnim;         // smoothed poses (player in the run, stickman on the title screen)

static void buildArt() {
    for (int s = 0; s < 6; s++) for (int v = 0; v < 3; v++) gTile[s][v] = mkTex(makeTile(s, v));
    for (int v = 0; v < 3; v++) gFar[v] = mkTex(makeFar(v));
}
static void tileMod(int r, int g, int b) {
    for (int s = 0; s < 6; s++) for (int v = 0; v < 3; v++) SDL_SetTextureColorMod(gTile[s][v], (Uint8)r, (Uint8)g, (Uint8)b);
}

// ============================================================================
//  SETTINGS / PERSISTENCE
// ============================================================================
struct Settings { float music = 0.6f, sfx = 0.8f, sens = 1.0f; bool shake = true, reduced = false, full = true; float best = 0; };
static Settings cfg;
static std::string savePath;
static void loadCfg() {
    char* pp = SDL_GetPrefPath("PixelCity", "StickmanPixelCity");
    savePath = pp ? std::string(pp) + "save.txt" : "save.txt";
    if (pp) SDL_free(pp);
    FILE* f = fopen(savePath.c_str(), "r");
    if (!f) return;
    int sh = 1, rd = 0, fu = 1;
    float m, s, se, b;
    if (fscanf(f, "%f %f %f %d %d %d %f", &m, &s, &se, &sh, &rd, &fu, &b) == 7) {
        cfg.music = clampf(m, 0, 1); cfg.sfx = clampf(s, 0, 1); cfg.sens = clampf(se, 0.5f, 1.5f);
        cfg.shake = sh != 0; cfg.reduced = rd != 0; cfg.full = fu != 0; cfg.best = std::max(0.0f, b);
    }
    fclose(f);
}
static void saveCfg() {
    FILE* f = fopen(savePath.c_str(), "w");
    if (!f) return;
    fprintf(f, "%f %f %f %d %d %d %f\n", cfg.music, cfg.sfx, cfg.sens, cfg.shake, cfg.reduced, cfg.full, cfg.best);
    fclose(f);
}

// ============================================================================
//  AUDIO  (fully synthesised: ambience, wind, generative cinematic loop, SFX)
// ============================================================================
struct Voice { bool on = false; int type = 0; float t = 0, dur = 0.1f, f0 = 440, f1 = 440, amp = 0.5f, ph = 0; };
static SDL_AudioDeviceID gAud = 0;
static Voice vox[12];
static std::atomic<float> aMusic{0.6f}, aSfx{0.8f}, aWind{0.0f};
static std::atomic<int> aMode{0};  // 0 off, 1 menu, 2 gameplay
static bool audioStarted = false;

static void audioCB(void*, Uint8* stream, int len) {
    float* o = (float*)stream;
    int n = len / (int)(sizeof(float) * 2);
    const float sr = 44100.0f;
    static double mt = 0;
    static u32 nz = 22222;
    static float wlp = 0, rlp = 0, bph = 0, kph = 0, nlp = 0, lpb = 0;
    static float pad[3] = {0, 0, 0}, arp = 0;
    static const float bassF[4] = {55.0f, 43.65f, 65.41f, 49.0f};
    static const float chord[4][3] = {{220, 261.63f, 329.63f}, {174.61f, 220, 261.63f}, {261.63f, 329.63f, 392}, {196, 246.94f, 293.66f}};
    float mv = aMusic.load(), sv = aSfx.load(), wind = aWind.load();
    int mode = aMode.load();
    for (int i = 0; i < n; i++) {
        nz ^= nz << 13; nz ^= nz >> 17; nz ^= nz << 5;
        float noise = ((nz & 0xFFFF) / 32768.0f) - 1.0f;
        float m = 0;
        if (mode > 0) {
            double step = mt / 0.15625;
            int si = (int)step; float sp = (float)(step - si);
            int bar = (si / 8) & 3;
            for (int k = 0; k < 3; k++) {
                pad[k] += chord[bar][k] / sr; if (pad[k] > 1) pad[k] -= 1;
                m += sinf(2 * PI * pad[k]) * 0.035f;
            }
            bph += bassF[bar] / sr; if (bph > 1) bph -= 1;
            float saw = (2 * bph - 1);
            lpb += (saw - lpb) * 0.06f;
            m += lpb * 0.22f * (0.6f + 0.4f * expf(-(float)(si & 1) * 0.0f - sp * 2.0f));
            if (mode == 2) {
                int idx = (si % 4 == 3) ? 1 : (si % 4);
                if (idx > 2) idx = 1;
                arp += chord[bar][idx] * 2 / sr; if (arp > 1) arp -= 1;
                m += (2 * fabsf(2 * arp - 1) - 1) * 0.07f * expf(-sp * 4);
                float tt = sp * 0.15625f;
                if (si % 4 == 0) { kph += (50 + 110 * expf(-tt * 35)) / sr; m += sinf(2 * PI * kph) * expf(-tt * 14) * 0.45f; }
                nlp += (noise - nlp) * 0.5f;
                if (si % 2 == 1) m += (noise - nlp) * expf(-sp * 10) * 0.05f;
                if (si % 8 == 4) m += noise * expf(-sp * 5) * 0.12f;
            } else m *= 0.7f;
            mt += 1.0 / sr;
        }
        m *= mv * 0.8f;
        float s = 0;
        for (int v = 0; v < 12; v++) {
            Voice& vo = vox[v];
            if (!vo.on) continue;
            float tt = vo.t / vo.dur, env = (1 - tt) * (1 - tt);
            float f = vo.f0 + (vo.f1 - vo.f0) * tt;
            if (vo.type == 3) f = tt < 0.4f ? vo.f0 : vo.f1;
            vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
            float w;
            switch (vo.type) {
                case 0: w = noise * 0.5f + sinf(2 * PI * vo.ph) * 0.3f; break;
                case 1: w = sinf(2 * PI * vo.ph) * 0.6f + (vo.ph < 0.5f ? 0.15f : -0.15f); break;
                case 2: w = sinf(2 * PI * vo.ph) * 0.8f + (tt < 0.4f ? noise * 0.3f : 0.0f); break;
                case 3: w = sinf(2 * PI * vo.ph) * 0.5f; break;
                case 4: w = vo.ph < 0.5f ? 0.3f : -0.3f; break;
                case 5: w = (2 * vo.ph - 1) * 0.4f; break;
                case 6: w = noise * 0.4f; break;
                default: w = sinf(2 * PI * vo.ph) * 0.5f; break;
            }
            s += w * env * vo.amp;
            vo.t += 1.0f / sr;
            if (vo.t >= vo.dur) vo.on = false;
        }
        // city ambience + wind rush (speed dependent)
        rlp += (noise - rlp) * 0.0025f;
        wlp += (noise - wlp) * (0.02f + 0.12f * wind);
        s += rlp * 0.9f + wlp * (0.03f + 0.45f * wind);
        s *= sv;
        float out = clampf(m + s, -1, 1);
        o[i * 2] = out; o[i * 2 + 1] = out;
    }
}
static void initAudio() {
    SDL_AudioSpec want, have;
    SDL_zero(want);
    want.freq = 44100; want.format = AUDIO_F32SYS; want.channels = 2; want.samples = 1024; want.callback = audioCB;
    gAud = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void sfx(int type) {
    if (!gAud) return;
    static const float P[8][4] = {  // dur, f0, f1, amp
        {0.14f, 900, 1800, 0.5f}, {0.10f, 1200, 400, 0.6f}, {0.16f, 130, 45, 0.9f}, {0.16f, 880, 1320, 0.5f},
        {0.05f, 600, 600, 0.4f}, {0.90f, 440, 90, 0.6f}, {0.12f, 500, 500, 0.5f}, {0.12f, 300, 650, 0.5f}};
    SDL_LockAudioDevice(gAud);
    int slot = 0; float oldest = -1;
    for (int i = 0; i < 12; i++) { if (!vox[i].on) { slot = i; oldest = 1e9f; break; } if (vox[i].t > oldest) { oldest = vox[i].t; slot = i; } }
    Voice& v = vox[slot];
    v.on = true; v.type = type; v.t = 0; v.dur = P[type][0]; v.f0 = P[type][1]; v.f1 = P[type][2]; v.amp = P[type][3]; v.ph = 0;
    SDL_UnlockAudioDevice(gAud);
}

// ============================================================================
//  GAME DATA
// ============================================================================
enum State { MAIN_MENU, SETTINGS, HOW_TO_PLAY, CREDITS, PLAYING, PAUSED, GAME_OVER };
static State gState = MAIN_MENU, settingsFrom = MAIN_MENU;
static double gTime = 0;

struct Obs { int type; float x, w, h; bool solid; int param; };  // 0 hvac 1 tower 2 barrier 3 antenna 4 crane 5 billboard 6 dish
struct Anchor { float x, y; };
struct Building {
    float x, w, roofY; int style; u32 seed;
    std::vector<Obs> obs; std::vector<Anchor> anch;
    bool mastL = false, mastR = false, cable = false;
    float cx0 = 0, cy0 = 0, cx1 = 0, cy1 = 0;
};
struct Coll { float x, y; };
struct Part { float x, y, vx, vy, life, max; u32 c; int sz; bool alive; };

static std::deque<Building> bld;
static std::vector<Coll> colls;
static Part parts[220];
static int partHead = 0;
static Rng wrng(1);

struct Player {
    float x = 0, y = 0, px = 0, py = 0, vx = 0, vy = 0;
    bool onGround = false, swinging = false, alive = true, usedAir = false;
    float ax = 0, ay = 0, rope = 0;
    float coyote = 0, jumpBuf = 0, animT = 0, landT = 0, shootT = 0, attachT = 0, releaseT = 0, deadT = 0, flipT = 0;
    bool hero = false;                       // last landing was a hard one -> superhero pose
    int chain = 0;
};
static Player P;
static float camX = 0, camY = 0, startX = 0, shakeT = 0, chainShowT = 0;
static float distM = 0, bonus = 0, speedBonus = 0;
static int coinCount = 0;
static bool newBest = false;
static bool jumpEdge = false, jumpRel = false, swingHeld = false, swingWas = false;
static float steer = 0;
static bool haveTarget = false;
static float tgtX = 0, tgtY = 0;
static float trans = -1, menuT = 0, fadeIn = 0;

static const float GRAV = 1400.0f;
static float difficulty() { return clampf(distM / 2000.0f, 0, 1); }
static int scoreVal() { return (int)(distM + bonus + speedBonus); }

static void spawnPart(float x, float y, float vx, float vy, float life, u32 c, int sz = 2) {
    if (cfg.reduced && (partHead & 1)) { partHead = (partHead + 1) % 220; return; }
    parts[partHead] = {x, y, vx, vy, life, life, c, sz, true};
    partHead = (partHead + 1) % 220;
}
static void burst(float x, float y, int n, u32 c, float spd) {
    for (int i = 0; i < n; i++) {
        float a = (float)i / n * 2 * PI + wrng.f();
        spawnPart(x, y, cosf(a) * spd * (0.4f + wrng.f()), sinf(a) * spd * (0.4f + wrng.f()), 0.35f + wrng.f() * 0.3f, c);
    }
}
static void doShake(float t) { if (cfg.shake) shakeT = std::max(shakeT, t); }

// ---------------------------------------------------------------- generation
static void addBuilding(bool first) {
    float d = difficulty();
    Building b;
    b.seed = wrng.next();
    b.style = wrng.range(0, 5);
    float gap = 0;
    if (first) { b.x = -300; b.w = 1100; b.roofY = 0; b.style = 0; }
    else {
        Building& p = bld.back();
        gap = (float)wrng.range((int)(60 + 60 * d), (int)(140 + 300 * d));
        int lo = (int)(540 - 300 * d), hi = (int)(820 - 380 * d);
        b.w = (float)((wrng.range(lo, hi) / 16) * 16);
        int up = gap > 150 ? 140 : 60;
        b.roofY = clampf(p.roofY + wrng.range(-up, 130), -380, 260);
        b.x = p.x + p.w + gap;
        if (b.style == p.style) b.style = (b.style + 1 + wrng.range(0, 4)) % 6;
        if (gap > 150) {  // light-mast cable across the gap with a hanging lamp = web anchor
            p.mastR = true; b.mastL = true; p.cable = true;
            p.cx0 = p.x + p.w - 10; p.cy0 = p.roofY - 280; p.cx1 = b.x + 10; p.cy1 = b.roofY - 280;
            p.anch.push_back({(p.cx0 + p.cx1) / 2, (p.cy0 + p.cy1) / 2 + 22});
        }
        if (gap > 110) {  // token arc across the gap
            for (int i = 0; i < 5; i++) {
                float t = i / 4.0f;
                colls.push_back({p.x + p.w + t * gap, lerpf(p.roofY, b.roofY, t) - 64 - 70 * sinf(t * PI)});
            }
        }
    }
    // solid rooftop hazards (never on narrow roofs, always spaced for reaction time)
    if (!first && b.w >= 440 && wrng.f() < 0.3f + 0.5f * d) {
        int n = (b.w >= 700 && wrng.f() < 0.5f) ? 2 : 1;
        float x = b.x + 260;
        for (int i = 0; i < n; i++) {
            int ty = wrng.range(0, 2);
            float w = ty == 0 ? 28.0f : (ty == 1 ? 30.0f : 24.0f), h = ty == 0 ? 20.0f : (ty == 1 ? 46.0f : 14.0f);
            float span = (b.x + b.w - 200) - x - w;
            if (span < 0) break;
            x += wrng.range(0, (int)std::min(span, 160.0f));
            b.obs.push_back({ty, x, w, h, true, 0});
            x += w + 230;
        }
    }
    // decor that doubles as anchors
    if (!first && wrng.f() < 0.75f) {
        float x = b.x + wrng.range(30, std::max(31, (int)b.w - 30)), h = (float)wrng.range(130, 190);
        b.obs.push_back({3, x, 2, h, false, 0});
        b.anch.push_back({x + 1, b.roofY - h});
    }
    if (b.w > 320 && wrng.f() < (b.style == 5 ? 0.7f : 0.25f)) {
        float x = b.x + wrng.range(40, (int)b.w - 170), h = (float)wrng.range(220, 300);
        b.obs.push_back({4, x, 110, h, false, 0});
        b.anch.push_back({x + 110, b.roofY - h + 4});
    }
    if (b.w > 320 && wrng.f() < 0.3f) {
        float x = b.x + wrng.range(20, (int)b.w - 130);
        b.obs.push_back({5, x, 96, 114, false, wrng.range(0, 3)});
        b.anch.push_back({x + 48, b.roofY - 114});
    }
    if (wrng.f() < 0.4f) b.obs.push_back({6, b.x + wrng.range(20, std::max(21, (int)b.w - 20)), 12, 16, false, 0});
    if (!first && b.w >= 360 && wrng.f() < 0.45f)
        for (int i = 0; i < 4; i++) colls.push_back({b.x + 90 + i * 36.0f, b.roofY - 58});
    bld.push_back(std::move(b));
}
static void ensureWorld() {
    while (bld.back().x + bld.back().w < camX + W + 1400) addBuilding(false);
    while (bld.size() > 3 && bld.front().x + bld.front().w < camX - 800) bld.pop_front();
    colls.erase(std::remove_if(colls.begin(), colls.end(), [](const Coll& c) { return c.x < camX - 300; }), colls.end());
}

static void startRun() {
    bld.clear(); colls.clear();
    for (auto& p : parts) p.alive = false;
    wrng = Rng(SDL_GetTicks() * 2654435761u + 17u);
    P = Player();
    gPlayerAnim.init = false; gRunPhase = 0;
    distM = bonus = speedBonus = 0; coinCount = 0; newBest = false; chainShowT = 0; shakeT = 0;
    addBuilding(true);
    P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; P.vx = 230; P.onGround = true;
    startX = P.x;
    camX = P.x - W * 0.30f; camY = P.y - H * 0.58f;
    ensureWorld();
    gState = PLAYING;
    aMode = 2;
}

// ---------------------------------------------------------------- web
static bool findAnchor(float& ox, float& oy) {
    float best = 1e9f; bool f = false;
    for (auto& b : bld) {
        if (b.x > P.x + 700 || b.x + b.w < P.x - 50) continue;
        for (auto& a : b.anch) {
            float dx = a.x - P.x, dy = P.y - a.y;
            if (dx < 10 || dx > 380 || dy < 70 || dy > 330 || hypotf(dx, dy) > 400) continue;
            float sc = fabsf(dx - 170) + fabsf(dy - 230) * 0.6f;
            if (sc < best) { best = sc; ox = a.x; oy = a.y; f = true; }
        }
    }
    return f;
}
static void attachWeb(float ax, float ay) {
    P.swinging = true; P.ax = ax; P.ay = ay;
    P.rope = std::max(90.0f, hypotf(P.x - ax, P.y - ay));
    P.chain++; P.attachT = 0.18f; P.usedAir = false;
    if (P.chain >= 2) { bonus += 10.0f * P.chain; chainShowT = 1.6f; }
    burst(ax, ay, 8, 0xFFFFFF, 90);
    sfx(1);
}
static void releaseWeb(bool boosted) {
    if (!P.swinging) return;
    P.swinging = false; P.releaseT = 0.25f;
    burst(P.x, P.y - 20, 4, 0xBFD8FF, 60);
    if (boosted) sfx(7); else sfx(6);
}
static void killPlayer() {
    if (!P.alive) return;
    P.alive = false; P.swinging = false; P.deadT = 0;
    P.vy = -320; P.vx = std::min(P.vx, 80.0f) * 0.4f;
    doShake(0.4f);
    burst(P.x, P.y, 14, 0xD62839, 160);
    sfx(5); aMode = 1;
}

// returns true if resolved a collision this step
static void solidHit(float L, float T, float R, float Bt, bool lethalSide) {
    float pl = P.x - 8, pr = P.x + 8, pt = P.y - 24, pb = P.y + 26, prevB = P.py + 26;
    if (!(pr > L && pl < R && pb > T && pt < Bt)) return;
    if (prevB <= T + 14 && P.vy >= 0) { P.y = T - 26; P.vy = 0; P.onGround = true; return; }
    if (pb - T < 26 && P.vy >= -50) { P.y = T - 26; P.vy = std::min(P.vy, 0.0f); P.onGround = true; return; }  // ledge assist
    if (lethalSide || P.vx > 200) { killPlayer(); return; }
    if (P.x < (L + R) * 0.5f) P.x = L - 8; else P.x = R + 8;
    P.vx = std::min(P.vx, 0.0f) * 0.2f;
    if (P.swinging) releaseWeb(false);
}
static void collide() {
    for (auto& b : bld) {
        if (b.x + b.w < P.x - 40 || b.x > P.x + 40) continue;
        solidHit(b.x, b.roofY, b.x + b.w, b.roofY + 3200, false);
        if (!P.alive) return;
        for (auto& o : b.obs) if (o.solid) { solidHit(o.x, b.roofY - o.h, o.x + o.w, b.roofY, true); if (!P.alive) return; }
    }
}

static void stepPhysics(float dt) {
    Player& p = P;
    if (!p.alive) {
        p.vy += GRAV * dt; p.x += p.vx * dt; p.y += p.vy * dt;
        return;
    }
    float runSp = 230 + 230 * difficulty();
    p.px = p.x; p.py = p.y;
    p.coyote -= dt; p.jumpBuf -= dt;
    if (jumpEdge) { p.jumpBuf = 0.12f; jumpEdge = false; }
    if (p.jumpBuf > 0) {
        if (p.swinging) { releaseWeb(true); p.vy -= 200; p.jumpBuf = 0; }
        else if (p.onGround || p.coyote > 0) {
            p.vy = -560; p.onGround = false; p.coyote = 0; p.jumpBuf = 0; sfx(7);
            for (int i = 0; i < 4; i++) spawnPart(p.x, p.y + 26, (i - 1.5f) * 25, -20, 0.3f, 0x8A90B0);
        } else if (!p.usedAir) { p.vy = -440; p.usedAir = true; p.jumpBuf = 0; p.flipT = 0.55f; sfx(7); }
    }
    if (jumpRel) { if (p.vy < -250 && !p.swinging) p.vy *= 0.6f; jumpRel = false; }
    if (p.onGround) p.vx += (runSp - p.vx) * std::min(1.0f, 4 * dt);
    bool wasGround = p.onGround;
    p.onGround = false;
    p.vy += GRAV * dt;
    const float preVy = p.vy;
    if (!wasGround && fabsf(steer) > 0.01f && fabsf(p.vx) < 700) p.vx += steer * 240 * cfg.sens * dt;
    p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.swinging) {
        float dx = p.x - p.ax, dy = p.y - p.ay, d = hypotf(dx, dy);
        if (d > p.rope && d > 0.001f) {
            float nx = dx / d, ny = dy / d;
            p.x = p.ax + nx * p.rope; p.y = p.ay + ny * p.rope;
            float vr = p.vx * nx + p.vy * ny;
            if (vr > 0) { p.vx -= vr * nx; p.vy -= vr * ny; }
        }
        if (p.vx > 0 && p.y > p.ay) p.vx += 110 * dt;   // gentle "pump" at the bottom of the arc
        float dr = expf(-0.12f * dt); p.vx *= dr; p.vy *= dr;
        if (p.x - p.ax > 200) releaseWeb(false);
    } else {
        float dr = expf(-0.05f * dt); p.vx *= dr;
    }
    collide();
    if (!p.alive) return;
    if (p.onGround) {
        p.coyote = 0.1f; p.usedAir = false;
        if (!wasGround) {  // landing
            p.hero = preVy > 640.0f; p.landT = p.hero ? 0.42f : 0.18f; p.flipT = 0;
            if (p.swinging) releaseWeb(false);
            bonus += 25 + (p.chain >= 2 ? 10.0f * p.chain : 0);
            if (p.chain >= 2) chainShowT = 1.6f;
            p.chain = 0;
            sfx(2); doShake(0.12f);
            for (int i = 0; i < 6; i++) spawnPart(p.x, p.y + 26, (i - 2.5f) * 35, -30 - wrng.f() * 30, 0.35f, 0x9AA0C0);
        }
    }
    if (p.y > 900) killPlayer();
}

// ============================================================================
//  INPUT
// ============================================================================
enum { R_NONE, R_SWING, R_JUMP, R_PAUSE, R_UI, R_STEER, R_SLIDER };
struct Touch { bool on = false; SDL_FingerID id = 0; float x = 0, y = 0, sx = 0; int role = 0; int btn = 0; };
static Touch tch[10];
enum { B_PLAY = 1, B_SETTINGS, B_HOW, B_CREDITS, B_BACK, B_RESUME, B_RESTART, B_MENU, B_TRY, B_SHAKE, B_REDUCED, B_FULL, S_MUSIC, S_SFX, S_SENS };
struct Btn { int id, kind, x, y, w, h; const char* label; float* val; bool* flag; float vmin, vmax; };  // kind 0 button 1 slider 2 toggle
static std::vector<Btn> btns;
static Btn pauseBtn;

static void ctlGeom(float& sx, float& sy, float& sr, float& jx, float& jy, float& jr) {
    sr = 46; jr = 36;
    sx = W - safeR - sr - 6; sy = H - safeB - sr - 4;
    jx = sx - 125; jy = sy + 10;
}
static void buildUI() {
    btns.clear();
    float bh = std::max(minTouch, 38.0f);
    pauseBtn = {0, 0, (int)(W / 2 - 22), (int)safeT, 44, 44, "", nullptr, nullptr, 0, 1};
    switch (gState) {
        case MAIN_MENU: {
            if (trans >= 0) break;
            int x = (int)safeL + 10, w = (int)std::min(230.0f, W * 0.42f);
            int y = (int)(H * 0.40f), ph = (int)bh + 8;
            btns.push_back({B_PLAY, 0, x, y, w, ph, "PLAY", nullptr, nullptr, 0, 1}); y += ph + 8;
            btns.push_back({B_SETTINGS, 0, x, y, w - 20, (int)bh, "SETTINGS", nullptr, nullptr, 0, 1}); y += (int)bh + 8;
            btns.push_back({B_HOW, 0, x, y, w - 20, (int)bh, "HOW TO PLAY", nullptr, nullptr, 0, 1}); y += (int)bh + 8;
            btns.push_back({B_CREDITS, 0, x, y, w - 20, (int)bh, "CREDITS", nullptr, nullptr, 0, 1});
        } break;
        case SETTINGS: {
            int pw = std::min(W - (int)(safeL + safeR), 560), px = (W - pw) / 2;
            int cw = (pw - 48) / 2, y = 84;
            btns.push_back({S_MUSIC, 1, px + 16, y, cw, 44, "MUSIC", &cfg.music, nullptr, 0, 1});
            btns.push_back({S_SFX, 1, px + 16, y + 52, cw, 44, "EFFECTS", &cfg.sfx, nullptr, 0, 1});
            btns.push_back({S_SENS, 1, px + 16, y + 104, cw, 44, "STEERING", &cfg.sens, nullptr, 0.5f, 1.5f});
            int tx = px + 32 + cw, th = (int)std::max(bh, 40.0f);
            btns.push_back({B_SHAKE, 2, tx, y, cw, th, "CAMERA SHAKE", nullptr, &cfg.shake, 0, 1});
            btns.push_back({B_REDUCED, 2, tx, y + 52, cw, th, "FEWER PARTICLES", nullptr, &cfg.reduced, 0, 1});
            btns.push_back({B_FULL, 2, tx, y + 104, cw, th, "IMMERSIVE", nullptr, &cfg.full, 0, 1});
            btns.push_back({B_BACK, 0, W / 2 - 90, H - (int)safeB - 48, 180, 44, "BACK", nullptr, nullptr, 0, 1});
        } break;
        case HOW_TO_PLAY: case CREDITS:
            btns.push_back({B_BACK, 0, W / 2 - 90, H - (int)safeB - 48, 180, 44, "BACK", nullptr, nullptr, 0, 1});
            break;
        case PAUSED: {
            int w = 220, h = (int)bh, g = 8, x = W / 2 - w / 2, y = (H - (4 * h + 3 * g)) / 2 + 12;
            btns.push_back({B_RESUME, 0, x, y, w, h, "RESUME", nullptr, nullptr, 0, 1}); y += h + g;
            btns.push_back({B_RESTART, 0, x, y, w, h, "RESTART", nullptr, nullptr, 0, 1}); y += h + g;
            btns.push_back({B_SETTINGS, 0, x, y, w, h, "SETTINGS", nullptr, nullptr, 0, 1}); y += h + g;
            btns.push_back({B_MENU, 0, x, y, w, h, "MAIN MENU", nullptr, nullptr, 0, 1});
        } break;
        case GAME_OVER: {
            int y = H - (int)safeB - 56;
            btns.push_back({B_TRY, 0, W / 2 - 210, y, 200, 48, "TRY AGAIN", nullptr, nullptr, 0, 1});
            btns.push_back({B_MENU, 0, W / 2 + 10, y, 200, 48, "MAIN MENU", nullptr, nullptr, 0, 1});
        } break;
        default: break;
    }
}
static bool inRect(float x, float y, int rx, int ry, int rw, int rh, int pad = 0) {
    return x >= rx - pad && x <= rx + rw + pad && y >= ry - pad && y <= ry + rh + pad;
}
static void setSlider(const Btn& b, float x) {
    float t = clampf((x - b.x) / (float)b.w, 0, 1);
    *b.val = b.vmin + (b.vmax - b.vmin) * t;
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void activate(int id) {
    sfx(4);
    switch (id) {
        case B_PLAY: trans = 0; break;
        case B_SETTINGS: settingsFrom = gState; gState = SETTINGS; break;
        case B_HOW: gState = HOW_TO_PLAY; break;
        case B_CREDITS: gState = CREDITS; break;
        case B_BACK: gState = (gState == SETTINGS) ? settingsFrom : MAIN_MENU; break;
        case B_RESUME: gState = PLAYING; break;
        case B_RESTART: case B_TRY: startRun(); break;
        case B_MENU: gState = MAIN_MENU; trans = -1; menuT = 0; aMode = 1; break;
        case B_SHAKE: cfg.shake = !cfg.shake; saveCfg(); break;
        case B_REDUCED: cfg.reduced = !cfg.reduced; saveCfg(); break;
        case B_FULL:
            cfg.full = !cfg.full; saveCfg();
            SDL_SetWindowFullscreen(gWin, cfg.full ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
            break;
        default: break;
    }
}
static void releaseAll() {
    for (auto& t : tch) t = Touch();
    swingHeld = false; steer = 0;
}
static void toInternal(float nx, float ny, float& x, float& y) {
    x = (nx * OUTW - OFFX) / SC; y = (ny * OUTH - OFFY) / SC;
}
static void fingerDown(const SDL_TouchFingerEvent& e) {
    if (!audioStarted && gAud) { SDL_PauseAudioDevice(gAud, 0); audioStarted = true; aMode = 1; }
    if (portrait) return;
    Touch* t = nullptr;
    for (auto& q : tch) if (!q.on) { t = &q; break; }
    if (!t) return;
    t->on = true; t->id = e.fingerId; toInternal(e.x, e.y, t->x, t->y); t->sx = t->x; t->role = R_NONE;
    if (gState == PLAYING) {
        float sx, sy, sr, jx, jy, jr; ctlGeom(sx, sy, sr, jx, jy, jr);
        if (inRect(t->x, t->y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 6)) t->role = R_PAUSE;
        else if (hypotf(t->x - sx, t->y - sy) <= sr * 1.2f) t->role = R_SWING;
        else if (hypotf(t->x - jx, t->y - jy) <= jr * 1.25f) { t->role = R_JUMP; jumpEdge = true; }
        else if (t->x < W * 0.55f) t->role = R_STEER;
    } else {
        for (auto& b : btns) if (inRect(t->x, t->y, b.x, b.y, b.w, b.h, 4)) {
            t->btn = b.id; t->role = b.kind == 1 ? R_SLIDER : R_UI;
            if (b.kind == 1) setSlider(b, t->x);
            break;
        }
    }
}
static void fingerMove(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_SLIDER) for (auto& b : btns) if (b.id == t.btn) setSlider(b, t.x);
    }
}
static void fingerUp(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_JUMP) jumpRel = true;
        else if (t.role == R_PAUSE) { if (inRect(t.x, t.y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 10) && gState == PLAYING) { gState = PAUSED; sfx(4); } }
        else if (t.role == R_UI) { for (auto& b : btns) if (b.id == t.btn && inRect(t.x, t.y, b.x, b.y, b.w, b.h, 6)) { int id = b.id; t = Touch(); activate(id); break; } }
        else if (t.role == R_SLIDER) saveCfg();
        t = Touch();
    }
}
static void pollHeld() {
    swingHeld = false; steer = 0;
    for (auto& t : tch) if (t.on) {
        if (t.role == R_SWING) swingHeld = true;
        if (t.role == R_STEER) steer = clampf((t.x - t.sx) / 50.0f, -1, 1);
    }
}

// ============================================================================
//  RENDERING
// ============================================================================
static void drawHalo(int cx, int cy) {
    for (int i = 0; i < 3; i++) disc(cx, cy, 34 - i * 8, 0x6A78FF, 9);
}
static void drawBackdrop(float cx, float cy, double t) {
    static const u32 sky[] = {0x070A1E, 0x0A0F28, 0x0E1432, 0x131A3C, 0x1A1F46, 0x222350, 0x2B2A5A, 0x35305F, 0x3F3566};
    const int nb = 9;
    for (int i = 0; i < nb; i++) rect(0, i * H / nb, W, H / nb + 1, sky[i]);
    for (int i = 0; i < 80; i++) {
        u32 h = hash3(i, 77, 3);
        int sx = pmod((int)(h % (u32)(W * 2)) - (int)(cx * 0.02f), W), sy = (int)((h >> 10) % (u32)(H * 0.6f));
        bool dim = ((int)(t * 2 + i)) % 7 == 0;
        rect(sx, sy, 1, 1, 0xFFFFFF, dim ? 90 : 220);
    }
    disc((int)(W * 0.82f), (int)(H * 0.16f), 14, 0xE8ECFF, 230);
    disc((int)(W * 0.82f) + 5, (int)(H * 0.16f) - 3, 12, 0x0E1432, 255);
    for (int i = 0; i < 6; i++) {  // drifting clouds
        int x = pmod((int)(i * 260 + t * (6 + i * 2) - cx * 0.05f), W + 300) - 150, y = 40 + (i * 47) % 120;
        rect(x, y, 70, 8, 0x3A3B72, 90); rect(x + 10, y - 6, 40, 6, 0x3A3B72, 90); rect(x + 20, y + 8, 50, 5, 0x3A3B72, 90);
    }
    { int ax = W + 20 - (int)fmod(t * 28.0, (double)(W + 80)), ay = (int)(H * 0.22f);  // distant aircraft
      rect(ax - 3, ay, 6, 2, 0xAAB4D8); rect(ax + 4, ay, 18, 1, 0xAAB4D8, 60);
      if (((int)(t * 2)) & 1) rect(ax, ay - 2, 2, 2, 0xFF3030); else rect(ax, ay - 2, 2, 2, 0xFFFFFF); }
    // far skyline
    static int farW[24], farH[24]; static int farP = 0;
    if (!farP) { Rng r(5); for (int i = 0; i < 24; i++) { farW[i] = (r.range(40, 90) / 8) * 8; farH[i] = r.range(60, 170); farP += farW[i]; } }
    float off = fmodf(cx * 0.10f, (float)farP);
    int x = (int)-off, idx = 0;
    while (x < W) {
        int bw = farW[idx % 24], top = (int)(H * 0.60f - farH[idx % 24] - (cy + 210) * 0.04f);
        if (x + bw > 0) {
            rect(x, top, bw, H - top, 0x141A3A);
            for (int ty = top; ty < H; ty += 32) for (int tx = 0; tx < bw; tx += 32) {
                SDL_Rect s = {0, 0, std::min(32, bw - tx), 32}, d = {x + tx, ty, s.w, 32};
                SDL_RenderCopy(gRen, gFar[hash3(idx, tx, ty) % 3], &s, &d);
            }
            rect(x, top, bw, 2, 0x2A3260);
        }
        x += bw; idx++;
    }
    rect(0, (int)(H * 0.45f), W, H, 0x2B2F6A, 28);
    // mid skyline (bigger, darker facades, independent parallax)
    static int midW[10], midH[10], midS[10], midP = 0;
    if (!midP) { Rng r(9); for (int i = 0; i < 10; i++) { midW[i] = (r.range(96, 176) / 16) * 16; midH[i] = r.range(0, 90); midS[i] = r.range(0, 5); midP += midW[i] + 10; } }
    tileMod(85, 92, 140);
    off = fmodf(cx * 0.30f, (float)midP);
    x = (int)-off; idx = 0;
    while (x < W) {
        int bw = midW[idx % 10], top = (int)(H * 0.30f + midH[idx % 10] - (cy + 210) * 0.12f);
        if (x + bw > 0) {
            for (int ty = top; ty < H; ty += 64) for (int tx = 0; tx < bw; tx += 64) {
                SDL_Rect s = {0, 0, std::min(64, bw - tx), 64}, d = {x + tx, ty, s.w, 64};
                SDL_RenderCopy(gRen, gTile[midS[idx % 10]][hash3(idx, tx, ty) % 3], &s, &d);
            }
            rect(x - 1, top - 4, bw + 2, 4, 0x1B2048);
            rect(x + bw / 2, top - 22, 2, 18, 0x1B2048);
            if (((int)(t * 1.3) + idx) & 1) rect(x + bw / 2 - 1, top - 24, 4, 3, 0xFF3A3A, 200);
        }
        x += bw + 10; idx++;
    }
    tileMod(255, 255, 255);
    rect(0, (int)(H * 0.5f), W, H, 0x3A3F80, 34);  // atmospheric haze
}

static void drawObs(const Obs& o, int sx, int sy, double t) {
    int x = sx, y = sy;
    switch (o.type) {
        case 0:  // HVAC
            rect(x, y - 20, 28, 20, 0x59606E); rect(x, y - 20, 28, 2, 0x8A93A6);
            disc(x + 8, y - 11, 5, 0x1B1F28);
            { int ph = (int)(t * 12) & 1; if (ph) { rect(x + 3, y - 12, 10, 2, 0x4A5060); rect(x + 7, y - 16, 2, 10, 0x4A5060); } else { line(x + 4, y - 15, x + 12, y - 7, 0x4A5060); line(x + 12, y - 15, x + 4, y - 7, 0x4A5060); } }
            for (int i = 0; i < 3; i++) rect(x + 17, y - 16 + i * 4, 9, 2, 0x2B303B);
            break;
        case 1:  // water tower
            rect(x + 3, y - 18, 3, 18, 0x3B2A1E); rect(x + 24, y - 18, 3, 18, 0x3B2A1E);
            line(x + 4, y - 18, x + 25, y - 2, 0x3B2A1E);
            rect(x, y - 42, 30, 24, 0x7A5236); rect(x, y - 36, 30, 2, 0x4A301F); rect(x, y - 26, 30, 2, 0x4A301F);
            rect(x + 3, y - 40, 4, 20, 0x9A6B46); rect(x + 4, y - 46, 22, 4, 0x4A301F); rect(x + 9, y - 50, 12, 4, 0x4A301F);
            break;
        case 2:  // barrier
            rect(x, y - 14, 24, 14, 0xC9C3B5);
            for (int i = 0; i < 3; i++) rect(x + 2 + i * 8, y - 12, 4, 10, 0xE0A81E);
            rect(x, y - 14, 24, 2, 0xE8E3D5);
            break;
        case 3: {  // antenna
            int h = (int)o.h;
            rect(x, y - h, 2, h, 0x2A2F3F); rect(x - 5, y - h + 20, 12, 1, 0x2A2F3F); rect(x - 3, y - h + 30, 8, 1, 0x2A2F3F);
            if (((int)(t * 1.5) + (int)o.x) & 1) { disc(x, y - h - 2, 4, 0xFF2A2A, 60); rect(x - 1, y - h - 3, 4, 4, 0xFF4040); }
        } break;
        case 4: {  // construction crane
            int h = (int)o.h, jw = (int)o.w;
            rect(x, y - h, 6, h, 0xC9A227);
            for (int i = 0; i < h; i += 10) { rect(x, y - h + i, 6, 1, 0x6B5611); line(x, y - h + i, x + 5, y - h + i + 9, 0x6B5611); }
            rect(x - 30, y - h, 30 + jw, 4, 0xC9A227); rect(x - 30, y - h + 4, 14, 10, 0x555B68);
            rect(x - 6, y - h - 8, 12, 8, 0x3A4150);
            rect(x + jw - 1, y - h + 4, 1, 26, 0x888888); rect(x + jw - 3, y - h + 30, 5, 4, 0xD9481F);
            if (((int)(t * 2)) & 1) { disc(x + 3, y - h - 10, 3, 0xFF4040, 70); rect(x + 2, y - h - 11, 3, 3, 0xFF5050); }
            rect(x + jw - 2, y - h + 1, 3, 3, 0xFFE9A0);
        } break;
        case 5: {  // animated billboard
            static const char* ads[4] = {"NEON NOODLES", "CITY BANK", "SKY TV", "PIZZA 24/7"};
            static const u32 bg[4] = {0x3A1030, 0x103A50, 0x2A1050, 0x503A10};
            int w = (int)o.w;
            rect(x + 8, y - 70, 4, 70, 0x2A2F3F); rect(x + w - 12, y - 70, 4, 70, 0x2A2F3F);
            rect(x, y - 114, w, 46, 0x1A1D28);
            rect(x + 3, y - 111, w - 6, 40, bg[o.param & 3]);
            SDL_Rect clip = {x + 3, y - 111, w - 6, 40};
            SDL_RenderSetClipRect(gRen, &clip);
            { const char* s = ads[o.param & 3]; int tw = textW(s, 2) + 40; int tx = x + 3 + w - 6 - (int)fmod(t * 30.0, (double)(tw + w));
              text(s, tx, y - 100, 2, 0xFFE9A0);
              rect(x + 3, y - 80, w - 6, 3, 0xFF3A6A, 160 + (int)(60 * sinf((float)t * 4))); }
            SDL_RenderSetClipRect(gRen, nullptr);
            rect(x, y - 114, w, 2, 0x6A7090);
        } break;
        default:  // dish
            rect(x, y - 6, 2, 6, 0x4A5060); rect(x - 6, y - 14, 12, 3, 0xB8BED0); rect(x - 4, y - 11, 8, 2, 0x8A90A8); rect(x - 1, y - 16, 2, 4, 0x6A7090);
            break;
    }
}
static void drawFacade(const Building& b, int sx, int sy) {
    u32 tm = (u32)(gTime * 0.4);
    int y0 = sy + 8;
    int r0 = std::max(0, (int)floorf((0 - y0) / 64.0f));
    int cols = ((int)b.w + 63) / 64;
    for (int r = r0; y0 + r * 64 < H; r++) {
        for (int c = 0; c < cols; c++) {
            int tx = sx + c * 64;
            if (tx + 64 < 0 || tx > W) continue;
            int v = (int)(hash3(b.seed + c, r, 7) % 3);
            if (hash3(c + (u32)b.seed, r, tm) % 29 == 0) v = (v + 1) % 3;
            int sw = std::min(64, (int)b.w - c * 64);
            SDL_Rect s = {0, 0, sw, 64}, d = {tx, y0 + r * 64, sw, 64};
            SDL_RenderCopy(gRen, gTile[b.style][v], &s, &d);
        }
    }
    int top = std::max(sy, 0);
    rect(sx, top, 3, H - top, 0x05060F, 130);
    rect(sx + (int)b.w - 3, top, 3, H - top, 0x6A78FF, 40);
    rect(sx - 2, sy, (int)b.w + 4, 8, 0x4B5068);
    rect(sx - 2, sy, (int)b.w + 4, 2, 0x8A93B0);
    rect(sx, sy + 6, (int)b.w, 2, 0x1B1E2C);
}
static void drawCollectible(float wx, float wy, float cx, float cy) {
    int x = (int)(wx - cx), y = (int)(wy - cy + sinf((float)gTime * 3 + wx * 0.05f) * 2);
    if (x < -20 || x > W + 20) return;
    disc(x, y, 8, 0xFF6A7A, 50);
    disc(x, y, 7, 0x0A0A14); disc(x, y, 6, 0xD62839);
    rect(x - 1, y - 3, 2, 6, 0xFFFFFF); rect(x - 3, y - 1, 6, 1, 0xFFFFFF); rect(x - 3, y - 3, 1, 1, 0xFFFFFF);
    rect(x + 3, y - 3, 1, 1, 0xFFFFFF); rect(x - 3, y + 2, 1, 1, 0xFFFFFF); rect(x + 3, y + 2, 1, 1, 0xFFFFFF);
    if (((int)(gTime * 4 + wx)) % 5 == 0) rect(x + 4, y - 6, 2, 2, 0xFFFFFF);
}
static void drawCable(const Building& b, float cx, float cy) {
    if (!b.cable) return;
    float x0 = b.cx0 - cx, y0 = b.cy0 - cy, x1 = b.cx1 - cx, y1 = b.cy1 - cy;
    if (x1 < -20 || x0 > W + 20) return;
    float px = x0, py = y0;
    for (int i = 1; i <= 24; i++) {
        float u = i / 24.0f, qx = lerpf(x0, x1, u), qy = lerpf(y0, y1, u) + 22 * 4 * u * (1 - u);
        line(px, py + 1, qx, qy + 1, 0x05060F, 200); line(px, py, qx, qy, 0x9AA3C0);
        px = qx; py = qy;
    }
    float ax = (x0 + x1) / 2, ay = (y0 + y1) / 2 + 22;
    disc((int)ax, (int)ay + 2, 8, 0xFFE8A0, 45);
    rect((int)ax - 3, (int)ay - 2, 6, 6, 0xFFE8A0); rect((int)ax - 1, (int)ay - 4, 2, 2, 0x4A5060);
}
static void drawMasts(const Building& b, int sx, int sy) {
    if (b.mastR) { int x = sx + (int)b.w - 12; rect(x, sy - 280, 3, 280, 0x2A2F3F); rect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) rect(x, sy - 284, 3, 3, 0xFF4040); }
    if (b.mastL) { int x = sx + 9; rect(x, sy - 280, 3, 280, 0x2A2F3F); rect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) rect(x, sy - 284, 3, 3, 0xFF4040); }
}

static int pickFrame() {
    Player& p = P;
    if (!p.alive) return p.deadT < 0.3f ? F_HIT : F_DEAD;
    if (p.swinging) return p.attachT > 0 ? F_ATTACH : F_SWING;
    if (p.shootT > 0 && !p.onGround) return F_SHOOT;
    if (p.releaseT > 0) return F_RELEASE;
    if (p.landT > 0) return p.hero ? F_HERO : F_LAND;
    if (p.onGround) return F_RUN;
    if (p.flipT > 0) return F_FLIP;
    return p.vy < 0 ? F_JUMP : F_FALL;
}

static void drawWorldScene(float cx, float cy) {
    for (auto& b : bld) {
        if (b.x + b.w < cx - 160 || b.x > cx + W + 160) continue;
        int sx = (int)floorf(b.x - cx), sy = (int)floorf(b.roofY - cy);
        for (auto& o : b.obs) if (!o.solid) drawObs(o, (int)floorf(o.x - cx), sy, gTime);
        drawFacade(b, sx, sy);
        drawMasts(b, sx, sy);
        for (auto& o : b.obs) if (o.solid) drawObs(o, (int)floorf(o.x - cx), sy, gTime);
    }
    for (auto& b : bld) drawCable(b, cx, cy);
    for (auto& c : colls) drawCollectible(c.x, c.y, cx, cy);
}
static void drawParticles(float cx, float cy) {
    for (auto& p : parts) if (p.alive)
        rect((int)(p.x - cx), (int)(p.y - cy), p.sz, p.sz, p.c, (int)(255 * clampf(p.life / p.max, 0, 1)));
}
static void drawPlayerAndWeb(float cx, float cy) {
    Player& p = P;
    int sx = (int)floorf(p.x - cx), sy = (int)floorf(p.y - cy);
    // anchor hint (glowing target while airborne)
    if (haveTarget && !p.swinging && p.alive) {
        int ax = (int)(tgtX - cx), ay = (int)(tgtY - cy);
        int r = 5 + (int)(2 * sinf((float)gTime * 8));
        disc(ax, ay, r + 2, 0x7FE0FF, 40); rect(ax - 1, ay - 1, 3, 3, 0xFFFFFF);
    }
    double ang = 0;
    if (p.swinging) ang = atan2((double)(p.ax - p.x), (double)(p.y - p.ay)) * 180.0 / PI;
    else if (!p.alive) ang = gTime * 500;
    else if (!p.onGround && p.flipT > 0) {          // double-jump somersault, eased
        float u = clampf(1.0f - p.flipT / 0.55f, 0, 1);
        ang = (u * u * (3 - 2 * u)) * 360.0;
    }
    else if (!p.onGround && p.releaseT > 0) ang = clampf(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / PI * 0.6f, -30, 42);  // dive follows the flight path
    else if (!p.onGround) ang = clampf(p.vy * 0.01f, -8, 14);
    const int fr = pickFrame();
    const StkPose& pose = stkAdvance(gPlayerAnim, fr, gRunPhase, clampf(0.5f + (p.x - p.ax) / 80.0f, 0, 1));
    float hfx, hfy;
    stickHand(pose, sx, sy + 26, ang, hfx, hfy);
    if (p.swinging) {
        int hx = (int)hfx, hy = (int)hfy, ax = (int)(p.ax - cx), ay = (int)(p.ay - cy);
        line((float)hx, (float)hy + 1, (float)ax, (float)ay + 1, 0x05060F, 220);
        line((float)hx, (float)hy, (float)ax, (float)ay, 0xFFFFFF);
        line((float)hx + 1, (float)hy, (float)ax + 1, (float)ay, 0xC8D8FF, 150);
    } else if (p.shootT > 0 && p.alive) {  // rope flick toward the sky when nothing to grab
        float u = 1 - p.shootT / 0.14f;
        line(hfx, hfy, hfx + 70 * u, hfy - 70 * u, 0xFFFFFF, 200);
    }
    drawHalo(sx, sy - 6);
    drawStickman(pose, sx, sy + 26, ang);
    if (p.vx > 420 && p.alive)  // speed lines
        for (int i = 0; i < 4; i++) rect(sx - 40 - (int)hash3(i, (u32)(gTime * 20), 1) % 50, sy - 30 + i * 14, 20 + (int)hash3(i, 4, 4) % 20, 1, 0xFFFFFF, 70);
}

// ---------------------------------------------------------------- UI drawing
static void drawButton(const Btn& b, bool pressed) {
    if (b.kind == 1) {
        rect(b.x, b.y, textW(b.label, 1), 7, 0, 0);
        text(b.label, b.x, b.y, 1, 0xBFC8F0);
        char v[16]; snprintf(v, sizeof v, "%d%%", (int)lroundf((*b.val - b.vmin) / (b.vmax - b.vmin) * 100));
        text(v, b.x + b.w - textW(v, 1), b.y, 1, 0xFFFFFF);
        int ty = b.y + 18;
        rect(b.x, ty, b.w, 12, 0x0A0C1C, 200); rect(b.x, ty, b.w, 1, 0xD62839); rect(b.x, ty + 11, b.w, 1, 0xD62839);
        int fw = (int)((*b.val - b.vmin) / (b.vmax - b.vmin) * b.w);
        rect(b.x, ty + 2, fw, 8, 0xD62839);
        rect(b.x + fw - 3, ty - 4, 6, 20, pressed ? 0xFFFFFF : 0xE8ECFF);
        return;
    }
    rect(b.x, b.y, b.w, b.h, pressed ? 0xD62839 : 0x0A0C1C, pressed ? 230 : 190);
    rect(b.x, b.y, b.w, 1, 0xD62839); rect(b.x, b.y + b.h - 1, b.w, 1, 0xD62839);
    rect(b.x, b.y, 1, b.h, 0xD62839); rect(b.x + b.w - 1, b.y, 1, b.h, 0xD62839);
    if (b.kind == 2) {
        int sc = fitScale(b.label, b.w - 70, 2);
        text(b.label, b.x + 8, b.y + (b.h - 7 * sc) / 2, sc, 0xFFFFFF);
        bool on = *b.flag;
        rect(b.x + b.w - 52, b.y + b.h / 2 - 9, 44, 18, on ? 0xD62839 : 0x2A2F3F);
        rect(b.x + b.w - (on ? 24 : 50), b.y + b.h / 2 - 7, 14, 14, 0xFFFFFF);
        return;
    }
    int sc = fitScale(b.label, b.w - 24, b.id == B_PLAY ? 3 : 2);
    int tx = b.x + (b.w - textW(b.label, sc)) / 2, ty = b.y + (b.h - 7 * sc) / 2;
    textShadow(b.label, tx, ty, sc, 0xFFFFFF);
    if (b.id == B_PLAY || pressed) {  // animated selection indicator
        int o = (int)(2 + 2 * sinf((float)gTime * 6));
        text(">", b.x + 6 + o, ty, sc, 0xFF4050);
    }
}
static void drawButtons() {
    for (auto& b : btns) {
        bool pr = false;
        for (auto& t : tch) if (t.on && t.btn == b.id && (t.role == R_UI || t.role == R_SLIDER)) pr = true;
        drawButton(b, pr);
    }
}
static void drawRotateScreen() {
    rect(0, 0, W, H, 0x070A1E);
    int cx = W / 2, cy = H / 2 - 30;
    float a = sinf((float)gTime * 2.0f);
    rect(cx - 12, cy - 20, 24, 40, 0xE8ECFF); rect(cx - 10, cy - 17, 20, 30, 0x0E1432); rect(cx - 3, cy + 15, 6, 2, 0xE8ECFF);
    int ax = cx + 36 + (int)(a * 6);
    text(">", ax, cy - 8, 3, 0xD62839);
    textC("ROTATE YOUR", cx, cy + 50, fitScale("ROTATE YOUR", W - 20, 3), 0xFFFFFF);
    textC("DEVICE", cx, cy + 50 + 26, fitScale("DEVICE", W - 20, 3), 0xFFFFFF);
    textC("TO LANDSCAPE", cx, cy + 50 + 52, fitScale("TO LANDSCAPE", W - 20, 2), 0xD62839);
}
static void drawTitle() {
    int sc = (int)clampf(W * 0.46f / 60.0f, 3, 7);
    int x = (int)safeL + 10, y = (int)(H * 0.08f);
    text("STICKMAN", x + sc, y + sc, sc, 0x4A0A14);
    text("STICKMAN", x, y, sc, 0xE02A3A);
    text("STICKMAN", x, y - 1, sc, 0xFF6A78, 70);
    int sc2 = std::max(2, sc * 5 / 10);
    textShadow("PIXEL CITY", x + 4, y + 7 * sc + 8, sc2, 0xCFE0FF);
    rect(x, y + 7 * sc + 8 + 7 * sc2 + 6, textW("STICKMAN", sc), 2, 0xD62839);
}
static void drawMenuScene(double dt) {
    menuT += (float)dt;
    drawBackdrop(menuT * 16.0f, -200, gTime);
    // foreground rooftop ledge slab
    int roofY = (int)(H * 0.76f), sx0 = (int)(W * 0.50f), sw = W - sx0 + 20;
    Building mb; mb.x = (float)sx0; mb.w = (float)(sw / 16 * 16); mb.roofY = 0; mb.style = 1; mb.seed = 99;
    drawFacade(mb, sx0, roofY);
    // radio mast with blinking light
    int mx = (int)(W * 0.90f), mtop = (int)(H * 0.20f);
    rect(mx, mtop, 3, roofY - mtop, 0x2A2F3F); rect(mx - 5, mtop + 18, 13, 1, 0x2A2F3F);
    if (((int)(gTime * 1.5)) & 1) { disc(mx + 1, mtop - 2, 4, 0xFF2A2A, 70); rect(mx, mtop - 3, 3, 3, 0xFF4040); }
    // stickman standing on the ledge, rope to the mast
    int spx = (int)(W * 0.68f);
    float sway = sinf((float)gTime * 1.3f);
    int idle = ((int)(gTime * 1.2)) & 1;
    int fy = roofY, handX = spx + 4, handY = fy - 32;
    float t = trans;
    int frame = F_IDLE;  // continuous breathing loop
    double ang = 0; int px = spx, py = fy;
    if (t >= 0) {
        if (t < 0.35f) { frame = F_SHOOT; }
        else {
            float u = clampf((t - 0.35f) / 0.6f, 0, 1);
            frame = u < 0.55f ? F_ATTACH : F_RELEASE;
            px = (int)lerpf((float)spx, (float)(W + 60), u * u); py = fy - (int)(130 * sinf(u * PI * 0.9f));
            ang = u * 40;
        }
    }
    const StkPose& pose = stkAdvance(gMenuAnim, frame, (float)gTime * 0.83f, 0.5f);
    { float hx, hy; stickHand(pose, px, py, ang, hx, hy); handX = (int)hx; handY = (int)hy; }
    float webLen = (t >= 0 && t < 0.35f) ? t / 0.35f : 1.0f;
    float wx = lerpf((float)handX, (float)mx + 1, webLen), wy = lerpf((float)handY, (float)mtop, webLen);
    if (t < 0 || t < 0.6f) {
        float px0 = (float)handX, py0 = (float)handY;
        for (int i = 1; i <= 16; i++) {
            float u = i / 16.0f, qx = lerpf((float)handX, wx, u), qy = lerpf((float)handY, wy, u) + (t < 0 ? (18 + 4 * sway) * 4 * u * (1 - u) : 0);
            line(px0, py0 + 1, qx, qy + 1, 0x05060F, 200); line(px0, py0, qx, qy, 0xFFFFFF);
            px0 = qx; py0 = qy;
        }
    }
    drawHalo(px, py - 26 + (int)(idle && t < 0));
    drawStickman(pose, px, py, ang);
}

static void drawHUD() {
    char b[64];
    snprintf(b, sizeof b, "SCORE %d", scoreVal());
    textShadow(b, (int)safeL, (int)safeT, 2, 0xFFFFFF);
    snprintf(b, sizeof b, "DIST %dM", (int)distM);
    textShadow(b, (int)safeL, (int)safeT + 18, 2, 0xBFD8FF);
    snprintf(b, sizeof b, "WEBS %d", coinCount);
    textShadow(b, W - (int)safeR - textW(b, 2), (int)safeT, 2, 0xFF6A7A);
    snprintf(b, sizeof b, "BEST %dM", (int)std::max(cfg.best, distM));
    textShadow(b, W - (int)safeR - textW(b, 2), (int)safeT + 18, 2, 0xBFD8FF);
    // pause button
    rect(pauseBtn.x, pauseBtn.y, 44, 44, 0x0A0C1C, 170);
    rect(pauseBtn.x, pauseBtn.y, 44, 1, 0xD62839); rect(pauseBtn.x, pauseBtn.y + 43, 44, 1, 0xD62839);
    rect(pauseBtn.x, pauseBtn.y, 1, 44, 0xD62839); rect(pauseBtn.x + 43, pauseBtn.y, 1, 44, 0xD62839);
    rect(pauseBtn.x + 14, pauseBtn.y + 12, 5, 20, 0xFFFFFF); rect(pauseBtn.x + 25, pauseBtn.y + 12, 5, 20, 0xFFFFFF);
    if (chainShowT > 0 && P.chain + 0 >= 0) {
        snprintf(b, sizeof b, "SWING CHAIN +%d", 10 * std::max(2, P.chain));
        textC(b, W / 2, (int)(H * 0.22f), 2, 0x7FE0FF);
    }
    // on-screen controls
    float sx, sy, sr, jx, jy, jr; ctlGeom(sx, sy, sr, jx, jy, jr);
    bool sp = false, jp = false;
    for (auto& t : tch) if (t.on) { if (t.role == R_SWING) sp = true; if (t.role == R_JUMP) jp = true; }
    disc((int)sx, (int)sy, (int)sr, sp ? 0xD62839 : 0x0A0C1C, sp ? 220 : 150);
    disc((int)sx, (int)sy, (int)sr - 3, sp ? 0xFF4050 : 0x15183A, sp ? 120 : 120);
    for (int i = 0; i < 4; i++) { float a = i * PI / 4; line(sx - cosf(a) * 20, sy - sinf(a) * 20 - 4, sx + cosf(a) * 20, sy + sinf(a) * 20 - 4, 0xFFFFFF, 200); }
    textC("SWING", (int)sx, (int)sy + 18, 1, 0xFFFFFF);
    disc((int)jx, (int)jy, (int)jr, jp ? 0xD62839 : 0x0A0C1C, jp ? 220 : 150);
    disc((int)jx, (int)jy, (int)jr - 3, jp ? 0xFF4050 : 0x15183A, 120);
    rect((int)jx - 1, (int)jy - 14, 3, 20, 0xFFFFFF); rect((int)jx - 8, (int)jy - 8, 4, 3, 0xFFFFFF); rect((int)jx + 5, (int)jy - 8, 4, 3, 0xFFFFFF);
    rect((int)jx - 5, (int)jy - 12, 3, 3, 0xFFFFFF); rect((int)jx + 3, (int)jy - 12, 3, 3, 0xFFFFFF);
    textC("JUMP", (int)jx, (int)jy + 12, 1, 0xFFFFFF);
}
static void dim(int a) { rect(0, 0, W, H, 0x03040C, a); }
static void panelBox(int x, int y, int w, int h) {
    rect(x, y, w, h, 0x0A0C1C, 215);
    rect(x, y, w, 1, 0xD62839); rect(x, y + h - 1, w, 1, 0xD62839); rect(x, y, 1, h, 0xD62839); rect(x + w - 1, y, 1, h, 0xD62839);
}
static void drawLines(const char* const* ls, int n, int cx, int y0, int maxW) {
    for (int i = 0; i < n; i++) { int sc = fitScale(ls[i], maxW, 2); textC(ls[i], cx, y0 + i * 26, sc, 0xDDE6FF); }
}

static void render(double dt) {
    SDL_SetRenderTarget(gRen, gTarget);
    SDL_SetRenderDrawBlendMode(gRen, SDL_BLENDMODE_BLEND);
    if (portrait) { drawRotateScreen(); goto present; }
    {
        bool world = gState == PLAYING || gState == PAUSED || gState == GAME_OVER || (gState == SETTINGS && settingsFrom == PAUSED);
        buildUI();
        if (world) {
            float shx = 0, shy = 0;
            if (shakeT > 0 && cfg.shake) { shx = ((int)hash3((u32)(gTime * 90), 1, 2) % 5) - 2.0f; shy = ((int)hash3((u32)(gTime * 90), 3, 4) % 5) - 2.0f; }
            float cx = floorf(camX + shx), cy = floorf(camY + shy);
            drawBackdrop(cx, cy, gTime);
            drawWorldScene(cx, cy);
            drawParticles(cx, cy);
            drawPlayerAndWeb(cx, cy);
            rect(0, (int)(H * 0.86f), W, H, 0x2A3060, 30);
            if (gState == PLAYING) drawHUD();
        } else drawMenuScene(dt);

        switch (gState) {
            case MAIN_MENU:
                drawTitle();
                drawButtons();
                if (cfg.best > 0) { char b[40]; snprintf(b, sizeof b, "BEST %dM", (int)cfg.best); text(b, (int)safeL + 10, H - (int)safeB - 10, 1, 0x9AA3C8); }
                break;
            case SETTINGS: {
                dim(150);
                int pw = std::min(W - (int)(safeL + safeR), 560);
                panelBox((W - pw) / 2, 14, pw, H - 28);
                textC("SETTINGS", W / 2, 28, 4, 0xE02A3A);
                drawButtons();
                textC("BEST PLAYED IN LANDSCAPE", W / 2, 250, 1, 0x9AA3C8);
            } break;
            case HOW_TO_PLAY: {
                dim(150);
                panelBox(W / 2 - 280 < 14 ? 14 : W / 2 - 280, 14, std::min(560, W - 28), H - 28);
                textC("HOW TO PLAY", W / 2, 28, 4, 0xE02A3A);
                static const char* ls[] = {"HOLD SWING IN THE AIR TO SHOOT A ROPE", "WATCH FOR THE GLOWING ANCHOR POINTS", "RELEASE TO FLY WITH YOUR MOMENTUM",
                    "TAP JUMP TO LEAP. TAP AGAIN IN AIR", "SLIDE A FINGER ON THE LEFT TO STEER", "COLLECT TOKENS. CHAIN SWINGS FOR BONUS"};
                drawLines(ls, 6, W / 2, 80, std::min(520, W - 60));
                drawButtons();
            } break;
            case CREDITS: {
                dim(150);
                panelBox(W / 2 - 280 < 14 ? 14 : W / 2 - 280, 14, std::min(560, W - 28), H - 28);
                textC("CREDITS", W / 2, 28, 4, 0xE02A3A);
                static const char* ls[] = {"STICKMAN: PIXEL CITY", "STICKMAN STYLE INSPIRED BY ALAN BECKER", "FAN-MADE TRIBUTE. NOT AFFILIATED.", "ALL ART AND AUDIO ARE GENERATED IN CODE",
                    "BUILT WITH C++ AND SDL2"};
                drawLines(ls, 5, W / 2, 90, std::min(520, W - 60));
                drawButtons();
            } break;
            case PAUSED:
                dim(150);
                textC("PAUSED", W / 2, (int)(H * 0.12f), 5, 0xE02A3A);
                drawButtons();
                break;
            case GAME_OVER: {
                dim(160);
                textC("GAME OVER", W / 2, (int)(H * 0.10f), 5, 0xE02A3A);
                char b[64];
                snprintf(b, sizeof b, "SCORE %d", scoreVal()); textC(b, W / 2, (int)(H * 0.10f) + 52, 3, 0xFFFFFF);
                snprintf(b, sizeof b, "DISTANCE %dM", (int)distM); textC(b, W / 2, (int)(H * 0.10f) + 86, 2, 0xBFD8FF);
                snprintf(b, sizeof b, "BEST %dM%s", (int)cfg.best, newBest ? "  NEW!" : ""); textC(b, W / 2, (int)(H * 0.10f) + 112, 2, newBest ? 0xFFE9A0 : 0xBFD8FF);
                snprintf(b, sizeof b, "WEBS COLLECTED %d", coinCount); textC(b, W / 2, (int)(H * 0.10f) + 138, 2, 0xFF6A7A);
                drawButtons();
            } break;
            default: break;
        }
        if (fadeIn > 0) rect(0, 0, W, H, 0x000000, (int)(255 * clampf(fadeIn / 0.5f, 0, 1)));
        if (trans > 0.7f) rect(0, 0, W, H, 0x000000, (int)(255 * clampf((trans - 0.7f) / 0.3f, 0, 1)));
    }
present:
    SDL_SetRenderTarget(gRen, nullptr);
    SDL_SetRenderDrawColor(gRen, 0, 0, 0, 255);
    SDL_RenderClear(gRen);
    SDL_Rect dst = {OFFX, OFFY, W * SC, H * SC};
    SDL_RenderCopy(gRen, gTarget, nullptr, &dst);
    SDL_RenderPresent(gRen);
}

// ============================================================================
//  UPDATE
// ============================================================================
static void updateGame(double dt) {
    pollHeld();
    Player& p = P;
    // web attach / release (edge + hold)
    if (swingHeld && !swingWas) { sfx(0); p.shootT = 0.14f; }
    swingWas = swingHeld;
    haveTarget = false;
    if (p.alive && !p.onGround && !p.swinging) haveTarget = findAnchor(tgtX, tgtY);
    if (p.alive && swingHeld && !p.swinging && !p.onGround && haveTarget) attachWeb(tgtX, tgtY);
    if (p.swinging && !swingHeld) releaseWeb(false);
    // fixed timestep physics
    static double acc = 0;
    acc += dt;
    int guard = 0;
    while (acc >= 1.0 / 120.0 && guard++ < 12) { stepPhysics(1.0f / 120.0f); acc -= 1.0 / 120.0; }
    if (guard >= 12) acc = 0;
    // timers
    p.animT += (float)dt; p.landT -= (float)dt; p.shootT -= (float)dt; p.attachT -= (float)dt; p.releaseT -= (float)dt; p.flipT -= (float)dt;
    if (p.alive && p.onGround) gRunPhase += (float)dt * 1.44f * clampf(p.vx / 230.0f, 0.6f, 2.2f);
    chainShowT -= (float)dt; shakeT -= (float)dt;
    if (p.alive) {
        distM = std::max(distM, (p.x - startX) / 16.0f);
        if (p.vx > 420) speedBonus += (float)dt * 20.0f;
        for (size_t i = 0; i < colls.size();) {
            if (hypotf(colls[i].x - p.x, colls[i].y - (p.y - 4)) < 24) {
                coinCount++; bonus += 10; sfx(3);
                burst(colls[i].x, colls[i].y, 6, 0xFFE9A0, 80);
                colls[i] = colls.back(); colls.pop_back();
            } else i++;
        }
        if (p.swinging || p.vx > 350) {  // web trail sparks
            if (((int)(gTime * 30)) % 3 == 0) spawnPart(p.x - 6, p.y - 8, -30, 10, 0.25f, 0x7FA8FF, 1);
        }
    } else {
        p.deadT += (float)dt;
        if (p.deadT > 1.1f && gState == PLAYING) {
            if (distM > cfg.best) { cfg.best = distM; newBest = true; }
            saveCfg();
            gState = GAME_OVER;
        }
    }
    for (auto& q : parts) if (q.alive) {
        q.life -= (float)dt; if (q.life <= 0) { q.alive = false; continue; }
        q.x += q.vx * (float)dt; q.y += q.vy * (float)dt; q.vy += 300 * (float)dt;
    }
    // camera
    float tx = p.x - W * 0.30f + clampf(p.vx * 0.12f, -20, 80);
    float ty = p.y - H * 0.58f;
    if (p.swinging) ty = lerpf(p.y, p.ay, 0.3f) - H * 0.55f;
    if (p.alive || p.deadT < 0.6f) {
        camX += (tx - camX) * (1 - expf(-6.0f * (float)dt));
        camY += (ty - camY) * (1 - expf(-4.0f * (float)dt));
    }
    ensureWorld();
    aWind = clampf((p.vx - 250) / 400.0f, 0, 1) * (p.onGround ? 0.4f : 1.0f);
}

int main(int, char**) {
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
    SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight Portrait");
    SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "1");  // lets you test on a desktop with the mouse
    SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");
    SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) return 1;
    loadCfg();
    Uint32 flags = SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
#ifdef __ANDROID__
    flags |= SDL_WINDOW_FULLSCREEN;
#endif
    gWin = SDL_CreateWindow("Stickman: Pixel City", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 600, flags);
    gRen = SDL_CreateRenderer(gWin, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!gWin || !gRen) return 1;
    SDL_SetRenderDrawBlendMode(gRen, SDL_BLENDMODE_BLEND);
    initFont();
    recalcDisplay();
    buildArt();
    initAudio();
    startRun();           // builds a valid world, then drop back to the menu
    gState = MAIN_MENU; aMode = 1; menuT = 0;

    bool running = true;
    Uint64 last = SDL_GetPerformanceCounter();
    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_QUIT: running = false; break;
                case SDL_WINDOWEVENT:
                    if (e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED || e.window.event == SDL_WINDOWEVENT_RESIZED) { recalcDisplay(); releaseAll(); }
                    if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST) { releaseAll(); if (gState == PLAYING) gState = PAUSED; }
                    break;
                case SDL_APP_WILLENTERBACKGROUND:
                    releaseAll(); if (gState == PLAYING) gState = PAUSED; saveCfg();
                    if (gAud) SDL_PauseAudioDevice(gAud, 1);
                    break;
                case SDL_APP_DIDENTERFOREGROUND:
                    if (gAud && audioStarted) SDL_PauseAudioDevice(gAud, 0);
                    break;
                case SDL_FINGERDOWN: fingerDown(e.tfinger); break;
                case SDL_FINGERMOTION: fingerMove(e.tfinger); break;
                case SDL_FINGERUP: fingerUp(e.tfinger); break;
                case SDL_KEYDOWN:
                    if (e.key.keysym.scancode == SDL_SCANCODE_AC_BACK || e.key.keysym.sym == SDLK_ESCAPE) {
                        if (gState == PLAYING) gState = PAUSED;
                        else if (gState == PAUSED) gState = PLAYING;
                        else if (gState == SETTINGS || gState == HOW_TO_PLAY || gState == CREDITS) activate(B_BACK);
                    }
                    break;
                default: break;
            }
        }
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = (double)(now - last) / (double)SDL_GetPerformanceFrequency();
        last = now;
        dt = std::min(dt, 0.05);
        gTime += dt;
        if (fadeIn > 0) fadeIn -= (float)dt;
        buildUI();
        if (!portrait) {
            if (gState == PLAYING) updateGame(dt);
            else if (gState == GAME_OVER) {  // let the death tumble finish, but nothing else simulates
                for (auto& q : parts) if (q.alive) { q.life -= (float)dt; if (q.life <= 0) q.alive = false; }
            }
            if (gState == MAIN_MENU && trans >= 0) {
                trans += (float)dt;
                if (trans >= 1.0f) { trans = -1; startRun(); fadeIn = 0.5f; }
            }
        }
        render(dt);
    }
    saveCfg();
    SDL_Quit();
    return 0;
}
