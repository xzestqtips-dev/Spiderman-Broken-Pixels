#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static const Btn* findBtn(int id) { for (auto& b : btns) if (b.id == id) return &b; return nullptr; }
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_fps/", 1);
    if (system("rm -rf /tmp/pcity_fps && mkdir -p /tmp/pcity_fps") != 0) return 2;
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(true);
    // Frame limiter: default 60, the button cycles 30 -> 60 -> 120 -> uncapped -> 30, and the choice survives a save/load.
    CHECK(fpsCap() == 60);
    gState = SETTINGS; buildUI();
    CHECK(findBtn(B_FPS_CAP) && findBtn(B_SHOW_FPS));
    for (auto& b : btns) CHECK(b.y + b.h <= uvzWorldHeight);
    activate(B_FPS_CAP); CHECK(fpsCap() == 120);
    activate(B_FPS_CAP); CHECK(fpsCap() == 0);          // uncapped
    activate(B_SHOW_FPS); CHECK(!cfg.showFps);
    saveCfg(); cfg.fpsIdx = 1; cfg.showFps = true; loadCfg();
    CHECK(fpsCap() == 0 && !cfg.showFps);
    activate(B_FPS_CAP); CHECK(fpsCap() == 30);
    // Credits: STRYER on the main menu opens the full-screen view; BACK (large, top-left) and Esc/Android-back return to the menu.
    gState = MAIN_MENU; navStack.clear(); trans = -1; buildUI();
    const Btn* st = findBtn(B_CREDITS);
    CHECK(st && strcmp(st->label, "STRYER") == 0);
    activate(B_CREDITS); CHECK(gState == CREDITS);
    buildUI();
    const Btn* bk = findBtn(B_BACK);
    CHECK(bk && bk->x <= (int)uvzSafeLeft + 1 && bk->y <= (int)uvzSafeTop + 4);   // top-left
    CHECK(bk && bk->w >= 120 && bk->h >= 48);                                    // large touch target
    CHECK(btns.size() == 1);
    activate(B_BACK); CHECK(gState == MAIN_MENU);
    // Speed zoom: no pull-back below the threshold, full pull-back far above it, eased in both directions, never past the limits.
    gState = PLAYING; P = Player(); P.alive = true; P.onGround = false; gZoom = 1.0f; cfg.reduced = false;
    bld.clear(); { Building b; b.x = -3000; b.w = 12000; b.roofY = 20000; b.style = 0; b.seed = 1; bld.push_back(b); }   // empty sky: nothing to land on
    camX = -uvzWorldWidth * 0.3f; camY = -3000 - uvzWorldHeight * 0.58f;
    for (int i = 0; i < 300; i++) { P.vx = 400; P.vy = 0; P.x = 0; P.y = -3000; updateGame(1.0 / 60); }
    CHECK(gZoom == 1.0f);
    float prev = gZoom, worstStep = 0;
    for (int i = 0; i < 600; i++) { P.vx = 2400; P.vy = 0; P.x = 0; P.y = -3000; P.px = 0; P.py = -3000; updateGame(1.0 / 60); worstStep = std::max(worstStep, prev - gZoom); prev = gZoom; }
    CHECK(gZoom < 0.91f && gZoom >= ZOOM_MIN);
    CHECK(worstStep < 0.02f);                                                    // smooth, no snap
    for (int i = 0; i < 600; i++) { P.vx = 300; P.vy = 0; P.x = 0; P.y = -3000; P.px = 0; P.py = -3000; updateGame(1.0 / 60); }
    CHECK(gZoom > 0.99f);                                                        // eased back in
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
