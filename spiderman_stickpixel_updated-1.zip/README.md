# Stickman: Pixel City

A mobile-first, landscape pixel-art endless runner written in **C++17 + SDL2** as a single source file.
Run across rooftops, grab glowing anchor points with your rope, swing, release and chain swings for bonus points.

## Features

- **Stickman player in the style of Alan Becker's *Animator vs. Animation*** - uniform-width limbs, a plain round head, no face.
  He is not a sprite: the skeleton is posed from joint angles every frame, so there are **no asset files**.
  Smooth by construction: run / idle / swing poses come from a continuous phase (stride speed follows ground speed),
  every joint angle is a damped spring chasing the target pose, so limbs overshoot and settle (follow-through) and every move flows into the next, and limbs are drawn as anti-aliased capsules.
- **Spider-Man-inspired moveset, randomised per move:** every run, jump, fall, web shot, swing and landing picks a random pose variant (hunched or sprinting run, tucked / spread / layout swings, star-jump or crouched leaps, deep-crouch or one-hand landings) plus a small random nudge, and a fast release sometimes ends in a front or back somersault. Also idle crouch, web throw, double-jump tuck flip, superhero landing, hit and defeat. Web shots travel to their selected anchor before swing attachment; wall contact can enter an attached crawl state with alternating limb poses.
- Procedurally generated city, parallax skyline, fonts, music and sound effects - everything is made in code.
- Pixel-perfect integer scaling that adapts to any phone resolution, with safe-area margins and touch targets sized from the screen DPI.
- **Swing boost:** landing with speed carried out of a swing gives a temporary run-speed bonus (2-5 s, bigger for faster swings), shown by a bar on the HUD.
- **Slide:** a short low skid that holds onto your speed (with three random slide poses and dust); pressing SLIDE just before landing slides straight out of the fall and lengthens the boost.
- Press-to-start title, clean menu / settings / controls screens, rebindable keyboard controls, a drag-and-drop touch layout editor and a saved best score.
- Larger procedural buildings, expanded gaps, extra anchor points and camera tracking tuned for vertical movement.

## Controls

| Action | Touch | Keyboard (default, rebindable) |
| --- | --- | --- |
| Steer | Slide a finger on the steer side of the screen | `A` / `D` |
| Jump / double jump | Tap the JUMP button | `Space` |
| Slide | Tap SLIDE on a roof (or just before landing) | `S` |
| Rope | Hold SWING in the air near a glowing anchor, release to fly | Hold `Left Shift` |
| Pause | Pause button / Back button | `P` or `Esc` |

Menus: `Up` / `Down` to move, `Left` / `Right` to adjust sliders, `Enter` / `Space` to select, `Esc` to go back. The mouse also works (hover to highlight, click to select, and it acts as touch in-game).

### Customising controls

Open **CONTROLS** from the main menu or the pause menu. Choices are saved in `controls.txt` next to the save file.

- **Keyboard tab** - select a box, then press the new key. `Esc` cancels. If the key is already used, the two actions swap so nothing is left unbound. *Reset tab* restores the defaults.
- **Touch tab** - button size, button opacity, steering sensitivity and a **left-handed** mode that mirrors the whole layout (buttons and steer zone).
- **Edit layout** - drag the SWING, JUMP and SLIDE buttons anywhere on the screen; the shaded area shows the steer zone. *Reset* puts them back.

## Interface

The title opens on a **PRESS TO START** screen (tap, click or press any key). Menus use a clean, high-contrast style inspired by the Spider-Man games: white on ink, a single red accent, slanted highlight bars and thin rules. The spider emblem is an original shape drawn in code; there are still no asset files.

## Build (desktop)

Requires a C++17 compiler, CMake 3.16+ and the SDL2 development package.

```bash
# Debian / Ubuntu
sudo apt install build-essential cmake libsdl2-dev
# macOS
brew install cmake sdl2

cmake -S . -B build
cmake --build build
./build/stickman_pixel_city
```

Without CMake on Linux / macOS:

```bash
g++ -std=c++17 -O2 src/main.cpp $(sdl2-config --cflags --libs) -o stickman_pixel_city
```

On Windows use CMake with a vcpkg SDL2 install (`-DCMAKE_TOOLCHAIN_FILE=<vcpkg>/scripts/buildsystems/vcpkg.cmake`).

## Build (Android)

The game is plain SDL2, so it drops into SDL's stock Android project:

1. Clone [libsdl-org/SDL](https://github.com/libsdl-org/SDL) (2.x) and open its `android-project` folder in Android Studio.
2. Copy `src/main.cpp` into `android-project/app/jni/src/`.
3. In `app/jni/src/Android.mk` set `LOCAL_SRC_FILES := main.cpp` and add `LOCAL_CPPFLAGS += -std=c++17`.
4. Build and run.

The code requests landscape-only SDL orientation hints, handles the Android back button and background / foreground pause. Android builds should also set `android:screenOrientation="landscape"` on the SDL activity in the Android manifest, since the Android manifest is supplied by the SDL Android wrapper and is not included in this source-only repository.

## Customising the stickman

Everything lives in the `STICKMAN BEGIN / END` block of `src/main.cpp`:

- `STK_BODY` / `STK_OUTLINE` - limb colour and the thin rim that keeps him readable on the night sky
  (try `0xFF8A1E` for the orange "Second Coming" look).
- `stkMakePose()` - every pose as a handful of joint angles (`stkRate()` sets how fast he eases between them) (degrees from straight down, positive = toward the facing side).
- `STK_THIGH`, `STK_SHIN`, `STK_UARM`, ... - limb lengths.

## Credits

Stickman style inspired by Alan Becker's *Animator vs. Animation*. This is an unofficial fan tribute and is not affiliated with or endorsed by Alan Becker or Alan Becker Productions.

## License

[MIT](LICENSE) - Copyright (c) 2026 xzestqtips (zkqruvz).

## Skill upgrades, coins and rebirth
- Tap the spider-web **UPGRADES** icon on the main menu or game-over screen.
- Every 200 m travelled earns 15 coins. Coins, levels and rebirths are saved in `progress.txt` next to `save.txt`.
- Run Speed: +0.25 per level, 500 coins, max level 50, rebirth 1,000 coins.
- Swing Speed: +0.20 per level, 750 coins, max level 50, rebirth 5,000 coins.
- Rebirth (needs level 50) resets that skill's level and adds a permanent +0.1x multiplier, up to rebirth 50. Total speed = (1 + level bonus) x (1 + 0.1 x rebirths).
- Logic lives in `src/progression.h`. Tests: `tests/test_progression.cpp` (logic) and `tests/test_game.cpp` (headless run of the real game code with a stub SDL).
