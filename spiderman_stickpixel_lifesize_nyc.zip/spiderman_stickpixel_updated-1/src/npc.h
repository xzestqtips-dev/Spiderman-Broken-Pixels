#pragma once
// Sidewalk walkers: reaction logic (pure, no rendering). A walker's scripted stroll is a pure function of time;
// this adds a small per-walker state on top: looking up at a swinger, startling and hopping away when the
// player lands or whips past close by, then easing back to the stroll. Everything is smoothed (no snapping).
#include <cmath>
namespace npc {
static const float MAX_OFF = 34.0f;        // furthest a startled walker is pushed off its path (px)
static const float STARTLE_T = 0.65f;
struct State {
    float off = 0;       // sideways displacement from the scripted path (world px)
    float look = 0;      // 0..1 how far the head is tipped up toward the player
    float react = 0;     // 0..1 smoothed startle pose weight
    float startle = 0;   // seconds of startle left
    float hop = 0, hopV = 0;   // vertical hop offset (<= 0 is up)
    float fear = 0;      // 0..1 how scared (scales the hop and the retreat)
    bool seen = false;
};
struct Hero { float x, y, vx, vy; bool swinging, onGround, landedNow; float feetY; float groundY; };
inline float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
// wx: the walker's current world x. Returns true if the walker startled on this step.
inline bool update(State& s, float wx, const Hero& h, float dt) {
    if (dt <= 0) return false;
    if (dt > 0.05f) dt = 0.05f;
    const float dx = h.x - wx, adx = fabsf(dx);
    const float above = h.groundY - h.feetY;                 // how high the player's feet are over the street
    bool alarm = false; float fear = 0.6f;
    if (h.landedNow && adx < 110.0f && above < 40.0f) { alarm = true; fear = clamp01(1.0f - adx / 110.0f) * 0.5f + 0.5f; }
    if (h.swinging && adx < 70.0f && above > 20.0f && above < 150.0f) { alarm = true; fear = 0.8f; }   // swung right over their head
    if (above < 30.0f && fabsf(h.vx) > 320.0f && adx < 55.0f) { alarm = true; fear = 0.9f; }          // sprinted past too close
    bool started = false;
    if (alarm && s.startle <= 0.0f) {
        s.startle = STARTLE_T; s.fear = fear; started = true;
        s.hopV = -(110.0f + 110.0f * fear);
    }
    const float lookT = (above > 60.0f && adx < 190.0f) ? clamp01(1.0f - adx / 190.0f) * (h.swinging ? 1.0f : 0.7f) : 0.0f;
    s.look += (lookT - s.look) * (dt * 6.0f > 1 ? 1 : dt * 6.0f);
    if (s.startle > 0.0f) {
        s.startle -= dt; if (s.startle < 0) s.startle = 0;
        const float away = dx > 0 ? -1.0f : 1.0f;
        s.off += away * (48.0f + 40.0f * s.fear) * dt;
        if (s.off > MAX_OFF) s.off = MAX_OFF; if (s.off < -MAX_OFF) s.off = -MAX_OFF;
    } else {
        const float step = 9.0f * dt;                         // calm down: drift back toward the path
        s.off = fabsf(s.off) <= step ? 0.0f : s.off - (s.off > 0 ? step : -step);
    }
    if (s.hop < 0.0f || s.hopV < 0.0f) {
        s.hopV += 820.0f * dt; s.hop += s.hopV * dt;
        if (s.hop >= 0.0f) { s.hop = 0.0f; s.hopV = 0.0f; }
    }
    const float reactT = s.startle > 0.0f ? 1.0f : 0.0f;
    s.react += (reactT - s.react) * (dt * 14.0f > 1 ? 1 : dt * 14.0f);
    return started;
}
}
