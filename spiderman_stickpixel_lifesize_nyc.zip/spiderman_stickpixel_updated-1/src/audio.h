// Procedural audio for the game: no sample files, everything is synthesized.
// SDL-free on purpose, so the game callback, the headless tests and tools/render_audio.cpp share one implementation.
//
// Sound design: a comic-book hero feel.
//   sfx 0 web shoot  - pneumatic "thwip": bandpassed noise sweeping up + a little pop
//   sfx 1 web attach - wet "thwack" as the line sticks
//   sfx 2 wall thud  - heavy low impact
//   sfx 3 trick/bad  - two-tone chime
//   sfx 4 tick       - UI click
//   sfx 5 splat      - crunch + descending "womp"
//   sfx 6 land       - soft street landing
//   sfx 7 jump/flip  - rising "hup" whoosh
//   sfx 8 combo zip  - bright rising zip with a ringing fifth
// Music (original composition, heroic brass over pulsing bass):
//   mode 1 = title/menu theme: orchestral brass + swelling strings over a boom-bap beat, funk bass and vinyl crackle.
//   mode 2 = gameplay: driving timpani/snare/hats, string ostinato, full brass.
#pragma once
#include <cmath>
#include <cstdint>
#include <cstddef>
#include <vector>

namespace audio {

static const float kPi = 3.14159265f;
static const float kSampleRate = 44100.0f;
enum { kVoices = 12, kSfxCount = 9, kMaxVariants = 8 };

struct Voice {
    bool on = false;
    int type = 0;
    float t = 0, dur = 0.1f, f0 = 440, f1 = 440, amp = 0.5f, ph = 0, ph2 = 0;
    float lo = 0, bd = 0;   // state-variable filter memory
};

class Synth {
public:
    Voice vox[kVoices];

    // Optional sample bank: assets/audio/sfx/<name>_<n>.wav. A sfx type with at least one clip plays a random clip
    // instead of the synthesized sound; types without clips fall back to the synth, so missing files are harmless.
    // Accepts 16-bit PCM WAV (mono or stereo, 44.1 kHz). Call before the audio device starts.
    bool addClip(int type, const unsigned char* b, size_t len) {
        if (type < 0 || type >= kSfxCount || clipCount[type] >= kMaxVariants || len < 44) return false;
        auto u16 = [&](size_t o) { return (unsigned)(b[o] | (b[o + 1] << 8)); };
        auto u32 = [&](size_t o) { return (unsigned)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | ((unsigned)b[o + 3] << 24)); };
        if (b[0] != 'R' || b[1] != 'I' || b[2] != 'F' || b[3] != 'F' || b[8] != 'W') return false;
        unsigned ch = 0, rate = 0, bits = 0; size_t pos = 12;
        while (pos + 8 <= len) {
            unsigned sz = u32(pos + 4);
            if (memcmp8(b + pos, "fmt ") && pos + 8 + 16 <= len) { if (u16(pos + 8) != 1) return false; ch = u16(pos + 10); rate = u32(pos + 12); bits = u16(pos + 22); }
            else if (memcmp8(b + pos, "data")) {
                if (ch < 1 || ch > 2 || bits != 16 || rate != 44100) return false;
                size_t avail = len - (pos + 8); if (sz > avail) sz = (unsigned)avail;
                size_t frames = sz / (2 * ch);
                std::vector<float>& c = clips[type][clipCount[type]];
                c.resize(frames);
                for (size_t i = 0; i < frames; i++) {
                    float acc = 0;
                    for (unsigned k = 0; k < ch; k++) { size_t o = pos + 8 + (i * ch + k) * 2; acc += (int16_t)(b[o] | (b[o + 1] << 8)) / 32768.0f; }
                    c[i] = acc / ch;
                }
                clipCount[type]++;
                return frames > 0;
            }
            pos += 8 + sz + (sz & 1);
        }
        return false;
    }
    // Looping beds from assets/audio: slot 0 menu music, 1 gameplay music, 2 idle rumble, 3 fast wind. 16-bit mono/stereo PCM at any rate (resampled to the mixer rate).
    bool setLoop(int slot, const unsigned char* b, size_t len) {
        if (slot < 0 || slot >= 4 || len < 44 || b[0] != 'R' || b[1] != 'I' || b[2] != 'F' || b[3] != 'F') return false;
        auto u16 = [&](size_t o) { return (unsigned)(b[o] | (b[o + 1] << 8)); };
        auto u32 = [&](size_t o) { return (unsigned)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | ((unsigned)b[o + 3] << 24)); };
        unsigned ch = 0, rate = 0, bits = 0; size_t pos = 12;
        while (pos + 8 <= len) {
            unsigned sz = u32(pos + 4);
            if (memcmp8(b + pos, "fmt ") && pos + 8 + 16 <= len) { if (u16(pos + 8) != 1) return false; ch = u16(pos + 10); rate = u32(pos + 12); bits = u16(pos + 22); }
            else if (memcmp8(b + pos, "data")) {
                if (ch < 1 || ch > 2 || bits != 16 || rate < 8000) return false;
                size_t avail = len - (pos + 8); if (sz > avail) sz = (unsigned)avail;
                size_t frames = sz / (2 * ch);
                std::vector<float> src(frames);
                for (size_t i = 0; i < frames; i++) {
                    float acc = 0;
                    for (unsigned k = 0; k < ch; k++) { size_t o = pos + 8 + (i * ch + k) * 2; acc += (int16_t)(b[o] | (b[o + 1] << 8)) / 32768.0f; }
                    src[i] = acc / ch;
                }
                if (rate == (unsigned)kSampleRate) loops[slot] = std::move(src);
                else {
                    size_t nf = (size_t)((double)frames * kSampleRate / rate); loops[slot].assign(nf, 0.0f);
                    for (size_t i = 0; i < nf; i++) { double q = (double)i * rate / kSampleRate; size_t i0 = (size_t)q; size_t i1 = i0 + 1 < frames ? i0 + 1 : 0; float f = (float)(q - i0); loops[slot][i] = src[i0] * (1 - f) + src[i1] * f; }
                }
                loopPos[slot] = 0;
                return !loops[slot].empty();
            }
            pos += 8 + sz + (sz & 1);
        }
        return false;
    }
    bool hasLoop(int slot) const { return slot >= 0 && slot < 4 && !loops[slot].empty(); }
    int clipsLoaded() const { int n = 0; for (int t = 0; t < kSfxCount; t++) n += clipCount[t]; return n; }

    // Start a sound effect; steals the oldest voice when all are busy. Call with the audio device locked.
    void trigger(int type) {
        if (type < 0 || type >= kSfxCount) return;
        if (clipCount[type] > 0) {   // sampled sound: random variant on a free (or the oldest) clip voice
            nz ^= nz << 13; nz ^= nz >> 17; nz ^= nz << 5;
            int slot = 0; size_t oldest = 0;
            for (int i = 0; i < kVoices; i++) {
                if (!cv[i].d) { slot = i; break; }
                if (cv[i].pos >= oldest) { oldest = cv[i].pos; slot = i; }
            }
            cv[slot].d = &clips[type][nz % (unsigned)clipCount[type]]; cv[slot].pos = 0;
            return;
        }
        //                          dur    f0     f1    amp
        static const float P[kSfxCount][4] = {
            {0.16f, 700, 3200, 0.95f},   // 0 thwip
            {0.13f, 240, 70, 0.90f},     // 1 thwack
            {0.20f, 130, 45, 0.95f},     // 2 wall thud
            {0.20f, 880, 1320, 0.50f},   // 3 chime
            {0.04f, 1800, 1800, 0.35f},  // 4 tick
            {0.90f, 620, 80, 0.65f},     // 5 splat / womp
            {0.14f, 180, 90, 0.80f},     // 6 land
            {0.16f, 300, 1100, 0.65f},   // 7 hup
            {0.30f, 700, 1900, 0.60f}};  // 8 zip
        int slot = 0; float oldest = -1;
        for (int i = 0; i < kVoices; i++) {
            if (!vox[i].on) { slot = i; break; }
            if (vox[i].t > oldest) { oldest = vox[i].t; slot = i; }
        }
        Voice& v = vox[slot];
        v = Voice();
        v.on = true; v.type = type; v.dur = P[type][0]; v.f0 = P[type][1]; v.f1 = P[type][2]; v.amp = P[type][3];
    }

    // Render n mono samples. mv/sv = music/sfx volume 0..1, wind 0..1, mode 0 off / 1 menu / 2 gameplay, bed 0 drops the wind+rumble bed.
    void render(float* out, int n, float mv, float sv, float wind, int mode, float bed = 1.0f) {
        const float sr = kSampleRate;
        // bar chords (midi) : Am F C G | Am F G E
        static const int chordN[8][3] = {{57, 60, 64}, {53, 57, 60}, {55, 60, 64}, {55, 59, 62}, {57, 60, 64}, {53, 57, 60}, {55, 59, 62}, {56, 59, 64}};
        static const int rootN[8] = {45, 41, 48, 43, 45, 41, 43, 40};
        // original lead line, 8 steps per bar, 0 = rest
        static const int lead[64] = {
            69, 0, 72, 0, 76, 0, 74, 72,   72, 0, 69, 0, 72, 0, 77, 0,
            76, 0, 79, 0, 76, 74, 72, 0,   74, 0, 71, 0, 74, 0, 79, 0,
            69, 0, 72, 0, 76, 0, 81, 0,    79, 0, 77, 0, 76, 0, 72, 0,
            74, 0, 76, 74, 71, 0, 67, 0,   68, 0, 71, 0, 76, 75, 76, 0};
        // title/menu theme lead: bolder, syncopated brass fanfare (original)
        static const int theme[64] = {
            69, 69, 0, 72, 0, 76, 0, 0,    77, 0, 76, 0, 72, 0, 69, 0,
            72, 72, 0, 76, 0, 79, 0, 0,    79, 0, 77, 0, 76, 0, 74, 0,
            69, 69, 0, 72, 0, 76, 0, 81,   81, 0, 79, 0, 77, 0, 76, 0,
            74, 0, 79, 0, 83, 0, 81, 79,   80, 0, 76, 0, 71, 0, 0, 0};
        for (int i = 0; i < n; i++) {
            nz ^= nz << 13; nz ^= nz >> 17; nz ^= nz << 5;
            float noise = ((nz & 0xFFFF) / 32768.0f) - 1.0f;
            float m = 0;
            if (mode > 0 && !hasLoop(mode - 1)) {
                double step = mt / 0.15625;
                long si = (long)step; float sp = (float)(step - si);
                int bs = (int)(si % 64), bar = bs / 8, st = bs % 8;
                // string pad: three detuned saws per chord tone through a one-pole lowpass
                float pd = 0;
                for (int k = 0; k < 3; k++) {
                    float f = mtof(chordN[bar][k]);
                    padA[k] += f / sr; if (padA[k] > 1) padA[k] -= 1;
                    padB[k] += f * 1.006f / sr; if (padB[k] > 1) padB[k] -= 1;
                    pd += (2 * padA[k] - 1) + (2 * padB[k] - 1);
                }
                padLp += (pd - padLp) * 0.045f;
                m += padLp * (mode == 1 ? 0.07f * (0.55f + 0.45f * (st + sp) / 8.0f) : 0.06f);
                // bass: saw + sub, pulsing in gameplay
                int bn = rootN[bar] + (mode == 1 && st == 5 ? 12 : 0);
                bph += mtof(bn) / sr; if (bph > 1) bph -= 1;
                sub += mtof(rootN[bar] - 12) / sr; if (sub > 1) sub -= 1;
                lpb += ((2 * bph - 1) - lpb) * 0.07f;
                float bassEnv = mode == 2 ? (0.55f + 0.45f * expf(-sp * 3.0f)) : 0.7f;
                if (mode == 1) bassEnv = (st == 0 || st == 3 || st == 5 || st == 7) ? 0.3f + 0.9f * expf(-sp * 3.5f) : 0.12f;   // funk pluck
                m += (lpb * 0.20f + sinf(2 * kPi * sub) * 0.14f) * bassEnv;
                // brass lead: two detuned saws, filter opens on each note
                int ln = (mode == 1 ? theme : lead)[bs];
                if (ln) { leadF = mtof(ln); lastNoteT = sp; }
                else lastNoteT += 1.0f / (sr * 0.15625f);
                float held = leadF;
                if (held > 0) {
                    lph += held / sr; if (lph > 1) lph -= 1;
                    lph2 += held * 1.007f / sr; if (lph2 > 1) lph2 -= 1;
                    float env = expf(-lastNoteT * 0.6f);
                    float sw = (2 * lph - 1) + (2 * lph2 - 1);
                    float cut = 0.04f + 0.30f * env;
                    brLp += (sw - brLp) * cut;
                    float vol = mode == 2 ? 0.19f : 0.17f;
                    m += brLp * vol * (0.35f + 0.65f * env);
                }
                if (mode == 2) {
                    // string ostinato: chord-tone arpeggio on 8ths
                    int idx = (int)(si % 4); idx = idx == 3 ? 1 : idx;
                    arp += mtof(chordN[bar][idx] + 12) / sr; if (arp > 1) arp -= 1;
                    m += (2 * fabsf(2 * arp - 1) - 1) * 0.055f * expf(-sp * 3.5f);
                    float tt = sp * 0.15625f;
                    // timpani/kick: steps 0 and 4 (+ pickup on 6 every other bar)
                    if (st == 0 || st == 4 || (st == 6 && (bar & 1))) {
                        kph += (48 + 120 * expf(-tt * 38)) / sr; if (kph > 1) kph -= 1;
                        m += sinf(2 * kPi * kph) * expf(-tt * 12) * 0.50f;
                    }
                    // snare / clap: steps 2 and 6
                    nlp += (noise - nlp) * 0.5f;
                    if (st == 2 || st == 6) m += (noise - nlp * 0.5f) * expf(-sp * 7) * 0.13f;
                    // hats on odd steps
                    if (st & 1) m += (noise - nlp) * expf(-sp * 14) * 0.055f;
                    // cymbal swell into the next bar
                    if (st == 7) m += (noise - nlp) * sp * sp * 0.05f;
                } else {
                    // boom-bap: deep timpani-kick on 1 and the "and" of 2, snare on 2 and 4, swung-feel hats, vinyl crackle
                    float tt = sp * 0.15625f;
                    nlp += (noise - nlp) * 0.5f;
                    if (st == 0 || st == 3 || (st == 5 && (bar & 1))) {
                        kph += (42 + 95 * expf(-tt * 30)) / sr; if (kph > 1) kph -= 1;
                        m += sinf(2 * kPi * kph) * expf(-tt * 9) * 0.55f;
                    }
                    if (st == 2 || st == 6) m += (noise - nlp * 0.4f) * expf(-sp * 6) * 0.15f;
                    if (!(st & 1)) m += (noise - nlp) * expf(-sp * 16) * 0.035f;
                    else m += (noise - nlp) * expf(-sp * 5) * 0.03f * (0.4f + (st == 7 ? 0.6f : 0.0f));
                    if ((nz & 0x3FFF) == 0) m += noise * 0.05f;   // crackle
                    m *= 0.9f;
                }
                mt += 1.0 / sr;
            }
            if (mode > 0 && hasLoop(mode - 1)) { const std::vector<float>& L = loops[mode - 1]; m = L[loopPos[mode - 1]]; if (++loopPos[mode - 1] >= L.size()) loopPos[mode - 1] = 0; }
            m *= mv * 0.8f;
            float s = 0;
            for (int v = 0; v < kVoices; v++) {
                Voice& vo = vox[v];
                if (!vo.on) continue;
                s += voiceSample(vo, noise);
                vo.t += 1.0f / sr;
                if (vo.t >= vo.dur) vo.on = false;
            }
            for (int v = 0; v < kVoices; v++) {   // sampled clips
                ClipVoice& c = cv[v];
                if (!c.d) continue;
                s += (*c.d)[c.pos++] * 0.9f;
                if (c.pos >= c.d->size()) c.d = nullptr;
            }
            rlp += (noise - rlp) * 0.0025f;
            wlp += (noise - wlp) * (0.02f + 0.12f * wind);
            if (hasLoop(2) || hasLoop(3)) {   // sampled ambience replaces the noise bed
                float amb = 0;
                if (hasLoop(2)) { amb += loops[2][loopPos[2]] * (1.0f - 0.6f * wind); if (++loopPos[2] >= loops[2].size()) loopPos[2] = 0; }
                if (hasLoop(3)) { amb += loops[3][loopPos[3]] * (0.15f + 0.85f * wind); if (++loopPos[3] >= loops[3].size()) loopPos[3] = 0; }
                s += bed * amb * 0.5f;
            } else s += bed * (rlp * 0.9f + wlp * (0.03f + 0.45f * wind));
            s *= sv;
            float o = m + s;
            out[i] = o < -1 ? -1 : (o > 1 ? 1 : o);
        }
    }

private:
    struct ClipVoice { const std::vector<float>* d = nullptr; size_t pos = 0; };
    ClipVoice cv[kVoices];
    std::vector<float> loops[4]; size_t loopPos[4] = {0, 0, 0, 0};
    std::vector<float> clips[kSfxCount][kMaxVariants];
    int clipCount[kSfxCount] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    static bool memcmp8(const unsigned char* a, const char* t) { return a[0] == (unsigned char)t[0] && a[1] == (unsigned char)t[1] && a[2] == (unsigned char)t[2] && a[3] == (unsigned char)t[3]; }
    uint32_t nz = 22222;
    double mt = 0;
    float wlp = 0, rlp = 0, bph = 0, sub = 0, kph = 0, nlp = 0, lpb = 0, padLp = 0, arp = 0, brLp = 0;
    float padA[3] = {0, 0, 0}, padB[3] = {0, 0, 0};
    float leadF = 0, lph = 0, lph2 = 0, lastNoteT = 9;

    static float mtof(int midi) { return 440.0f * powf(2.0f, (midi - 69) / 12.0f); }

    // chamberlin state-variable filter, returns the band-pass output
    static float svfBand(Voice& v, float in, float fc, float q) {
        float f = 2.0f * sinf(kPi * fc / kSampleRate);
        v.lo += f * v.bd;
        float hi = in - v.lo - q * v.bd;
        v.bd += f * hi;
        return v.bd;
    }
    static float svfLow(Voice& v, float in, float fc, float q) {
        svfBand(v, in, fc, q);
        return v.lo;
    }

    float voiceSample(Voice& vo, float noise) {
        const float sr = kSampleRate;
        float tt = vo.t / vo.dur;
        float att = vo.t < 0.003f ? vo.t / 0.003f : 1.0f;     // 3 ms click guard
        float env = (1 - tt) * (1 - tt) * att;
        float f = vo.f0 + (vo.f1 - vo.f0) * tt;
        float w = 0;
        switch (vo.type) {
            case 0: {   // thwip: noise through a rising resonant bandpass, plus a short low pop at the start
                float bp = svfBand(vo, noise, f, 0.35f);
                vo.ph += (260 - 160 * tt) / sr; if (vo.ph > 1) vo.ph -= 1;
                float pop = tt < 0.16f ? sinf(2 * kPi * vo.ph) * (1 - tt / 0.16f) * 0.5f : 0.0f;
                w = bp * 0.55f + pop;
                env = powf(1 - tt, 1.4f) * att;
                break; }
            case 1: {   // thwack: low thump + lowpassed noise slap
                vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
                float slap = svfLow(vo, noise, 1400 - 900 * tt, 0.9f);
                w = sinf(2 * kPi * vo.ph) * 0.75f + slap * (tt < 0.5f ? 0.45f : 0.0f);
                break; }
            case 2: {   // wall thud
                vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
                w = sinf(2 * kPi * vo.ph) * 0.85f + svfLow(vo, noise, 500, 0.8f) * (tt < 0.4f ? 0.5f : 0.0f);
                break; }
            case 3: {   // two-tone chime with an octave shimmer
                float ff = tt < 0.4f ? vo.f0 : vo.f1;
                vo.ph += ff / sr; if (vo.ph > 1) vo.ph -= 1;
                vo.ph2 += ff * 2 / sr; if (vo.ph2 > 1) vo.ph2 -= 1;
                w = sinf(2 * kPi * vo.ph) * 0.5f + sinf(2 * kPi * vo.ph2) * 0.18f;
                break; }
            case 4: {   // tick
                vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
                w = vo.ph < 0.5f ? 0.3f : -0.3f;
                break; }
            case 5: {   // splat: noise crunch, then a falling saw "womp" through a closing lowpass
                vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
                float saw = svfLow(vo, 2 * vo.ph - 1, 200 + 1400 * (1 - tt), 0.9f);
                float crunch = tt < 0.10f ? noise * (1 - tt / 0.10f) * 0.7f : 0.0f;
                w = saw * 0.6f + crunch;
                env = (1 - tt) * att;
                break; }
            case 6: {   // soft landing
                vo.ph += f / sr; if (vo.ph > 1) vo.ph -= 1;
                w = sinf(2 * kPi * vo.ph) * 0.6f + svfLow(vo, noise, 700, 0.8f) * 0.35f;
                break; }
            case 7: {   // hup: rising whoosh + short sine lift
                float bp = svfBand(vo, noise, f, 0.6f);
                vo.ph += (240 + 260 * tt) / sr; if (vo.ph > 1) vo.ph -= 1;
                w = bp * 0.45f + sinf(2 * kPi * vo.ph) * 0.35f;
                break; }
            case 8: {   // zip: fast rising noise sweep + ringing fifth
                float bp = svfBand(vo, noise, f, 0.3f);
                vo.ph += 880 / sr; if (vo.ph > 1) vo.ph -= 1;
                vo.ph2 += 1320 / sr; if (vo.ph2 > 1) vo.ph2 -= 1;
                float ring = tt > 0.25f ? (sinf(2 * kPi * vo.ph) + sinf(2 * kPi * vo.ph2)) * 0.22f : 0.0f;
                w = bp * 0.4f + ring;
                env = tt < 0.25f ? att : (1 - (tt - 0.25f) / 0.75f) * (1 - (tt - 0.25f) / 0.75f);
                break; }
            default: w = 0;
        }
        return w * env * vo.amp;
    }
};

}  // namespace audio
