# Sprite sheets

Everything the game draws from fixed pixel art lives on `spritesheet.tga` (32-bit, top-left origin, straight alpha).
`spritesheet.txt` lists one sprite per line:

    name  x  y  w  h  category  pivotX  pivotY

`pivot` is the sprite's anchor inside its rectangle (feet, ground corner, centre ...). `0 0` means top-left.
The game only reads the first five columns, so the extra columns are free to use in your own tools.

`assets/sheets/<category>.tga|txt` hold the same sprites split by category, easier to browse or edit one group at a time.
Regenerate everything with `tools/gen_spritesheet.sh` (no SDL needed).

| category  | sprites | what is in it | pivot |
|-----------|---------|---------------|-------|
| buildings | 62 | `tile_<style>_<variant>` facade tiles (6 styles x 3), `far_<n>` skyline tiles, `prop_obs_*` rooftop obstacles (AC unit, water tower, striped barrier, antenna mast and crane with blink frames, vent, 4 billboards), `prop_crate_0..3` street crates, `prop_roof_*` (AC units, chimney, dish, water tower, antenna with light off/on, 4 neon signs, helipad with lights off/on, shed), `prop_billboard_0..5` rooftop ads, `prop_fire_landing` and `prop_fire_storey_0/1` fire-escape pieces | props: bottom-left corner on the roof / street; `prop_roof_*` and `prop_billboard_*`: left end of the roof line; fire escape: top-left of the landing |
| vehicles  | 72 | `car_<type>_<colour>_<e/w>_<lean>`: taxi, car, bus, truck, motorbike (4 lean frames) | none |
| people    | 56 | `faller_<shirt>_<arms>` falling civilians, `ped_<coat>_<bag>_<step>_<e/w>` pedestrians | feet / ground line |
| sky       | 4  | `heli_<0/1>` rotor frames, `bird_<0/1>` wing frames | reference point |
| player    | 75 | stickman poses: `player_<pose>_<style>_<step>`, `player_swing_<style>_<0..2>` (0 = back, 2 = forward) | feet centre (56, 82) in a 112x112 cell |
| ui        | 46 | `ui_spider_<white/red/dark/ink>_<16/32/54>`, `ui_web_<colour>_<8/14/22>`, `ui_logo_<3/4/6>`, `ui_btn_*` (slant, cta, outline, box, tab, round; normal and hot), `ui_toggle_*`, `ui_slider_knob_*` | emblems and icons: centre |
| font      | 47 | white 5x7 glyphs, `font_<ASCII hex>` (`font_41` = A, `font_2E` = .); advance 6 px at scale 1; tint when drawing | none |

Player poses (`<pose>`): idle(4 phases) run(3 styles x 8 phases) shoot attach jump fall flip backflip flipopen release land hero hit dead cling climb(4) slide walljump twist star dive vault(4 steps) roll.

UI buttons are baked without text; draw labels with the font sprites.

## Where each category comes from
- `buildings`, `vehicles`, `people`, `sky`: the painters in `tools/sprite_art.h` (the game loads these at runtime).
- `player`, `ui`, `font`, `prop_*`: baked from the game's own draw code by `tools/sprite_bake.h`
  (`bakeStickman`, `bakeGlyph`, `drawButton`, `drawSpider`, `drawWebIcon`, `drawObs`, `drawCrate`, `drawRoof*`, `drawBillboardBoard`, `drawFireEscapeLanding/Stairs`), so they always match the code.
  The game now draws these from the sheet (each with a code fallback if the sheet or a sprite is missing):
  - `font_*` glyphs: every `text()` call (tinted with the text colour, scaled by integer factors).
  - `prop_roof_*` chimney, dish, water tower, antenna (light off/on), helipad (lights off/on), shed, and the six `prop_billboard_*` boards; pivot = the roof-line point the draw code uses.
  - `prop_crate_0..3` street crates (a crate whose height is capped lower by the difficulty tier is still drawn from code) and the fixed-size rooftop obstacles `prop_obs_0_0/1`, `prop_obs_1`, `prop_obs_2`, `prop_obs_6`.
  Still drawn from code: the player (poses blend continuously and the whole body rotates, so a fixed set of baked frames would not match), UI buttons/icons (drawn at many sizes and colours), roof AC units and neon signs (variable size / blinking alpha), obstacle types 3, 4 and 5 (variable size / scrolling ad), fire escapes.
  Edit a sprite in a pixel editor and the game shows it; edit the draw function and re-run `tools/gen_spritesheet.sh` to re-bake.

Still drawn live on purpose, because they animate or depend on the time of day: chimney steam, neon night glow, parapet string lights, traffic light and window glow.
