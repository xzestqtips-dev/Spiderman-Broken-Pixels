#!/bin/bash
# Regenerate assets/spritesheet.tga and assets/spritesheet.txt from the painters in tools/sprite_art.h.
cd "$(dirname "$0")/.."
g++ -std=c++17 -O1 -w -Itests/stub_gfx tools/gen_spritesheet.cpp -o /tmp/gen_spritesheet && /tmp/gen_spritesheet assets
