#pragma once
// Bakes the art that the game normally draws from code (font glyphs, stickman poses, UI pieces, street props) into Img sprites,
// so tools/gen_spritesheet.cpp can put them on the sprite sheet. Included after src/main.cpp (needs the software SDL in tests/stub_gfx).
#include <functional>

// ---- capture: run any draw code against a render target and recover straight alpha ---------------------------------
// The draw code is run twice, once over black and once over white; the difference gives the alpha of every pixel.
// `ox, oy` is the point the draw code treats as its origin; after trimming to the visible pixels it is returned as the sprite pivot.
struct Baked { Img img; int px = 0, py = 0; };
static Baked captureDraw(int w, int h, int ox, int oy, const std::function<void()>& draw, bool trim = true) {
    SDL_Texture* t = SDL_CreateTexture(nullptr, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_TARGET, w, h);
    std::vector<uint32_t> over[2];
    for (int pass = 0; pass < 2; pass++) {
        SDL_SetRenderTarget(uvzRenderer, t);
        SDL_RenderSetClipRect(uvzRenderer, nullptr);
        const Uint8 v = pass ? 255 : 0;
        SDL_SetRenderDrawColor(uvzRenderer, v, v, v, 255);
        SDL_RenderClear(uvzRenderer);
        draw();
        over[pass] = t->px;
    }
    SDL_SetRenderTarget(uvzRenderer, nullptr);
    SDL_DestroyTexture(t);
    Img full(w, h);
    int x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
        const uint32_t b = over[0][(size_t)y * w + x], k = over[1][(size_t)y * w + x];
        int d = 0;
        for (int sh = 0; sh <= 16; sh += 8) d += 255 - (int)(((k >> sh) & 255) - ((b >> sh) & 255));   // 255 - (white - black) per channel
        int a = std::min(255, std::max(0, d / 3));
        if (a < 6) continue;                                  // rounding noise from the integer blender
        uint32_t c = 0;
        for (int sh = 0; sh <= 16; sh += 8) c |= (uint32_t)std::min(255, ((int)((b >> sh) & 255) * 255 + a / 2) / a) << sh;
        full.p[(size_t)y * w + x] = ((uint32_t)a << 24) | c;
        x0 = std::min(x0, x); y0 = std::min(y0, y); x1 = std::max(x1, x); y1 = std::max(y1, y);
    }
    if (x1 < 0) return {Img(1, 1), 0, 0};
    if (!trim) { x0 = 0; y0 = 0; x1 = w - 1; y1 = h - 1; }
    Baked out{Img(x1 - x0 + 1, y1 - y0 + 1), ox - x0, oy - y0};
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) out.img.p[(size_t)(y - y0) * out.img.w + (x - x0)] = full.get(x, y);
    return out;
}

// ---- font: the 5x7 bitmap glyphs (white, so the game can tint them) ------------------------------------------------
static Img bakeGlyph(const Glyph& g) {
    Img im(5, 7);
    for (int r = 0; r < 7; r++) for (int b = 0; b < 5; b++) if (g.r[r] & (16 >> b)) im.set(b, r, 0xFFFFFFFFu);
    return im;
}

// ---- player: the stickman, posed exactly the way drawStickman() poses and rasterises it ------------------------------
// Every cell is STK_TEX x STK_TEX with the feet-centre at (STK_TEX / 2, STK_TEX / 2 + STK_FEET_Y).
static Img bakeStickman(const StkPose& pose) {
    gStkMirror = false;
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)(STK_TEX / 2), (float)(STK_TEX / 2 + STK_FEET_Y), 0.0, X, Y);
    memset(gStkBuf, 0, sizeof(gStkBuf));
    static const StkBone farSet[] = { {J_NECK, J_ELB}, {J_ELB, J_HNB}, {J_HIP, J_KNB}, {J_KNB, J_FTB}, {J_HIP, J_NECK} };
    static const StkBone nearLeg[] = { {J_HIP, J_KNF}, {J_KNF, J_FTF} };
    static const StkBone nearArm[] = { {J_NECK, J_ELF}, {J_ELF, J_HNF} };
    stkDrawBones(X, Y, farSet, 5, true, 0, 0);
    stkDrawBones(X, Y, nearLeg, 2, false, 0, 0);
    stkDrawBones(X, Y, nearArm, 2, false, 0, 0);
    Img im(STK_TEX, STK_TEX);
    for (int i = 0; i < STK_TEX * STK_TEX; i++) {
        const float* q = &gStkBuf[i * 4];
        const float a = q[3];
        if (a <= 0.001f) continue;
        const uint32_t r = (uint32_t)clampValue(q[0] / a * 255.0f + 0.5f, 0, 255), g = (uint32_t)clampValue(q[1] / a * 255.0f + 0.5f, 0, 255);
        const uint32_t b = (uint32_t)clampValue(q[2] / a * 255.0f + 0.5f, 0, 255), al = (uint32_t)clampValue(a * 255.0f + 0.5f, 0, 255);
        im.p[i] = (al << 24) | (r << 16) | (g << 8) | b;
    }
    return im;
}
struct PlayerSet { const char* name; int frame, styles, steps; float swing; };   // `steps` samples of the phase (or the vault progress) per style
static const PlayerSet PLAYER_SETS[] = {
    {"idle", F_IDLE, 1, 4, 0},      {"run", F_RUN, 3, 8, 0},        {"shoot", F_SHOOT, 2, 1, 0},    {"attach", F_ATTACH, 1, 1, 0},
    {"jump", F_JUMP, 3, 1, 0},      {"fall", F_FALL, 2, 1, 0},      {"flip", F_FLIP, 1, 1, 0},      {"backflip", F_BACKFLIP, 1, 1, 0},
    {"flipopen", F_FLIPOPEN, 1, 1, 0}, {"release", F_RELEASE, 1, 1, 0}, {"land", F_LAND, 3, 1, 0},  {"hero", F_HERO, 1, 1, 0},
    {"hit", F_HIT, 1, 1, 0},        {"dead", F_DEAD, 1, 1, 0},      {"cling", F_CLING, 1, 1, 0},    {"climb", F_CLIMB, 1, 4, 0},
    {"slide", F_SLIDE, 3, 1, 0},    {"walljump", F_WALLJUMP, 1, 1, 0}, {"twist", F_TWIST, 1, 1, 0}, {"star", F_STAR, 1, 1, 0},
    {"dive", F_DIVE, 1, 1, 0},      {"vault", F_VAULT, 1, 4, 0},    {"roll", F_ROLL, 1, 1, 0},
};
// The swing pose blends between two key poses (0 = back, 1 = forward), four styles.
static const float SWING_STEPS[3] = {0.0f, 0.5f, 1.0f};

// ---- ui: pieces drawn by the menu / HUD code, without any text (labels come from the font sprites) -------------------
static void uiSetup() { uiAge = 5; gTime = 0; ctlTab = 0; }
static Baked bakeButton(int kind, int style, int w, int h, bool hot, bool* flag = nullptr, int id = 0) {
    uiSetup();
    Btn b{id, kind, 6, 6, w, h, "", nullptr, flag, 0, 1, style, 0};
    return captureDraw(w + 12, h + 26, 0, 0, [&] { drawButton(b, 0, hot, false); });
}
