// Renders the game's synthesized audio (src/audio.h) to WAV files.
// Build + run:  g++ -std=c++17 -O2 -Isrc tools/render_audio.cpp -o /tmp/render_audio && /tmp/render_audio assets/audio
#include "audio.h"
#include <cstdio>
#include <string>
#include <vector>

static void writeWav(const std::string& fn, const std::vector<float>& d) {
    FILE* f = fopen(fn.c_str(), "wb");
    if (!f) { perror(fn.c_str()); return; }
    uint32_t n = (uint32_t)d.size() * 2, sr = 44100, br = sr * 2, riff = 36 + n, s16 = 16;
    uint16_t fmt = 1, ch = 1, ba = 2, bits = 16;
    fwrite("RIFF", 1, 4, f); fwrite(&riff, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f); fwrite(&s16, 4, 1, f);
    fwrite(&fmt, 2, 1, f); fwrite(&ch, 2, 1, f); fwrite(&sr, 4, 1, f); fwrite(&br, 4, 1, f); fwrite(&ba, 2, 1, f); fwrite(&bits, 2, 1, f);
    fwrite("data", 1, 4, f); fwrite(&n, 4, 1, f);
    for (float x : d) { int16_t s = (int16_t)((x < -1 ? -1 : x > 1 ? 1 : x) * 32767); fwrite(&s, 2, 1, f); }
    fclose(f);
}
int main(int argc, char** argv) {
    std::string dir = argc > 1 ? argv[1] : ".";
    static const char* names[audio::kSfxCount] = {"web_shoot", "web_attach", "wall_thud", "trick_chime", "tick", "splat", "land_soft", "jump_flip", "combo_zip"};
    for (int t = 0; t < audio::kSfxCount; t++) {
        audio::Synth s; std::vector<float> o(44100 * (t == 5 ? 1 : 1) / (t == 5 ? 1 : 3));
        s.trigger(t); s.render(o.data(), (int)o.size(), 0, 1, 0, 0, 0);
        writeWav(dir + "/sfx_" + std::to_string(t) + "_" + names[t] + ".wav", o);
    }
    for (int mode = 1; mode <= 2; mode++) {   // 4 full passes of the 8-bar loop would be 40 s; one pass = 64 steps * 0.15625 s = 10 s
        audio::Synth s; std::vector<float> o((int)(44100 * 10.0));
        s.render(o.data(), (int)o.size(), 1, 0, 0, mode, 0);
        writeWav(dir + (mode == 1 ? "/music_menu_loop.wav" : "/music_gameplay_loop.wav"), o);
    }
    { audio::Synth s; std::vector<float> o(44100 * 4); s.render(o.data(), (int)o.size(), 0, 1, 1, 0, 1); writeWav(dir + "/ambient_wind_fast.wav", o); }
    { audio::Synth s; std::vector<float> o(44100 * 4); s.render(o.data(), (int)o.size(), 0, 1, 0, 0, 1); writeWav(dir + "/ambient_rumble_idle.wav", o); }
    return 0;
}
