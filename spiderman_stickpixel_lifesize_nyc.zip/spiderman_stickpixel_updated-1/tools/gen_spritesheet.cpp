// Generates the sprite sheets in assets/ from the pixel-art painters (tools/sprite_art.h) and from the game's own draw code (tools/sprite_bake.h).
//   assets/spritesheet.tga + .txt          everything on one sheet, grouped by category (this is what the game loads)
//   assets/sheets/<category>.tga + .txt    one sheet per category: buildings, vehicles, people, sky, player, ui, font
// .txt line:  name x y w h category pivotX pivotY      (pivot = the sprite's anchor point inside its rect; 0 0 = top-left)
// Build and run through tools/gen_spritesheet.sh (compiles against the software SDL in tests/stub_gfx, so no SDL2 install is needed).
#define main game_main
#include "../src/main.cpp"
#undef main
#include "sprite_art.h"
#include "sprite_bake.h"
#include <sys/stat.h>

struct Item { std::string name, cat; Img img; int px = 0, py = 0; };
static std::vector<Item> items;
static void add(const std::string& cat, const std::string& name, Img im, int px = 0, int py = 0) { items.push_back({name, cat, std::move(im), px, py}); }
static void addBaked(const std::string& cat, const std::string& name, Baked b) { add(cat, name, std::move(b.img), b.px, b.py); }
static std::string fmt(const char* f, int a = 0, int b = 0, int c = 0, int d = 0) { char nm[96]; snprintf(nm, sizeof nm, f, a, b, c, d); return nm; }

// Shelf-pack `list` (indices into items) into a sheet of width SW; with `bands` every category starts on a fresh row.
static void writeSheet(const std::string& base, const std::vector<size_t>& list, int SW, bool bands) {
    std::vector<std::string> cats;
    for (size_t i : list) if (std::find(cats.begin(), cats.end(), items[i].cat) == cats.end()) cats.push_back(items[i].cat);
    struct Place { int x = 0, y = 0; };
    std::vector<Place> pos(items.size());
    int x = 0, y = 0, rowH = 0;
    for (const std::string& cat : cats) {
        std::vector<size_t> order;
        for (size_t i : list) if (items[i].cat == cat) order.push_back(i);
        std::stable_sort(order.begin(), order.end(), [&](size_t a, size_t b) { return items[a].img.h > items[b].img.h; });
        if (bands && x > 0) { x = 0; y += rowH + 1; rowH = 0; }
        for (size_t i : order) {
            const Img& im = items[i].img;
            if (x + im.w > SW) { x = 0; y += rowH + 1; rowH = 0; }
            pos[i] = {x, y}; x += im.w + 1; rowH = std::max(rowH, im.h);
        }
    }
    const int SH = y + rowH;
    Img sheet(SW, SH);
    std::string txt;
    for (size_t i : list) {
        const Img& im = items[i].img;
        for (int yy = 0; yy < im.h; yy++) for (int xx = 0; xx < im.w; xx++) {
            const u32 c = im.p[(size_t)yy * im.w + xx];
            sheet.set(pos[i].x + xx, pos[i].y + yy, (c >> 24) ? c : 0);   // fully transparent pixels are stored as 0
        }
        char line[192]; snprintf(line, sizeof line, "%s %d %d %d %d %s %d %d\n", items[i].name.c_str(), pos[i].x, pos[i].y, im.w, im.h, items[i].cat.c_str(), items[i].px, items[i].py);
        txt += line;
    }
    FILE* f = fopen((base + ".tga").c_str(), "wb");
    if (!f) { fprintf(stderr, "cannot write %s.tga\n", base.c_str()); exit(1); }
    unsigned char hd[18] = {0}; hd[2] = 2; hd[12] = SW & 255; hd[13] = SW >> 8; hd[14] = SH & 255; hd[15] = SH >> 8; hd[16] = 32; hd[17] = 0x28;   // top-left origin, 8 alpha bits
    fwrite(hd, 1, 18, f);
    for (u32 c : sheet.p) { unsigned char b[4] = {(unsigned char)c, (unsigned char)(c >> 8), (unsigned char)(c >> 16), (unsigned char)(c >> 24)}; fwrite(b, 1, 4, f); }
    fclose(f);
    f = fopen((base + ".txt").c_str(), "wb"); fwrite(txt.data(), 1, txt.size(), f); fclose(f);
    printf("  %-28s %4zu sprites  %dx%d\n", base.c_str(), list.size(), SW, SH);
}

int main(int argc, char** argv) {
    const std::string dir = argc > 1 ? argv[1] : "assets";
    mkdir(dir.c_str(), 0777); mkdir((dir + "/sheets").c_str(), 0777);
    initFont();

    // ============================ buildings ============================
    for (int st = 0; st < 6; st++) for (int v = 0; v < 3; v++) add("buildings", fmt("tile_%d_%d", st, v), makeTile(st, v));
    for (int v = 0; v < 3; v++) add("buildings", fmt("far_%d", v), makeFar(v));
    {   // rooftop obstacles (drawObs): pivot = bottom-left corner on the roof; blink / animation frames where the prop has them
        struct O { int type; float w, h; int frames; };
        static const O OBS[] = {{0, 28, 20, 2}, {1, 30, 50, 1}, {2, 24, 14, 1}, {3, 0, 80, 2}, {4, 60, 70, 2}, {5, 200, 0, 1}, {6, 0, 0, 1}};
        for (const O& o : OBS) for (int fr = 0; fr < o.frames; fr++) for (int var = 0; var < (o.type == 5 ? 4 : 1); var++) {
            Obs ob{o.type, 0, o.w, o.h, false, var};
            static const char* const ADS[4] = {"NEON NOODLES", "CITY BANK", "SKY TV", "PIZZA 24/7"};   // same texts as drawObs; baked with the ad centred on the board
            const double t = o.type == 0 ? (fr ? 0.1 : 0.0) : o.type == 3 ? (fr ? 1.0 : 0.0) : o.type == 4 ? (fr ? 0.5 : 0.0)
                           : ((o.w - 6) - ((o.w - 6) - measureTextWidth(ADS[var], 2)) / 2.0) / 30.0;
            const std::string nm = o.type == 5 ? fmt("prop_obs_5_%d", var) : o.frames > 1 ? fmt("prop_obs_%d_%d", o.type, fr) : fmt("prop_obs_%d", o.type);
            addBaked("buildings", nm, captureDraw(260, 200, 50, 190, [&] { drawObs(ob, 50, 190, t); }));
        }
    }
    {   // street crates (drawCrate): pivot = bottom-left corner on the street line
        static const float VW[4] = {28, 46, 28, 60}, VH[4] = {22, 24, 36, 24};
        for (int v = 0; v < 4; v++) {
            StreetCrate c{0, VW[v], VH[v], v};
            addBaked("buildings", fmt("prop_crate_%d", v), captureDraw(100, 60, 20, 40, [&] { drawCrate(c, 20, 40); }));
        }
    }

    {   // rooftop details (the drawRoof* functions): pivot = left end of the roof line under the prop
        auto roof = [&](const std::string& nm, int w, int h, int ox, const std::function<void(int, int)>& draw) {   // draw(x, roofY)
            const int ry = h - 4;
            addBaked("buildings", nm, captureDraw(w, h, ox, ry, [&] { draw(ox, ry); }));
        };
        static const int AC_W[3] = {22, 28, 34}, AC_H[3] = {10, 14, 17};
        for (int i = 0; i < 3; i++) roof(fmt("prop_roof_ac_%d", i), 60, 40, 10, [&](int x, int y) { drawRoofAC(x, y, AC_W[i], AC_H[i]); });
        roof("prop_roof_chimney", 40, 50, 10, [&](int x, int y) { drawRoofChimney(x, y); });
        roof("prop_roof_dish", 50, 60, 10, [&](int x, int y) { drawRoofDish(x, y); });
        roof("prop_roof_watertower", 60, 90, 10, [&](int x, int y) { drawRoofWaterTower(x, y); });
        for (int on = 0; on < 2; on++) roof(fmt("prop_roof_antenna_%d", on), 50, 110, 10, [&](int x, int y) { drawRoofAntenna(x, y, on != 0); });
        for (int k = 0; k < 4; k++) roof(fmt("prop_roof_neon_%d", k), 50, 130, 10, [&](int x, int y) { drawRoofNeon(x, y, k, 255); });
        for (int on = 0; on < 2; on++) roof(fmt("prop_roof_helipad_%d", on), 100, 20, 10, [&](int x, int y) { drawRoofHelipad(x, y, on != 0); });
        roof("prop_roof_shed", 70, 50, 10, [&](int x, int y) { drawRoofShed(x, y); });
        for (int k = 0; k < 6; k++) roof(fmt("prop_billboard_%d", k), 100, 80, 16, [&](int x, int y) { drawBillboardBoard(x, y, k); });
        // fire escape: a landing (pivot = its top-left) and a full storey = landing + the flight down to the next one (flight direction alternates)
        const int pw = 60;
        addBaked("buildings", "prop_fire_landing", captureDraw(pw + 20, 60, 10, 30, [&] { drawFireEscapeLanding(10, 30, pw); }));
        for (int left = 0; left < 2; left++) {
            const int xa = left ? 10 + 6 : 10 + pw - 8, xb = left ? 10 + pw - 8 : 10 + 6;
            addBaked("buildings", fmt("prop_fire_storey_%d", left), captureDraw(pw + 20, TILE + 60, 10, 30, [&] {
                drawFireEscapeLanding(10, 30, pw); drawFireEscapeStairs(xa, xb, 30, 30 + TILE); }));
        }
    }

    // ============================ vehicles ============================
    static const u32 PAL[CAR_COLORS] = {0xE8B72D, 0xB7473F, 0x3F92B5, 0x747C86, 0x5D9B69, 0xC66F9A};
    for (int t = 0; t < 5; t++) for (int c = 0; c < CAR_COLORS; c++) {
        if (t == 0 && c != 0) continue;                  // taxis are always yellow
        if (t != 0 && c == 0) continue;                  // everything else uses colours 1..5
        for (int dir = 0; dir < 2; dir++) for (int l = 0; l < (t == 4 ? 4 : 1); l++)
            add("vehicles", fmt("car_%d_%d_%c_%d", t, c, dir ? 'w' : 'e', l), paintCar(t, PAL[c], dir == 0, l));
    }

    // ============================ people ============================
    for (int s = 0; s < 4; s++) for (int f = 0; f < 2; f++) add("people", fmt("faller_%d_%d", s, f), paintFaller(s, f), 6, 10);
    for (int c = 0; c < PED_COATS; c++) for (int b = 0; b < 2; b++) for (int st = 0; st < 2; st++) for (int dir = 0; dir < 2; dir++)
        add("people", fmt("ped_%d_%d_%d_%c", c, b, st, dir ? 'w' : 'e'), paintPed(c, b, st, dir == 0), 4, 12);

    // ============================ sky ============================
    for (int f = 0; f < 2; f++) { add("sky", fmt("heli_%d", f), paintHeli(f), 19, 3); add("sky", fmt("bird_%d", f), paintBird(f), 3, 2); }

    // ============================ player ============================
    // pivot = feet centre = (STK_TEX / 2, STK_TEX / 2 + STK_FEET_Y). The game rotates / mirrors these at draw time.
    {
        const int PX = STK_TEX / 2, PY = STK_TEX / 2 + STK_FEET_Y;
        for (const PlayerSet& s : PLAYER_SETS) for (int st = 0; st < s.styles; st++) for (int k = 0; k < s.steps; k++) {
            const float phase = s.frame == F_VAULT ? (k + 0.5f) / s.steps : (float)k / s.steps;
            add("player", std::string("player_") + s.name + "_" + std::to_string(st) + "_" + std::to_string(k),
                bakeStickman(stkMakePose(s.frame, phase, s.swing, st, 0)), PX, PY);
        }
        for (int st = 0; st < 4; st++) for (int k = 0; k < 3; k++)
            add("player", fmt("player_swing_%d_%d", st, k), bakeStickman(stkMakePose(F_SWING, 0, SWING_STEPS[k], st, 0)), PX, PY);
    }

    // ============================ ui ============================
    {
        struct Col { const char* n; u32 c; };
        static const Col COL[] = {{"white", UI_WHITE}, {"red", UI_RED}, {"dark", UI_RED_D}, {"ink", UI_INK}};
        for (const Col& c : COL) for (int s : {16, 32, 54}) {   // spider emblem, pivot = its centre
            const int W = (int)(2.8f * s) + 8, m = W / 2;
            addBaked("ui", std::string("ui_spider_") + c.n + "_" + std::to_string(s), captureDraw(W, W, m, m, [&] { drawSpider(m, m, (float)s, c.c); }));
        }
        for (const Col& c : COL) for (int r : {8, 14, 22}) {    // web icon, pivot = its centre
            const int W = r * 2 + 6, m = W / 2;
            addBaked("ui", std::string("ui_web_") + c.n + "_" + std::to_string(r), captureDraw(W, W, m, m, [&] { drawWebIcon(m, m, (float)r, c.c); }));
        }
        for (int sc : {3, 4, 6}) {   // wordmark: shadowed STICKMAN, red slant bar, tagline (the spider is its own sprite)
            const int W = std::max(textWSp("STICKMAN", sc, sc), textWSp("NYC STREETS", 2, 8)) + 16, H = 7 * sc + 44;
            addBaked("ui", fmt("ui_logo_%d", sc), captureDraw(W, H, 0, 0, [&] {
                const int cx = W / 2, ty = 6, w2 = textWSp("STICKMAN", sc, sc);
                textSpC("STICKMAN", cx + 2, ty + 2, sc, UI_RED_D, sc);
                textSpC("STICKMAN", cx, ty, sc, UI_WHITE, sc);
                const int y2 = ty + 7 * sc + 10;
                slantBar(cx - w2 / 2, y2, w2, 3, 3, UI_RED, 255);
                textSpC("NYC STREETS", cx, y2 + 10, 2, 0xBFD0FF, 8);
            }));
        }
        addBaked("ui", "ui_slider_knob_red", captureDraw(16, 20, 0, 0, [&] { slantBar(4, 3, 8, 14, 3, UI_RED, 255); }));
        addBaked("ui", "ui_slider_knob_white", captureDraw(16, 20, 0, 0, [&] { slantBar(4, 3, 8, 14, 3, UI_WHITE, 255); }));
        static bool on = true, off = false;
        addBaked("ui", "ui_btn_slant_normal", bakeButton(0, 1, 160, 28, false));
        addBaked("ui", "ui_btn_slant_hot", bakeButton(0, 1, 160, 28, true));
        addBaked("ui", "ui_btn_cta_normal", bakeButton(0, 3, 160, 32, false));
        addBaked("ui", "ui_btn_cta_hot", bakeButton(0, 3, 160, 32, true));
        addBaked("ui", "ui_btn_outline_normal", bakeButton(0, 4, 120, 24, false));
        addBaked("ui", "ui_btn_outline_hot", bakeButton(0, 4, 120, 24, true));
        addBaked("ui", "ui_btn_box_normal", bakeButton(5, 0, 120, 28, false));
        addBaked("ui", "ui_btn_box_hot", bakeButton(5, 0, 120, 28, true));
        addBaked("ui", "ui_btn_tab_off", bakeButton(0, 8, 130, 26, false, nullptr, 0));
        addBaked("ui", "ui_btn_tab_on", bakeButton(0, 8, 130, 26, false, nullptr, B_TAB_KEYS));
        addBaked("ui", "ui_btn_tab_hot", bakeButton(0, 8, 130, 26, true, nullptr, 0));
        addBaked("ui", "ui_btn_round_normal", bakeButton(4, 0, 48, 48, false));
        addBaked("ui", "ui_btn_round_hot", bakeButton(4, 0, 48, 48, true));
        addBaked("ui", "ui_toggle_on", bakeButton(2, 0, 200, 24, false, &on));
        addBaked("ui", "ui_toggle_off", bakeButton(2, 0, 200, 24, false, &off));
        addBaked("ui", "ui_toggle_on_hot", bakeButton(2, 0, 200, 24, true, &on));
        addBaked("ui", "ui_toggle_off_hot", bakeButton(2, 0, 200, 24, true, &off));
    }

    // ============================ font ============================
    // white 5x7 glyphs (tint them when drawing); name = font_<ASCII code in hex>, e.g. font_41 = 'A', font_2E = '.'. Advance = 6 px at scale 1.
    for (const Glyph& g : fontGlyphs) add("font", fmt("font_%02X", (int)(unsigned char)g.c), bakeGlyph(g));

    // ============================ write ============================
    std::vector<std::string> cats;
    for (const Item& it : items) if (std::find(cats.begin(), cats.end(), it.cat) == cats.end()) cats.push_back(it.cat);
    printf("%zu sprites in %zu categories\n", items.size(), cats.size());
    std::vector<size_t> all(items.size());
    for (size_t i = 0; i < all.size(); i++) all[i] = i;
    writeSheet(dir + "/spritesheet", all, 1024, true);
    for (const std::string& cat : cats) {
        std::vector<size_t> l;
        for (size_t i = 0; i < items.size(); i++) if (items[i].cat == cat) l.push_back(i);
        writeSheet(dir + "/sheets/" + cat, l, cat == "player" ? 1024 : 512, false);
    }
    return 0;
}
