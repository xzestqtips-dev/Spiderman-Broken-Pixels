#!/bin/sh
# Makes the Android build draw edge-to-edge, including under the camera notch / punch-hole.
# Without this, Android keeps the notch strip black in landscape (the black bar on the left).
# Usage: tools/android_fullscreen.sh <path to SDL's android-project>
set -e
PROJ="${1:-sdl/android-project}"
JAVA="$(find "$PROJ" -name SDLActivity.java | head -1)"
[ -n "$JAVA" ] || { echo "SDLActivity.java not found under $PROJ" >&2; exit 1; }
if grep -q "uvz-cutout" "$JAVA"; then echo "already patched"; exit 0; fi

# 1 = LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES (Android 9+). Fully-qualified names so no imports are needed.
perl -0pi -e 's/(super\.onCreate\(savedInstanceState\);)/$1\n        \/\/ uvz-cutout: draw under the notch so the game fills the whole screen\n        if (android.os.Build.VERSION.SDK_INT >= 28) {\n            android.view.WindowManager.LayoutParams uvzLp = getWindow().getAttributes();\n            uvzLp.layoutInDisplayCutoutMode = 1;\n            getWindow().setAttributes(uvzLp);\n        }/' "$JAVA"

grep -q "uvz-cutout" "$JAVA" || { echo "patch did not apply to $JAVA" >&2; exit 1; }
echo "patched $JAVA"
