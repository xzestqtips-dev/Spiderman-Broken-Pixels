// Release launch shape (high arc -> ballistic jump, bottom of the arc -> low fast dive), dive-to-swing speed conversion,
// and the buffered / retried web tap.
#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void world() { bld.clear(); Building b; b.x = -3000; b.w = 14000; b.roofY = 2500; b.style = 0; b.seed = 1; bld.push_back(b); }
static void startSwing(float x, float y, float vx, float vy, float ax, float ay) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    P.swinging = true; P.ax = ax; P.ay = ay; P.rope = hypotf(x - ax, y - ay); P.ropeEff = P.rope;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true; swingWas = true; gFlow = 0; badClear();
}
static float deg(float vx, float vy) { return atan2f(-vy, vx) * 180.0f / pi; }
// apex height (smaller y = higher) and horizontal travel over `steps` physics steps of free flight
static void fly(Player s, int steps, float& apexY, float& x1) {
    P = s; P.launchT = 0; apexY = P.y;
    for (int i = 0; i < steps; i++) { stepPhysics(1.0f / 120.0f); apexY = std::min(apexY, P.y); }
    x1 = P.x;
}
int main() {
    if (system("rm -rf /tmp/pcity_ld && mkdir -p /tmp/pcity_ld") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_ld/", 1);
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gProg = prog::Data(); cfg.reduced = false;

    // ---- 4. release launch shape ------------------------------------------------------------------------------------------------
    {
        const float sp = 1000.0f;
        auto sh = [&](float a) { return releaseShape(sp * cosf(a * pi / 180), -sp * sinf(a * pi / 180)); };
        const ReleaseShape mid = sh(24.0f), hi = sh(55.0f), lo = sh(2.0f);
        printf("shape @24 deg: rot %.1f hang x%.2f | @55 deg: rot %.1f hang x%.2f speed +%.1f%% | @2 deg: rot %.1f hang x%.2f speed +%.1f%%\n",
               mid.rot * 180 / pi, mid.hangK, hi.rot * 180 / pi, hi.hangK, hi.speedK * 100, lo.rot * 180 / pi, lo.hangK, lo.speedK * 100);
        CHECK(mid.rot == 0 && mid.speedK == 0 && mid.hangK == 1.0f);                       // neutral zone: the old release
        CHECK(hi.hi > 0.8f && hi.lo == 0 && hi.rot > 8.0f * pi / 180 && hi.hangK > 1.6f);   // high on the arc: steered up, floats longer
        CHECK(lo.lo > 0.85f && lo.hi == 0 && lo.speedK > 0.055f && lo.hangK < 0.5f);        // flat at the bottom: faster, almost no hang
        CHECK(lo.rot < 0 && fabsf(lo.rot) < 12.0f * pi / 180);                              // flattened toward the horizontal, never a plunge
        CHECK(releaseShape(-500, -300).rot == 0 && releaseShape(200, -100).hangK == 1.0f);  // backwards or slow: unshaped
        CHECK(releaseShape(500, 900).lo == 0 && releaseShape(800, 600).lo < 0.5f);          // a steep plunge is not a "low dive" release
        float prev = -1;                                                                     // the effect grows smoothly with the angle
        for (float a = 28; a <= 60; a += 2) { const float h = sh(a).hi; CHECK(h >= prev - 1e-6f); prev = h; }
        for (float a = 40; a <= 62; a += 2) CHECK(sh(a).hangK > 1.0f);
        for (float a = -36; a <= 18; a += 2) CHECK(sh(a).hangK < 1.0f);
        // in the game: a high release flies higher than the same release without the shaping
        world(); gFlow = 0;
        const float a = 56.0f, v = 1000.0f;
        startSwing(0, 0, v * cosf(a * pi / 180), -v * sinf(a * pi / 180), 0, -300); P.swingT = 1.0f;
        const float vx0 = P.vx, vy0 = P.vy;
        releaseWeb(true);
        Player shaped = P;
        const float k = 1.0f + POP_NOW * shaped.launchK;
        Player plain = shaped; plain.vx = vx0 * k; plain.vy = vy0 * k; plain.hangT = HANG_TIME;   // the unshaped release: pop along the velocity, normal hang
        float apS, xS, apP, xP; fly(shaped, 140, apS, xS); fly(plain, 140, apP, xP);
        printf("high release: angle %.1f -> %.1f deg, hang %.2f s, apex %.0f vs %.0f px (higher by %.0f)\n", deg(vx0, vy0), deg(shaped.vx, shaped.vy), shaped.hangT, apS, apP, apP - apS);
        CHECK(deg(shaped.vx, shaped.vy) > deg(plain.vx, plain.vy) + 6.0f);
        CHECK(shaped.hangT > HANG_TIME * 1.5f);
        CHECK(apS < apP - 25.0f);
        // a low release is faster and travels further in the same time
        const float a2 = 3.0f; const float v2 = 1000.0f;
        startSwing(0, 0, v2 * cosf(a2 * pi / 180), -v2 * sinf(a2 * pi / 180), 0, -300); P.swingT = 1.0f;
        const float lx0 = P.vx, ly0 = P.vy;
        releaseWeb(true);
        shaped = P; const float k2 = 1.0f + POP_NOW * shaped.launchK;
        plain = shaped; plain.vx = lx0 * k2; plain.vy = ly0 * k2; plain.hangT = HANG_TIME;
        fly(shaped, 60, apS, xS); fly(plain, 60, apP, xP);
        printf("low release: speed %.0f vs %.0f px/s, hang %.2f s, 0.5 s travel %.0f vs %.0f px\n", hypotf(shaped.vx, shaped.vy), hypotf(plain.vx, plain.vy), shaped.hangT, xS, xP);
        CHECK(hypotf(shaped.vx, shaped.vy) > hypotf(plain.vx, plain.vy) * 1.04f);
        CHECK(shaped.hangT < HANG_TIME * 0.5f);
        CHECK(xS > xP + 15.0f);
        // the speed cap still holds
        const float cap = swingSpeedCap(swingMult());
        startSwing(0, 0, cap * 0.99f, -10, 0, -300); P.swingT = 1.0f; releaseWeb(true);
        CHECK(hypotf(P.vx, P.vy) <= cap + 1.0f);
        // a failed release and the wall vault are not shaped (they were not before)
        startSwing(0, 0, 800, 0, 0, -300); P.swingT = 1.0f; const float fv = hypotf(P.vx, P.vy); releaseWeb(false, true);
        CHECK(fabsf(hypotf(P.vx, P.vy) - fv) < 1.0f);
    }

    // ---- 5. dive to swing ---------------------------------------------------------------------------------------------------------
    {
        const float cap = swingSpeedCap(swingMult());
        CHECK(diveConvertBonus(500, 300, -100, 300) == 0.0f);                     // slow fall: nothing to convert
        CHECK(diveConvertBonus(500, 1000, -150, -350) == 0.0f);                   // anchor below the player: no swing arc to feed
        CHECK(diveConvertBonus(500, 1000, -150, 350) > 200.0f);
        auto attach = [&](bool diving, float mem, float vx, float vy) {
            world(); P = Player(); P.alive = true; P.onGround = false; P.x = 0; P.y = 0; P.px = 0; P.py = 0; P.vx = vx; P.vy = vy;
            P.diving = diving; P.diveMemT = mem; gFlow = 0; P.chain = 0; badClear();
            attachWeb(150, -350);
            swingHeld = true; swingWas = true;
            for (int i = 0; i < 12; i++) stepPhysics(1.0f / 120.0f);   // 0.1 s: the rope has taken the part of the fall it cancels
            return hypotf(P.vx, P.vy);
        };
        const float plain = attach(false, 0, 500, 1000), dive = attach(true, 0, 500, 1000);
        const bool did = gDiveSwing; const float gain = gDiveSwingGain;   // read right after the dive attach (the later attaches reset them)
        const float justEnded = attach(false, 0.2f, 500, 1000), late = attach(false, 0, 500, 1000);
        printf("speed 0.1 s after attaching at 1000 px/s fall: plain %.0f, in a dive %.0f (gain %.0f), dive ended 0.2 s ago %.0f\n", plain, dive, gain, justEnded);
        CHECK(did && gain > 200.0f);
        CHECK(dive > plain + 100.0f && justEnded > plain + 100.0f && late == plain);   // a dive that ended a moment ago still counts; a late one does not
        CHECK(dive <= cap + 1.0f);
        // the extra goes forward along the swing, and the rope can still hold the player (no stretch)
        attach(true, 0, 500, 1000); CHECK(P.vx > 0 && P.swinging && !P.diving);
        // over the whole swing it is faster and the rope never stretches
        auto swingPeak = [&](bool diving) {
            attach(diving, 0, 500, 1000); swingHeld = true; swingWas = true;
            float peak = 0, stretch = 0;
            for (int i = 0; i < 360 && P.swinging; i++) { stepPhysics(1.0f / 120.0f); peak = std::max(peak, hypotf(P.vx, P.vy)); stretch = std::max(stretch, hypotf(P.x - P.ax, P.y - P.ay) - P.ropeEff); }
            CHECK(stretch < 0.5f);
            return peak;
        };
        const float pk0 = swingPeak(false), pk1 = swingPeak(true);
        printf("peak swing speed: plain %.0f, dive-to-swing %.0f (+%.0f%%)\n", pk0, pk1, (pk1 / pk0 - 1) * 100);
        CHECK(pk1 > pk0 * 1.08f && pk1 <= cap * 1.02f);
        // extreme fall speed is capped
        { const float ex = attach(true, 0, 800, 3000); const float capNow = swingSpeedCap(swingMult()); printf("extreme fall: %.0f (cap %.0f; it already counts the chain and the Flow bump from this attach)\n", ex, capNow); CHECK(ex <= capNow + 1.0f); }
    }

    // ---- 1. buffered / retried web tap -------------------------------------------------------------------------------------------
    {
        gState = PLAYING; trans = -1;
        const int K = ctl.key[A_SWING];
        auto airborne = [&](float x, float y, float vx, float vy) {
            P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.onGround = false; P.alive = true;
            badClear(); gLastPickX = gLastPickY = 1e9f; gAirT = 1; swingWas = false; swingHeld = false; gWebBufT = 0; gWebRetryT = 0; hintT = 0; hintFound = false;
            g_keys[K] = 0;
        };
        auto roof = [&](float x, float w) { Building r; r.x = x; r.w = w; r.roofY = 0; r.style = 0; r.seed = 2; r.obs.push_back({3, x + 600, 3, 400, false, 0}); bld.push_back(r); };
        auto street = [&]() { bld.clear(); Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); };
        const float dt = 1.0f / 60.0f;
        // 1a. tap with nothing in reach, anchor comes into range 0.07 s later: the tap is retried and fires
        street(); airborne(0, 100, 300, 0);
        g_keys[K] = 1; updateGame(dt);
        CHECK(!P.webFlying && !P.swinging && gWebBufT > 0.0f);
        roof(500, 1200);
        bool fired = false; int frames = 0;
        for (int i = 0; i < 6 && !fired; i++) { updateGame(dt); frames++; fired = P.webFlying || P.swinging; }
        printf("buffered tap: anchor appeared, web fired after %d more frames (%.3f s)\n", frames, frames * dt);
        CHECK(fired && frames * dt <= WEB_BUF + 0.001f);
        // 1b. the same, but the anchor only appears after the buffer has run out: no web
        street(); airborne(0, 100, 300, 0);
        g_keys[K] = 1; updateGame(dt);
        for (int i = 0; i < 14; i++) updateGame(dt);      // 0.23 s: past WEB_BUF
        CHECK(gWebBufT == 0.0f && !P.webFlying);
        roof(500, 1200);
        for (int i = 0; i < 10; i++) updateGame(dt);
        CHECK(!P.webFlying && !P.swinging);
        // 1c. released before the anchor appears: the buffer is dropped
        street(); airborne(0, 100, 300, 0);
        g_keys[K] = 1; updateGame(dt); g_keys[K] = 0; updateGame(dt);
        CHECK(gWebBufT == 0.0f);
        roof(500, 1200);
        for (int i = 0; i < 8; i++) updateGame(dt);
        CHECK(!P.webFlying && !P.swinging);
        // 1d. tapped just before leaving the ground (still "on the ground" this frame): fires as soon as the player is airborne
        bld.clear(); { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); } roof(500, 1200);
        airborne(0, 100, 300, 0); P.onGround = true;
        g_keys[K] = 1; updateGame(dt);
        fired = P.webFlying || P.swinging; frames = 0;
        for (int i = 0; i < 6 && !fired; i++) { updateGame(dt); frames++; fired = P.webFlying || P.swinging; }
        CHECK(fired && frames <= 3);
        // 1e. a normal tap with an anchor in reach still fires on the same frame (unchanged), and holding does not re-fire
        bld.clear(); { Building s; s.x = -3000; s.w = 12000; s.roofY = 900; s.style = 0; s.seed = 1; bld.push_back(s); } roof(500, 1200);
        airborne(0, 100, 300, 0);
        g_keys[K] = 1; updateGame(dt);
        CHECK(P.webFlying || P.swinging);
        g_keys[K] = 0;
    }
    printf("[launch_dive] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
