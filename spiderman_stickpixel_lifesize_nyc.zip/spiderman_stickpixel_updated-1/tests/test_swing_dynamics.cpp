#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static float bend(const StkPose& p) { return fabsf(p.shF - p.thF) + fabsf(p.shB - p.thB); }
int main() {
    const float dt = 1.0f / 60;
    StkPose base = stkMakePose(F_SWING, 0, 0.5f, 0, 0);
    // fast swing: legs straighten and trail, lean grows, ramps in smoothly
    SwingDyn d; StkPose p; float prevLean = base.lean, maxStep = 0;
    for (int i = 0; i < 120; i++) { p = base; applySwingDynamics(p, d, true, 900, 100, dt); maxStep = std::max(maxStep, fabsf(p.lean - prevLean)); prevLean = p.lean; }
    CHECK(d.stretch > 0.95f && d.tuck < 0.05f);
    CHECK(bend(p) < bend(base) * 0.5f);
    CHECK(p.thF < base.thF && p.thB < base.thB && p.lean > base.lean);
    CHECK(maxStep < 1.5f);                                            // no snapping between frames
    // slow rising swing: knees tuck
    SwingDyn t; for (int i = 0; i < 120; i++) { p = base; applySwingDynamics(p, t, true, 150, -200, dt); }
    CHECK(t.tuck > 0.9f && t.stretch < 0.01f && bend(p) > bend(base));
    // let go of the web: both ease back to the plain pose
    for (int i = 0; i < 180; i++) { p = base; applySwingDynamics(p, d, false, 900, 100, dt); }
    CHECK(d.stretch < 0.001f && fabsf(p.thF - base.thF) < 0.01f && fabsf(p.lean - base.lean) < 0.01f);
    // targets are monotonic and bounded; every joint stays finite across speeds
    float last = -1; bool mono = true;
    for (int sp = 0; sp <= 1500; sp += 25) { const float v = swingStretchTarget((float)sp); if (v < last - 1e-6f || v < 0 || v > 1) mono = false; last = v; }
    CHECK(mono);
    for (int sp = 0; sp <= 1500; sp += 100) for (int sw = 0; sw <= 4; sw++) {
        StkPose q = stkMakePose(F_SWING, 0, sw / 4.0f, sw % 4, 0); SwingDyn e; e.stretch = swingStretchTarget((float)sp); e.tuck = swingTuckTarget((float)sp, -50);
        applySwingDynamics(q, e, true, (float)sp, -50, dt);
        float jx[J_N], jy[J_N]; stkSolve(q, jx, jy);
        for (int i = 0; i < J_N; i++) CHECK(std::isfinite(jx[i]) && std::isfinite(jy[i]) && fabsf(jx[i]) < 60 && fabsf(jy[i]) < 70);
    }
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
