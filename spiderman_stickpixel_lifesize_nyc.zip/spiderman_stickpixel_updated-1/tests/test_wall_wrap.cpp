#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void world() {
    bld.clear();
    Building a; a.x = -3000; a.w = 3000; a.roofY = 2500; a.seed = 1; a.style = 0;
    Building b; b.x = 500; b.w = 3000; b.roofY = 0; b.seed = 2; b.style = 1;
    bld.push_back(a); bld.push_back(b);
}
static void swingAt(float x, float y, float vx, float vy, float ax, float ay) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    P.swinging = true; P.ax = ax; P.ay = ay; P.rope = hypotf(x - ax, y - ay); P.swingT = 1.0f;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true; swingWas = true; badClear(); gFlow = 0;
}

int main() {
    if (system("rm -rf /tmp/pcity_ww && mkdir -p /tmp/pcity_ww") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_ww/", 1);
    loadCfg(); loadControls();
    uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gWallsSolid = true; /* these tests cover the legacy solid-wall behavior */ gState = PLAYING;
    gProg = prog::Data();
    const float dt = 1.0f / 120.0f;

    {
        world(); swingAt(470, 90, 520, -420, 200, -300);
        bool vaulted = false;
        for (int i = 0; i < 20 && !vaulted; i++) { stepPhysics(dt); if (!P.swinging) vaulted = true; }
        CHECK(vaulted && !P.wallCling && P.alive && P.vy < -400);
        // roofs are scenery (not platforms): the pop must carry the player over the roof edge before he drops below the roofline
        float apex = P.y;
        for (int i = 0; i < 600 && P.alive && !(P.vy > 0 && P.y > 0); i++) { stepPhysics(dt); apex = std::min(apex, P.y); }
        printf("mantle: apex y=%.0f, crossed the roofline at x=%.0f alive=%d\n", apex, P.x, (int)P.alive);
        CHECK(P.alive && P.x > 500 && apex < -20);
    }

    {
        world(); swingAt(420, 500, 450, -100, 200, 100);
        int guard = 0; while (P.swinging && P.wrapN == 0 && guard++ < 400) stepPhysics(dt);
        printf("wrap: wraps %d, anchor (%.0f, %.0f), swinging %d, cling %d\n", P.wrapN, P.ax, P.ay, (int)P.swinging, (int)P.wallCling);
        CHECK(P.wrapN == 1 && P.swinging && !P.wallCling && P.alive);
        CHECK(fabsf(P.ax - 496) < 1 && fabsf(P.ay + 2) < 1);
        const float rope = P.rope; float worst = 0;
        for (int i = 0; i < 360 && P.alive; i++) {
            stepPhysics(dt);
            if (P.swinging) worst = std::max(worst, hypotf(P.x - P.ax, P.y - P.ay) - rope);
            if (!P.swinging || P.wallCling) break;
        }
        CHECK(worst < 0.5f);
        CHECK(P.alive && std::isfinite(P.x) && std::isfinite(P.y));
    }

    {
        world(); swingAt(420, 500, 450, -100, 200, 100); P.wrapN = 2;
        int guard = 0; while (P.swinging && guard++ < 400) stepPhysics(dt);
        CHECK(P.wallCling && P.wrapN == 2);
    }

    {
        world(); bld[1].roofY = 900;
        swingAt(420, 500, 450, -100, 200, 100);
        int guard = 0; while (P.swinging && P.y < 880 && guard++ < 600) stepPhysics(dt);
        CHECK(P.wrapN == 0);
    }

    {
        world();
        const float pen = simSwing(300, 400, 500, -100, 200, 0, 1.0f);
        printf("look-ahead penalty for a swing into the face: %.0f\n", pen);
        CHECK(pen <= 120.0f);
    }

    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL WALL WRAP TESTS PASSED\n");
    return fails ? 1 : 0;
}
