#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void world() { bld.clear(); Building b; b.x = -3000; b.w = 14000; b.roofY = 2500; b.style = 0; b.seed = 1; bld.push_back(b); }
static void startSwing(float x, float y, float vx, float vy, float ax, float ay) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    P.swinging = true; P.ax = ax; P.ay = ay; P.rope = hypotf(x - ax, y - ay);
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true; swingWas = true; gFlow = 0; badClear();
}
int main() {
    if (system("rm -rf /tmp/pcity_sm && mkdir -p /tmp/pcity_sm") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_sm/", 1);
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gProg = prog::Data();
    const float dt = 1.0f / 120.0f;

    world(); startSwing(-100, 0, 600, 300, 0, -250);
    for (int i = 0; i < 30; i++) stepPhysics(dt);
    const float vx0 = P.vx, vy0 = P.vy, sp0 = hypotf(vx0, vy0);
    releaseWeb(true);
    // the release now pops along the velocity: same direction, a clear kick, never a slowdown
    CHECK(hypotf(P.vx, P.vy) >= sp0 && fabsf(P.vx * vy0 - P.vy * vx0) < 1e-2f * sp0 * hypotf(P.vx, P.vy));
    for (int i = 0; i < 6; i++) stepPhysics(dt);
    CHECK(hypotf(P.vx, P.vy) < sp0 * 1.3f + 50 && hypotf(P.vx, P.vy) > sp0 * 0.9f - 50);

    world(); startSwing(100, 80, 500, -400, 0, -250);
    stepPhysics(dt); releaseWeb(false);
    CHECK(P.vy < 0);
    for (int i = 0; i < 12; i++) stepPhysics(dt);
    CHECK(P.vy < 0 || P.vy < 100);

    float vyA = P.vy; for (int i = 0; i < 60; i++) stepPhysics(dt);
    CHECK(P.vy > vyA + 400 && !P.swinging && P.vx > 350);

    world(); startSwing(-200, -90, 0, 0, 0, -250);
    float vBot = 0, vEnd = 1e9f; bool ok = true;
    for (int i = 0; i < 360 && P.swinging; i++) {
        stepPhysics(dt);
        const float d = hypotf(P.x - P.ax, P.y - P.ay);
        if (fabsf(d - P.ropeEff) > 0.05f || P.ropeEff > P.rope + 0.01f || P.ropeEff < 0.86f * P.rope) ok = false;   // the rope may be reeled in by up to ~13 %
        if (fabsf(P.x - P.ax) < 25) vBot = std::max(vBot, hypotf(P.vx, P.vy));
        if (P.x - P.ax > 150) vEnd = std::min(vEnd, hypotf(P.vx, P.vy));
    }
    CHECK(ok && vBot > vEnd + 100);

    world(); startSwing(0, 0, 300, 0, 0, -200);
    P.vx = NAN; stepPhysics(dt);
    CHECK(std::isfinite(P.x) && std::isfinite(P.y) && std::isfinite(P.vx) && std::isfinite(P.vy));
    P.vx = 1e9f; P.vy = -1e9f; stepPhysics(dt);
    CHECK(fabsf(P.vx) <= 4000.0f + 1 && fabsf(P.vy) <= 4000.0f + 1);

    printf("[swing_momentum] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
