// The on-screen text is drawn from the sprite sheet's font_<hex> glyphs. Checks that every game glyph is on the sheet,
// matches the built-in bitmap pixel for pixel, and that text() really takes the sheet path (and falls back without it).
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    initFont();
    CHECK(loadSpriteSheet());
    bindSprites();
    int glyphs = 0;
    for (const Glyph& g : fontGlyphs) {
        const SprRect& s = gFontSpr[(int)g.c];
        CHECK(s.ok && s.w == 5 && s.h == 7);
        if (!s.ok) continue;
        glyphs++;
        bool same = true;
        for (int r = 0; r < 7; r++) for (int b = 0; b < 5; b++) {
            const u32 px = gSheetImg.get(s.x + b, s.y + r);
            const bool on = (g.r[r] & (16 >> b)) != 0;
            if (on ? px != 0xFFFFFFFFu : (px >> 24) != 0) same = false;
        }
        CHECK(same);
    }
    CHECK(glyphs == (int)(sizeof(fontGlyphs) / sizeof(fontGlyphs[0])));
    CHECK(!gFontSpr[' '].ok && !gFontSpr['a'].ok);          // space and unmapped codes are not on the sheet: blank, drawn from code
    // text() goes through the sheet when it is loaded ...
    CHECK(sprDrawGlyph('A', 0, 0, 2, 0xFFFFFF, 255));
    CHECK(!sprDrawGlyph(' ', 0, 0, 2, 0xFFFFFF, 255));
    CHECK(!sprDrawGlyph(200, 0, 0, 2, 0xFFFFFF, 255));
    // ... and still works (from the bitmap) when the sheet is gone
    SDL_Texture* keep = gSheet; gSheet = nullptr;
    CHECK(!sprDrawGlyph('A', 0, 0, 2, 0xFFFFFF, 255));
    text("SCORE 123", 4, 4, 2, 0xFFFFFF);
    gSheet = keep;
    printf("[font_sheet] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
