// Preview renders of the polish pass: g++ -std=c++17 -O1 -Itests/stub_gfx tests/shot_polish.cpp -o /tmp/shotp && /tmp/shotp
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static void present() {
    SDL_SetRenderTarget(uvzRenderer, nullptr); SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255); SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight}; SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
}
static void dump(const char* name) {
    char p[160]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); fprintf(f, "P6\n%d %d\n255\n", g_outW, g_outH);
    for (uint32_t c : g_screen) { unsigned char b[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c}; fwrite(b, 1, 3, f); }
    fclose(f);
}
int main() {
    mkdir("/tmp/shots", 0777); setenv("PCITY_PREF", "/tmp/pcity_t/", 1); if (system("mkdir -p /tmp/pcity_t")) {}
    g_outW = 960; g_outH = 540; g_screen.assign((size_t)g_outW * g_outH, 0xFF00FF00u);
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt(); startRun();
    gState = PLAYING; gTime = 10; gSkyTime = 20;
    for (int i = 0; i < 20; i++) { gTime += 0.016; updateGame(0.016); }
    SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
    // A: street, a walker startled mid-hop and one looking up, car with the suspension pressed, player on its roof
    trafficCars.clear(); trafficSignals.clear(); nextTrafficSpawnX = 1e9f;
    TrafficCar c; c.x = 520; c.speed = 0; c.maxSpeed = 0; c.type = 1; c.width = trafficWidth(1); c.height = trafficHeight(1); c.dir = 1; c.lane = 0; c.color = 0xB7473F; c.id = 5; c.dip = 4.5f;
    trafficCars.push_back(c);
    P.x = 520; P.y = carTopY(trafficCars[0]) - 26; P.px = P.x; P.py = P.y; P.vx = 0; P.vy = 0; P.onGround = true; P.swinging = false;
    camX = P.x - 300; camY = -120; ensureWorld();
    const int S = 300;
    for (int cc = (int)floorf(camX / S) - 1; cc <= (int)floorf((camX + uvzWorldWidth) / S) + 1; cc++) for (int k = 0; k < 3; k++) {
        npc::State& st = gWalkerState[walkerKey(cc, k)];
        if (k == 0) { st.startle = 0.4f; st.react = 1.0f; st.hop = -9.0f; st.off = -14.0f; }
        if (k == 1) { st.look = 1.0f; }
    }
    for (int i = 0; i < 90; i++) { P.x = 520; P.vx = 0; render(0.016); } printf("A: P.y=%.1f feet=%.1f carTop=%.1f onGround=%d ride=%d state=%d\n", P.y, P.y+26, carTopY(trafficCars[0]), P.onGround, P.rideId, (int)gState); present(); dump("A_street");
    // B: fast swing (stretched) and slow rising swing (tucked)
    for (int pass = 0; pass < 2; pass++) {
        P = Player(); P.alive = true; P.swinging = true; P.onGround = false; P.rope = 260; P.ropeEff = 260;
        P.x = 800 + pass * 3000; P.ax = P.x + 40; P.ay = -420; P.y = P.ay + 250;
        P.vx = pass ? 90 : 780; P.vy = pass ? -120 : 220; P.px = P.x; P.py = P.y;
        gSwingDyn = SwingDyn(); gPlayerAnim = StkAnim();
        camX = P.x - uvzWorldWidth * 0.45f; camY = P.y - uvzWorldHeight * 0.55f; ensureWorld();
        for (int i = 0; i < 40; i++) { P.vx = pass ? 90 : 780; P.vy = pass ? -120 : 220; render(0.016); }
        printf("world %dx%d player at %.0f,%.0f\n", uvzWorldWidth, uvzWorldHeight, (P.x - camX), (P.y - camY));
        present(); dump(pass ? "C_swing_tuck" : "B_swing_stretch");
    }
    return 0;
}
