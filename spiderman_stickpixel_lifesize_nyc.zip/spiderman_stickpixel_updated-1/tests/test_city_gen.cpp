#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    wrng = Rng(123); distM = 0;
    bld.clear(); addBuilding(true);
    for (int i = 0; i < 300; i++) { distM = (float)(i * 10); addBuilding(false); }
    int noAnchors = 0, narrow = 0, tooWide = 0, smallGap = 0; float sumW = 0, sumGap = 0;
    for (size_t i = 1; i < bld.size(); i++) {
        const Building& b = bld[i], &p = bld[i - 1];
        int poles = 0; for (auto& o : b.obs) if (o.type == 3) poles++;
        if (poles > 0) noAnchors++;   // counts buildings that still carry a dedicated anchor pole: there must be none
        const float gap = b.x - (p.x + p.w);
        if (gap > 1 && gap < CITY_GAP_MIN - 1) smallGap++;   // NYC: flush party walls (gap 0) or a full avenue
        if (b.w < 200) narrow++; if (b.w > CITY_W_MAX + 1) tooWide++;
        sumW += b.w; sumGap += gap;
    }
    const float n = (float)(bld.size() - 1);
    printf("buildings %zu: avg roof %.0f px, avg gap %.0f px, leftover anchor poles %d\n", bld.size(), sumW / n, sumGap / n, noAnchors);
    CHECK(noAnchors == 0 && smallGap == 0 && narrow == 0 && tooWide == 0);
    CHECK(sumGap / n > 40.0f);   // avenues still open between blocks
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
