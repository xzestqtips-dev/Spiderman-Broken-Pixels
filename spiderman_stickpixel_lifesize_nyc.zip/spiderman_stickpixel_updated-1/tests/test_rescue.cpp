// Web Catch: falling civilians are rescued by touching them in the air (rescueTick() in src/main.cpp).
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

int main() {
    if (system("rm -rf /tmp/pcity_rs && mkdir -p /tmp/pcity_rs") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_rs/", 1);
    loadCfg(); loadControls();
    uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gState = PLAYING;
    gProg = prog::Data();

    {   // civilians spawn ahead as the player travels
        startRun(); P.alive = true; P.onGround = false; P.x = 0; P.y = -600;
        for (int i = 0; i < 400; i++) { P.x += 20; rescueTick(1.0f / 60.0f); }
        CHECK(gRescues + (int)gFallers.size() >= 1 || gRescueStreak == 0);
        CHECK(!gFallers.empty() || gNextFallerX > 2000.0f);
    }
    {   // catching one pays, feeds the combo and Flow
        startRun(); P = Player(); P.alive = true; P.onGround = false; P.x = 1000; P.y = -500;
        Faller f; f.x = 1010; f.y = -500; f.vx = f.vy = 0; f.t = 0; f.alive = true; f.shirt = 0;
        gFallers.push_back(f); gNextFallerX = 1e9f; gFlow = 0; const float b0 = bonus;
        rescueTick(1.0f / 120.0f);
        CHECK(gRescues == 1 && gRescueStreak == 1);
        CHECK(bonus > b0 && gCombo.count == 1 && gCombo.lastKindShown == combo::RESCUE && gFlow > 0);
        CHECK(!gFallers[0].alive);
    }
    {   // a miss at street level removes it with no reward and resets the streak
        startRun(); P = Player(); P.alive = true; P.onGround = false; P.x = 0; P.y = -900; gNextFallerX = 1e9f;
        gRescueStreak = 3;
        Faller f; f.x = 600; f.y = -300; f.vx = f.vy = 0; f.t = 0; f.alive = true; f.shirt = 1;
        gFallers.push_back(f); const float b0 = bonus;
        for (int i = 0; i < 400; i++) rescueTick(1.0f / 60.0f);
        CHECK(gRescues == 0 && gRescueStreak == 0 && bonus == b0 && gCombo.count == 0);
    }
    {   // no catching while standing on the ground, none after death, none behind the menu
        startRun(); P = Player(); P.alive = true; P.onGround = true; P.x = 1000; P.y = -500; gNextFallerX = 1e9f;
        Faller f; f.x = 1000; f.y = -500; f.vx = f.vy = 0; f.t = 0; f.alive = true; f.shirt = 2;
        gFallers.push_back(f); rescueTick(1.0f / 120.0f);
        CHECK(gRescues == 0);
        P.onGround = false; P.alive = false; rescueTick(1.0f / 120.0f); CHECK(gRescues == 0);
        startRun(); CHECK(gFallers.empty() && gRescues == 0 && gRescueStreak == 0);
        gMenuIdle = true; P.alive = true; P.x = 5000; rescueTick(1.0f / 60.0f); CHECK(gFallers.empty()); gMenuIdle = false;
    }
    {   // spawning is deterministic (own hash, not the world RNG) and the numbers stay finite
        float xs[2] = {0, 0};
        for (int pass = 0; pass < 2; pass++) {
            startRun(); P = Player(); P.alive = true; P.onGround = false; P.y = -600; P.x = 0;
            for (int i = 0; i < 200 && gFallers.empty(); i++) { P.x += 15; rescueTick(0.0f); }
            CHECK(!gFallers.empty()); if (!gFallers.empty()) xs[pass] = gFallers[0].x;
        }
        CHECK(xs[0] == xs[1] && xs[0] > 0);
        startRun(); P = Player(); P.alive = true; P.onGround = false; P.y = -600;
        for (int i = 0; i < 600; i++) { P.x += 15; rescueTick(1.0f / 60.0f); }
        for (const Faller& f : gFallers) CHECK(std::isfinite(f.x) && std::isfinite(f.y));
        CHECK(gFallers.size() < 20);
    }
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
