// Life-size vehicle preview: g++ -std=c++17 -O1 -Itests/stub_gfx tests/shot_cars.cpp -o /tmp/shotk && /tmp/shotk
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static void present() {
    SDL_SetRenderTarget(uvzRenderer, nullptr); SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255); SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight}; SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
}
static void dump(const char* name) {
    char p[160]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); fprintf(f, "P6\n%d %d\n255\n", g_outW, g_outH);
    for (uint32_t c : g_screen) { unsigned char b[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c}; fwrite(b, 1, 3, f); }
    fclose(f);
}
int main() {
    mkdir("/tmp/shots", 0777); setenv("PCITY_PREF", "/tmp/pcity_t/", 1); if (system("mkdir -p /tmp/pcity_t")) {}
    g_outW = 960; g_outH = 540; g_screen.assign((size_t)g_outW * g_outH, 0xFF00FF00u);
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt(); startRun();
    gState = PLAYING; gTime = 10; gSkyTime = 20;
    for (int i = 0; i < 20; i++) { gTime += 0.016; updateGame(0.016); }
    SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
    const int types[3][3] = {{0, 4, 1}, {2, -1, -1}, {3, -1, -1}};
    for (int v = 0; v < 3; v++) {
        trafficCars.clear(); trafficSignals.clear(); nextTrafficSpawnX = 1e9f;
        float x = 400; int id = 1;
        for (int k = 0; k < 3; k++) { const int t = types[v][k]; if (t < 0) continue;
            TrafficCar c; c.speed = 0; c.maxSpeed = 0; c.type = t; c.width = trafficWidth(t); c.height = trafficHeight(t); c.dir = 1; c.lane = 0;
            c.color = t == 0 ? 0xE8B72D : 0x3F92B5; c.id = id++; c.x = x + c.width * 0.5f; trafficCars.push_back(c); x += c.width + 40; }
        P = Player(); P.alive = true; P.x = 330; P.y = STREET_GROUND_Y - 26 - 5; P.px = P.x; P.py = P.y; P.onGround = true;   // standing on the sidewalk side, to compare height
        camX = 300; camY = -150; ensureWorld();
        for (int i = 0; i < 30; i++) { P.x = 330; P.vx = 0; render(0.016); }
        present(); char n[32]; snprintf(n, sizeof n, "K%d", v); dump(n);
    }
    return 0;
}
