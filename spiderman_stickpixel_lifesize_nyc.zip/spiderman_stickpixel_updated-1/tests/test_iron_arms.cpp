// Iron Arms: locked until unlocked in the Skill Upgrades menu; TAP = upward launch, HOLD + SLIDE = forward launch; one shared 12 s cooldown
// during which the button is completely hidden and inert, and which ends by itself. Drives the real touch handlers and updateGame().
#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void floorWorld() { bld.clear(); Building b; b.x = -3000; b.w = 12000; b.roofY = 900; b.style = 0; b.seed = 1; bld.push_back(b); }
static void airRunner(float vx, float vy) {
    P = Player(); P.x = 0; P.y = 100; P.px = 0; P.py = 100; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = false; zipEdge = false; gFlow = 0; gSafeLandUntil = gTime + 1e9;
    gState = PLAYING; releaseAll();
}
static void tDown(int id, float x, float y) { SDL_TouchFingerEvent e = {}; e.fingerId = id; e.x = (x * uvzScaleX + uvzOffsetX) / uvzOutputWidth; e.y = (y * uvzScaleY + uvzOffsetY) / uvzOutputHeight; fingerDown(e); }
static void tUp(int id, float x, float y)   { SDL_TouchFingerEvent e = {}; e.fingerId = id; e.x = (x * uvzScaleX + uvzOffsetX) / uvzOutputWidth; e.y = (y * uvzScaleY + uvzOffsetY) / uvzOutputHeight; fingerUp(e); }
static int roleOf(int id) { for (auto& t : tch) if (t.on && t.id == (SDL_FingerID)id) return t.role; return -1; }
static const float DT = 1.0f / 60.0f;
static void frame() { updateGame(DT); }
static void keepAloft() { if (P.y > 500) { P.y = 0; P.py = 0; if (P.vy > 0) P.vy = 300; } }   // never let a long test run hit the street

int main() {
    if (system("rm -rf /tmp/pcity_ia && mkdir -p /tmp/pcity_ia") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_ia/", 1);
    loadCfg(); loadControls();
    uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun();
    floorWorld();
    float bx, by, br; ironBtnPos(bx, by, br);
    float sx[3], sy[3], sr[3]; for (int i = 0; i < 3; i++) ctlPos(i, sx[i], sy[i], sr[i]);

    // ---- locked: no button, no input, no launch ----
    gProg = prog::Data();
    airRunner(300, 0);
    CHECK(!prog::ironUnlocked(gProg) && !ironButtonShown());
    tDown(1, bx, by); CHECK(roleOf(1) != R_IRON); tUp(1, bx, by); frame();
    CHECK(P.vy > -100 && gIronCd == 0.0f);                       // nothing happened
    gIronUpEdge = true; frame(); CHECK(P.vy > -100 && gIronCd == 0.0f);   // even a stray edge cannot launch a locked ability

    // ---- unlocking through the skills menu rules: one-time price, no levels, no rebirth, old saves still load ----
    { prog::Data d; CHECK(prog::upgradeCostAt(d, prog::IRON) == 1500 && prog::maxLevel(prog::IRON) == 1 && prog::maxRebirth(prog::IRON) == 0);
      d.coins = 1499; CHECK(!prog::canUpgrade(d, prog::IRON) && !prog::upgrade(d, prog::IRON) && !prog::ironUnlocked(d));
      d.coins = 1500; CHECK(prog::upgrade(d, prog::IRON) && prog::ironUnlocked(d) && d.coins == 0);
      d.coins = 99999; CHECK(!prog::upgrade(d, prog::IRON) && d.coins == 99999 && !prog::canRebirth(d, prog::IRON));
      prog::Data r; CHECK(prog::parse(prog::serialize(d).c_str(), r) && prog::ironUnlocked(r));
      prog::Data o; CHECK(prog::parse("PROG2 77 1 2 3 4 5 0 0 0 0 0\n", o) && o.coins == 77 && o.level[4] == 5 && !prog::ironUnlocked(o)); }
    { gProg = prog::Data(); gProg.coins = 5000; btns.clear(); gState = SKILLS; Btn b = {B_UP_IRON, 0, 0, 0, 10, 10, "", nullptr, nullptr, 0, 1, 0, 0}; pressBtn(b); gState = PLAYING; }
    CHECK(prog::ironUnlocked(gProg) && gProg.coins == 3500);

    // ---- tap = upward launch; the button vanishes the same frame ----
    airRunner(300, 0);
    CHECK(ironButtonShown());
    tDown(1, bx, by); CHECK(roleOf(1) == R_IRON);
    frame(); CHECK(gIronCd == 0.0f && P.vy > -100);               // nothing yet: a tap launches on release
    tUp(1, bx, by); frame();
    CHECK(P.vy < -900 && fabsf(P.vx - 300) < 40);                // strong upward kick, sideways momentum kept
    CHECK(gIronCd > IRON_COOLDOWN - 0.1f && !ironButtonShown());  // cooldown running, button hidden immediately
    CHECK(gIronKind == 1 && gIronFxT > 0);

    // ---- while hidden: inert. A touch there is steering, input edges are dropped, nothing re-launches or resets the cooldown ----
    tDown(2, bx, by); CHECK(roleOf(2) != R_IRON); tUp(2, bx, by);
    const float cd0 = gIronCd, vy0 = P.vy;
    gIronUpEdge = true; gIronFwdEdge = true; gIronKeyDown = true; frame();
    CHECK(gIronCd < cd0 && gIronCd > cd0 - 0.05f);              // the timer kept running, was not restarted
    CHECK(P.vy > vy0 - 5.0f && !gIronUpEdge && !gIronFwdEdge);   // no second launch, edges not buffered
    gIronKeyDown = false;
    // SLIDE still works normally while Iron Arms is cooling down
    tDown(3, sx[2], sy[2]); CHECK(roleOf(3) == R_SLIDE && slideEdge); tUp(3, sx[2], sy[2]); slideEdge = false;

    // ---- exactly 12 s later it is back by itself, airborne and falling, with no menu / respawn ----
    float t = 0; bool back = false; float backAt = -1;
    P.vx = 300;
    while (t < 13.0f && !back) {
        keepAloft(); frame(); t += DT;
        if (ironButtonShown()) { back = true; backAt = t; }
        else CHECK(!ironButtonShown() && gIronCd > 0.0f);
    }
    CHECK(back && P.alive && !P.onGround);
    CHECK(backAt > 11.9f && backAt < 12.1f);                     // 12 s of play, to within a frame (the launch frame itself counts)
    CHECK(gIronCd == 0.0f);
    // and it is usable again
    tDown(4, bx, by); CHECK(roleOf(4) == R_IRON); tUp(4, bx, by); frame(); CHECK(P.vy < -900 && !ironButtonShown());

    // ---- hold + SLIDE = forward-and-upward launch; the slide is not triggered; one shared cooldown ----
    gIronCd = 0; gIronFxT = 0; airRunner(300, 200);
    tDown(5, bx, by); CHECK(roleOf(5) == R_IRON && ironHeldNow());
    tDown(6, sx[2], sy[2]);
    CHECK(roleOf(6) == R_NONE && !slideEdge && gIronFwdEdge);     // consumed as the forward launch, not as a slide or a held slide (no dive)
    frame();
    CHECK(P.vx > 300 + 450 && P.vx <= IRON_FWD_TOP + 5 && P.vy < -600);
    CHECK(P.slideT <= 0 && !P.diving);
    CHECK(gIronCd > IRON_COOLDOWN - 0.1f && !ironButtonShown() && gIronKind == 2);
    CHECK(roleOf(5) == R_NONE);                                   // the finger still on the old button is now inert
    tUp(5, bx, by); frame(); CHECK(P.vy > -1500 && gIronCd < IRON_COOLDOWN);   // releasing it later does not launch again
    tUp(6, sx[2], sy[2]);
    // switching launch type cannot bypass the shared timer
    gIronUpEdge = true; frame(); gIronFwdEdge = true; frame();
    CHECK(gIronCd < IRON_COOLDOWN - 0.03f && gIronCd > IRON_COOLDOWN - 0.2f);

    // ---- slide keeps its normal behaviour whenever Iron Arms is not held ----
    gIronCd = 0; airRunner(300, 0);
    tDown(7, sx[2], sy[2]); CHECK(roleOf(7) == R_SLIDE && slideEdge && !gIronFwdEdge); tUp(7, sx[2], sy[2]); slideEdge = false;
    P.swinging = false; frame(); CHECK(gIronCd == 0.0f);

    // ---- both launches at once: only one fires (forward wins) ----
    gIronCd = 0; airRunner(300, 0); gIronUpEdge = gIronFwdEdge = true; frame();
    CHECK(gIronKind == 2 && gIronCd > IRON_COOLDOWN - 0.1f && gIronCd <= IRON_COOLDOWN);

    // ---- from every motion state: swinging, zipping, wall-cling, standing on the ground ----
    gIronCd = 0; airRunner(300, 0); P.swinging = true; P.ax = P.x + 100; P.ay = P.y - 300; P.rope = 300; gIronUpEdge = true; frame();
    CHECK(!P.swinging && P.vy < -900 && gIronCd > 0);
    gIronCd = 0; airRunner(300, 0); P.zipping = true; P.zipX = 300; P.zipY = 0; gIronFwdEdge = true; frame();
    CHECK(!P.zipping && P.vx > 700 && gIronCd > 0);
    gIronCd = 0; airRunner(0, 0); P.wallCling = true; P.wallDir = 1; gIronUpEdge = true; ironFire(false);
    CHECK(!P.wallCling && P.vy < -900 && P.vx < 0);              // pushed off the wall
    gIronCd = 0; airRunner(250, 0); P.y = 900 - 26; P.onGround = true; P.groundedPrev = true; gIronUpEdge = true; frame();
    CHECK(!P.onGround && P.vy < -900);

    // ---- no launch while dead; a new run starts with the ability ready again ----
    gIronCd = 0; airRunner(300, 0); P.alive = false; gIronUpEdge = true; frame(); CHECK(gIronCd == 0.0f && !ironButtonShown());
    gIronCd = 7.0f; startRun(); CHECK(gIronCd == 0.0f); gState = PLAYING; CHECK(ironButtonShown());

    // ---- arm animation: folded when idle, four arms, reach down for the upward launch, stretch back for the forward launch ----
    gIronFxT = 0; gIronKind = 0; airRunner(300, 0); P.onGround = true;
    for (int k = 0; k < 4; k++) { float a1, a2, e; ironArmTarget(k, a1, a2, e); CHECK(e < 0.01f && a2 < a1); }          // folded behind
    gIronKind = 1; gIronFxDur = 0.5f; gIronFxT = 0.5f;
    for (int k = 0; k < 4; k++) { float a1, a2, e; ironArmTarget(k, a1, a2, e); CHECK(e > 0.99f && a1 < -0.7f && a1 > -2.5f); }   // pointing down, fanned
    gIronKind = 2; gIronFxT = 0.5f;
    for (int k = 0; k < 4; k++) { float a1, a2, e; ironArmTarget(k, a1, a2, e); CHECK(e > 0.99f && fabsf(a1) < 0.6f); }          // stretched backward
    gIronFxT = 0.05f;   // effect almost over: they fold back
    { float a1, a2, e; ironArmTarget(0, a1, a2, e); CHECK(e < 0.99f); }
    gIronFxT = 0;
    for (int i = 0; i < 90; i++) ironArmsUpdate(DT);              // springs settle on the folded pose without blowing up
    for (int k = 0; k < 4; k++) CHECK(std::isfinite(gIronArm[k].a1) && std::isfinite(gIronArm[k].a2) && gIronArm[k].ext < 0.05f);

    printf("[iron_arms] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
