#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static npc::Hero hero(float x, float feetY, float vx, bool sw, bool landed) { npc::Hero h; h.x = x; h.y = feetY - 26; h.vx = vx; h.vy = 0; h.swinging = sw; h.onGround = !sw; h.landedNow = landed; h.feetY = feetY; h.groundY = 0; return h; }
int main() {
    const float dt = 1.0f / 120.0f;
    { npc::State s; for (int i = 0; i < 240; i++) npc::update(s, 0, hero(900, 0, 200, false, false), dt);   // far away: nothing happens
      CHECK(s.startle == 0 && s.off == 0 && s.look == 0 && s.react < 0.01f); }
    { npc::State s; bool st = npc::update(s, 0, hero(40, 0, 0, false, true), dt);                         // landed next to them: startle + hop
      CHECK(st && s.startle > 0 && s.hopV < 0);
      float maxUp = 0, maxOff = 0, prevReact = s.react, maxJump = 0, peakSigned = 0;
      for (int i = 0; i < 600; i++) { npc::update(s, 0, hero(40, 0, 0, false, false), dt); maxUp = std::min(maxUp, s.hop); if (fabsf(s.off) > maxOff) { maxOff = fabsf(s.off); peakSigned = s.off; } maxJump = std::max(maxJump, fabsf(s.react - prevReact)); prevReact = s.react; if (s.hop > 0.001f) break; }
      CHECK(maxUp < -4.0f);                    // actually left the ground
      CHECK(maxOff <= npc::MAX_OFF + 0.01f);   // never pushed past the limit
      CHECK(maxJump < 0.2f);                   // pose weight eases, never snaps
      CHECK(peakSigned < -5.0f);                        // stepped away from the player (player is on the right)
      for (int i = 0; i < 4000; i++) npc::update(s, 0, hero(900, 0, 0, false, false), dt);
      CHECK(s.hop == 0 && fabsf(s.off) < 0.01f && s.react < 0.01f); }   // calms down and returns to the path
    { npc::State s; for (int i = 0; i < 90; i++) npc::update(s, 0, hero(60, -120, 0, true, false), dt);   // a swinger passes 120 px up: look up
      CHECK(s.look > 0.3f);
      npc::State t; for (int i = 0; i < 90; i++) npc::update(t, 0, hero(20, -90, 300, true, false), dt);   // swinging low overhead: startle
      CHECK(t.fear > 0.5f); }
    { npc::State s; npc::update(s, 0, hero(10, 0, 500, false, false), dt); CHECK(s.startle > 0); }       // sprinted right past them
    // walker rendering: the same walker at many times never produces NaN joints, and poses stay in the skeleton's range
    for (int c = -3; c < 4; c++) for (int k = 0; k < 3; k++) for (int t = 0; t < 400; t++) {
        const Walker w = walkerAt(c, k, t * 0.1f); npc::State st; st.look = (t % 10) / 10.0f; st.react = (t % 7) / 7.0f;
        const StkPose p = walkerPose(w, st, k); float jx[J_N], jy[J_N]; stkSolve(p, jx, jy);
        for (int i = 0; i < J_N; i++) if (!std::isfinite(jx[i]) || !std::isfinite(jy[i]) || fabsf(jx[i]) > 60 || jy[i] < -30 || jy[i] > 60) { printf("bad joint c=%d k=%d t=%d i=%d x=%.1f y=%.1f idle=%d\n", c, k, t, i, jx[i], jy[i], (int)w.idle); CHECK(false); return 1; }
    }
    CHECK(true);
    // updateWalkers wires into the player
    P = Player(); P.x = 300; P.y = -300; P.onGround = false; P.vy = 400; updateWalkers(0.01f);
    P.y = -26; P.onGround = true; P.vy = 0; for (int i = 0; i < 5; i++) updateWalkers(0.01f);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
