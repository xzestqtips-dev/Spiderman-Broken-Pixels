// Rooftop props are drawn from the sprite sheet: every prop the game places must be bound, with its pivot read from the .txt,
// and drawing must fall back to code (return false) when the sheet is missing.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    initFont();
    CHECK(loadSpriteSheet());
    bindSprites();
    for (int i = 0; i < PROP_N; i++) CHECK(gPropSpr[i].ok && gPropSpr[i].w > 0 && gPropSpr[i].h > 0);
    // pivots come from columns 7 and 8 of spritesheet.txt: the roof line sits at the sprite's bottom edge (or just above it for lit frames)
    CHECK(gPropSpr[PROP_CHIMNEY].px == 1 && gPropSpr[PROP_CHIMNEY].py == 28);
    CHECK(gPropSpr[PROP_WATERTOWER].px == 0 && gPropSpr[PROP_WATERTOWER].py == 60);
    CHECK(gPropSpr[PROP_SHED].px == 3 && gPropSpr[PROP_SHED].py == 25);
    for (int k = 0; k < 6; k++) CHECK(gPropSpr[PROP_BILLBOARD0 + k].px == 2 && gPropSpr[PROP_BILLBOARD0 + k].py == 44);
    CHECK(gPropSpr[PROP_ANTENNA_ON].h > gPropSpr[PROP_ANTENNA_OFF].h);   // the lit frame includes the aircraft light
    CHECK(gPropSpr[PROP_HELIPAD_ON].h > gPropSpr[PROP_HELIPAD_OFF].h);
    for (int k = 0; k < 4; k++) CHECK(gPropSpr[PROP_CRATE0 + k].ok && gPropSpr[PROP_CRATE0 + k].px == 1);   // street crates (shadow 1 px left of the box)
    CHECK(gPropSpr[PROP_CRATE0 + 2].h > gPropSpr[PROP_CRATE0].h);                                          // variant 2 is the tall two-high crate
    CHECK(gPropSpr[PROP_OBS0_0].ok && gPropSpr[PROP_OBS0_1].ok && gPropSpr[PROP_OBS1].ok && gPropSpr[PROP_OBS2].ok && gPropSpr[PROP_OBS6].ok);
    CHECK(sprDrawProp(PROP_DISH, 100, 100));
    SDL_Texture* keep = gSheet; gSheet = nullptr;
    CHECK(!sprDrawProp(PROP_DISH, 100, 100));                            // no sheet: the caller draws the prop from code
    gSheet = keep;
    // an old 5-column sheet line still loads (pivot 0, 0)
    int px = -1; { char n[64], c[32]; int x, y, w, h, a = 0, b = 0; CHECK(sscanf("foo 1 2 3 4", "%63s %d %d %d %d %31s %d %d", n, &x, &y, &w, &h, c, &a, &b) == 5); px = a; }
    CHECK(px == 0);
    printf("[sheet_props] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
