// (The runner keeps its ~40 px/s drift on a roof, so each ride is kept under a second.)
// Roof landings squash the suspension once, settle without bouncing above rest, never hurt the player or the car, and a rider is carried smoothly.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static TrafficCar mkCar(float x, int type) {
    TrafficCar c; c.x = x; c.speed = 0; c.maxSpeed = 0; c.width = trafficWidth(type); c.height = trafficHeight(type);
    c.type = type; c.dir = 1; c.lane = 0; c.color = 0xD0B040; c.id = 77; return c;
}
static void blank() {
    bld.clear(); trafficCars.clear(); trafficSignals.clear(); nextTrafficSpawnX = 1e9f; addBuilding(true);
    P = Player(); P.alive = true; steer = 0; swingHeld = false; jumpEdge = slideEdge = jumpRel = false; gImpactT = 0; gState = PLAYING;
}
static void step() { updateTraffic(1.0f / 120); stepPhysics(1.0f / 120); }
static float peakFor(int type, float vy) {
    blank(); trafficCars.push_back(mkCar(1000, type));
    const float top = carTopY(trafficCars[0]);
    P.x = 1000; P.y = top - 60; P.py = P.y; P.px = P.x; P.vy = vy; P.onGround = false;
    float peak = 0, prevY = P.y, maxPlayerStep = 0; int kicks = 0; float prevDipV = 0;
    for (int i = 0; i < 90 && P.alive; i++) {
        step();
        const TrafficCar& c = trafficCars[0];
        peak = std::max(peak, c.dip);
        if (c.dipV > prevDipV + 5.0f && c.dipV > 20.0f) kicks++;       // a fresh impulse (the spring itself only ever decelerates dipV after the kick)
        prevDipV = c.dipV;
        if (P.onGround && i > 5) maxPlayerStep = std::max(maxPlayerStep, fabsf(P.y - prevY));
        prevY = P.y;
        CHECK(c.dip >= 0.0f && c.dip <= SUSP_MAX + 1e-4f);
    }
    const bool narrow = trafficCars[0].width < 60.0f;      // a motorcycle is too short for the runner's drift: it rides off the back, which is fine
    CHECK(P.alive && (narrow || (P.onGround && P.rideId == 77)));
    CHECK(trafficCars[0].dip == 0.0f);                                  // fully settled
    CHECK(narrow || maxPlayerStep < 1.5f);                                        // the rider follows the roof smoothly (no snapping)
    CHECK(kicks <= 1);                                                  // exactly one kick per touchdown
    return peak;
}
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); if (system("mkdir -p /tmp/pcity_t")) {}
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();
    const float soft = peakFor(1, 300), hard = peakFor(1, 800), bus = peakFor(2, 800), moto = peakFor(4, 800);
    printf("peak dip px: soft %.2f hard %.2f bus %.2f moto %.2f\n", soft, hard, bus, moto);
    CHECK(soft > 0.3f && soft < hard);                                  // depends on impact speed
    CHECK(bus < hard);                                                  // heavier vehicles move less
    CHECK(moto >= hard);
    // Standing on the roof does not keep re-triggering it.
    blank(); trafficCars.push_back(mkCar(1000, 1));
    P.x = 1000; P.y = carTopY(trafficCars[0]) - 26.0f; P.py = P.y; P.px = P.x; P.onGround = true; P.groundedPrev = true; P.rideId = 77;
    for (int i = 0; i < 90; i++) step();
    CHECK(trafficCars[0].dip == 0.0f && P.alive && P.rideId == 77);
    // A gentle touchdown (< 120 px/s) causes no squash; the car is never damaged or moved by the landing.
    blank(); trafficCars.push_back(mkCar(1000, 1)); const float x0 = trafficCars[0].x;
    P.x = 1000; P.y = carTopY(trafficCars[0]) - 27.0f; P.py = P.y; P.px = P.x; P.vy = 60; for (int i = 0; i < 60; i++) step();
    CHECK(trafficCars[0].dip == 0.0f && trafficCars[0].x == x0 && P.alive);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
