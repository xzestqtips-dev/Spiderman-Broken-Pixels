#define PCITY_TEST_STREET_Y 1e9f
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
// The camera must never let the player leave the screen, even in a 1800 px/s fall or a 1600 px/s swing.
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_camf/", 1);
    if (system("rm -rf /tmp/pcity_camf && mkdir -p /tmp/pcity_camf") != 0) return 2;
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun();
    bld.clear(); Building b; b.x = -3000; b.w = 400000; b.roofY = 90000; b.style = 0; b.seed = 1; bld.push_back(b);
    gState = PLAYING;
    P = Player(); P.alive = true; P.onGround = false; P.x = 0; P.y = 0; P.px = 0; P.py = 0;
    camX = P.x - uvzWorldWidth * 0.3f; camY = P.y - uvzWorldHeight * 0.58f;
    float minFx = 9, maxFx = -9, minFy = 9, maxFy = -9;
    for (int i = 0; i < 600; i++) {
        const float vy = i < 200 ? 1800.0f : (i < 400 ? -1500.0f : 0.0f), vx = i < 300 ? 1600.0f : 250.0f;
        P.vx = vx; P.vy = vy; P.x += vx / 60.0f; P.y += vy / 60.0f; P.px = P.x; P.py = P.y; P.swinging = false; P.alive = true; P.deadT = 0;
        updateGame(1.0 / 60);
        const float fx = (P.x - camX) / uvzWorldWidth, fy = (P.y - camY) / uvzWorldHeight;
        minFx = std::min(minFx, fx); maxFx = std::max(maxFx, fx); minFy = std::min(minFy, fy); maxFy = std::max(maxFy, fy);
    }
    printf("player screen fraction x %.2f..%.2f, y %.2f..%.2f\n", minFx, maxFx, minFy, maxFy);
    CHECK(minFx >= 0.1f && maxFx <= 0.6f);
    CHECK(minFy >= 0.2f && maxFy <= 0.82f);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
