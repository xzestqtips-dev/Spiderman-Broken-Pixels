// Marvel-style swing feel: rope whip, chain speed build-up, release pop + hang time, fast web attach, camera pull-back, pose/web polish.
#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void world() { bld.clear(); Building b; b.x = -3000; b.w = 14000; b.roofY = 2500; b.style = 0; b.seed = 1; bld.push_back(b); }
static void startSwing(float x, float y, float vx, float vy, float ax, float ay) {
    P = Player(); P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; P.alive = true; P.onGround = false;
    P.swinging = true; P.ax = ax; P.ay = ay; P.rope = hypotf(x - ax, y - ay); P.ropeEff = P.rope;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true; swingWas = true; gFlow = 0; badClear();
}
int main() {
    if (system("rm -rf /tmp/pcity_mv && mkdir -p /tmp/pcity_mv") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_mv/", 1);
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gProg = prog::Data(); cfg.reduced = false;
    const float dt = 1.0f / 120.0f;

    // 1. whip: the rope is reeled in 10-15% through the bottom/upswing, speed jumps there vs a fixed-length rope, nothing stretches or snaps
    {
        world(); startSwing(-230, -60, 0, 0, 0, -300);
        float minEff = 1e9f, peakWhip = 0, worstStep = 0, prev = 0, maxStretch = 0; bool after = false;
        for (int i = 0; i < 600 && P.swinging; i++) {
            stepPhysics(dt);
            const float v = hypotf(P.vx, P.vy);
            if (P.x > P.ax) { after = true; minEff = std::min(minEff, P.ropeEff); }
            if (P.x - P.ax > -30 && P.x - P.ax < 150) peakWhip = std::max(peakWhip, v);
            worstStep = std::max(worstStep, fabsf(v - prev)); prev = v;
            maxStretch = std::max(maxStretch, hypotf(P.x - P.ax, P.y - P.ay) - P.ropeEff);
        }
        // reference: the same swing on a rope that never shortens
        float x = -230, y = -60, vx = 0, vy = 0, peakFixed = 0; const float rope = hypotf(x, y + 300);
        for (int i = 0; i < 600; i++) { vy += GRAV * dt; x += vx * dt; y += vy * dt; swingStep(x, y, vx, vy, 0, -300, rope, 1.0f, 0.0f, dt); if (x > -30 && x < 150) peakFixed = std::max(peakFixed, hypotf(vx, vy)); if (x > 150) break; }
        printf("whip: rope reeled to %.1f%% of its length, speed through the bottom %.0f vs %.0f px/s fixed rope (+%.0f%%), worst step %.1f, stretch %.3f\n",
               100 * minEff / P.rope, peakWhip, peakFixed, (peakWhip / peakFixed - 1) * 100, worstStep, maxStretch);
        CHECK(after && minEff <= 0.90f * P.rope && minEff >= 0.86f * P.rope);
        CHECK(peakWhip > peakFixed * 1.08f);
        CHECK(worstStep < 25.0f && maxStretch < 0.05f);
    }
    // the reel conserves angular momentum about the anchor (the physical reason for the jump)
    {
        float x = 0, y = 250, vx = 600, vy = 0, rEff = 250; const float ax = 0, ay = 0;
        const float L0 = (x - ax) * vy - (y - ay) * vx;
        for (int i = 0; i < 20; i++) { reelStep(x, y, ax, ay, vx, vy, 250.0f, rEff, dt); const float d = hypotf(x - ax, y - ay); x = ax + (x - ax) / d * rEff; y = ay + (y - ay) / d * rEff; }
        const float L1 = (x - ax) * vy - (y - ay) * vx;
        printf("reel: length %.0f -> %.1f, angular momentum %.0f -> %.0f\n", 250.0f, rEff, L0, L1);
        CHECK(rEff < 250.0f * 0.95f && fabsf(L1 / L0 - 1.0f) < 0.04f);
    }

    // 2. chain build-up: lower damping, higher cap with Flow/chain, bonus on every web in a chain, stronger pump
    {
        P = Player(); gFlow = 0; P.chain = 0;
        const float d0 = swingDamping(), c0 = swingSpeedCap(1.0f);
        gFlow = 1.0f; P.chain = 5;
        const float d1 = swingDamping(), c1 = swingSpeedCap(1.0f);
        printf("damping %.3f -> %.3f /s (was 0.12), speed cap %.0f -> %.0f px/s\n", d0, d1, c0, c1);
        CHECK(d0 <= 0.06f && d1 <= 0.03f && c1 >= c0 + 450.0f);
        gFlow = 0;
        world(); float spd[3];
        for (int ch = 0; ch < 3; ch++) {
            P = Player(); P.alive = true; P.x = 0; P.y = 0; P.vx = 700; P.vy = -200; P.chain = ch == 0 ? 0 : (ch == 1 ? 1 : 4);
            const float v0 = hypotf(P.vx, P.vy); attachWeb(300, -300); spd[ch] = hypotf(P.vx, P.vy) / v0;
        }
        printf("attach speed factor: 1st web %.3f, 2nd %.3f, 5th %.3f\n", spd[0], spd[1], spd[2]);
        CHECK(spd[0] == 1.0f && spd[1] > 1.02f && spd[2] > spd[1] + 0.05f && spd[2] < 1.2f);
        // a held swing keeps more speed over time than the old 12 %/s drag would allow
        world(); startSwing(-200, -100, 300, 0, 0, -300);
        for (int i = 0; i < 360 && P.swinging; i++) { stepPhysics(dt); }
        CHECK(P.alive);
    }

    // (released in the neutral zone, 20-28 deg above the horizontal: higher/flatter releases are shaped, see test_launch_dive)
    // 3. release: immediate pop along the velocity, ~0.15 s of reduced gravity, and a forced release launches as well
    {
        world(); startSwing(0, 0, 900 * cosf(25 * pi / 180), -900 * sinf(25 * pi / 180), 0, -300); P.swingT = 1.0f;
        const float v0 = hypotf(P.vx, P.vy), ang0 = atan2f(P.vy, P.vx);
        releaseWeb(true);
        const float v1 = hypotf(P.vx, P.vy);
        printf("release pop: %.0f -> %.0f px/s instantly (+%.0f%%), hang %.2f s, launchK %.2f\n", v0, v1, (v1 / v0 - 1) * 100, P.hangT, P.launchK);
        CHECK(v1 > v0 * 1.10f && fabsf(atan2f(P.vy, P.vx) - ang0) < 1e-3f);
        CHECK(P.hangT > 0.14f && P.hangT <= 0.151f);
        Player a = P; P.hangT = 0; Player b = P; (void)b;
        P = a; P.launchT = 0; const float vy0 = P.vy; for (int i = 0; i < 18; i++) stepPhysics(dt);   // 0.15 s
        const float withHang = P.vy - vy0;
        P = a; P.hangT = 0; P.launchT = 0; for (int i = 0; i < 18; i++) stepPhysics(dt);
        const float noHang = P.vy - vy0;
        printf("vy gained in 0.15 s: %.0f with hang vs %.0f without (gravity share %.2f)\n", withHang, noHang, HANG_GRAV);
        CHECK(withHang < noHang * 0.6f && withHang > 0);
        // forced release at the forward limit
        world(); startSwing(0.78f * 300, 0.62f * 300, 560, -420, 0, 0); P.ropeEff = P.rope; P.swingT = 1.0f;
        const float vf0 = hypotf(P.vx, P.vy); bool released = false;
        for (int i = 0; i < 60 && !released; i++) { stepPhysics(dt); if (!P.swinging) released = true; }
        printf("forced release: released %d, launchK %.3f, speed %.0f -> %.0f\n", (int)released, P.launchK, vf0, hypotf(P.vx, P.vy));
        CHECK(released && P.launchK >= 0.05f);
        CHECK(forcedReleaseK(700, -300) >= 0.05f);
    }

    // 4. web attach: capped near 0.2 s, and the web pulls toward the anchor while travelling
    {
        float worst = 0; for (float d = 50; d < 4000; d += 50) for (float sm : {1.0f, 1.5f, 2.2f}) worst = std::max(worst, webTravelTime(d, sm));
        printf("longest web flight over all distances/levels: %.3f s (was up to 0.65)\n", worst);
        CHECK(worst <= 0.2001f && webTravelTime(900, 1.0f) < 0.26f);
        world(); P = Player(); P.alive = true; P.onGround = false; P.x = 0; P.y = 0; P.px = 0; P.py = 0; P.vx = 300; P.vy = 0;
        tgtX = 300; tgtY = -300; badClear();
        Player free = P; for (int i = 0; i < 24; i++) stepPhysics(dt);
        const float fx = P.x, fy = P.y;
        P = free; P.webFlying = true; for (int i = 0; i < 24; i++) stepPhysics(dt);
        const float d0 = hypotf(fx - tgtX, fy - tgtY), d1 = hypotf(P.x - tgtX, P.y - tgtY);
        printf("after 0.2 s of web flight: %.0f px from the anchor vs %.0f in plain free fall\n", d1, d0);
        CHECK(d1 < d0 - 25.0f);   // a slight pull, not a yank
    }

    // 5. camera: pulls back toward 0.9 at speed, eases back, keeps the player pinned, and the swing path renders
    {
        world(); P = Player(); P.x = 0; P.y = 0; P.px = 0; P.py = 0; P.alive = true; P.onGround = false; gState = PLAYING; gZoom = 1.0f;
        float minZ = 1.0f, worstZStep = 0, pz = 1.0f;
        for (int i = 0; i < 240; i++) { P.vx = 1800; P.vy = 0; P.x = 0; P.y = 0; P.px = 0; P.py = 0; updateGame(1.0 / 60); minZ = std::min(minZ, gZoom); worstZStep = std::max(worstZStep, fabsf(gZoom - pz)); pz = gZoom; }
        printf("zoom at 1800 px/s: %.3f, biggest change per frame %.4f\n", gZoom, worstZStep);
        CHECK(gZoom < 0.905f && gZoom >= ZOOM_MIN && worstZStep < 0.01f);
        for (int i = 0; i < 360; i++) { P.vx = 200; P.vy = 0; P.x = 0; P.y = 0; P.px = 0; P.py = 0; updateGame(1.0 / 60); }
        CHECK(gZoom == 1.0f);
        cfg.reduced = true; for (int i = 0; i < 240; i++) { P.vx = 1800; P.vy = 0; P.x = 0; P.y = 0; P.px = 0; P.py = 0; updateGame(1.0 / 60); }
        CHECK(gZoom == 1.0f); cfg.reduced = false;
        for (float z : {1.0f, 0.95f, 0.9f}) {
            P.x = 1234; P.y = -56; int W1, H1; float zcx, zcy; const float cx = 1000, cy = -200;
            zoomView(z, cx, cy, W1, H1, zcx, zcy);
            const float sx = (P.x - zcx) * (float)uvzWorldWidth / W1, sy = (P.y - zcy) * (float)uvzWorldHeight / H1;
            CHECK(fabsf(sx - (P.x - cx)) < 2.0f && fabsf(sy - (P.y - cy)) < 2.0f && W1 >= uvzWorldWidth);
        }
        const int W = uvzWorldWidth, H = uvzWorldHeight;
        startSwing(100, 100, 900, -300, 300, -200); camX = P.x - 200; camY = P.y - 150; gState = PLAYING; trans = -1; gZoom = 0.9f;
        render(0.016); render(0.016);
        CHECK(uvzWorldWidth == W && uvzWorldHeight == H);
        gZoom = 1.0f;
    }

    // 6. pose and web: the body follows the rope (and leans into travel at speed); the line sags when slack and straightens when taut
    {
        world(); startSwing(-150, 100, 0, 0, 0, -200);
        const float tLeft = swingTiltDeg(P);
        startSwing(150, 100, 0, 0, 0, -200);
        const float tRight = swingTiltDeg(P);
        startSwing(0, 100, 900, 0, 0, -200);
        const float tFast = swingTiltDeg(P);
        startSwing(0, 100, 0, 0, 0, -200);
        const float tStill = swingTiltDeg(P);
        printf("tilt: body left of anchor %.1f, right of anchor %.1f, bottom at speed %.1f, bottom still %.1f deg\n", tLeft, tRight, tFast, tStill);
        CHECK(tLeft > 10 && tRight < -10 && fabsf(tStill) < 1.0f && tFast > 10.0f);
        startSwing(0, 0, 0, 0, 100, -250); P.ropeEff = P.rope;   // hanging at rest high in the swing
        const float slack = webTension(P);
        startSwing(0, 200, 1000, 0, 0, -100); P.ropeEff = P.rope;   // fast at the bottom
        const float taut = webTension(P);
        const float sagSlack = webSagPx(300, slack, 0), sagTaut = webSagPx(300, taut, 0), sagFresh = webSagPx(300, taut, 1.0f);
        printf("web tension %.2f (slow, high) vs %.2f (fast, bottom); sag %.1f px vs %.1f px, fresh attach %.1f px\n", slack, taut, sagSlack, sagTaut, sagFresh);
        CHECK(taut > slack + 0.3f && sagSlack > sagTaut * 2.0f && sagTaut >= 0.0f && sagFresh > sagTaut + 5.0f && sagSlack <= 17.0f);
    }

    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL SWING MARVEL TESTS PASSED\n");
    return fails ? 1 : 0;
}
