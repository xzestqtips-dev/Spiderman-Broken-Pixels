#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void world() {
    bld.clear();
    Building a; a.x = -3000; a.w = 9000; a.roofY = 2500; a.seed = 1; a.style = 0;
    Building b; b.x = 500; b.w = 1000; b.roofY = 0; b.seed = 2; b.style = 1;
    bld.push_back(a); bld.push_back(b);
}
int main() {
    if (system("rm -rf /tmp/pcity_wm && mkdir -p /tmp/pcity_wm") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_wm/", 1);
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gWallsSolid = true; /* these tests cover the legacy solid-wall behavior */ gState = PLAYING;
    gProg = prog::Data();
    const float dt = 1.0f / 120.0f;
    world();
    P = Player(); P.x = 485; P.y = 800; P.px = P.x; P.py = P.y; P.vx = 300; P.vy = -420; P.alive = true; P.onGround = false;
    steer = 0; jumpEdge = slideEdge = jumpRel = false; swingHeld = true; swingWas = true; badClear(); gFlow = 0;
    float vyAtCling = 0; bool got = false, jumpStep = false; float lastVy = 0, maxStep = 0; int gotAt = 0;
    for (int i = 0; i < 120 && P.alive; i++) {
        stepPhysics(dt);
        if (P.wallCling && !got) { got = true; gotAt = i; vyAtCling = P.vy; lastVy = P.vy; continue; }
        if (got && i < gotAt + 30) { maxStep = std::max(maxStep, fabsf(P.vy - lastVy)); lastVy = P.vy; }
    }
    (void)jumpStep;
    printf("wall contact while rising: vy %.0f, biggest vy change per step after %.1f\n", vyAtCling, maxStep);
    CHECK(got);
    CHECK(vyAtCling < -250.0f);
    CHECK(maxStep < 20.0f);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
