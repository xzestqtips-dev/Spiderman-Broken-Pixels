// Software-render harness for Iron Arms: dumps gameplay frames (folded arms, button, upward launch, forward launch, cooldown) as PPMs in /tmp/shots.
// Usage: g++ -std=c++17 -O1 -w -Itests/stub_gfx tests/shot_iron.cpp -o /tmp/shot_iron && /tmp/shot_iron 1280 600
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static void present() {
    SDL_SetRenderTarget(uvzRenderer, nullptr); SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255); SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight}; SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
}
static void dump(const char* name) {
    char p[160]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); fprintf(f, "P6\n%d %d\n255\n", g_outW, g_outH);
    for (uint32_t c : g_screen) { unsigned char b[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c}; fwrite(b, 1, 3, f); }
    fclose(f);
}
static void shot(const char* name) { gTime += 0.016; render(0.016); present(); dump(name); }
int main(int argc, char** argv) {
    mkdir("/tmp/shots", 0777);
    setenv("PCITY_PREF", "/tmp/pcity_iron/", 1); system("mkdir -p /tmp/pcity_iron");
    int W = argc > 1 ? atoi(argv[1]) : 1280, H = argc > 2 ? atoi(argv[2]) : 600;
    g_outW = W; g_outH = H; g_screen.assign((size_t)W * H, 0xFF00FF00u);
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gRunT0 = 0;
    gProg = prog::Data(); gProg.level[prog::IRON] = 1;
    if (argc > 3 && !strcmp(argv[3], "skills")) {   // the Skill Upgrades screen with Iron Arms locked (argv[4]=1: unlocked)
        if (argc > 4 && atoi(argv[4])) gProg.level[prog::IRON] = 1; else gProg.level[prog::IRON] = 0;
        gProg.coins = 4200; startRun(true); gState = MAIN_MENU; trans = -1; uiAge = 5; openSub(SKILLS); uiAge = 5;
        for (int i = 0; i < 4; i++) { gTime += 0.016; render(0.016); present(); } uiAge = 5; shot(argc > 4 && atoi(argv[4]) ? "iron_skills_on" : "iron_skills_off");
        return 0;
    }
    gState = PLAYING;
    for (int i = 0; i < 40; i++) { gTime += 0.016; updateGame(0.016); }
    shot("iron_1_run");                                              // running on the rooftop: arms folded, button visible
    P.vx = 300; ironFire(false);                                      // upward launch
    for (int i = 0; i < 4; i++) { gTime += 0.016; updateGame(0.016); }
    shot("iron_2_up_early");
    for (int i = 0; i < 6; i++) { gTime += 0.016; updateGame(0.016); }
    shot("iron_3_up_mid");
    for (int i = 0; i < 40; i++) { gTime += 0.016; updateGame(0.016); }
    shot("iron_4_up_late_cooldown");                                  // button must be gone
    gIronCd = 0;
    for (int i = 0; i < 30; i++) { gTime += 0.016; updateGame(0.016); }
    ironFire(true);
    for (int i = 0; i < 5; i++) { gTime += 0.016; updateGame(0.016); }
    shot("iron_5_fwd_early");
    for (int i = 0; i < 8; i++) { gTime += 0.016; updateGame(0.016); }
    shot("iron_6_fwd_mid");
    return 0;
}
