// Buildings are untouchable: walls ignore the player, roofs still work as landing spots, rooftop objects stay solid.
#define PCITY_TEST_STREET_Y 900.0f
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void fly(float x, float y, float vx, float vy) { P = Player(); P.alive = true; P.onGround = false; P.x = x; P.y = y; P.px = x; P.py = y; P.vx = vx; P.vy = vy; steer = 0; swingHeld = false; swingWas = false; badClear(); }
int main() {
    if (system("rm -rf /tmp/pcity_uw && mkdir -p /tmp/pcity_uw") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_uw/", 1);
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(); gProg = prog::Data();
    CHECK(!gWallsSolid);   // shipped default
    const float dt = 1.0f / 120.0f;
    auto city = []() { bld.clear(); Building a; a.x = -3000; a.w = 3300; a.roofY = -100; a.style = 0; a.seed = 1; bld.push_back(a);
                       Building t; t.x = 400; t.w = 1500; t.roofY = -300; t.style = 0; t.seed = 2; bld.push_back(t); };
    // 1. flying into a wall (with and without the web button held): no death, no cling, no bump
    for (int held = 0; held < 2; held++) {
        city(); fly(250, 100, 900, 0); swingHeld = held; bool cling = false, dead = false; float minX = 1e9f;
        for (int i = 0; i < 60; i++) { P.vy = std::min(P.vy, 0.0f); stepPhysics(dt); cling |= P.wallCling; dead |= !P.alive; minX = std::min(minX, P.x); }
        printf("wall hit (held=%d): reached x=%.0f, cling %d, dead %d\n", held, P.x, (int)cling, (int)dead);
        CHECK(!cling && !dead && P.x > 600);
    }
    // 2. a swing straight through a wall is not interrupted (no forced release, no vault)
    city(); fly(300, 100, 700, -100); P.swinging = true; P.ax = 380; P.ay = -200; P.rope = hypotf(P.x - P.ax, P.y - P.ay); P.ropeEff = P.rope; swingHeld = true; swingWas = true;
    { bool released = false; for (int i = 0; i < 90 && P.alive; i++) { stepPhysics(dt); if (!P.swinging) released = true; if (P.x > 420 && P.x < 440 && P.y + 26 > -300) break; }
      CHECK(P.alive && !P.wallCling); (void)released; }
    // 3. roofs are landing spots: drop onto the near roof, land on the far roof, and keep standing
    city(); fly(100, -600, 0, 0);
    for (int i = 0; i < 400 && !P.onGround; i++) stepPhysics(dt);
    printf("landed on roof: y=%.1f (feet %.1f, roof %.1f)\n", P.y, P.y + 26, bld[0].roofY - START_ROOF_LIFT);
    CHECK(P.onGround && P.alive && fabsf(P.y + 26 - (bld[0].roofY - START_ROOF_LIFT)) < 1.0f);
    city(); fly(900, -700, 0, 200);
    for (int i = 0; i < 600 && !P.onGround; i++) stepPhysics(dt);
    CHECK(P.onGround && P.alive && fabsf(P.y + 26 - (bld[1].roofY - START_ROOF_LIFT)) < 1.0f);
    // 4. fast fall onto a roof does not tunnel through it
    city(); fly(900, -1500, 0, 1400); int landed = 0;
    for (int i = 0; i < 600; i++) { stepPhysics(dt); if (P.onGround) { landed = 1; break; } }
    CHECK(landed && P.y + 26 < bld[1].roofY + 2);
    // 5. coming from below the roofline (inside the body) does not land: roofs are only landed on from above
    city(); fly(900, -200, 0, 0);
    for (int i = 0; i < 20; i++) stepPhysics(dt);
    CHECK(!P.onGround && P.y > -300);
    // 6. rooftop objects are still solid
    city(); { Obs o{}; o.x = 800; o.w = 40; o.h = 60; o.type = 0; o.solid = true; o.param = 0; bld[1].obs.push_back(o); }
    fly(700, -340, 900, 0); bool died = false;
    for (int i = 0; i < 90; i++) { P.vy = std::min(P.vy, 0.0f); stepPhysics(dt); if (!P.alive) { died = true; break; } }
    printf("rooftop object still solid: dead=%d\n", (int)died);
    CHECK(died || P.x < 840);
    // 7. the legacy switch still brings the walls back
    gWallsSolid = true; city(); fly(250, 100, 900, 0); bool hit = false;
    for (int i = 0; i < 60; i++) { P.vy = std::min(P.vy, 0.0f); stepPhysics(dt); if (!P.alive || P.wallCling) { hit = true; break; } }
    CHECK(hit); gWallsSolid = false;
    printf("%d checks, %d failed\n", checks, fails);
    if (!fails) printf("ALL UNTOUCHABLE WALL TESTS PASSED\n");
    return fails ? 1 : 0;
}
