#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
// "Buildings can always be swung on": from the roof, the air and the street, a web target must exist on every building,
// and the anchor poles must clear both the building and its left neighbour.
int main() {
    int totalNoAnchor = 0, poleLow = 0, tests = 0;
    for (int seed = 1; seed <= 6; seed++) {
        wrng = Rng(seed * 7919); distM = (float)(seed * 400);
        bld.clear(); addBuilding(true);
        for (int i = 0; i < 120; i++) addBuilding(false);
        for (size_t i = 2; i + 2 < bld.size(); i++) {
            const Building& b = bld[i], &p = bld[i - 1];
            int poles = 0;
            for (auto& o : b.obs) if (o.type == 3) poles++;
            CHECK(poles == 0);   // no dedicated web-anchor poles any more: the web sticks to any surface
            const float xs[3] = {b.x + b.w * 0.15f, b.x + b.w * 0.5f, b.x + b.w * 0.85f};
            const float ys[3] = {b.roofY - 80.0f, b.roofY - 200.0f, STREET_GROUND_Y - 26.0f};
            for (float x : xs) for (float y : ys) {
                P = Player(); P.x = x; P.y = y; P.vx = 300; P.vy = -50;
                float ax, ay;
                // Swing to anything: a web needs a surface ABOVE the player to hang from. Only probes that have one (a taller roof ahead
                // within reach) must find a target; open air above every roof in range legitimately has none.
                bool higher = false;
                for (const Building& q : bld) if (q.x + q.w > x + 150.0f && q.x < x + 2200.0f && q.roofY < y - 90.0f) { higher = true; break; }
                if (!higher) continue;
                tests++;
                if (!pickAnchor(makeQuery(), ax, ay)) totalNoAnchor++;
            }
        }
    }
    printf("%d probes, %d without an anchor, %d low poles\n", tests, totalNoAnchor, poleLow);
    CHECK(totalNoAnchor * 50 <= tests);   // <= 2 %: the rare miss is a very long, shallow shot across open air to a distant taller roof
    CHECK(poleLow == 0);
    // denser city: average building+gap pitch stays tight
    wrng = Rng(5); distM = 0; bld.clear(); addBuilding(true);
    for (int i = 0; i < 200; i++) addBuilding(false);
    const float pitch = (bld.back().x - bld[1].x) / (float)(bld.size() - 2);
    printf("avg building pitch %.0f px\n", pitch);
    CHECK(pitch < 1000.0f);
    // New York landmarks appear regularly, never back to back, and 
    int lm[5] = {0}, adj = 0;
    for (size_t i = 1; i < bld.size(); i++) {
        lm[bld[i].landmark]++;
        if (bld[i].landmark && bld[i - 1].landmark) adj++;
    }
    printf("landmarks: empire %d chrysler %d wtc %d flatiron %d\n", lm[1], lm[2], lm[3], lm[4]);
    CHECK(lm[1] > 0 && lm[2] > 0 && lm[3] > 0 && lm[4] > 0 && adj == 0);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
