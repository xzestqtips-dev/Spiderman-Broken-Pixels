// Audio synth sanity: every sfx makes sound and ends, music is audible, output stays finite and in range.
#include "../src/audio.h"
#include <cstdio>
#include <cmath>
#include <vector>
static int fails = 0;
#define CHECK(c, msg) do { if (!(c)) { printf("FAIL %s\n", msg); fails++; } } while (0)
int main() {
    for (int t = 0; t < audio::kSfxCount; t++) {
        audio::Synth s; std::vector<float> o(44100 * 2);
        s.trigger(t); s.render(o.data(), (int)o.size(), 0, 1, 0, 0, 0);
        float pk = 0, tail = 0; bool bad = false;
        for (size_t i = 0; i < o.size(); i++) { if (!std::isfinite(o[i]) || fabsf(o[i]) > 1.0f) bad = true; pk = fmaxf(pk, fabsf(o[i])); if (i > 44100 * 1.5) tail = fmaxf(tail, fabsf(o[i])); }
        char m[64];
        snprintf(m, sizeof m, "sfx %d audible", t); CHECK(pk > 0.05f, m);
        snprintf(m, sizeof m, "sfx %d finite/in range", t); CHECK(!bad, m);
        snprintf(m, sizeof m, "sfx %d ends (silent tail)", t); CHECK(tail < 1e-6f, m);
    }
    for (int mode = 1; mode <= 2; mode++) {
        audio::Synth s; std::vector<float> o(44100 * 12);
        s.render(o.data(), (int)o.size(), 1, 0, 0, mode, 0);
        double e = 0; bool bad = false;
        for (float x : o) { if (!std::isfinite(x) || fabsf(x) > 1.0f) bad = true; e += x * x; }
        CHECK(sqrt(e / o.size()) > 0.02, mode == 1 ? "menu music audible" : "game music audible");
        CHECK(!bad, "music finite/in range");
    }
    { audio::Synth s; std::vector<float> o(4096); s.render(o.data(), 4096, 1, 1, 0, 0, 0);
      double e = 0; for (float x : o) e += fabs(x); CHECK(e == 0.0, "mode 0 + no sfx + no bed is silent"); }
    { audio::Synth s; for (int i = 0; i < 40; i++) s.trigger(i % audio::kSfxCount);   // voice stealing must not crash
      std::vector<float> o(2048); s.render(o.data(), 2048, 0, 1, 0, 0, 0); }
    {   // sample bank: every sfx type has clips in assets/audio/sfx and plays them; a bad file is rejected
        static const char* N[audio::kSfxCount] = {"web_shoot", "web_attach", "wall_hit", "reward", "ui", "splat", "land", "jump", "release"};
        audio::Synth s; int loaded = 0;
        for (int t = 0; t < audio::kSfxCount; t++) for (int n = 0; n < audio::kMaxVariants; n++) {
            char fn[128]; snprintf(fn, sizeof fn, "assets/audio/sfx/%s_%d.wav", N[t], n);
            FILE* f = fopen(fn, "rb"); if (!f) break;
            std::vector<unsigned char> d(1 << 22); size_t got = fread(d.data(), 1, d.size(), f); fclose(f);
            CHECK(s.addClip(t, d.data(), got), fn); loaded++;
        }
        CHECK(loaded >= audio::kSfxCount, "at least one clip per sfx type");
        CHECK(s.clipsLoaded() == loaded, "clip count matches");
        for (int t = 0; t < audio::kSfxCount; t++) {
            audio::Synth q = s; q.trigger(t); std::vector<float> o(44100 * 2); q.render(o.data(), (int)o.size(), 0, 1, 0, 0, 0);
            float pk = 0, tail = 0; for (size_t i = 0; i < o.size(); i++) { pk = fmaxf(pk, fabsf(o[i])); if (i > 44100 * 1.5) tail = fmaxf(tail, fabsf(o[i])); }
            CHECK(pk > 0.05f && tail < 1e-6f, "sampled sfx audible and ends");
        }
        unsigned char junk[64] = {0}; CHECK(!s.addClip(0, junk, sizeof junk), "junk rejected");
    }
    printf(fails ? "FAILED %d\n" : "all audio checks passed\n", fails);
    return fails ? 1 : 0;
}
