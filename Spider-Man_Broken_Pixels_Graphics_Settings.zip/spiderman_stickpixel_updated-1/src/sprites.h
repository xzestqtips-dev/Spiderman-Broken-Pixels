#pragma once
// Sprite sheet runtime. All fixed-size pixel art (building tiles, vehicles, civilians, pedestrians, helicopter, birds) lives in
// assets/spritesheet.tga (uncompressed 32-bit TGA) with assets/spritesheet.txt mapping each sprite name to "x y w h".
// The sheet is produced by tools/gen_spritesheet.cpp (tools/gen_spritesheet.sh); edit it in any pixel editor, keep the names/rects.
// It also holds the baked player / ui / font / prop sprites (see assets/SPRITESHEET.md). Each .txt line is "name x y w h category pivotX pivotY"; only the first five columns are read here.
// Included by src/main.cpp after Img / createTexture / SDL_Renderer are defined.
#include <string>
#include <unordered_map>

struct SprRect { int x = 0, y = 0, w = 0, h = 0; bool ok = false; int px = 0, py = 0; };   // px, py: pivot inside the rectangle (column 7, 8 of the .txt)

static SDL_Texture* gSheet = nullptr;
static Img gSheetImg(1, 1);
static std::unordered_map<std::string, SprRect> gSprMap;

enum { CAR_COLORS = 6, PED_COATS = 6 };
static SprRect gCarSpr[5][CAR_COLORS][2][4];     // type, paint colour, facing (0 east / 1 west), motorbike lean
static SprRect gFallerSpr[4][2];                 // shirt colour, arms frame
static SprRect gPedSpr[PED_COATS][2][2][2];      // coat colour, carries a bag, step frame, facing (0 east / 1 west)
static SprRect gHeliSpr[2], gBirdSpr[2];         // rotor blur frame / wings up-down
enum { PROP_CHIMNEY, PROP_DISH, PROP_WATERTOWER, PROP_ANTENNA_OFF, PROP_ANTENNA_ON, PROP_HELIPAD_OFF, PROP_HELIPAD_ON, PROP_SHED, PROP_BILLBOARD0, PROP_CRATE0 = PROP_BILLBOARD0 + 6, PROP_OBS0_0 = PROP_CRATE0 + 4, PROP_OBS0_1, PROP_OBS1, PROP_OBS2, PROP_OBS6, PROP_N };
static SprRect gPropSpr[PROP_N];                 // rooftop props baked from drawRoof*(); pivot = the point the draw code treats as (x, roof line)
static SprRect gFontSpr[128];                    // white 5x7 glyphs, indexed by ASCII code (tinted when drawn)

static bool sprReadFile(const char* path, std::vector<unsigned char>& out) {
    SDL_RWops* f = SDL_RWFromFile(path, "rb");
    if (!f) return false;
    const Sint64 n = SDL_RWsize(f);
    if (n <= 0 || n > (64 << 20)) { SDL_RWclose(f); return false; }
    out.resize((size_t)n);
    const size_t got = SDL_RWread(f, out.data(), 1, (size_t)n);
    SDL_RWclose(f);
    return got == (size_t)n;
}
// Uncompressed true-colour TGA, 32 bpp, either vertical origin.
static bool sprDecodeTga(const std::vector<unsigned char>& d, Img& im) {
    if (d.size() < 18 || d[1] != 0 || d[2] != 2 || d[16] != 32) return false;
    const int idlen = d[0], w = d[12] | (d[13] << 8), h = d[14] | (d[15] << 8);
    if (w <= 0 || h <= 0 || w > 4096 || h > 4096 || d.size() < (size_t)(18 + idlen + (size_t)w * h * 4)) return false;
    const bool topDown = (d[17] & 0x20) != 0;
    im = Img(w, h);
    const unsigned char* p = d.data() + 18 + idlen;
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++, p += 4)
        im.p[(size_t)(topDown ? y : h - 1 - y) * w + x] = ((u32)p[3] << 24) | ((u32)p[2] << 16) | ((u32)p[1] << 8) | (u32)p[0];
    return true;
}
static bool loadSpriteSheet() {
    static const char* const DIRS[] = {"assets/", "../assets/", "../../assets/"};
    for (const char* dir : DIRS) {
        std::vector<unsigned char> tga, map;
        const std::string base = std::string(dir) + "spritesheet";
        if (!sprReadFile((base + ".tga").c_str(), tga) || !sprReadFile((base + ".txt").c_str(), map)) continue;
        const bool decoded = sprDecodeTga(tga, gSheetImg);
        std::vector<unsigned char>().swap(tga);   // the ~10 MB raw file is no longer needed once decoded: don't hold it through the map parse + texture upload
        if (!decoded) continue;
        gSprMap.clear();
        map.push_back(0);                         // NUL-terminate in place: parse each line straight from the buffer instead of copying it into a string first
        const char* txt = (const char*)map.data();
        const size_t txtLen = map.size() - 1;
        size_t pos = 0;
        while (pos < txtLen) {
            const char* nl = (const char*)memchr(txt + pos, '\n', txtLen - pos);
            size_t e = nl ? (size_t)(nl - txt) : txtLen;
            char line[256]; const size_t ln = std::min(e - pos, sizeof line - 1);
            memcpy(line, txt + pos, ln); line[ln] = 0;   // bounded stack copy keeps sscanf from running into the next line
            char name[64], cat[32]; SprRect r;
            const int got = sscanf(line, "%63s %d %d %d %d %31s %d %d", name, &r.x, &r.y, &r.w, &r.h, cat, &r.px, &r.py);
            if (got < 8) { r.px = 0; r.py = 0; }   // old 5-column sheets have no pivot
            if (got >= 5 &&
                r.x >= 0 && r.y >= 0 && r.w > 0 && r.h > 0 && r.x + r.w <= gSheetImg.w && r.y + r.h <= gSheetImg.h) { r.ok = true; gSprMap[name] = r; }
            pos = e + 1;
        }
        if (gSheet) { SDL_DestroyTexture(gSheet); gSheet = nullptr; }   // a repeat call must not orphan the previous texture
        gSheet = createTexture(gSheetImg);
        return gSheet != nullptr;
    }
    fprintf(stderr, "spritesheet.tga / spritesheet.txt not found (looked in assets/): sprites will be missing. Run tools/gen_spritesheet.sh\n");
    return false;
}
// The CPU copy of the sheet (w*h*4 bytes, ~10 MB) is only needed while the tile / far-building textures are cut out of it in buildArt();
// the GPU texture is all the renderer uses afterwards.
static void sprReleaseSheetImage() { gSheetImg = Img(1, 1); }
static const SprRect* sprFind(const char* name) { auto it = gSprMap.find(name); return it == gSprMap.end() ? nullptr : &it->second; }
static Img sprCut(const SprRect& r) {
    Img im(r.w, r.h);
    for (int y = 0; y < r.h; y++) for (int x = 0; x < r.w; x++) im.p[(size_t)y * r.w + x] = gSheetImg.get(r.x + x, r.y + y);
    return im;
}
static void sprBind(SprRect& dst, const char* fmt, int a = 0, int b = 0, int c = 0, int d = 0) {
    char nm[64]; snprintf(nm, sizeof nm, fmt, a, b, c, d);
    const SprRect* r = sprFind(nm); dst = r ? *r : SprRect();
}
static void bindSprites() {
    for (int t = 0; t < 5; t++) for (int c = 0; c < CAR_COLORS; c++) for (int dir = 0; dir < 2; dir++) for (int l = 0; l < 4; l++) {
        char nm[64]; snprintf(nm, sizeof nm, "car_%d_%d_%c_%d", t, c, dir ? 'w' : 'e', l);
        const SprRect* r = sprFind(nm); gCarSpr[t][c][dir][l] = r ? *r : SprRect();
    }
    for (int s = 0; s < 4; s++) for (int f = 0; f < 2; f++) sprBind(gFallerSpr[s][f], "faller_%d_%d", s, f);
    for (int c = 0; c < PED_COATS; c++) for (int b = 0; b < 2; b++) for (int st = 0; st < 2; st++) for (int dir = 0; dir < 2; dir++) {
        char nm[64]; snprintf(nm, sizeof nm, "ped_%d_%d_%d_%c", c, b, st, dir ? 'w' : 'e');
        const SprRect* r = sprFind(nm); gPedSpr[c][b][st][dir] = r ? *r : SprRect();
    }
    for (int f = 0; f < 2; f++) { sprBind(gHeliSpr[f], "heli_%d", f); sprBind(gBirdSpr[f], "bird_%d", f); }
    static const char* const PROP_NAME[PROP_BILLBOARD0] = {"prop_roof_chimney", "prop_roof_dish", "prop_roof_watertower", "prop_roof_antenna_0", "prop_roof_antenna_1",
                                                         "prop_roof_helipad_0", "prop_roof_helipad_1", "prop_roof_shed"};
    for (int i = 0; i < PROP_BILLBOARD0; i++) { const SprRect* r = sprFind(PROP_NAME[i]); gPropSpr[i] = r ? *r : SprRect(); }
    for (int k = 0; k < 6; k++) sprBind(gPropSpr[PROP_BILLBOARD0 + k], "prop_billboard_%d", k);
    for (int k = 0; k < 4; k++) sprBind(gPropSpr[PROP_CRATE0 + k], "prop_crate_%d", k);
    sprBind(gPropSpr[PROP_OBS0_0], "prop_obs_0_%d", 0); sprBind(gPropSpr[PROP_OBS0_1], "prop_obs_0_%d", 1);   // AC unit, 2 fan frames
    sprBind(gPropSpr[PROP_OBS1], "prop_obs_%d", 1); sprBind(gPropSpr[PROP_OBS2], "prop_obs_%d", 2); sprBind(gPropSpr[PROP_OBS6], "prop_obs_%d", 6);
    for (int ch = 0; ch < 128; ch++) {   // font_<ASCII hex>: a glyph the sheet lacks stays !ok and text() draws that one character from code
        char nm[16]; snprintf(nm, sizeof nm, "font_%02X", ch);
        const SprRect* r = sprFind(nm); gFontSpr[ch] = r ? *r : SprRect();
    }
}
// Draw a sprite at (x, y) in world pixels; alpha and colour-mod (night dimming) are optional.
static void sprDraw(const SprRect& s, int x, int y, int a = 255, int cr = 255, int cg = 255, int cb = 255) {
    if (!s.ok || !gSheet) return;
    SDL_Rect src = {s.x, s.y, s.w, s.h}, dst = {x, y, s.w, s.h};
    SDL_SetTextureAlphaMod(gSheet, (Uint8)a);
    SDL_SetTextureColorMod(gSheet, (Uint8)cr, (Uint8)cg, (Uint8)cb);
    SDL_RenderCopy(uvzRenderer, gSheet, &src, &dst);
}
// Same, scaled by an integer factor (nearest-neighbour: the renderer's scale hint is "0" while the game draws).
static void sprDrawScaled(const SprRect& s, int x, int y, int sc, int a = 255, int cr = 255, int cg = 255, int cb = 255) {
    if (!s.ok || !gSheet) return;
    SDL_Rect src = {s.x, s.y, s.w, s.h}, dst = {x, y, s.w * sc, s.h * sc};
    SDL_SetTextureAlphaMod(gSheet, (Uint8)a);
    SDL_SetTextureColorMod(gSheet, (Uint8)cr, (Uint8)cg, (Uint8)cb);
    SDL_RenderCopy(uvzRenderer, gSheet, &src, &dst);
}
static bool sprDrawGlyph(unsigned char ch, int x, int y, int sc, u32 c, int a) {
    if (ch >= 128 || !gSheet || !gFontSpr[ch].ok) return false;
    sprDrawScaled(gFontSpr[ch], x, y, sc, a, (int)((c >> 16) & 255), (int)((c >> 8) & 255), (int)(c & 255));
    return true;
}
// Draw prop `id` so that its pivot lands on (x, y); false when the sheet has no such sprite (the caller then draws it from code).
static bool sprDrawProp(int id, int x, int y) {
    const SprRect& s = gPropSpr[id];
    if (!s.ok || !gSheet) return false;
    sprDraw(s, x - s.px, y - s.py);
    return true;
}
