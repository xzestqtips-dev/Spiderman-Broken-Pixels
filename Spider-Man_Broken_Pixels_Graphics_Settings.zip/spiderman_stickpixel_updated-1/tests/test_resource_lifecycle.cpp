// Resource-lifetime regression tests: GPU textures are not rebuilt needlessly, big transient buffers are released, and shutdown frees everything.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    uvzRenderer = nullptr;
    // 1) The CPU copy of the sprite sheet is dropped once buildArt() has cut its textures out of it.
    initFont();
    recalculateDisplayLayout();
    buildArt();
    CHECK(gSheet != nullptr);
    CHECK(gSheetImg.p.size() == 1);                          // was ~10 MB resident for the whole session
    CHECK(gTile[0][0] != nullptr && gFar[0] != nullptr);
    CHECK(sprFind("tile_0_0") != nullptr);                   // lookups still work after the image is released

    // 2) Relayout with an unchanged size (Android fires it on every focus / expose) must not destroy and recreate the render targets.
    const int live0 = g_texLive;
    for (int i = 0; i < 25; i++) recalculateDisplayLayout();
    CHECK(g_texLive == live0);
    const int wBefore = uvzWorldWidth;
    g_outW = 2560; g_outH = 1080;                            // a real size change still rebuilds them (and does not leak the old ones)
    recalculateDisplayLayout();
    CHECK(uvzWorldWidth != wBefore);
    CHECK(g_texLive == live0);
    CHECK(uvzRenderTarget != nullptr && uvzZoomTex != nullptr);

    // 3) The credits picture only exists while the credits screen is up.
    CHECK(gCreditsTex == nullptr);
    const int liveBeforeCredits = g_texLive;
    loadCreditsImage();
    CHECK(gCreditsTex != nullptr && gCreditsW > 0 && gCreditsH > 0 && std::max(gCreditsW, gCreditsH) <= 2048);
    CHECK(g_texLive == liveBeforeCredits + 1);
    unloadCreditsImage();
    CHECK(gCreditsTex == nullptr && g_texLive == liveBeforeCredits && !gCreditsTried);

    // 4) Shutdown releases every texture that was created.
    buildSky();
    shutdownResources();
    CHECK(g_texLive == 0);
    CHECK(uvzRenderTarget == nullptr && uvzZoomTex == nullptr && gSheet == nullptr && gSkyLayer[0].body == nullptr && gCloudTex[0] == nullptr);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
