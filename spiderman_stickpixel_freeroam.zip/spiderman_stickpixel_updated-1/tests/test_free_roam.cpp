// Free-roam mode: the endless runner is gone. The joystick controls ground speed in both directions, the city is finite and solid at its
// edges, buildings block walking, nothing is generated while playing, the camera follows in every direction, and web swinging works to the
// left as well as to the right. (Build WITHOUT -DPCITY_LEGACY_RUNNER; the other tests build with it.)
#define main game_main
#include "../src/main.cpp"
#undef main

static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
#define INFO(...) do { printf(__VA_ARGS__); printf("\n"); } while (0)

// The joystick is a drag from where the finger went down: steer = (x - sx) / 50.
static void joy(float v) {
    if (fabsf(v) < 1e-4f) { tch[1] = Touch(); return; }
    tch[1].on = true; tch[1].role = R_STEER; tch[1].sx = 100.0f; tch[1].x = 100.0f + 50.0f * v;
}
static void webHold(bool on) { tch[0].on = on; tch[0].role = on ? R_SWING : R_NONE; }
static void frames(int n) { for (int i = 0; i < n; i++) updateGame(1.0 / 60); }
static void putOnRoof(const Building& b, float x) { P.x = P.px = x; P.y = P.py = b.roofY - START_ROOF_LIFT - 26.0f; P.vx = P.vy = 0; P.onGround = true; P.groundedPrev = true; P.alive = true; }
static void fresh() {
    startRun(); gState = PLAYING; gMenuIdle = false;
    for (auto& t : tch) t = Touch();
    swingWas = false; jumpEdge = false; slideEdge = false;
    trafficCars.clear(); nextTrafficSpawnX = 1e9f;   // quiet street unless a test wants traffic
}

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_fr/", 1); system("rm -rf /tmp/pcity_fr && mkdir -p /tmp/pcity_fr");
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt();
    CHECK(gFreeRoam);

    // ---- 1. Nothing moves the player by itself ----
    fresh();
    const float x0 = P.x;
    frames(60 * 3);
    CHECK(P.alive && P.onGround && fabsf(P.x - x0) < 0.5f && fabsf(P.vx) < 0.5f);
    CHECK(gState == PLAYING);

    // ---- 2. Walk and run, right and left ----
    fresh(); putOnRoof(bld.front(), 0.0f);
    joy(0.35f); frames(90);                                   // a light push walks
    const float walkV = P.vx;
    CHECK(walkV > 20.0f && walkV < FR_WALK_SPEED * 1.05f);
    CHECK(P.face == 1);
    joy(1.0f); frames(60);                                    // a full push runs
    CHECK(P.vx > FR_WALK_SPEED * 1.4f && P.vx < FR_RUN_SPEED * runMult() * 1.05f);
    INFO("walk %.0f px/s, run %.0f px/s", walkV, P.vx);
    fresh(); putOnRoof(bld.front(), 600.0f);
    const float xl = P.x;
    joy(-1.0f); frames(90);
    CHECK(P.vx < -FR_WALK_SPEED * 1.4f && P.x < xl - 200.0f && P.face == -1 && P.alive);

    // ---- 3. Stop on a dime, turn round at will ----
    fresh(); putOnRoof(bld.front(), 0.0f);
    joy(1.0f); frames(50);
    CHECK(P.vx > 250.0f);
    joy(0.0f); frames(30);                                    // let go: 0.5 s later he is standing
    CHECK(fabsf(P.vx) < 10.0f);
    const float xs = P.x; frames(60);
    CHECK(fabsf(P.x - xs) < 1.0f);                            // and stays put
    joy(-1.0f); frames(40);
    CHECK(P.vx < -200.0f && P.face == -1);                    // moving backwards, not forced forward
    joy(1.0f); frames(40);
    CHECK(P.vx > 200.0f && P.face == 1);

    // ---- 4. The edges of the city are solid ----
    fresh(); putOnRoof(bld.front(), -250.0f);
    joy(-1.0f); frames(120);
    CHECK(P.alive && P.x >= gWorldL + 9.99f && P.x <= gWorldL + 11.0f && fabsf(P.vx) < 1.0f);
    fresh(); putOnRoof(bld.back(), gWorldR - 120.0f);
    joy(1.0f); frames(120);
    CHECK(P.alive && P.x <= gWorldR - 9.99f && P.x >= gWorldR - 11.0f && fabsf(P.vx) < 1.0f && P.onGround);
    INFO("world x range %.0f .. %.0f (%zu buildings)", gWorldL, gWorldR, bld.size());
    CHECK(gWorldR - gWorldL > FR_WORLD_LEN - 1.0f);

    // ---- 5. Walking off a roof is not game over; you land and can carry on ----
    fresh(); putOnRoof(bld.front(), 700.0f);
    joy(1.0f); frames(60 * 8);
    CHECK(P.alive && !P.deadGround && gState == PLAYING);
    joy(0.0f); { bool st = false; for (int i = 0; i < 300 && !st; i++) { frames(1); st = P.onGround; } CHECK(st); }   // (city traffic may shove him around; he is on his feet again soon)
    CHECK(true);                                        // on the street or a lower roof, standing
    joy(-1.0f); frames(60); CHECK(P.alive && P.vx < 0.0f);

    // ---- 6. Jumping and landing, facing either way ----
    for (int dir = -1; dir <= 1; dir += 2) {
        fresh(); putOnRoof(bld.front(), 200.0f);
        joy((float)dir); frames(20);
        jumpEdge = true; frames(2);
        CHECK(P.vy < -100.0f && !P.onGround);
        const float yTop = P.y; float apex = P.y; bool landed = false;
        for (int i = 0; i < 240 && !landed; i++) { frames(1); apex = std::min(apex, P.y); landed = P.onGround; }
        CHECK(landed && P.alive && apex < yTop - 20.0f);
        CHECK((P.x - 200.0f) * dir > 30.0f);
    }

    // ---- 7. Buildings are walls to a walker: no walking through a taller neighbour, either way ----
    {
        int ri = -1, li = -1;
        for (size_t i = 1; i + 1 < bld.size(); i++) {
            if (ri < 0 && bld[i + 1].x - (bld[i].x + bld[i].w) < 1.0f && bld[i + 1].roofY < bld[i].roofY - 90.0f && bld[i].w > 200.0f) ri = (int)i;
            if (li < 0 && bld[i].x - (bld[i - 1].x + bld[i - 1].w) < 1.0f && bld[i - 1].roofY < bld[i].roofY - 90.0f && bld[i].w > 200.0f) li = (int)i;
        }
        CHECK(ri >= 0 && li >= 0);
        if (ri >= 0) {
            fresh(); const Building b = bld[ri], nb = bld[ri + 1]; putOnRoof(b, b.x + b.w - 70.0f);
            joy(1.0f); frames(120);
            CHECK(P.alive && P.x <= nb.x - 7.9f && P.x >= b.x + b.w - 70.0f && P.onGround);
            { const float xa = P.x; frames(30); CHECK(fabsf(P.x - xa) < 0.5f); }   // pressed against the wall: no creeping through
        }
        if (li >= 0) {
            fresh(); const Building b = bld[li], nb = bld[li - 1]; putOnRoof(b, b.x + 70.0f);
            joy(-1.0f); frames(120);
            CHECK(P.alive && P.x >= nb.x + nb.w + 7.9f && P.onGround);
            { const float xa = P.x; frames(30); CHECK(fabsf(P.x - xa) < 0.5f); }
        }
    }

    // ---- 8. Nothing is generated or unloaded while playing ----
    fresh();
    const size_t nb0 = bld.size(), nc0 = gCrates.size(); const float wl0 = gWorldL, wr0 = gWorldR; const float firstX = bld.front().x, lastX = bld.back().x;
    for (float tx : {gWorldR - 400.0f, 5000.0f, gWorldL + 400.0f, 9000.0f}) {
        putOnRoof(bld[0], 0); P.x = P.px = tx; P.y = P.py = -9000.0f; P.onGround = false;   // far away, up in the air
        frames(120);
        P.alive = true; P.deadT = 0; gState = PLAYING;
    }
    CHECK(bld.size() == nb0 && gCrates.size() == nc0 && gWorldL == wl0 && gWorldR == wr0 && bld.front().x == firstX && bld.back().x == lastX);
    CHECK((int)trafficCars.size() <= FR_TRAFFIC_CARS);
    nextTrafficSpawnX = 0;
    fresh(); trafficCars.clear(); putOnRoof(bld.front(), 200.0f); frames(240);
    CHECK((int)trafficCars.size() > 0 && (int)trafficCars.size() <= FR_TRAFFIC_CARS);   // finite-city traffic keeps running around the player

    // ---- 9. Camera: follows in both directions, stays inside the city, player always on screen ----
    fresh(); putOnRoof(bld.front(), 200.0f); camX = P.x - uvzWorldWidth * 0.5f; camY = P.y - uvzWorldHeight * 0.58f;
    {
        float minF = 9, maxF = -9; const float c0 = camX;
        joy(1.0f); for (int i = 0; i < 40; i++) { frames(1); const float f = (P.x - camX) / uvzWorldWidth; minF = std::min(minF, f); maxF = std::max(maxF, f); }
        CHECK(camX > c0 + 20.0f);                                           // moved right with him
        const float c1 = camX;
        joy(-1.0f); for (int i = 0; i < 120; i++) { frames(1); const float f = (P.x - camX) / uvzWorldWidth; minF = std::min(minF, f); maxF = std::max(maxF, f); }
        CHECK(camX < c1 - 20.0f);                                           // and back left
        CHECK(minF > 0.05f && maxF < 0.95f);
        INFO("player on screen at %.2f .. %.2f of the width", minF, maxF);
        for (int i = 0; i < 240; i++) frames(1);                           // keep pushing into the left edge
        CHECK(fabsf(camX - gWorldL) < 0.6f && P.x < camX + uvzWorldWidth * 0.5f);
        CHECK(camX >= gWorldL - 0.01f);
        joy(0.0f); frames(120);
        const float cs = camX; frames(60); CHECK(fabsf(camX - cs) < 0.5f);  // standing still: the camera settles, no drifting
    }
    fresh(); putOnRoof(bld.back(), gWorldR - 300.0f);
    camX = P.x - uvzWorldWidth * 0.5f; joy(1.0f); frames(300);
    CHECK(camX <= gWorldR - uvzWorldWidth + 0.01f && P.x - camX < uvzWorldWidth);

    // ---- 10. Web swinging works to the right AND to the left ----
    for (int dir = 1; dir >= -1; dir -= 2) {
        int found = -1;
        for (size_t i = 3; i + 3 < bld.size(); i++) if (bld[i].roofY < -1000.0f && bld[i].w > 300.0f) { found = (int)i; break; }
        CHECK(found >= 0);
        if (found < 0) continue;
        fresh();
        // swing anchors must be above the player: make both neighbours clearly taller than the home roof so each side has a roof to catch
        bld[found - 1].roofY = bld[found].roofY - 700.0f; bld[found + 1].roofY = bld[found].roofY - 700.0f;
        for (auto& o : bld[found].obs) o.h = 0;   // no props on the home roof to grab instead
        const Building home = bld[found];
        putOnRoof(home, home.x + home.w * 0.5f);
        P.face = dir; joy((float)dir * 0.3f); frames(10); joy(0.0f);
        const float xs0 = P.x;
        jumpEdge = true; frames(18);                                      // up into the air
        CHECK(!P.onGround);
        webHold(true);
        bool swung = false; float minV = 1e9f, maxV = -1e9f; int dirSeen = 0;
        for (int i = 0; i < 60 * 3 && P.alive; i++) {
            frames(1);
            if (P.swinging) { swung = true; dirSeen = gDir; }
            minV = std::min(minV, P.vx); maxV = std::max(maxV, P.vx);
            if (swung && P.swingT > 0.9f) webHold(false);
        }
        webHold(false);
        CHECK(swung);
        CHECK(dirSeen == dir);
        CHECK(P.alive);
        CHECK((dir > 0 ? maxV : -minV) > 150.0f);                          // really travelled in that direction
        CHECK((P.x - xs0) * dir > 100.0f);
        INFO("swing dir %+d: anchor side ok, x moved %+.0f, vx range %.0f..%.0f", dir, P.x - xs0, minV, maxV);
    }

    // ---- 11. Mirror symmetry of the swing physics (same arc, mirrored) ----
    {
        // A pendulum released from the same relative start must be a mirror image when gDir flips.
        float res[2][4];
        for (int k = 0; k < 2; k++) {
            const int d = k == 0 ? 1 : -1; DirGuard g(d);
            float x = d * -200.0f, y = 80.0f, vx = d * 300.0f, vy = 0.0f;   // hanging below the anchor at (0, 0), moving the travel way
            float rope = hypotf(x, y), re = rope;
            for (int i = 0; i < 90; i++) {
                vy += GRAV * 1.0f / 120.0f; x += vx / 120.0f; y += vy / 120.0f;
                reelStep(x, y, 0, 0, vx, vy, rope, re, 1.0f / 120.0f);
                swingStep(x, y, vx, vy, 0, 0, re, 1.0f, 0.0f, 1.0f / 120.0f);
            }
            res[k][0] = x * d; res[k][1] = y; res[k][2] = vx * d; res[k][3] = vy;
        }
        CHECK(fabsf(res[0][0] - res[1][0]) < 0.01f && fabsf(res[0][1] - res[1][1]) < 0.01f && fabsf(res[0][2] - res[1][2]) < 0.01f && fabsf(res[0][3] - res[1][3]) < 0.01f);
        { DirGuard g(-1); const ReleaseFx a = releaseEval(-500.0f, -420.0f); DirGuard g2(1); const ReleaseFx b = releaseEval(500.0f, -420.0f); CHECK(a.perfect == b.perfect && fabsf(a.base - b.base) < 1e-6f && fabsf(a.extra - b.extra) < 1e-6f); }
    }

    // ---- 12. A car shoves you, it does not end the game ----
    fresh(); P.x = P.px = 400.0f; P.y = P.py = STREET_GROUND_Y - 26.0f; P.vx = P.vy = 0; P.onGround = true; P.groundedPrev = true;
    {
        TrafficCar car; car.type = 1; car.width = trafficWidth(1); car.height = trafficHeight(1); car.x = P.x + car.width * 0.5f + 4.0f; car.speed = 0; car.maxSpeed = 0; car.dir = -1; car.lane = 1; car.color = 0xB7473F; car.id = 777;
        trafficCars.push_back(car);
        nextTrafficSpawnX = 1e9f;
        joy(1.0f); frames(40);
        CHECK(P.alive && gState == PLAYING);
    }

    // ---- 13. Fall damage no longer ends the game by itself, but still hurts ----
    fresh();
    CHECK(classifyFall(1500.0f, false, 1.0f) == fall::HARD && classifyFall(100.0f, false, 1.0f) == fall::NONE);

    // ---- 14. The runner can still be switched back on (legacy build flag / runtime) ----
    gFreeRoam = false; startRun();
    CHECK(P.vx == 230.0f && gWorldR > 1e8f);
    gFreeRoam = true;

    printf("[free_roam] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
