#define main game_main
#include "../src/main.cpp"
#undef main
#define SWING_HOLD(v) do { tch[0].on = (v) != 0; tch[0].role = (v) ? R_SWING : R_NONE; } while (0)
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_cam/", 1);
    if (system("rm -rf /tmp/pcity_cam && mkdir -p /tmp/pcity_cam") != 0) return 2;
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun();
    bld.clear();
    Building b; b.x = -3000; b.w = 12000; b.roofY = 2000; b.style = 0; b.seed = 1; bld.push_back(b);
    gState = PLAYING;
    P = Player(); P.alive = true; P.onGround = false; P.x = 0; P.y = 0; P.px = 0; P.py = 0; P.ax = 100; P.ay = -300;
    camX = -uvzWorldWidth * 0.3f; camY = -uvzWorldHeight * 0.58f;
    float worst = 0, prev = camY;
    for (int i = 0; i < 240; i++) {
        const bool on = (i >= 60 && i < 150); SWING_HOLD(on); P.swinging = on; P.rope = 316.0f; swingWas = true;
        P.vx = 300; P.vy = 0; P.x = 0; P.y = 0; P.px = 0; P.py = 0; P.ax = 100; P.ay = -300;
        updateGame(1.0 / 60);
        worst = std::max(worst, fabsf(camY - prev)); prev = camY;
    }
    printf("camera: biggest vertical move per frame around attach/release %.2f px\n", worst);
    CHECK(worst < 3.0f);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
