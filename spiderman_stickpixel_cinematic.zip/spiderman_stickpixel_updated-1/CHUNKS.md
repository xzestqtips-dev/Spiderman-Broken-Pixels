# Chunked world

The world is cut into 1024 px wide chunks (`src/chunks.h`). Buildings, traffic signals and street crates are registered in every chunk they touch.

| Step | Where | What happens |
|------|-------|--------------|
| Load | `addBuilding`, `ensureCrates` | New objects open or join chunks. `ensureWorld` generates until 1400 px right of the screen. |
| Query | `bldNear / sigNear / crateNear` | Return only objects in the chunks under a range, left to right. Callers still do their own precise overlap test. |
| Unload | `ensureWorld`, `ensureCrates` | Objects behind the aligned unload edge (camera - 800 px) are erased from their chunks and popped; empty chunks are freed. |

Used by: scene / storefront / cable / signal / crate drawing, shadow and AO passes, `collide`, web raycasts, landing prediction, near-miss detection.

The grids are caches over the deques. Each query checks a cheap signature and rebuilds if a deque was edited directly (tests, restarts), so they cannot go stale.

Tests: `tests/test_chunks.cpp` (grid unit tests, brute-force equivalence over a 90 s run, bounded memory, direct-edit robustness).
