# Facade tile optimisation

The only tile grid in the game is the building facade: a grid of 96x96 textures, one `SDL_RenderCopy` per tile. Two things were wasted (`src/facade_tiles.h`, `drawFacade` in `src/main.cpp`):

| Change | What it does |
|--------|--------------|
| Hidden-tile culling | Tiles that start at or below the ground-floor plinth (or, on low buildings, the sidewalk) are fully overpainted later in the frame, so they are no longer drawn. Their lit-window and night-overlay work is skipped too. |
| Run merging | Horizontally adjacent tiles that use the same variant leave as ONE copy from a strip texture (the tile repeated `facade::STRIP_TILES` = 4 times). |

Cost: 18 strip textures of 384x96 = about 2.6 MB of VRAM. Set `STRIP_TILES` to 1 to turn merging off (no strips are allocated).

Verification
- `tests/test_facade_tiles.cpp` decodes every draw call of 1,674 facade renders (day, dusk, night, edges of the screen) and checks: exactly the visible, uncovered tiles are drawn, once each, with the right variant.
- `tests/compare_facade.sh` renders 336 full frames with and without the optimisation and compares checksums: IDENTICAL.
