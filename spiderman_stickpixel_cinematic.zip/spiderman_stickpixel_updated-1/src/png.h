// png.h - tiny self-contained PNG decoder (no SDL_image / zlib needed, so it builds the same on desktop and Android).
// Supports every colour type and bit depth, tRNS transparency, and Adam7 interlacing. Output is ARGB8888 in an Img.
#pragma once
#include <vector>
#include <cstdint>
#include <cstring>

namespace pngdec {
struct Bits {
    const uint8_t* d; size_t n, pos = 0; uint32_t buf = 0; int cnt = 0; bool bad = false;
    Bits(const uint8_t* p, size_t len) : d(p), n(len) {}
    int get(int need) {
        while (cnt < need) { if (pos >= n) { bad = true; return 0; } buf |= (uint32_t)d[pos++] << cnt; cnt += 8; }
        const int v = (int)(buf & ((1u << need) - 1u)); buf >>= need; cnt -= need; return v;
    }
};
struct Huff {
    uint16_t count[16], symbol[288];
    void build(const uint8_t* len, int n) {
        memset(count, 0, sizeof count);
        for (int i = 0; i < n; i++) count[len[i]]++;
        count[0] = 0;
        uint16_t offs[16]; offs[1] = 0;
        for (int i = 1; i < 15; i++) offs[i + 1] = (uint16_t)(offs[i] + count[i]);
        for (int i = 0; i < n; i++) if (len[i]) symbol[offs[len[i]]++] = (uint16_t)i;
    }
    int decode(Bits& b) const {
        int code = 0, first = 0, index = 0;
        for (int l = 1; l < 16; l++) {
            code |= b.get(1); if (b.bad) return -1;
            const int c = count[l];
            if (code - c < first) return symbol[index + (code - first)];
            index += c; first += c; first <<= 1; code <<= 1;
        }
        return -1;
    }
};
static const uint16_t LBASE[29] = {3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
static const uint8_t  LEXT[29]  = {0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
static const uint16_t DBASE[30] = {1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
static const uint8_t  DEXT[30]  = {0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};

// zlib stream (2-byte header, deflate blocks, adler ignored)
static bool inflateZ(const uint8_t* src, size_t n, std::vector<uint8_t>& out, size_t cap) {
    if (n < 2) return false;
    Bits b(src + 2, n - 2);
    for (;;) {
        const int last = b.get(1), type = b.get(2);
        if (b.bad) return false;
        if (type == 0) {
            b.buf = 0; b.cnt = 0;
            if (b.pos + 4 > b.n) return false;
            const unsigned len = b.d[b.pos] | (b.d[b.pos + 1] << 8); b.pos += 4;
            if (b.pos + len > b.n || out.size() + len > cap) return false;
            out.insert(out.end(), b.d + b.pos, b.d + b.pos + len); b.pos += len;
        } else if (type == 1 || type == 2) {
            Huff lit, dst;
            if (type == 1) {
                uint8_t l[288]; int i = 0;
                for (; i < 144; i++) l[i] = 8;
                for (; i < 256; i++) l[i] = 9;
                for (; i < 280; i++) l[i] = 7;
                for (; i < 288; i++) l[i] = 8;
                lit.build(l, 288);
                uint8_t dl[30]; for (i = 0; i < 30; i++) dl[i] = 5;
                dst.build(dl, 30);
            } else {
                const int nlen = b.get(5) + 257, ndist = b.get(5) + 1, ncode = b.get(4) + 4;
                static const uint8_t ORDER[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
                uint8_t cl[19] = {0};
                for (int i = 0; i < ncode; i++) cl[ORDER[i]] = (uint8_t)b.get(3);
                if (b.bad || nlen > 286 || ndist > 30) return false;
                Huff ch; ch.build(cl, 19);
                uint8_t lens[320] = {0}; int idx = 0;
                while (idx < nlen + ndist) {
                    const int sym = ch.decode(b); if (sym < 0) return false;
                    if (sym < 16) lens[idx++] = (uint8_t)sym;
                    else {
                        int rep, val = 0;
                        if (sym == 16) { if (idx == 0) return false; val = lens[idx - 1]; rep = 3 + b.get(2); }
                        else if (sym == 17) rep = 3 + b.get(3);
                        else rep = 11 + b.get(7);
                        if (idx + rep > nlen + ndist) return false;
                        while (rep--) lens[idx++] = (uint8_t)val;
                    }
                }
                lit.build(lens, nlen); dst.build(lens + nlen, ndist);
            }
            for (;;) {
                const int s = lit.decode(b); if (s < 0 || b.bad) return false;
                if (s < 256) { if (out.size() >= cap) return false; out.push_back((uint8_t)s); }
                else if (s == 256) break;
                else {
                    const int li = s - 257; if (li >= 29) return false;
                    const int len = LBASE[li] + b.get(LEXT[li]);
                    const int ds = dst.decode(b); if (ds < 0 || ds >= 30) return false;
                    const size_t dist = (size_t)DBASE[ds] + b.get(DEXT[ds]);
                    if (b.bad || dist > out.size() || out.size() + len > cap) return false;
                    for (int i = 0; i < len; i++) out.push_back(out[out.size() - dist]);
                }
            }
        } else return false;
        if (last) return true;
    }
}
static inline int paeth(int a, int b, int c) {
    const int p = a + b - c, pa = p > a ? p - a : a - p, pb = p > b ? p - b : b - p, pc = p > c ? p - c : c - p;
    return (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c);
}
}  // namespace pngdec

// Decodes a PNG file image into im (ARGB). Returns false for anything malformed or too large (> 16384 px per side).
template <class ImgT>
static bool sprDecodePng(const std::vector<unsigned char>& f, ImgT& im) {
    using namespace pngdec;
    static const uint8_t SIG[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    if (f.size() < 33 || memcmp(f.data(), SIG, 8) != 0) return false;
    uint32_t W = 0, H = 0; int depth = 0, ctype = 0, interlace = 0;
    std::vector<uint8_t> idat, plte, trns; bool haveHdr = false;
    size_t p = 8;
    while (p + 12 <= f.size()) {
        const uint32_t len = ((uint32_t)f[p] << 24) | (f[p + 1] << 16) | (f[p + 2] << 8) | f[p + 3];
        const char* t = (const char*)&f[p + 4]; const uint8_t* dat = &f[p + 8];
        if ((size_t)len > f.size() - p - 12) return false;
        if (!memcmp(t, "IHDR", 4) && len >= 13) {
            W = ((uint32_t)dat[0] << 24) | (dat[1] << 16) | (dat[2] << 8) | dat[3]; H = ((uint32_t)dat[4] << 24) | (dat[5] << 16) | (dat[6] << 8) | dat[7];
            depth = dat[8]; ctype = dat[9]; interlace = dat[12]; haveHdr = true;
        } else if (!memcmp(t, "PLTE", 4)) plte.assign(dat, dat + len);
        else if (!memcmp(t, "tRNS", 4)) trns.assign(dat, dat + len);
        else if (!memcmp(t, "IDAT", 4)) idat.insert(idat.end(), dat, dat + len);
        else if (!memcmp(t, "IEND", 4)) break;
        p += 12 + len;
    }
    if (!haveHdr || W == 0 || H == 0 || W > 16384 || H > 16384 || idat.empty()) return false;
    int ch;
    switch (ctype) { case 0: ch = 1; break; case 2: ch = 3; break; case 3: ch = 1; break; case 4: ch = 2; break; case 6: ch = 4; break; default: return false; }
    if (depth != 1 && depth != 2 && depth != 4 && depth != 8 && depth != 16) return false;
    if (ctype == 3 && (depth == 16 || plte.empty())) return false;
    if ((ctype == 2 || ctype == 4 || ctype == 6) && depth < 8) return false;
    const int bpp = std::max(1, ch * depth / 8);   // bytes per pixel for filtering
    const size_t cap = (size_t)H * (((size_t)W * ch * depth + 7) / 8 + 1) + (size_t)H * 8 + 1024;
    if (cap > ((size_t)512 << 20)) return false;
    std::vector<uint8_t> raw; raw.reserve(cap);
    if (!inflateZ(idat.data(), idat.size(), raw, cap)) return false;
    std::vector<uint8_t>().swap(idat);   // the compressed copy is no longer needed: don't hold it alongside raw + the decoded image

    im = ImgT((int)W, (int)H);
    auto sample = [&](const uint8_t* row, uint32_t x, int c) -> int {   // returns the sample scaled to 0..255 (palette index for ctype 3)
        if (depth == 8) return row[x * ch + c];
        if (depth == 16) return row[(x * ch + c) * 2];
        const uint32_t bit = (x * ch + c) * depth; const int v = (row[bit >> 3] >> (8 - depth - (bit & 7))) & ((1 << depth) - 1);
        return ctype == 3 ? v : v * 255 / ((1 << depth) - 1);
    };
    auto rawSample = [&](const uint8_t* row, uint32_t x, int c) -> int {   // un-scaled value for tRNS colour-key compare
        if (depth == 16) return (row[(x * ch + c) * 2] << 8) | row[(x * ch + c) * 2 + 1];
        if (depth == 8) return row[x * ch + c];
        const uint32_t bit = (x * ch + c) * depth; return (row[bit >> 3] >> (8 - depth - (bit & 7))) & ((1 << depth) - 1);
    };
    size_t pos = 0;
    auto doPass = [&](uint32_t pw, uint32_t ph, uint32_t x0, uint32_t y0, uint32_t dx, uint32_t dy) -> bool {
        if (pw == 0 || ph == 0) return true;
        const size_t stride = ((size_t)pw * ch * depth + 7) / 8;
        std::vector<uint8_t> prev(stride, 0), cur(stride);
        for (uint32_t y = 0; y < ph; y++) {
            if (pos + 1 + stride > raw.size()) return false;
            const int ft = raw[pos++]; memcpy(cur.data(), &raw[pos], stride); pos += stride;
            for (size_t i = 0; i < stride; i++) {
                const int a = i >= (size_t)bpp ? cur[i - bpp] : 0, b = prev[i], c = i >= (size_t)bpp ? prev[i - bpp] : 0;
                int add = 0;
                switch (ft) { case 0: break; case 1: add = a; break; case 2: add = b; break; case 3: add = (a + b) / 2; break; case 4: add = paeth(a, b, c); break; default: return false; }
                cur[i] = (uint8_t)(cur[i] + add);
            }
            for (uint32_t x = 0; x < pw; x++) {
                int r, g, b, a = 255;
                if (ctype == 0) { r = g = b = sample(cur.data(), x, 0); if (trns.size() >= 2 && rawSample(cur.data(), x, 0) == ((trns[0] << 8) | trns[1])) a = 0; }
                else if (ctype == 2) { r = sample(cur.data(), x, 0); g = sample(cur.data(), x, 1); b = sample(cur.data(), x, 2);
                    if (trns.size() >= 6 && rawSample(cur.data(), x, 0) == ((trns[0] << 8) | trns[1]) && rawSample(cur.data(), x, 1) == ((trns[2] << 8) | trns[3]) && rawSample(cur.data(), x, 2) == ((trns[4] << 8) | trns[5])) a = 0; }
                else if (ctype == 3) { const size_t i = (size_t)sample(cur.data(), x, 0); if (i * 3 + 2 >= plte.size()) { r = g = b = 0; } else { r = plte[i * 3]; g = plte[i * 3 + 1]; b = plte[i * 3 + 2]; } if (i < trns.size()) a = trns[i]; }
                else if (ctype == 4) { r = g = b = sample(cur.data(), x, 0); a = sample(cur.data(), x, 1); }
                else { r = sample(cur.data(), x, 0); g = sample(cur.data(), x, 1); b = sample(cur.data(), x, 2); a = sample(cur.data(), x, 3); }
                im.p[(size_t)(y0 + y * dy) * W + (x0 + x * dx)] = ((uint32_t)a << 24) | ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
            }
            prev.swap(cur);
        }
        return true;
    };
    if (!interlace) return doPass(W, H, 0, 0, 1, 1);
    static const uint32_t X0[7] = {0,4,0,2,0,1,0}, Y0[7] = {0,0,4,0,2,0,1}, DX[7] = {8,8,4,4,2,2,1}, DY[7] = {8,8,8,4,4,2,2};
    for (int k = 0; k < 7; k++) {
        const uint32_t pw = W > X0[k] ? (W - X0[k] + DX[k] - 1) / DX[k] : 0, ph = H > Y0[k] ? (H - Y0[k] + DY[k] - 1) / DY[k] : 0;
        if (!doPass(pw, ph, X0[k], Y0[k], DX[k], DY[k])) return false;
    }
    return true;
}
