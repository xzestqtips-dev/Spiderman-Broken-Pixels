// chunks.h - 1D chunk grid for the side-scrolling world.
//
// The world is cut into vertical slabs ("chunks") CHUNK_W px wide. Every world object (building, crate,
// traffic signal) is registered in each chunk its horizontal extent touches. Rendering, collision and
// web-targeting then ask for "everything near [x0, x1]" and only visit the chunks under that range instead of
// scanning the whole object list.
//
// Lifecycle
//   load   : chunks are created on demand when objects are inserted (the generator running ahead of the camera)
//   unload : the owner erase()s an object when it falls behind the player, then unloadBefore() releases the
//            leading chunks that became empty. A chunk that still holds a live object is never released, so the
//            grid can never hand out a dangling pointer.
//
// The grid does not own the objects. Pointers must stay valid while registered (std::deque keeps element
// addresses stable across push_back / pop_front, which is exactly how the world lists are used).
//
// Header-only, no SDL, no dependency on the game types, so it can be unit-tested on its own.
#pragma once
#include <cmath>
#include <cstddef>
#include <deque>
#include <vector>

namespace chunks {

static const float CHUNK_W = 1024.0f;   // slab width in world px (~34 m); the view is 960 px wide
static const int   MAX_SPAN = 64;       // an object wider than this many chunks lives in the always-visited "wide" list

inline int chunkOf(float x) { return (int)std::floor(x / CHUNK_W); }

struct Stats {
    int loaded = 0;    // chunks currently alive
    int visited = 0;   // chunks touched by the last query
    int items = 0;     // object visits of the last query
};

// Result of a range query. Lives on the stack (first N hits inline, spills to the heap only for huge ranges) and
// iterates as T&, so call sites keep their  for (auto& b : ...)  shape. Safe to nest.
template <class T, int N = 40>
class Hits {
public:
    void push(T* p) { if (n_ < N) s_[n_] = p; else big_.push_back(p); ++n_; }
    int size() const { return n_; }
    T& operator[](int i) const { return i < N ? *s_[i] : *big_[(size_t)(i - N)]; }
    struct It {
        const Hits* h; int i;
        T& operator*() const { return (*h)[i]; }
        It& operator++() { ++i; return *this; }
        bool operator!=(const It& o) const { return i != o.i; }
    };
    It begin() const { return {this, 0}; }
    It end() const { return {this, n_}; }
private:
    T* s_[N];
    std::vector<T*> big_;
    int n_ = 0;
};

template <class T>
class Grid {
public:
    struct Entry { T* item; int first; float lo, hi; };   // first = lowest chunk the item is registered in (dedupe + ordering key); lo/hi = exact extent in world px
    struct Chunk { std::vector<Entry> e; };

    void clear() { cells_.clear(); wide_.clear(); base_ = 0; count_ = 0; }
    bool empty() const { return cells_.empty() && wide_.empty(); }
    int loaded() const { return (int)cells_.size(); }
    int lowChunk() const { return base_; }
    int highChunk() const { return base_ + (int)cells_.size() - 1; }
    size_t registered() const { return count_; }

    // Register an item that occupies [x0, x1] (world px). Inside a chunk items keep insertion order.
    void insert(T* item, float x0, float x1) {
        if (x1 < x0) { const float t = x0; x0 = x1; x1 = t; }
        const int a = chunkOf(x0), b = chunkOf(x1);
        ++count_;
        if (b - a + 1 > MAX_SPAN) { wide_.push_back({item, a, x0, x1}); return; }
        grow(a, b);
        for (int c = a; c <= b; ++c) cells_[(size_t)(c - base_)].e.push_back({item, a, x0, x1});
    }

    // Remove an item that was inserted with the same extent. Returns true when it was found.
    bool erase(const T* item, float x0, float x1) {
        if (x1 < x0) { const float t = x0; x0 = x1; x1 = t; }
        const int a = chunkOf(x0), b = chunkOf(x1);
        bool found = false;
        if (b - a + 1 > MAX_SPAN) {
            for (size_t i = 0; i < wide_.size(); ++i) if (wide_[i].item == item) { wide_.erase(wide_.begin() + (long)i); found = true; break; }
        } else {
            for (int c = a; c <= b; ++c) {
                if (cells_.empty() || c < base_ || c > highChunk()) continue;
                auto& v = cells_[(size_t)(c - base_)].e;
                for (size_t i = 0; i < v.size(); ++i) if (v[i].item == item) { v.erase(v.begin() + (long)i); found = true; break; }
            }
        }
        if (found && count_) --count_;
        return found;
    }

    // Release the leading chunks that lie left of x AND hold nothing. Returns how many were released.
    int unloadBefore(float x) {
        const int keep = chunkOf(x);
        int n = 0;
        while (!cells_.empty() && base_ < keep && cells_.front().e.empty()) { cells_.pop_front(); ++base_; ++n; }
        return n;
    }

    // Visit each item whose registered chunks intersect [x0, x1] exactly once. Items come out ordered by the
    // chunk they start in, then by insertion order, which for a left-to-right generator is left-to-right.
    // Only a coarse filter: callers still do their own precise overlap test.
    // Exact = true additionally drops items whose own extent does not touch [x0, x1] (inclusive). The survivors are exactly the items a caller's
    // own overlap test would keep, in the same order, so a collision loop can switch to it without changing a single result.
    template <bool Exact = false, class F>
    void query(float x0, float x1, F&& f, Stats* st = nullptr) const {
        if (x1 < x0) { const float t = x0; x0 = x1; x1 = t; }
        int visited = 0, items = 0;
        for (const Entry& w : wide_) { if (Exact && (w.hi < x0 || w.lo > x1)) continue; f(*w.item); ++items; }
        if (!cells_.empty()) {
            int a = chunkOf(x0), b = chunkOf(x1);
            if (a < base_) a = base_;
            if (b > highChunk()) b = highChunk();
            for (int c = a; c <= b; ++c) {
                ++visited;
                for (const Entry& en : cells_[(size_t)(c - base_)].e) {
                    // An item spanning several chunks is reported once: by its first chunk, or by the first chunk
                    // of the query when the item starts further left.
                    if (en.first != c && c != a) continue;
                    if (Exact && (en.hi < x0 || en.lo > x1)) continue;
                    f(*en.item); ++items;
                }
            }
        }
        if (st) { st->visited = visited; st->items = items; st->loaded = (int)cells_.size(); }
    }

    template <int N = 40>
    Hits<T, N> hits(float x0, float x1, Stats* st = nullptr) const {
        Hits<T, N> h;
        query(x0, x1, [&](T& t) { h.push(&t); }, st);
        return h;
    }
    // Same, but only items whose extent touches [x0, x1] (see query<true>).
    template <int N = 40>
    Hits<T, N> hitsExact(float x0, float x1, Stats* st = nullptr) const {
        Hits<T, N> h;
        query<true>(x0, x1, [&](T& t) { h.push(&t); }, st);
        return h;
    }

private:
    void grow(int a, int b) {
        if (cells_.empty()) { base_ = a; cells_.resize((size_t)(b - a + 1)); return; }
        while (a < base_) { cells_.emplace_front(); --base_; }
        while (b > highChunk()) cells_.emplace_back();
    }
    std::deque<Chunk> cells_;
    std::vector<Entry> wide_;
    int base_ = 0;
    size_t count_ = 0;
};

// Load window around the camera. The unload edge is aligned down to a chunk boundary so the generator (ahead) and
// the unloader (behind) always agree on where a chunk starts.
struct Window {
    float behind = 800.0f;    // objects stay alive this far left of the camera (the old prune distance)
    float ahead  = 1400.0f;   // the generator keeps this much produced right of the screen (the old look-ahead)
    float unloadEdge(float camX) const { return std::floor((camX - behind) / CHUNK_W) * CHUNK_W; }
    float loadEdge(float camX, float viewW) const { return camX + viewW + ahead; }
};

}  // namespace chunks
