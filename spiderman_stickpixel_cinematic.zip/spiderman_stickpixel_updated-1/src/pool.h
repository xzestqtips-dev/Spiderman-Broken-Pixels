// pool.h - recycling helpers for objects that are spawned and dropped all the time (no SDL, unit-testable).
//
// A building owns a small std::vector<Obs> (rooftop props). Buildings are created a few hundred px apart and unloaded behind the camera, so
// a long run used to malloc and free one such vector per building. VecPool keeps the retired vectors (capacity intact, contents cleared)
// and hands them to the next object instead, so after warm-up the steady state allocates nothing.
#pragma once
#include <cstddef>
#include <utility>
#include <vector>

namespace pool {

template <class T>
class VecPool {
public:
    explicit VecPool(size_t maxSpare = 32) : maxSpare_(maxSpare) {}
    // An empty vector, preferably one that already owns a heap block.
    std::vector<T> take() {
        if (spare_.empty()) { fresh_++; return std::vector<T>(); }
        std::vector<T> v = std::move(spare_.back());
        spare_.pop_back();
        v.clear();
        reused_++;
        return v;
    }
    // Retire a vector. Vectors without storage are not worth keeping; the spare list is bounded so the pool itself cannot grow.
    void give(std::vector<T>& v) {
        if (v.capacity() == 0 || spare_.size() >= maxSpare_) return;
        v.clear();
        spare_.push_back(std::move(v));
        v = std::vector<T>();
    }
    size_t spare() const { return spare_.size(); }
    size_t reused() const { return reused_; }
    size_t fresh() const { return fresh_; }
    void clear() { spare_.clear(); spare_.shrink_to_fit(); reused_ = fresh_ = 0; }
private:
    std::vector<std::vector<T>> spare_;
    size_t maxSpare_, reused_ = 0, fresh_ = 0;
};

}  // namespace pool
