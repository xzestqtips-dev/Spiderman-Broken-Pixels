// facade_tiles.h - tile culling and run merging for the building facades (no SDL, unit-testable).
//
// A facade is a grid of TILE x TILE textures. Two things used to be wasted every frame:
//   * hidden tiles : the rows at the bottom of a building are overpainted by the opaque ground-floor plinth (or, on low buildings,
//                    by the sidewalk and road that drawStreetScene lays down afterwards), yet every one of them was still drawn;
//   * tile count   : each 96 px tile was its own draw call although neighbours often use the same variant.
// hiddenFrom() says where the covered region starts, Run merges horizontally adjacent tiles of the same variant into one draw
// call (the renderer then copies from a strip texture that repeats the tile STRIP_TILES times).
#pragma once

namespace facade {

static const int STRIP_TILES = 4;   // tiles per strip texture = longest merged run. 1 turns merging off and allocates no strips.

// First y (screen px) from which a tile that starts there is completely covered by something opaque drawn later in the frame.
//   baseTop = top of the ground-floor plinth (ground - 132); it exists only when the building is tall enough to show it.
//   Otherwise the sidewalk rect starts at ground - 7 and spans the full width, followed by the road.
inline int hiddenFrom(int y0, int ground) {
    const int baseTop = ground - 132;
    return baseTop > y0 + 20 ? baseTop : ground - 7;
}

struct Run { int c0 = 0, n = 0, v = 0, tx = 0, w = 0; };   // n tiles from column c0, variant v, starting at screen x tx, w px wide (last tile may be partial)

inline bool canExtend(const Run& r, int c, int v, int maxRun) { return r.n > 0 && r.v == v && r.c0 + r.n == c && r.n < maxRun; }

}  // namespace facade
