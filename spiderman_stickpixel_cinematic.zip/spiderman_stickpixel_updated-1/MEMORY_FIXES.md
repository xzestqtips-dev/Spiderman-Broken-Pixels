# Memory / resource fixes

| # | Where | Problem | Fix |
|---|-------|---------|-----|
| 1 | `androidSafeInsets()` (main.cpp) | ~10 JNI local refs leaked per call; it runs on every relayout/focus/expose on Android, so the 512-entry local ref table eventually overflows and the VM aborts | `PushLocalFrame` / `PopLocalFrame` around the whole function |
| 2 | `recalculateDisplayLayout()` | Destroyed + recreated two full-screen render-target textures on every call, even when the size was unchanged (always on Android) | Rebuild only when the target size actually changed |
| 3 | `gSheetImg` (sprites.h / buildArt) | ~10 MB CPU copy of the sprite sheet kept for the whole session after the GPU texture existed | `sprReleaseSheetImage()` at the end of `buildArt()` |
| 4 | `loadSpriteSheet()` | Raw TGA file (~10 MB) held through map parsing and texture upload; a std::string copy of every map line | Free the raw buffer right after decode; parse lines from a bounded stack buffer |
| 5 | Credits image | Decoded and uploaded at startup (up to 16 MB VRAM + transient buffers) although most sessions never open the credits | Loaded when the credits screen opens, freed when it closes |
| 6 | `loadCreditsImage()` | `im = sm` copied the reduced image; raw file bytes kept alive during resize | Move assignment; raw buffer freed after decode |
| 7 | `sprDecodePng()` | Concatenated IDAT copy kept alive next to the inflated data and the decoded image | Released right after inflate |
| 8 | `main()` exit | No teardown: textures, renderer, window and audio device were never released (audio callback could still be running during `SDL_Quit`) | `shutdownResources()`: close audio first, destroy all textures, renderer, window |
| 9 | `createTexture()` | Passed a failed (null) texture to `SDL_UpdateTexture` | Return null early |
| 10 | `loadSfxClips()` | New read buffer allocated per clip attempt | One buffer reused |
| 11 | `loadSpriteSheet()` | A repeated call orphaned the previous `gSheet` texture | Destroy before replacing |

Reviewed and intentionally left alone (already bounded or cheap): particles (fixed ring of 220), buildings / traffic / crates (deques pruned behind the camera),
walker state map (pruned past 160 entries), all per-frame rect batches (static vectors reused), stickman buffers (static), sky pixel buffer (reused).
`Building::obs` is one small vector per building spawned every few hundred px - pooling it would add complexity for no measurable gain.

New test: `tests/test_resource_lifecycle.cpp` (texture counter added to `tests/stub/SDL.h`).
