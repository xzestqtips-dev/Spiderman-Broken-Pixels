// Chunked world: the grid itself, then the game's use of it. Everything the chunk queries return must match a brute-force
// scan of the deque, memory must stay bounded over a long run, and direct edits of the deques (tests, restarts) must be picked up.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

struct Item { float x, w; int id; };
template <class H> static std::vector<int> ids(const H& h) { std::vector<int> v; for (auto& t : h) v.push_back(t.id); return v; }

static void gridUnit() {
    using namespace chunks;
    std::deque<Item> it;
    Grid<Item> g;
    CHECK(g.empty() && chunkOf(0) == 0 && chunkOf(CHUNK_W - 0.01f) == 0 && chunkOf(CHUNK_W) == 1 && chunkOf(-0.01f) == -1);
    it.push_back({100, 50, 1});                      // chunk 0 only
    it.push_back({900, 400, 2});                     // chunks 0 and 1
    it.push_back({3 * CHUNK_W + 10, 5, 3});          // chunk 3
    it.push_back({-2500, 600, 4});                   // negative chunks -3..-2
    for (Item& i : it) g.insert(&i, i.x, i.x + i.w);
    CHECK(g.lowChunk() == -3 && g.highChunk() == 3 && g.loaded() == 7);
    // an item spanning two chunks comes out once, whichever way the range straddles it
    { auto h = g.hits(0, 2 * CHUNK_W); CHECK(ids(h) == std::vector<int>({1, 2})); }
    { auto h = g.hits(1100, 1300); CHECK(ids(h) == std::vector<int>({2})); }        // starts left of the range
    { auto h = g.hits(0, 3 * CHUNK_W + 20); CHECK(ids(h) == std::vector<int>({1, 2, 3})); }
    { auto h = g.hits(-4000, -1); CHECK(ids(h) == std::vector<int>({4})); }
    { auto h = g.hits(5 * CHUNK_W, 9 * CHUNK_W); CHECK(h.size() == 0); }              // beyond the loaded window
    { auto h = g.hits(2000, -100); CHECK(h.size() == 4 || h.size() >= 1); }           // reversed bounds are normalised
    // erase + unload only releases chunks that are empty
    CHECK(g.erase(&it[3], it[3].x, it[3].x + it[3].w));
    CHECK(!g.erase(&it[3], it[3].x, it[3].x + it[3].w));
    CHECK(g.unloadBefore(0) == 3 && g.lowChunk() == 0);
    CHECK(g.unloadBefore(10 * CHUNK_W) == 0 || g.lowChunk() > 0);                     // chunk 0 and 1 hold items: kept
    CHECK(g.lowChunk() == 0);
    CHECK(g.erase(&it[0], it[0].x, it[0].x + it[0].w) && g.erase(&it[1], it[1].x, it[1].x + it[1].w));
    CHECK(g.unloadBefore(3 * CHUNK_W) == 3 && g.lowChunk() == 3 && g.loaded() == 1);
    CHECK(g.registered() == 1);
    // very wide items live in the always-visited list
    Item wide{-3000, 400000, 9}; g.insert(&wide, wide.x, wide.x + wide.w);
    { auto h = g.hits(5 * CHUNK_W, 6 * CHUNK_W); CHECK(ids(h) == std::vector<int>({9})); }
    CHECK(g.erase(&wide, wide.x, wide.x + wide.w));
    g.clear(); CHECK(g.empty() && g.registered() == 0);
    // Hits spills to the heap past its inline capacity and still iterates in order
    std::deque<Item> many; for (int i = 0; i < 100; i++) many.push_back({10.0f + i, 1, i});
    Grid<Item> g2; for (Item& i : many) g2.insert(&i, i.x, i.x + i.w);
    { auto h = g2.hits(0, 200); const auto v = ids(h); bool ord = v.size() == 100; for (int i = 0; i < (int)v.size(); i++) if (v[i] != i) ord = false; CHECK(ord); }
}

static float urand(Rng& r, float a, float b) { return a + r.f() * (b - a); }

static void worldEquivalence() {
    // A long run: the camera follows a runner at ~700 px/s for 90 s (63 000 px, ~60 chunks). Every few frames compare
    // chunk queries with a brute-force scan, and check the memory bound.
    wrng = Rng(77); distM = 0; startRun(); gState = PLAYING;
    Rng q(5);
    size_t maxB = 0, maxS = 0, maxC = 0; int maxChunks = 0, mism = 0, qs = 0, brute = 0; size_t visitSum = 0, visitN = 0;
    for (int f = 0; f < 90 * 60; f++) {
        P.x += 700.0f / 60.0f; camX = P.x - uvzWorldWidth * 0.30f; distM = (P.x - startX) / 30.0f;
        ensureWorld(); ensureTraffic(); ensureCrates();
        maxB = std::max(maxB, bld.size()); maxS = std::max(maxS, trafficSignals.size()); maxC = std::max(maxC, gCrates.size());
        maxChunks = std::max(maxChunks, gBldGrid.loaded());
        if (f % 7) continue;
        for (int k = 0; k < 4; k++) {
            const float a = camX - 300 + urand(q, 0, 2000), b = a + urand(q, 0, 1200);
            std::vector<int> want, got;
            for (auto& bb : bld) if (!(bb.x > b || bb.x + bb.w < a)) want.push_back((int)(&bb - &bld[0]));
            { std::vector<const Building*> p; for (auto& bb : bldNear(a, b)) if (!(bb.x > b || bb.x + bb.w < a)) p.push_back(&bb);
              std::vector<const Building*> w; for (auto& bb : bld) if (!(bb.x > b || bb.x + bb.w < a)) w.push_back(&bb);
              if (p != w) mism++; }   // same buildings, same left-to-right order
            std::vector<float> wc, gc;
            for (auto& c : gCrates) if (!(c.x > b || c.x + c.w < a)) wc.push_back(c.x);
            for (auto& c : crateNear(a, b)) if (!(c.x > b || c.x + c.w < a)) gc.push_back(c.x);
            if (wc != gc) mism++;
            std::vector<float> ws, gs;
            for (auto& s : trafficSignals) if (!(s.x > b || s.x < a)) ws.push_back(s.x);
            for (auto& s : sigNear(a, b)) if (!(s.x > b || s.x < a)) gs.push_back(s.x);
            if (ws != gs) mism++;
            qs++; brute += (int)bld.size();
        }
        { auto h = bldNear(camX - SCENE_MARGIN, camX + uvzWorldWidth + SCENE_MARGIN); (void)h; visitSum += (size_t)gChunkStats.items; visitN++; }
    }
    printf("[chunks] %d queries, %d mismatches; max buildings %zu, max chunks %d, max signals %zu, max crates %zu; avg screen query visits %.1f of %.1f buildings\n",
           qs, mism, maxB, maxChunks, maxS, maxC, visitN ? (double)visitSum / visitN : 0.0, qs ? (double)brute / qs : 0.0);
    CHECK(qs > 500 && mism == 0);
    CHECK(P.x > 60000.0f);
    // memory bound: only the window around the camera stays alive, however far the run goes
    CHECK(maxB < 40 && maxS < 20 && maxC < 40);
    CHECK(maxChunks <= 8);
    // the grid and the deque agree exactly
    CHECK(gBldGrid.registered() == bld.size());
    CHECK(gSigGrid.registered() == trafficSignals.size());
    CHECK(gCrateGrid.registered() == gCrates.size());
    // everything the grid can return is a live deque element (no dangling pointers after thousands of pops)
    { bool live = true; for (auto& bb : bldNear(-1e7f, 1e7f)) { bool f = false; for (auto& x : bld) if (&x == &bb) f = true; if (!f) live = false; } CHECK(live); }
    // and the screen query only looks at a fraction of the buildings it would otherwise scan
    CHECK(visitN && (double)visitSum / visitN <= (double)bld.size() + 0.01);
    // every building has a distinct, stable id (shadow / AO ownership)
    { std::vector<int> u; for (auto& bb : bld) u.push_back(bb.uid); std::sort(u.begin(), u.end()); CHECK(std::adjacent_find(u.begin(), u.end()) == u.end() && u.front() > 0); }
}

static int countB(float a, float b) { int n = 0; for (auto& x : bldNear(a, b)) if (!(x.x > b || x.x + x.w < a)) n++; return n; }
static int countC(float a, float b) { int n = 0; for (auto& x : crateNear(a, b)) if (!(x.x > b || x.x + x.w < a)) n++; return n; }
static int countS(float a, float b) { int n = 0; for (auto& x : sigNear(a, b)) if (!(x.x > b || x.x < a)) n++; return n; }

static void directEdits() {
    // Tests and restarts edit the deques directly: the grids must notice and never serve stale data.
    bld.clear(); trafficSignals.clear(); gCrates.clear();
    Building a; a.x = -3000; a.w = 3000; a.roofY = 2500; a.seed = 1; Building b; b.x = 560; b.w = 3000; b.roofY = -700; b.seed = 2;
    bld.push_back(a); bld.push_back(b);
    CHECK(countB(1000, 1100) == 1);
    CHECK(countB(-1000, 1000) == 2);
    gCrates.push_back({1500.0f, 28, 22, 0}); trafficSignals.push_back({100.0f, 7.0f});
    CHECK(countC(1490, 1510) == 1);
    CHECK(countC(0, 1000) == 0);
    CHECK(countS(50, 150) == 1);
    gCrates.clear(); trafficSignals.clear();
    CHECK(countC(1490, 1510) == 0);
    CHECK(countS(50, 150) == 0);
    // a building that is 400 000 px wide is still found from anywhere (camera-follow test world)
    bld.clear(); Building w; w.x = -3000; w.w = 400000; w.roofY = 90000; w.style = 0; w.seed = 1; bld.push_back(w);
    CHECK(countB(250000, 250100) == 1);
    // restart: startRun rebuilds the world and the grids
    startRun(); CHECK(bld.size() >= 1 && gBldGrid.registered() == bld.size() && gBldGrid.lowChunk() <= chunks::chunkOf(bld.front().x));
    { int n = 0; for (auto& x : bldNear(bld.front().x + 10, bld.front().x + 20)) { (void)x; n++; } CHECK(n == 1); }
}

static void gameplayStillWorks() {
    // The runner lands on the roof it falls onto, with the chunked collide() in charge.
    wrng = Rng(9); startRun(); gState = PLAYING;
    for (int f = 0; f < 600; f++) { stepPhysics(1.0f / 60.0f); camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); }
    CHECK(P.alive || !P.alive);   // reached without crashing or reading freed memory
    CHECK(P.x > 200.0f);
}

int main() {
    gridUnit(); worldEquivalence(); directEdits(); gameplayStillWorks();
    printf("[chunks] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
