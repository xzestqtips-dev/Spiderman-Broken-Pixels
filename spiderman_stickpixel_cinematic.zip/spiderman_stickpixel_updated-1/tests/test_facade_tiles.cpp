// Facade tiles: hidden-tile culling and run merging. Every RenderCopy drawFacade issues is decoded back into tiles and compared with an
// independent per-tile expectation: each visible, uncovered tile is drawn exactly once, with the right variant, and nothing else is drawn.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void unit() {
    using namespace facade;
    // the covered region starts at the plinth top when the building shows a plinth, else at the sidewalk
    CHECK(hiddenFrom(0, 1000) == 868);            // tall: plinth top = ground - 132
    CHECK(hiddenFrom(900, 1000) == 993);          // low roof (baseTop <= y0 + 20): sidewalk at ground - 7
    CHECK(hiddenFrom(848, 1000) == 993 && hiddenFrom(847, 1000) == 868);
    Run r; CHECK(!canExtend(r, 0, 0, 4));          // an empty run never extends
    r = {3, 1, 2, 0, 96};
    CHECK(canExtend(r, 4, 2, 4) && !canExtend(r, 4, 1, 4) && !canExtend(r, 5, 2, 4) && !canExtend(r, 4, 2, 1));
    r.n = 4; CHECK(!canExtend(r, 7, 2, 4));        // capped at the strip length
    CHECK(STRIP_TILES >= 1);
}

struct Tile { int c, r, v; };
static int tmOf() { return (int)(u32)(gTime * 0.4); }
static int variantOf(const Building& b, int c, int r) {
    int v = (int)(hashCoordinates(b.seed + c, r, 7) % 3);
    if (hashCoordinates(c + (u32)b.seed, r, (u32)tmOf()) % 41 == 0) v = (v + 1) % 3;
    return v;
}

static long gTilesDrawn = 0, gCopies = 0, gTilesOld = 0; static int gMaxRun = 0;
static void checkFacade(const Building& b, int sx, int sy, int ground) {
    std::vector<g_CopyRec> log; g_copyLog = &log;
    drawFacade(b, sx, sy, ground);
    g_copyLog = nullptr;
    const int st = b.style % 6, W = (int)b.w, y0 = sy + 14, cols = (W + TILE - 1) / TILE;
    const int hide = facade::hiddenFrom(y0, ground), hMax = std::min(uvzWorldHeight, hide);
    // expected: every visible tile whose top is above the covered region
    std::vector<Tile> want, got;
    for (int r = std::max(0, (int)floorf((0.0f - y0) / (float)TILE)); y0 + r * TILE < hMax; r++)
        for (int c = 0; c < cols; c++) { const int tx = sx + c * TILE; if (tx + TILE < 0 || tx > uvzWorldWidth) continue; want.push_back({c, r, variantOf(b, c, r)}); }
    long oldCount = 0;   // what the unoptimised loop drew: all visible tiles down to the screen bottom
    for (int r = std::max(0, (int)floorf((0.0f - y0) / (float)TILE)); y0 + r * TILE < uvzWorldHeight; r++)
        for (int c = 0; c < cols; c++) { const int tx = sx + c * TILE; if (tx + TILE < 0 || tx > uvzWorldWidth) continue; oldCount++; }
    bool ok = true;
    for (const g_CopyRec& rec : log) {
        const int ty = rec.dst.y; if ((ty - y0) % TILE != 0) { ok = false; continue; }
        const int r = (ty - y0) / TILE;
        if ((rec.dst.x - sx) % TILE != 0) { ok = false; continue; }
        const int c0 = (rec.dst.x - sx) / TILE, n = (rec.dst.w + TILE - 1) / TILE;
        if (rec.dst.h != TILE || rec.src.h != TILE || rec.src.w != rec.dst.w) ok = false;
        if (n > 1 && n > facade::STRIP_TILES) ok = false;
        gMaxRun = std::max(gMaxRun, n);
        // everything comes from the one facade atlas; the source rect must be the start of this building's style row and a variant cell
        const int cellW = TILE * facade::STRIP_TILES;
        if ((const void*)rec.tex != (const void*)gFacadeAtlas) { ok = false; continue; }
        if (rec.src.y != st * TILE || rec.src.x % cellW != 0) { ok = false; continue; }
        const int tv = rec.src.x / cellW;
        if (tv < 0 || tv > 2) { ok = false; continue; }
        // only the last tile of a building may be partial
        if (rec.dst.w % TILE != 0 && c0 + n != cols) ok = false;
        for (int k = 0; k < n; k++) got.push_back({c0 + k, r, tv});
    }
    CHECK(ok);
    auto key = [](const Tile& a, const Tile& b) { return a.r != b.r ? a.r < b.r : a.c < b.c; };
    std::sort(want.begin(), want.end(), key); std::sort(got.begin(), got.end(), key);
    bool same = want.size() == got.size();
    for (size_t i = 0; same && i < want.size(); i++) same = want[i].c == got[i].c && want[i].r == got[i].r && want[i].v == got[i].v;
    CHECK(same);                                          // exact tiles, exact variants, no gap, no overlap, nothing from the covered region
    CHECK((long)log.size() <= oldCount);
    gTilesDrawn += (long)got.size(); gCopies += (long)log.size(); gTilesOld += oldCount;
}

int main() {
    unit();
    setenv("PCITY_PREF", "/tmp/pcity_ft/", 1); if (system("mkdir -p /tmp/pcity_ft")) {}
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt();
    CHECK(gFacadeAtlas != nullptr);
    { const SDL_Rect a = facadeCell(0, 0), z = facadeCell(5, 2);   // cells tile the atlas without overlap and stay inside it (1152 x 576 at STRIP_TILES = 4)
      CHECK(a.x == 0 && a.y == 0 && a.w == TILE * facade::STRIP_TILES && a.h == TILE);
      CHECK(z.x + z.w == 3 * TILE * facade::STRIP_TILES && z.y + z.h == 6 * TILE); }
    wrng = Rng(21); bld.clear(); resetChunks(); addBuilding(true);
    for (int i = 0; i < 60; i++) { distM = i * 40.0f; addBuilding(false); }
    const double skies[] = {20.0, 100.0, 150.0};   // day / dusk / night: the night path adds window and darkening batches
    int calls = 0;
    for (size_t i = 0; i < bld.size(); i += 2) {
        const Building& b = bld[i];
        for (int ground : {400, 700, uvzWorldHeight + 300})                         // street on screen, near the bottom, far below
            for (int dx : {-700, -100, 0, 250, 600, uvzWorldWidth - 80}) {         // building straddling the left / right screen edges too
                for (double sky : skies) {
                    gSkyTime = sky; gTime = 3.0 + (double)(i % 7) * 11.3;
                    const int sy = ground - (int)(STREET_GROUND_Y - b.roofY);
                    checkFacade(b, dx, sy, ground);
                    calls++;
                }
            }
    }
    printf("[facade_tiles] %d facades; tiles drawn %ld, copy calls %ld (unoptimised loop: %ld calls); longest run %d tiles\n", calls, gTilesDrawn, gCopies, gTilesOld, gMaxRun);
    CHECK(calls > 500);
    CHECK(gCopies < gTilesOld);                    // there really are fewer draw calls
    CHECK(gMaxRun >= 2 && gMaxRun <= facade::STRIP_TILES);
    printf("[facade_tiles] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
