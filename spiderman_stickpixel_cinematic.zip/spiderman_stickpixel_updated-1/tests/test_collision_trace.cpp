// Physics-preservation check for the collision broad phase. A scripted, seeded "player" runs through generated cities (random swing taps, jumps over
// traffic, hops into crates) and every frame of player state is folded into one FNV hash. The whole simulation is run twice in this binary: once with
// the original coarse chunk queries and once with the exact-extent queries. Any difference in how collisions resolve (a missed roof, a different bump,
// another death frame) changes the hash and fails the test. (Verified once against the unmodified game too: identical hash.)
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static unsigned long long H = 0;
static void mix(const void* p, size_t n) { const unsigned char* b = (const unsigned char*)p; for (size_t i = 0; i < n; i++) { H ^= b[i]; H *= 1099511628211ULL; } }
static void mixF(float f) { mix(&f, sizeof f); }
static void mixI(int v) { mix(&v, sizeof v); }
static long gFrames, gDeaths, gRides, gGround;
static unsigned long long runTrace() {
    H = 1469598103934665603ULL; gFrames = gDeaths = gRides = gGround = 0;
    for (unsigned seed = 1; seed <= 24; seed++) {
        gProg = prog::Data();
        startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
        P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - uvzWorldWidth * 0.30f;
        ensureWorld(); gState = PLAYING; swingWas = false; gTime = 0;
        Rng in(seed * 104729u + 5u);
        bool hold = false; int holdLeft = 0;
        for (int i = 0; i < 60 * 45; i++) {
            gTime += 1.0 / 60;
            if (holdLeft-- <= 0) { hold = in.range(0, 2) != 0; holdLeft = in.range(3, 40); }   // random taps / holds, so webs attach and drop at odd moments
            if (P.alive && P.onGround && in.range(0, 29) == 0) jumpEdge = true;                  // hops into crates and cars
            tch[0] = Touch(); tch[0].on = hold && !P.onGround; tch[0].role = R_SWING;
            updateGame(1.0 / 60);
            camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); ensureTraffic();
            mixF(P.x); mixF(P.y); mixF(P.vx); mixF(P.vy); mixI(P.alive); mixI(P.onGround); mixI(P.rideId); mixI(P.swinging); mixI(P.wallCling);
            gFrames++; if (P.onGround && P.rideId >= 0) gRides++; if (P.onGround) gGround++;
            if (!P.alive) { gDeaths++; break; }
        }
    }
    return H;
}
int main() {
    if (system("rm -rf /tmp/pcity_ct && mkdir -p /tmp/pcity_ct") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_ct/", 1);
    loadCfg(); loadControls();
    uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt();
    gCoarseCollisionQueries = true;  const unsigned long long coarse = runTrace();
    const long f0 = gFrames, d0 = gDeaths, r0 = gRides, g0 = gGround;
    gCoarseCollisionQueries = false; const unsigned long long exact = runTrace();
    printf("[collision_trace] frames %ld, deaths %ld, on-vehicle frames %ld, grounded frames %ld\n[collision_trace] coarse %016llx  exact %016llx\n", gFrames, gDeaths, gRides, gGround, coarse, exact);
    CHECK(gFrames > 5000 && gGround > 100 && gRides > 50);   // the script really exercises landings and vehicle riding
    CHECK(exact == coarse);
    CHECK(f0 == gFrames && d0 == gDeaths && r0 == gRides && g0 == gGround);
    printf("[collision_trace] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
