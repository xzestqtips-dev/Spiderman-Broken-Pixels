// The extra font styles (BOLD, ITAL, COMIC, TINY, LCD, NEON, LED) are built from code. Checks that they cover the game's characters, stay inside
// their cell width, measure consistently with the old STD helpers, and that every style draws without trouble.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int lit(const FontSet& fs, int ch) { int n = 0; for (int r = 0; r < fs.h; r++) for (int b = 0; b < fs.w; b++) if (fs.rows[ch][r] & (1u << (fs.w - 1 - b))) n++; return n; }
int main() {
    initFont();
    // every style: nothing is set outside its w-bit cell, and the sizes are what the layout code assumes
    for (int f = 0; f < FS_COUNT; f++) {
        const FontSet& fs = fsOf((FontStyle)f);
        CHECK(fs.w > 0 && fs.h > 0 && fs.adv >= fs.w - 2);
        for (int ch = 0; ch < 128; ch++) for (int r = 0; r < fs.h; r++) CHECK((fs.rows[ch][r] >> fs.w) == 0);
    }
    // the four STD-derived styles carry every game glyph; bold has more lit pixels, italic keeps the count, comic is bold + slant
    for (const Glyph& g : fontGlyphs) {
        const int ch = (unsigned char)g.c;
        CHECK(gFS[FS_BOLD].has[ch] && gFS[FS_ITAL].has[ch] && gFS[FS_COMIC].has[ch] && gFS[FS_TINY].has[ch]);
        CHECK(lit(gFS[FS_ITAL], ch) == lit(gFS[FS_STD], ch));
        CHECK(lit(gFS[FS_BOLD], ch) >= lit(gFS[FS_STD], ch));
        CHECK(lit(gFS[FS_COMIC], ch) == lit(gFS[FS_BOLD], ch));
    }
    // 'I' rows are 0x0E; in the 7-wide italic cell the bottom row sits at columns 0-4 (0x0E << 2) and the top row leans 2 columns right (0x0E), bold widens to 0x1E
    CHECK(gFS[FS_STD].rows['I'][0] == 0x0E && gFS[FS_ITAL].rows['I'][0] == 0x0E && gFS[FS_ITAL].rows['I'][6] == (0x0E << 2) && gFS[FS_ITAL].rows['I'][3] == (0x04 << 1));
    CHECK(gFS[FS_BOLD].rows['I'][0] == 0x1E);
    // tiny and LCD
    for (const char* p = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:-/!?+%,<>"; *p; ++p) CHECK(gFS[FS_TINY].has[(unsigned char)*p]);
    for (const char* p = "0123456789-"; *p; ++p) CHECK(gFS[FS_LCD].has[(unsigned char)*p]);
    CHECK(lit(gFS[FS_LCD], '8') > lit(gFS[FS_LCD], '0') && lit(gFS[FS_LCD], '0') > lit(gFS[FS_LCD], '1'));
    CHECK(!(gFS[FS_LCD].rows['1'][0] & 0x0E));   // a 1 has no top segment
    CHECK(gFS[FS_LCD].rows['8'][4] == 0x0E && gFS[FS_LCD].rows['8'][8] == 0x0E && gFS[FS_LCD].rows['8'][1] == 0x11);
    // measuring: STD matches the old helpers, the others follow w/adv
    CHECK(fontWidth(FS_STD, "HELLO", 2) == measureTextWidth("HELLO", 2));
    CHECK(fontWidthSp(FS_STD, "HELLO", 2, 3) == textWSp("HELLO", 2, 3));
    CHECK(fontWidth(FS_BOLD, "AB", 2) == (2 * 7 - 1) * 2 && fontWidth(FS_TINY, "AB", 1) == 7 && fontWidth(FS_ITAL, "A", 1) == 7);
    CHECK(fontWidth(FS_STD, "", 3) == 0 && fontHeight(FS_LCD, 2) == 18 && fontHeight(FS_TINY, 1) == 5);
    CHECK(fitFontScale(FS_BOLD, "GAME OVER", 100, 5) < 5 && fitFont(FS_BOLD, "PIZZA", 2, 40) == FS_STD && fitFont(FS_BOLD, "NYC", 2, 60) == FS_BOLD);
    // every style draws (including unknown characters, spaces, lower case and a missing sprite sheet)
    for (int pass = 0; pass < 2; pass++) {
        if (pass == 1) { CHECK(loadSpriteSheet()); bindSprites(); }
        for (int f = 0; f < FS_COUNT; f++) {
            textF((FontStyle)f, "Score 123 km/h x1.5 + ~ {}", 4, 4, 2, 0xFFE9A0, 200);
            textShadowF((FontStyle)f, "COMBO", 4, 4, 3, 0xFFFFFF);
            textSpCF((FontStyle)f, "PAUSED", 100, 10, 3, 0xFFFFFF, 4, 128);
            textF((FontStyle)f, "", 0, 0, 1, 0xFFFFFF);
        }
    }
    printf("[font_styles] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
