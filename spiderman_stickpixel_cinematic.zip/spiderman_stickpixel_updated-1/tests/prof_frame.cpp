// Headless performance harness: drives the real game loop (updateGame + world streaming + render) with the same naive swing bot
// the smoke test uses, and reports frame time, draw-call counts, heap allocations and memory.
//
//   g++ -std=c++17 -O2 -w -Itests/prof_stub tests/prof_frame.cpp -o /tmp/prof && /tmp/prof [seeds] [seconds] [label]
//
// What this measures (and what it cannot):
//   * CPU time the game spends per frame on the SDL-free side: simulation, world streaming, and building the draw-command stream.
//     The stub renderer does no rasterising (g_noRaster), so GPU / fill-rate cost is NOT included; draw-call counts are the proxy.
//   * Heap allocations per frame (hitches on phones come from allocator churn) and live heap / RSS growth over a run (leaks).
#include <chrono>
#include <malloc.h>
#include <new>
#include <fstream>
#include <string>
#include <numeric>
#ifdef DIAG_ALLOC
#include <execinfo.h>
struct BigRec { void* p; size_t n; void* bt[10]; int nbt; };
static BigRec gBig[8192];
static void bigAdd(void* p, size_t n) { if (n < 24576) return; for (auto& r : gBig) if (!r.p) { r.p = p; r.n = n; r.nbt = backtrace(r.bt, 10); return; } }
static void bigDel(void* p) { for (auto& r : gBig) if (r.p == p) { r.p = nullptr; return; } }
#else
static void bigAdd(void*, size_t) {}
static void bigDel(void*) {}
#endif
static size_t gAllocs = 0, gAllocBytes = 0, gLive = 0, gPeakLive = 0;
void* operator new(size_t n) { void* p = malloc(n ? n : 1); if (!p) throw std::bad_alloc(); gAllocs++; gAllocBytes += n; gLive += malloc_usable_size(p); if (gLive > gPeakLive) gPeakLive = gLive; bigAdd(p, n); return p; }
void* operator new[](size_t n) { return operator new(n); }
void operator delete(void* p) noexcept { if (p) { bigDel(p); gLive -= malloc_usable_size(p); free(p); } }
void operator delete[](void* p) noexcept { operator delete(p); }
void operator delete(void* p, size_t) noexcept { operator delete(p); }
void operator delete[](void* p, size_t) noexcept { operator delete(p); }

#define main game_main
#include "../src/main.cpp"
#undef main

using Clock = std::chrono::steady_clock;
static double msSince(Clock::time_point t) { return std::chrono::duration<double, std::milli>(Clock::now() - t).count(); }
static long rssKB(const char* key) {   // VmRSS (current) / VmHWM (peak)
    std::ifstream f("/proc/self/status"); std::string l; const size_t n = strlen(key);
    while (std::getline(f, l)) if (l.compare(0, n, key) == 0) return atol(l.c_str() + n + 1);
    return -1;
}
static double pct(std::vector<double>& v, double p) { if (v.empty()) return 0; std::sort(v.begin(), v.end()); return v[std::min(v.size() - 1, (size_t)(p * (v.size() - 1) + 0.5))]; }
static void row(const char* name, std::vector<double> v) {
    double sum = 0; for (double x : v) sum += x;
    printf("  %-16s mean %7.3f  p50 %7.3f  p95 %7.3f  p99 %7.3f  max %7.3f ms\n", name, v.empty() ? 0 : sum / v.size(), pct(v, .5), pct(v, .95), pct(v, .99), pct(v, 1.0));
}

int main(int argc, char** argv) {
    const int N = argc > 1 ? atoi(argv[1]) : 8, SECONDS = argc > 2 ? atoi(argv[2]) : 40;
    const char* label = argc > 3 ? argv[3] : "run";
    if (system("rm -rf /tmp/pcity_prof && mkdir -p /tmp/pcity_prof") != 0) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_prof/", 1);
    const long rss0 = rssKB("VmRSS");
    loadCfg(); loadControls();
    uvzWindow = nullptr; uvzRenderer = nullptr;
    auto tInit = Clock::now();
    initFont(); recalculateDisplayLayout(); buildArt();
    const double initMs = msSince(tInit);
    const long rssInit = rssKB("VmRSS"); const size_t liveInit = gLive;

    std::vector<double> tUpd, tStream, tRender, tTotal, allocsPerFrame, copiesPerFrame, rectsPerFrame, linesPerFrame, switchesPerFrame;
    {   // reserve up front so the harness's own bookkeeping never reallocates mid-run (that growth was once mistaken for a game leak)
        const size_t cap = (size_t)N * 60 * SECONDS + 64;
        for (auto* v : {&tUpd, &tStream, &tRender, &tTotal, &allocsPerFrame, &copiesPerFrame, &rectsPerFrame, &linesPerFrame, &switchesPerFrame}) v->reserve(cap);
    }
    // heap owned by the harness + the stub's fake framebuffer, so reported heap numbers are the GAME's
    auto foreign = [&]() -> size_t { size_t b = g_fb.capacity(); for (auto* v : {&tUpd, &tStream, &tRender, &tTotal, &allocsPerFrame, &copiesPerFrame, &rectsPerFrame, &linesPerFrame, &switchesPerFrame}) b += v->capacity() * sizeof(double); return b; };
    const size_t foreign0 = foreign(); size_t foreignPeak = foreign0; (void)foreignPeak;
    std::vector<std::pair<int, size_t>> liveSamples; int frameNo = 0; float minZoom = 1;
    const bool phases = getenv("PHASES") != nullptr;
    struct Ph { const char* name; double ms = 0; long copies = 0, rects = 0, lines = 0; } ph[6] = {{"drawBackdrop"}, {"drawWorldScene"}, {"drawStreetScene"}, {"drawParticles"}, {"drawPlayerAndWeb"}, {"drawHUD"}};
    Ph hp[5] = {{"speed gauge"}, {"3x ctl buttons"}, {"combo HUD"}, {"pause btn"}, {"text (score etc)"}};
    long phFrames = 0;
    for (unsigned seed = 1; seed <= (unsigned)N; seed++) {
        gProg = prog::Data();
        startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
        P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - uvzWorldWidth * 0.30f;
        ensureWorld(); gState = PLAYING; swingWas = false; gTime = 0;
        float relT = 0;
        for (int i = 0; i < 60 * SECONDS; i++) {
            gTime += 1.0 / 60;
            bool want = false;
            if (P.alive) {
                if (P.onGround) { for (auto& c : trafficCars) { const float d = c.x - c.width * 0.5f - P.x; if (d > 0 && d < 150) jumpEdge = true; } }
                else {
                    want = (P.swinging || P.webFlying) ? true : ((i / 4) % 2 == 0);
                    if (P.swinging) { const float rope = std::max(P.rope, 1.0f); if (P.x - P.ax > 0.55f * rope && P.vy < 0) relT = 0.22f; }
                    if (relT > 0) { relT -= 1.0f / 60; want = false; }
                }
            }
            tch[0] = Touch(); tch[0].on = want; tch[0].role = R_SWING;
            const size_t a0 = gAllocs; const long c0 = g_copyCalls, r0 = g_fillRects, l0 = g_lineCalls, s0 = g_targetSwitches;
            auto t0 = Clock::now(); updateGame(1.0 / 60); const double u = msSince(t0);
            auto t1 = Clock::now(); camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); ensureTraffic(); const double st = msSince(t1);
            auto t2 = Clock::now(); render(1.0 / 60); const double r = msSince(t2);
            if (i >= 30) {   // skip the first half second: cold caches, first-use lazy init
                tUpd.push_back(u); tStream.push_back(st); tRender.push_back(r); tTotal.push_back(u + st + r);
                allocsPerFrame.push_back((double)(gAllocs - a0)); copiesPerFrame.push_back((double)(g_copyCalls - c0));
                rectsPerFrame.push_back((double)(g_fillRects - r0)); linesPerFrame.push_back((double)(g_lineCalls - l0)); switchesPerFrame.push_back((double)(g_targetSwitches - s0));
            }
            if (phases && i >= 30 && gState == PLAYING) {
                const float cx = floorf(camX), cy = floorf(camY); phFrames++;
                SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
                auto timed = [&](Ph& p, auto fn) { const long c = g_copyCalls, r = g_fillRects, l = g_lineCalls; auto t = Clock::now(); fn(); p.ms += msSince(t); p.copies += g_copyCalls - c; p.rects += g_fillRects - r; p.lines += g_lineCalls - l; };
                timed(ph[0], [&] { drawBackdrop(cx, cy, gSkyTime, true); }); timed(ph[1], [&] { drawWorldScene(cx, cy); }); timed(ph[2], [&] { drawStreetScene(cx, cy); });
                timed(ph[3], [&] { drawParticles(cx, cy); }); timed(ph[4], [&] { drawPlayerAndWeb(cx, cy); }); timed(ph[5], [&] { drawHUD(); });
                { const int x = (int)uvzSafeLeft, y = (int)uvzSafeTop, gr = 22; const int pcx = pauseBtn.x + 22, pcy = pauseBtn.y + 20;
                  timed(hp[0], [&] { drawSpeedGauge(x + gr + 3, y + gr + 3, gr, 40.0f + 80.0f * (float)((phFrames % 120) / 120.0)); });
                  timed(hp[1], [&] { for (int k = 0; k < 3; k++) drawCtlButton(k, false, false); });
                  timed(hp[2], [&] { drawComboHUD(x, y + 64); });
                  timed(hp[3], [&] { drawDisc(pcx, pcy, 15, UI_INK, 110); ringDraw(pcx, pcy, 15, 1, UI_WHITE, 150); });
                  timed(hp[4], [&] { textF(FS_TINY, "SCORE", x + 60, y + 1, 1, UI_DIM); textShadowF(FS_BOLD, "12345", x + 60, y + 10, 3, UI_WHITE); textShadowF(FS_ITAL, "321M", x + 60, y + 35, 2, 0xBFD8FF); drawTextWithShadow("COINS 1,234", 400, y, 1, 0xFFE9A0); textF(FS_LCD, " 88", x, 300, 2, UI_WHITE); }); }
            }
            minZoom = std::min(minZoom, gZoom);
            if (++frameNo % 600 == 0) liveSamples.push_back({frameNo, gLive - std::min(gLive, foreign())});
            if (!P.alive && P.deadT > 1.2f) break;
        }
    }
    const long rssEnd = rssKB("VmRSS"), hwm = rssKB("VmHWM");
    double sumT = 0; for (double x : tTotal) sumT += x;
    const double meanT = tTotal.empty() ? 0 : sumT / tTotal.size();
    printf("=== %s: %d frames over %d seeds (<=%d s each), 60 Hz fixed step, 1 core, -O2 ===\n", label, (int)tTotal.size(), N, SECONDS);
    row("updateGame", tUpd); row("world streaming", tStream); row("render (cmds)", tRender); row("TOTAL / frame", tTotal);
    printf("  CPU-bound ceiling: %.0f FPS (mean), %.0f FPS (p99 frame)   [GPU cost not included]\n", 1000.0 / std::max(meanT, 1e-9), 1000.0 / std::max(pct(tTotal, .99), 1e-9));
    auto mean = [](std::vector<double>& v) { double s = 0; for (double x : v) s += x; return v.empty() ? 0 : s / v.size(); };
    printf("  per frame: %.1f RenderCopy, %.1f FillRect, %.1f DrawLine, %.1f SetRenderTarget, %.1f heap allocs (p99 %.0f)\n",
           mean(copiesPerFrame), mean(rectsPerFrame), mean(linesPerFrame), mean(switchesPerFrame), mean(allocsPerFrame), pct(allocsPerFrame, .99));
    if (phases && phFrames) { printf("  phase breakdown (%ld PLAYING frames, un-zoomed draw path):\n", phFrames); for (auto& p : ph) printf("    %-17s %7.1f us/frame  %6.1f copies  %7.1f rects  %6.1f lines\n", p.name, 1000.0 * p.ms / phFrames, (double)p.copies / phFrames, (double)p.rects / phFrames, (double)p.lines / phFrames); printf("  HUD parts (each re-drawn standalone; they overlap the drawHUD row above):\n"); for (auto& p : hp) printf("    %-17s %7.1f us/frame  %6.1f copies  %7.1f rects  %6.1f lines\n", p.name, 1000.0 * p.ms / phFrames, (double)p.copies / phFrames, (double)p.rects / phFrames, (double)p.lines / phFrames); }
    printf("  startup (initFont+layout+buildArt): %.1f ms\n", initMs);
    printf("  memory: RSS before init %ld KB, after init %ld KB, end %ld KB, peak (HWM) %ld KB; game heap after init %zu KB, end %zu KB, peak %zu KB (harness/stub buffers excluded from live figures)\n",
           rss0, rssInit, rssEnd, hwm, liveInit / 1024, (gLive - std::min(gLive, foreign())) / 1024, gPeakLive / 1024);
    printf("  GPU textures (w*h*4, not in RSS): %zu live, %.2f MB now, %.2f MB peak\n", g_texBytesMap.size(), g_texBytes / 1048576.0, g_texBytesPeak / 1048576.0);
    { std::vector<long> tb; for (auto& kv : g_texBytesMap) tb.push_back(kv.second); std::sort(tb.rbegin(), tb.rend()); printf("  texture sizes (MB):"); for (long b : tb) printf(" %.2f", b / 1048576.0); printf("\n"); }
    printf("  live heap every 600 frames (KB):"); for (auto& s : liveSamples) printf(" %zu", s.second / 1024); printf("\n  min zoom reached: %.3f\n", minZoom);
#ifdef DIAG_ALLOC
    { std::vector<BigRec*> v; for (auto& r : gBig) if (r.p) v.push_back(&r); std::sort(v.begin(), v.end(), [](BigRec* a, BigRec* b) { return a->n > b->n; });
      printf("  LIVE BLOCKS >= 24 KB: %zu\n", v.size());
      for (size_t i = 0; i < v.size() && i < 12; i++) { printf("  BLOCK %zu KB :", v[i]->n / 1024); for (int k = 1; k < v[i]->nbt && k < 7; k++) printf(" %p", v[i]->bt[k]); printf("\n"); } }
#endif
    return 0;
}
