// Grid::hitsExact must return exactly the items whose extent touches the query range (inclusive), in the same order as the coarse hits().
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "../src/chunks.h"
struct Item { int id; float lo, hi; };
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    srand(7);
    std::vector<Item> items; items.reserve(4000);
    chunks::Grid<Item> g;
    float x = -3000;
    for (int i = 0; i < 400; i++) {
        const float w = (float)(40 + rand() % 400), gap = (float)(rand() % 3 == 0 ? 0 : rand() % 90);
        items.push_back({i, x, x + w}); x += w + gap;
    }
    items.push_back({9000, -2000, 30000});   // one huge item: lives in the always-visited "wide" list
    for (auto& it : items) g.insert(&it, it.lo, it.hi);
    long coarseTotal = 0, exactTotal = 0;
    for (int q = 0; q < 20000; q++) {
        const float a = -3500.0f + (float)(rand() % 20000), b = a + (q % 4 == 0 ? 0.0f : (float)(rand() % 300));
        std::vector<int> want;
        auto coarse = g.hits(a, b);
        for (auto& it : coarse) if (it.hi >= a && it.lo <= b) want.push_back(it.id);   // what every caller's own overlap test keeps
        auto ex = g.hitsExact(a, b);
        std::vector<int> got; for (auto& it : ex) got.push_back(it.id);
        CHECK(got == want);
        // brute force over everything, to be sure the coarse query never lost an overlapping item either
        std::vector<int> brute; for (auto& it : items) if (it.hi >= a && it.lo <= b) brute.push_back(it.id);
        std::vector<int> g2 = got, b2 = brute; std::sort(g2.begin(), g2.end()); std::sort(b2.begin(), b2.end());
        CHECK(g2 == b2);
        coarseTotal += coarse.size(); exactTotal += ex.size();
    }
    { auto h = g.hitsExact(500, 100); auto h2 = g.hitsExact(100, 500); CHECK(h.size() == h2.size()); }   // reversed bounds
    printf("[chunks_exact] avg items per 0-300 px query: coarse %.1f, exact %.1f\n", coarseTotal / 20000.0, exactTotal / 20000.0);
    printf("[chunks_exact] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
