#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static void resizeTo(int w, int h) { g_outW = w; g_outH = h; recalculateDisplayLayout(); }
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_fs/", 1);
    if (system("rm -rf /tmp/pcity_fs && mkdir -p /tmp/pcity_fs") != 0) return 2;
    loadCfg(); loadControls(); uvzWindow = reinterpret_cast<SDL_Window*>(1); uvzRenderer = nullptr;   // fake non-null window: the stub records the flags
    initFont(); resizeTo(1280, 600); buildArt(); startRun();
    gState = PLAYING; gTime = 5;
    // Layout for many screens: square pixels, the picture always covers the whole output (no borders), and touch input maps to the right world point.
    const int sizes[][2] = {{1280, 600}, {1920, 1080}, {2560, 1440}, {3840, 2160}, {2400, 1080}, {1366, 768}, {800, 480}, {3440, 1440}};
    for (auto& sz : sizes) {
        resizeTo(sz[0], sz[1]);
        CHECK(uvzScaleX == uvzScaleY && uvzPixelScale == (int)uvzScaleX);                                   // no stretching
        CHECK(uvzDisplayWidth >= uvzOutputWidth && uvzDisplayHeight >= uvzOutputHeight);                    // covers the screen: no empty borders
        CHECK(uvzDisplayWidth - uvzOutputWidth < uvzPixelScale && uvzDisplayHeight - uvzOutputHeight < uvzPixelScale);   // crop is less than one game pixel
        float x, y; toInternal(0.5f, 0.5f, x, y);
        CHECK(fabsf(x - uvzWorldWidth / 2.0f) < 1.0f && fabsf(y - uvzWorldHeight / 2.0f) < 1.0f);           // screen centre = world centre
        toInternal(0.0f, 0.0f, x, y); CHECK(x >= -uvzPixelScale && y >= -uvzPixelScale);
        toInternal(1.0f, 1.0f, x, y); CHECK(x <= uvzWorldWidth + uvzPixelScale && y <= uvzWorldHeight + uvzPixelScale);
    }
    // Toggling fullscreen in the middle of a run changes only the window: score, position, speed, combo and world are untouched.
    resizeTo(1280, 600); cfg.full = false; g_winFlags = 0;
    P.x = 1234; P.y = -321; P.vx = 777; distM = 88; bonus = 12; const size_t nb = bld.size(); const int tier = gTier;
    CHECK(fullscreenKey(SDL_SCANCODE_F11, 0, false));
    CHECK(cfg.full && windowIsFullscreen());
    resizeTo(1920, 1080);                                                                                      // what the SIZE_CHANGED event does
    CHECK(P.x == 1234 && P.y == -321 && P.vx == 777 && distM == 88 && bonus == 12 && bld.size() == nb && gTier == tier && gState == PLAYING);
    CHECK(!fullscreenKey(SDL_SCANCODE_F11, 0, true) || cfg.full);                                              // key auto-repeat does not toggle again
    CHECK(fullscreenKey(SDL_SCANCODE_RETURN, KMOD_ALT, false) && !cfg.full && !windowIsFullscreen());        // Alt+Enter leaves
    resizeTo(1280, 600);
    CHECK(P.x == 1234 && distM == 88 && gState == PLAYING);
    CHECK(!fullscreenKey(SDL_SCANCODE_RETURN, 0, false));                                                      // plain Enter is not hijacked
    // Esc: leaves fullscreen on the main menu only; during play it still pauses (not consumed here).
    setFullscreen(true);
    gState = PLAYING; CHECK(!fullscreenKey(SDL_SCANCODE_ESCAPE, 0, false) && cfg.full);
    gState = PAUSED;  CHECK(!fullscreenKey(SDL_SCANCODE_ESCAPE, 0, false) && cfg.full);
    gState = MAIN_MENU; CHECK(fullscreenKey(SDL_SCANCODE_ESCAPE, 0, false) && !cfg.full && !windowIsFullscreen());
    CHECK(!fullscreenKey(SDL_SCANCODE_ESCAPE, 0, false));                                                      // already windowed: Esc falls through
    // The SETTINGS button goes through the same path, and the setting is saved.
    gState = SETTINGS; activate(B_FULL); CHECK(cfg.full && windowIsFullscreen());
    cfg.full = false; loadCfg(); CHECK(cfg.full);
    // Rebinding a key must be able to capture F11 itself.
    gRebind = 0; CHECK(!fullscreenKey(SDL_SCANCODE_F11, 0, false)); gRebind = -1;
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
