// Object pooling: pool::VecPool unit tests, then the game's use of it. Over a long run the rooftop-prop vectors of unloaded buildings
// must be reused (not re-allocated), the pool must stay bounded, and the faller list must never reallocate or exceed its slots.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

static void unit() {
    pool::VecPool<int> p(3);
    CHECK(p.spare() == 0);
    { auto v = p.take(); CHECK(v.empty() && v.capacity() == 0 && p.fresh() == 1 && p.reused() == 0); }
    std::vector<int> a; a.reserve(40); a.push_back(7); const int* blk = a.data();
    p.give(a);
    CHECK(a.capacity() == 0 && p.spare() == 1);               // ownership moved into the pool
    { auto v = p.take(); CHECK(v.empty() && v.capacity() >= 40 && v.data() == blk && p.reused() == 1 && p.spare() == 0); }   // same heap block, cleared
    std::vector<int> none; p.give(none); CHECK(p.spare() == 0);   // a vector without storage is not kept
    for (int i = 0; i < 6; i++) { std::vector<int> v(10, i); p.give(v); }
    CHECK(p.spare() == 3);                                    // bounded
    p.clear(); CHECK(p.spare() == 0 && p.reused() == 0 && p.fresh() == 0);
}

static void worldRun() {
    gObsPool.clear();
    wrng = Rng(77); distM = 0; startRun(); gState = PLAYING;
    size_t maxSpare = 0, built = 0, popped = 0, lastSize = bld.size(), maxLive = 0;
    long obsSeen = 0;
    for (int f = 0; f < 90 * 60; f++) {
        P.x += 700.0f / 60.0f; camX = P.x - uvzWorldWidth * 0.30f; distM = (P.x - startX) / 30.0f;
        ensureWorld(); ensureTraffic(); ensureCrates();
        maxSpare = std::max(maxSpare, gObsPool.spare());
        maxLive = std::max(maxLive, bld.size());
        (void)lastSize;
    }
    for (const Building& b : bld) obsSeen += (long)b.obs.size();
    built = gObsPool.reused() + gObsPool.fresh();
    printf("[pool] %zu buildings built, %zu got a recycled obs vector, %zu fresh allocations; spare list peaked at %zu; max live buildings %zu\n",
           built, gObsPool.reused(), gObsPool.fresh(), maxSpare, maxLive);
    (void)popped;
    CHECK(built > 40);                                         // a real run
    CHECK(gObsPool.reused() > built / 2);                      // most buildings reuse a retired vector
    CHECK(gObsPool.fresh() <= maxLive + 40);                   // fresh allocations stop once the pool is warm (bounded by the live window)
    CHECK(maxSpare <= 32);
    CHECK(obsSeen > 0);                                        // recycled vectors still carry the right props
    for (const Building& b : bld) for (const Obs& o : b.obs) CHECK(o.x >= b.x - 1 && o.x <= b.x + b.w + 1);   // nothing stale from a previous owner
}

static void fallers() {
    gFallers.clear(); gFallers.reserve(0);
    wrng = Rng(3); distM = 0; startRun(); gState = PLAYING; gMenuIdle = false; P.alive = true; gNextFallerX = 0;
    rescueTick(0.0f);
    CHECK(gFallers.capacity() >= FALLER_SLOTS);
    const Faller* base = gFallers.data(); size_t maxN = 0; bool moved = false; int spawned = 0;
    for (int f = 0; f < 60 * 60; f++) {
        P.x += 12.0f; P.y = -300.0f; P.onGround = false; camX = P.x - uvzWorldWidth * 0.30f;
        const size_t before = gFallers.size();
        rescueTick(1.0f / 60.0f);
        if (gFallers.size() > before) spawned++;
        maxN = std::max(maxN, gFallers.size());
        if (!gFallers.empty() && gFallers.data() != base) moved = true;
    }
    CHECK(spawned > 5);
    CHECK(maxN <= FALLER_SLOTS && maxN >= 1);
    CHECK(!moved);                                             // storage never reallocated after the first reserve
    for (const Faller& f : gFallers) CHECK(std::isfinite(f.x) && std::isfinite(f.y));
}

int main() {
    setenv("PCITY_PREF", "/tmp/pcity_pool/", 1); if (system("mkdir -p /tmp/pcity_pool")) {}
    unit();
    uvzRenderer = nullptr; initFont(); recalculateDisplayLayout();
    worldRun();
    fallers();
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
