// Draw-call batching regression: the sky backdrop must leave as few texture runs as possible (SDL_Renderer merges consecutive
// RenderCopy calls on one texture into one GPU draw, so "texture runs" is the draw-call count that matters).
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt();
    std::vector<g_CopyRec> log; g_copyLog = &log;
    int worst = 0;
    for (int k = 0; k < 40; k++) {
        log.clear();
        drawBackdrop(1000.0f * k, 0.0f, 20.0f + 9.0f * k, true);
        int runs = 0; const SDL_Texture* prev = nullptr;
        for (auto& r : log) { if (r.tex != prev) runs++; prev = r.tex; }
        worst = std::max(worst, runs);
        for (auto& r : log) CHECK(r.tex != nullptr);
    }
    CHECK(gCloudTex != nullptr);
    printf("[batching] worst-case texture runs in the backdrop: %d\n", worst);
    CHECK(worst <= 8);   // 1 clouds + (body, lights) x 3 layers + sky gradient; was up to ~25 (one switch per cloud, per skyline tile)
    g_copyLog = nullptr;
    printf("[batching] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
