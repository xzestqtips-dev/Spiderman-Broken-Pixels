// Pixel-equivalence harness for the facade tile optimisation (hidden-tile culling + run merging).
// Renders a fixed set of frames and prints one checksum per frame; build it once against the optimised source and once against a copy
// with culling/merging disabled (hideY = 1 << 30, maxRun = 1) and diff the outputs. Equal lines = identical pixels.
//   g++ -std=c++17 -O1 -w -Itests/stub tests/shot_facade_compare.cpp -o /tmp/ffc && /tmp/ffc
#define main game_main
#include "../src/main.cpp"
#undef main
static uint64_t fnv() { uint64_t h = 1469598103934665603ull; for (uint8_t c : g_fb) { h ^= c; h *= 1099511628211ull; } return h; }
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_ffc/", 1); if (system("mkdir -p /tmp/pcity_ffc")) {}
    g_blit = true;   // keep texture pixels so RenderCopy paints the facade tiles into the frame buffer
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();
    int n = 0;
    for (unsigned seed : {3u, 11u, 29u}) {
        startRun(); wrng = Rng(seed * 7919u); bld.clear(); resetChunks(); addBuilding(true);
        gState = PLAYING; gTime = 10;
        for (int i = 0; i < 40; i++) { distM = i * 40.0f; addBuilding(false); }   // a persistent city (no pruning): ~x 0..30000
        const float camYs[] = {-235.0f, -700.0f, -1800.0f, -90.0f};
        const double skies[] = {20.0, 60.0, 100.0, 150.0};   // day, sunset-ish, dusk, night (180 s cycle)
        for (int k = 0; k < 8; k++) for (float cy : camYs) for (double sky : skies) {
            if (k % 2 && sky == 60.0) continue;
            gSkyTime = sky; gZoom = 1.0f;
            camX = 200.0f + k * 1500.0f + (seed % 5) * 37.0f; camY = cy; P.x = camX + 300; P.y = camY + 300; P.alive = true;
            std::fill(g_fb.begin(), g_fb.end(), (uint8_t)0);
            render(0.016);
            { int nz = 0; for (uint8_t c : g_fb) nz += c != 0; if (nz < (int)g_fb.size() / 4) printf("BLANK-ish frame\n"); }
            printf("seed %u k %d camY %.0f sky %.0f zoom %.1f : %016llx\n", seed, k, cy, sky, gZoom, (unsigned long long)fnv());
            n++;
        }
    }
    printf("frames %d\n", n);
    fprintf(stderr, "RenderCopy calls total %d\n", g_copyCalls);
    return 0;
}
