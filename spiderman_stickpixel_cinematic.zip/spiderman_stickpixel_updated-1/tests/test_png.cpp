// Headless test for src/png.h: decodes the fixtures in tests/data against raw RGBA dumps made with Pillow / ImageMagick.
#include <cstdio>
#include <cstdint>
#include <algorithm>
#include <vector>
#include <string>
typedef uint32_t u32;
struct Img { int w, h; std::vector<u32> p; Img(int w_, int h_) : w(w_), h(h_), p((size_t)w_ * h_, 0) {} };
#include "../src/png.h"
static bool slurp(const std::string& f, std::vector<unsigned char>& o) { FILE* fp = fopen(f.c_str(), "rb"); if (!fp) return false; unsigned char b[4096]; size_t n; while ((n = fread(b, 1, sizeof b, fp)) > 0) o.insert(o.end(), b, b + n); fclose(fp); return true; }
int main() {
    int fails = 0, checks = 0;
    FILE* sz = fopen("tests/data/sizes.txt", "r"); if (!sz) { printf("no fixtures\n"); return 2; }
    char name[64]; int w, h;
    while (fscanf(sz, "%63s %d %d", name, &w, &h) == 3) {
        std::vector<unsigned char> png, rgba; Img im(1, 1);
        checks++;
        if (!slurp(std::string("tests/data/") + name + ".png", png) || !slurp(std::string("tests/data/") + name + ".rgba", rgba)) { printf("FAIL %s: missing file\n", name); fails++; continue; }
        if (!sprDecodePng(png, im) || im.w != w || im.h != h) { printf("FAIL %s: decode (%dx%d)\n", name, im.w, im.h); fails++; continue; }
        long bad = 0;
        for (int i = 0; i < w * h; i++) {
            const u32 e = ((u32)rgba[i * 4 + 3] << 24) | ((u32)rgba[i * 4] << 16) | ((u32)rgba[i * 4 + 1] << 8) | rgba[i * 4 + 2];
            const bool opaqueOnly = false; (void)opaqueOnly;
            if (im.p[i] != e) bad++;
        }
        printf("%-8s %3dx%-3d %s\n", name, w, h, bad ? "MISMATCH" : "ok");
        if (bad) { printf("FAIL %s: %ld pixels differ\n", name, bad); fails++; }
    }
    fclose(sz);
    std::vector<unsigned char> junk = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34}; Img t(1, 1);
    checks++; if (sprDecodePng(junk, t)) { printf("FAIL garbage accepted\n"); fails++; }
    std::vector<unsigned char> trunc; slurp("tests/data/big.png", trunc); trunc.resize(trunc.size() / 2);
    checks++; if (sprDecodePng(trunc, t)) { printf("FAIL truncated accepted\n"); fails++; }
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
