// Performance changes must not change output. This proves it for the two optimisations made after profiling:
//   1. arcBand (speed gauge): cached ring pixels  == the original per-pixel scan (same rects, same order),
//   2. sprLoadTgaFile (streaming sprite-sheet load) == the original whole-buffer sprDecodeTga (same pixels, same accept / reject rules).
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

// The scan arcBand used before caching, kept verbatim as the reference.
static void arcBandRef(int cx, int cy, float r0, float r1, float a0, float a1, std::vector<SDL_Rect>& rs) {
    rs.clear();
    const int R = (int)r1 + 1;
    for (int dy = -R; dy <= R; dy++) {
        int run = 0; bool open = false;
        for (int dx = -R; dx <= R + 1; dx++) {
            bool in = false;
            if (dx <= R) {
                const float d = sqrtf((float)(dx * dx + dy * dy));
                if (d >= r0 && d <= r1) {
                    float ang = atan2f((float)dy, (float)dx) * 180.0f / pi;
                    if (ang < 0) ang += 360.0f;
                    if (ang < 100.0f) ang += 360.0f;
                    in = ang >= a0 && ang <= a1;
                }
            }
            if (in && !open) { run = dx; open = true; }
            else if (!in && open) { rs.push_back({cx + run, cy + dy, dx - run, 1}); open = false; }
        }
    }
}
static bool sameRects(const std::vector<SDL_Rect>& a, const std::vector<SDL_Rect>& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); i++) if (a[i].x != b[i].x || a[i].y != b[i].y || a[i].w != b[i].w || a[i].h != b[i].h) return false;
    return true;
}
static bool writeFile(const char* path, const std::vector<unsigned char>& d) { FILE* f = fopen(path, "wb"); if (!f) return false; fwrite(d.data(), 1, d.size(), f); fclose(f); return true; }
static std::vector<unsigned char> makeTga(int w, int h, int idlen, bool topDown, int bpp = 32, int type = 2, int dropBytes = 0) {
    std::vector<unsigned char> d(18, 0);
    d[0] = (unsigned char)idlen; d[2] = (unsigned char)type; d[12] = w & 255; d[13] = w >> 8; d[14] = h & 255; d[15] = h >> 8; d[16] = (unsigned char)bpp; d[17] = topDown ? 0x20 : 0;
    for (int i = 0; i < idlen; i++) d.push_back((unsigned char)(200 + i));
    for (int i = 0; i < w * h; i++) { d.push_back((unsigned char)(i * 7)); d.push_back((unsigned char)(i * 13)); d.push_back((unsigned char)(i * 29 + 1)); d.push_back((unsigned char)(i * 3 + 5)); }
    d.resize(d.size() - (size_t)dropBytes);
    return d;
}
int main() {
    // ---- 1. arcBand ----
    std::vector<SDL_Rect> a, b; int arcCases = 0; long rectsCompared = 0;
    const float radii[] = {6, 10, 14, 22, 30, 45};
    for (float r : radii) {
        const float rings[2][2] = {{r - 7.0f, r + 1.5f}, {(float)(int)(r - 6), (float)(int)r}};
        for (auto& ring : rings) {
            for (int k = 0; k <= 40; k++) {   // sweep lit angle across the whole gauge, plus the fixed segment / rim ranges
                const float A0 = 105.0f, A1 = 390.0f, seg = (A1 - A0) / 4.0f, gap = 4.0f, lit = A0 + (float)k / 40.0f * (A1 - A0);
                const float ranges[][2] = {{A0 - 3.0f, A1 + 3.0f}, {A0 + 0 * seg + gap / 2, A0 + 1 * seg - gap / 2}, {A0 + 2 * seg + gap / 2, std::min(A0 + 3 * seg - gap / 2, lit)},
                                           {A0 + gap / 2, lit}, {100.0f, 400.0f}, {lit, lit + 17.3f}};
                for (auto& rg : ranges) {
                    const int cx = 25 + k * 3, cy = 31 + k;
                    arcBandRects(cx, cy, ring[0], ring[1], rg[0], rg[1], a); arcBandRef(cx, cy, ring[0], ring[1], rg[0], rg[1], b);
                    arcCases++; rectsCompared += (long)b.size();
                    if (!sameRects(a, b)) { CHECK(false); printf("  mismatch r=%.1f ring=[%.1f,%.1f] a=[%.2f,%.2f] got %zu want %zu\n", r, ring[0], ring[1], rg[0], rg[1], a.size(), b.size()); }
                }
            }
        }
    }
    printf("[arcBand] %d cases, %ld rects compared\n", arcCases, rectsCompared);
    CHECK(rectsCompared > 20000);
    // a ring that matches nothing is empty and does not crash; the cache survives more distinct rings than it holds
    arcBandRects(0, 0, 5, 9, 300, 100, a); CHECK(a.empty());
    for (int i = 0; i < 20; i++) { arcBandRects(0, 0, 3.0f + i, 6.0f + i, 100, 400, a); arcBandRef(0, 0, 3.0f + i, 6.0f + i, 100, 400, b); CHECK(sameRects(a, b)); }

    // ---- 2. streaming TGA loader ----
    struct Case { const char* name; std::vector<unsigned char> d; };
    std::vector<Case> cases = {
        {"bottom-up", makeTga(13, 9, 0, false)}, {"top-down", makeTga(13, 9, 0, true)}, {"id field 5", makeTga(7, 11, 5, false)}, {"id field 255", makeTga(4, 4, 255, true)},
        {"1x1", makeTga(1, 1, 0, false)}, {"wide 300x2", makeTga(300, 2, 0, true)},
        {"24 bpp rejected", makeTga(5, 5, 0, false, 24)}, {"RLE type rejected", makeTga(5, 5, 0, false, 32, 10)}, {"truncated by 1 byte", makeTga(6, 6, 0, false, 32, 2, 1)},
        {"truncated by a row", makeTga(6, 6, 0, true, 32, 2, 24)}, {"zero width", makeTga(0, 5, 0, false)}, {"header only", std::vector<unsigned char>(10, 0)},
    };
    { auto big = makeTga(1, 1, 0, false); big[12] = 0x01; big[13] = 0x10; cases.push_back({"width 4097 rejected", big}); }   // 0x1001 = 4097
    for (auto& c : cases) {
        const char* path = "/tmp/pcity_equiv.tga";
        CHECK(writeFile(path, c.d));
        Img ref(3, 3), got(3, 3); ref.p.assign(9, 0xDEADBEEF); got.p.assign(9, 0xDEADBEEF);
        const bool okRef = sprDecodeTga(c.d, ref), okGot = sprLoadTgaFile(path, got);
        if (okRef != okGot) printf("  case '%s': ref=%d got=%d\n", c.name, (int)okRef, (int)okGot);
        CHECK(okRef == okGot);
        if (okRef && okGot) { CHECK(ref.w == got.w && ref.h == got.h && ref.p == got.p); }
        if (!okGot) { CHECK(got.w == 3 && got.h == 3 && got.p[0] == 0xDEADBEEF); }   // a failed load leaves the caller's image untouched
    }
    CHECK(!sprLoadTgaFile("/tmp/pcity_does_not_exist.tga", *new Img(1, 1)));
    { FILE* f = fopen("assets/spritesheet.tga", "rb");   // the real 10 MB sheet: pixel-identical to the old decode
      if (f) { fclose(f); std::vector<unsigned char> raw; CHECK(sprReadFile("assets/spritesheet.tga", raw)); Img ref(1, 1), got(1, 1);
               CHECK(sprDecodeTga(raw, ref)); CHECK(sprLoadTgaFile("assets/spritesheet.tga", got));
               CHECK(ref.w == got.w && ref.h == got.h && ref.p == got.p); printf("[tga] real sheet %dx%d identical: %d\n", got.w, got.h, (int)(ref.p == got.p)); }
      else printf("[tga] assets/spritesheet.tga not found; real-sheet check skipped\n"); }
    // the sheet loader as a whole still finds its sprites
    CHECK(loadSpriteSheet()); CHECK(gSheet != nullptr); CHECK(!gSprMap.empty());
    printf("[perf_equivalence] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
