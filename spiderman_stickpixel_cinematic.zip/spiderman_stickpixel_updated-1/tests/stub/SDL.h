#pragma once
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
typedef uint8_t Uint8; typedef uint16_t Uint16; typedef int16_t Sint16; typedef uint32_t Uint32; typedef int32_t Sint32; typedef int64_t Sint64; typedef uint64_t Uint64;
typedef int64_t SDL_FingerID; typedef uint32_t SDL_AudioDeviceID;
struct SDL_Rect { int x, y, w, h; };

// file access used by the sprite sheet loader
struct SDL_RWops { FILE* f; };
inline SDL_RWops* SDL_RWFromFile(const char* p, const char* m) { FILE* f = fopen(p, m); return f ? new SDL_RWops{f} : nullptr; }
inline int64_t SDL_RWsize(SDL_RWops* c) { fseek(c->f, 0, SEEK_END); long n = ftell(c->f); fseek(c->f, 0, SEEK_SET); return n; }
inline size_t SDL_RWread(SDL_RWops* c, void* p, size_t sz, size_t n) { return fread(p, sz, n, c->f); }
inline int SDL_RWclose(SDL_RWops* c) { fclose(c->f); delete c; return 0; }
struct SDL_Window; struct SDL_Renderer; struct SDL_Texture;
enum SDL_Scancode { SDL_SCANCODE_UNKNOWN = 0, SDL_SCANCODE_A = 4, SDL_SCANCODE_D = 7, SDL_SCANCODE_E = 8, SDL_SCANCODE_P = 19, SDL_SCANCODE_R = 21, SDL_SCANCODE_S = 22, SDL_SCANCODE_X = 27, SDL_SCANCODE_Z = 29, SDL_SCANCODE_RETURN = 40, SDL_SCANCODE_ESCAPE = 41,
  SDL_SCANCODE_SPACE = 44, SDL_SCANCODE_RIGHT = 79, SDL_SCANCODE_LEFT = 80, SDL_SCANCODE_DOWN = 81, SDL_SCANCODE_UP = 82, SDL_SCANCODE_KP_ENTER = 88, SDL_SCANCODE_F11 = 68,
  SDL_SCANCODE_LCTRL = 224, SDL_SCANCODE_LSHIFT = 225, SDL_SCANCODE_LALT = 226, SDL_SCANCODE_RCTRL = 228, SDL_SCANCODE_RSHIFT = 229, SDL_SCANCODE_RALT = 230,
  SDL_SCANCODE_AC_BACK = 270, SDL_NUM_SCANCODES = 512 };
enum { SDL_BLENDMODE_BLEND = 1 };
enum { SDL_INIT_TIMER = 1, SDL_INIT_AUDIO = 16, SDL_INIT_VIDEO = 32 };
enum { SDL_WINDOW_SHOWN = 4, SDL_WINDOW_FULLSCREEN = 1, SDL_WINDOW_FULLSCREEN_DESKTOP = 4097, SDL_WINDOW_RESIZABLE = 32, SDL_WINDOW_ALLOW_HIGHDPI = 8192 };
enum { SDL_WINDOWPOS_CENTERED = 0x2FFF0000 };
enum { SDL_RENDERER_SOFTWARE = 1, SDL_RENDERER_ACCELERATED = 2, SDL_RENDERER_PRESENTVSYNC = 4, SDL_RENDERER_TARGETTEXTURE = 8 };
struct SDL_RendererInfo { const char* name; Uint32 flags; Uint32 num_texture_formats; Uint32 texture_formats[16]; int max_texture_width, max_texture_height; };
inline int SDL_GetRendererInfo(SDL_Renderer*, SDL_RendererInfo* i) { i->name = "opengl"; i->flags = 2 | 4 | 8; i->max_texture_width = i->max_texture_height = 8192; return 0; }
inline int SDL_GetNumRenderDrivers() { return 2; }
inline int SDL_GetRenderDriverInfo(int k, SDL_RendererInfo* i) { i->name = k == 0 ? "opengl" : "software"; i->flags = k == 0 ? 14 : 1; i->max_texture_width = i->max_texture_height = 8192; return 0; }
inline int SDL_GetCPUCount() { return 8; }
inline int SDL_GetSystemRAM() { return 16384; }
enum { SDL_TEXTUREACCESS_STATIC = 0, SDL_TEXTUREACCESS_STREAMING = 1, SDL_TEXTUREACCESS_TARGET = 2 };
enum { SDL_PIXELFORMAT_RGBA8888 = 1, SDL_PIXELFORMAT_ARGB8888 = 2, SDL_PIXELFORMAT_ABGR8888 = 3 };
enum { SDL_QUIT = 256, SDL_APP_WILLENTERBACKGROUND = 260, SDL_APP_DIDENTERFOREGROUND = 262, SDL_WINDOWEVENT = 512, SDL_KEYDOWN = 768, SDL_KEYUP = 769, SDL_MOUSEMOTION = 1024,
  SDL_FINGERDOWN = 1792, SDL_FINGERUP = 1793, SDL_FINGERMOTION = 1794 };
enum { SDL_WINDOWEVENT_RESIZED = 5, SDL_WINDOWEVENT_SIZE_CHANGED = 6, SDL_WINDOWEVENT_FOCUS_LOST = 13, SDL_WINDOWEVENT_EXPOSED = 3, SDL_WINDOWEVENT_FOCUS_GAINED = 12 };
enum SDL_ScaleMode { SDL_ScaleModeNearest = 0, SDL_ScaleModeLinear = 1 };
struct SDL_DisplayMode { Uint32 format; int w, h, refresh_rate; void* driverdata; };
#define SDL_HINT_RENDER_SCALE_QUALITY "a"
#define SDL_HINT_ORIENTATIONS "b"
#define SDL_HINT_TOUCH_MOUSE_EVENTS "c"
#define SDL_HINT_MOUSE_TOUCH_EVENTS "d"
#define SDL_HINT_ANDROID_TRAP_BACK_BUTTON "e"
struct SDL_Keysym { SDL_Scancode scancode; Uint16 mod; };
struct SDL_KeyboardEvent { Uint32 type; Uint8 repeat; SDL_Keysym keysym; };
struct SDL_WindowEvent { Uint32 type; Uint8 event; Sint32 data1, data2; };
struct SDL_TouchFingerEvent { Uint32 type; SDL_FingerID touchId, fingerId; float x, y, dx, dy, pressure; };
struct SDL_MouseMotionEvent { Uint32 type; Sint32 x, y, xrel, yrel; };
union SDL_Event { Uint32 type; SDL_KeyboardEvent key; SDL_WindowEvent window; SDL_TouchFingerEvent tfinger; SDL_MouseMotionEvent motion; };
struct SDL_AudioSpec { int freq; Uint16 format; Uint8 channels; Uint8 silence; Uint16 samples; Uint32 size; void (*callback)(void*, Uint8*, int); void* userdata; };
#define SDL_zero(x) memset(&(x), 0, sizeof(x))
#define AUDIO_F32SYS 0
inline int SDL_Init(Uint32) { return 0; }
inline void SDL_Quit() {}
inline void SDL_DestroyRenderer(SDL_Renderer*) {}
inline void SDL_DestroyWindow(SDL_Window*) {}
inline const char* SDL_GetError() { return ""; }
inline void SDL_SetHint(const char*, const char*) {}
inline Uint32 SDL_GetTicks() { return 1234; }
inline Uint64 SDL_GetPerformanceCounter() { return 0; }
inline Uint64 SDL_GetPerformanceFrequency() { return 1; }
inline char* SDL_GetPrefPath(const char*, const char*) { static const char* d = getenv("PCITY_PREF"); char* r = (char*)malloc(256); snprintf(r, 256, "%s", d ? d : "/tmp/pcity_pref/"); return r; }
inline void SDL_free(void* p) { free(p); }
inline SDL_Window* SDL_CreateWindow(const char*, int, int, int, int, Uint32) { return nullptr; }
inline SDL_Renderer* SDL_CreateRenderer(SDL_Window*, int, Uint32) { return nullptr; }
static int g_outW = 1280, g_outH = 720;   // tests change these to simulate a resize / fullscreen switch
inline int SDL_GetRendererOutputSize(SDL_Renderer*, int* w, int* h) { *w = g_outW; *h = g_outH; return 0; }
inline void SDL_GetWindowSize(SDL_Window*, int* w, int* h) { *w = 1280; *h = 720; }
inline int SDL_GetDisplayDPI(int, float* a, float* b, float* c) { if (a) *a = 400; if (b) *b = 400; if (c) *c = 400; return 0; }
static Uint32 g_winFlags = 0;
inline int SDL_SetWindowFullscreen(SDL_Window*, Uint32 f) { g_winFlags = f; return 0; }
inline Uint32 SDL_GetWindowFlags(SDL_Window*) { return g_winFlags; }
inline Uint16 SDL_GetModState() { return 0; }
enum { KMOD_ALT = 0x0300 };
inline void SDL_SetWindowSize(SDL_Window*, int, int) {}
inline int SDL_SetTextureScaleMode(SDL_Texture*, SDL_ScaleMode) { return 0; }
inline int SDL_GetCurrentDisplayMode(int, SDL_DisplayMode* m) { if (m) { m->w = 1280; m->h = 720; m->refresh_rate = 60; } return 0; }
inline int SDL_RenderSetVSync(SDL_Renderer*, int) { return 0; }
inline void SDL_Delay(Uint32) {}
#define SDL_VERSION_ATLEAST(X, Y, Z) 1
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cmath>
struct g_TexData { int w = 0, h = 0; std::vector<uint32_t> px; Uint8 cm[3] = {255, 255, 255}; };
inline std::unordered_map<const void*, g_TexData> g_tex; inline bool g_blit = false;   // tests: keep texture pixels and make RenderCopy paint them into g_fb
inline std::vector<uint8_t> g_fb; inline int g_fbW = 0, g_fbH = 0; inline bool g_drawOn = false;
inline uint8_t g_cr = 0, g_cg = 0, g_cb = 0, g_ca = 255;
inline Uint8 g_keys[512];
inline int g_texLive = 0;   // textures created minus destroyed: lets tests assert nothing is leaked
inline SDL_Texture* SDL_CreateTexture(SDL_Renderer*, Uint32, int, int w, int h) { static int pool[8192]; static int nxt = 0; int* t = &pool[nxt++ % 8192]; if (g_blit) { g_TexData d; d.w = w; d.h = h; d.px.assign((size_t)w * h, 0); g_tex[t] = std::move(d); } g_texLive++; if (w > 1000 || h > 1000) {} else if (w >= 300 && h >= 200) { g_fbW = w; g_fbH = h; g_fb.assign((size_t)w * h * 3, 0); } return (SDL_Texture*)t; }
inline void SDL_DestroyTexture(SDL_Texture*) { g_texLive--; }
inline int SDL_UpdateTexture(SDL_Texture* tx, const SDL_Rect* r, const void* px, int pitch) {
    if (!g_blit) return 0;
    auto it = g_tex.find(tx); if (it == g_tex.end() || !px) return 0;
    g_TexData& d = it->second; const int x0 = r ? r->x : 0, y0 = r ? r->y : 0, w = r ? r->w : d.w, h = r ? r->h : d.h;
    for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (x0 + x < d.w && y0 + y < d.h) d.px[(size_t)(y0 + y) * d.w + x0 + x] = ((const uint32_t*)((const char*)px + (size_t)y * pitch))[x];
    return 0;
}
inline int SDL_SetTextureBlendMode(SDL_Texture*, int) { return 0; }
inline int SDL_SetTextureAlphaMod(SDL_Texture*, Uint8) { return 0; }
inline int SDL_SetTextureColorMod(SDL_Texture* tx, Uint8 r, Uint8 g, Uint8 b) { if (g_blit) { auto it = g_tex.find(tx); if (it != g_tex.end()) { it->second.cm[0] = r; it->second.cm[1] = g; it->second.cm[2] = b; } } return 0; }
inline int SDL_SetRenderTarget(SDL_Renderer*, SDL_Texture* t) { g_drawOn = t != nullptr; return 0; }
inline int SDL_SetRenderDrawColor(SDL_Renderer*, Uint8 r, Uint8 g, Uint8 b, Uint8 a) { g_cr = r; g_cg = g; g_cb = b; g_ca = a; return 0; }
inline int SDL_SetRenderDrawBlendMode(SDL_Renderer*, int) { return 0; }
struct g_CopyRec { const SDL_Texture* tex; SDL_Rect src, dst; };
static int g_copyCalls = 0; static std::vector<g_CopyRec>* g_copyLog = nullptr;   // tests: count RenderCopy calls / record them
inline int SDL_RenderCopy(SDL_Renderer*, SDL_Texture* t, const SDL_Rect* s, const SDL_Rect* d) { g_copyCalls++; if (g_copyLog && d) g_copyLog->push_back({t, s ? *s : SDL_Rect{0, 0, 0, 0}, *d});   // a null source rect (whole texture) is logged as 0x0
    if (g_blit && g_drawOn && s && d && s->w > 0 && s->h > 0 && d->w > 0 && d->h > 0) {
        auto it = g_tex.find(t);
        if (it != g_tex.end()) {
            const g_TexData& td = it->second;
            for (int y = 0; y < d->h; y++) for (int x = 0; x < d->w; x++) {
                const int sx = s->x + x * s->w / d->w, sy = s->y + y * s->h / d->h, px = d->x + x, py = d->y + y;
                if (sx < 0 || sy < 0 || sx >= td.w || sy >= td.h || px < 0 || py < 0 || px >= g_fbW || py >= g_fbH) continue;
                const uint32_t c = td.px[(size_t)sy * td.w + sx]; const int a = (int)(c >> 24);
                uint8_t* q = &g_fb[((size_t)py * g_fbW + px) * 3];
                const int r = (int)((c >> 16) & 255) * td.cm[0] / 255, g = (int)((c >> 8) & 255) * td.cm[1] / 255, b = (int)(c & 255) * td.cm[2] / 255;
                q[0] = (uint8_t)((r * a + q[0] * (255 - a)) / 255); q[1] = (uint8_t)((g * a + q[1] * (255 - a)) / 255); q[2] = (uint8_t)((b * a + q[2] * (255 - a)) / 255);
            }
        }
    }
    return 0; }
inline int SDL_RenderClear(SDL_Renderer*) { return 0; }
inline void g_px(int x, int y) { if (!g_drawOn || x < 0 || y < 0 || x >= g_fbW || y >= g_fbH) return; uint8_t* p = &g_fb[((size_t)y * g_fbW + x) * 3]; int a = g_ca; p[0] = (uint8_t)((g_cr * a + p[0] * (255 - a)) / 255); p[1] = (uint8_t)((g_cg * a + p[1] * (255 - a)) / 255); p[2] = (uint8_t)((g_cb * a + p[2] * (255 - a)) / 255); }
inline void SDL_RenderPresent(SDL_Renderer*) {}
inline int SDL_RenderFillRect(SDL_Renderer*, const SDL_Rect* r) { for (int y = r->y; y < r->y + r->h; y++) for (int x = r->x; x < r->x + r->w; x++) g_px(x, y); return 0; }
inline int SDL_RenderFillRects(SDL_Renderer* r, const SDL_Rect* rs, int n) { for (int i = 0; i < n; i++) SDL_RenderFillRect(r, rs + i); return 0; }
inline int SDL_RenderDrawLine(SDL_Renderer*, int x0, int y0, int x1, int y1) { int n = std::max(std::abs(x1 - x0), std::abs(y1 - y0)); for (int i = 0; i <= n; i++) { float t = n ? (float)i / n : 0; g_px((int)std::lround(x0 + (x1 - x0) * t), (int)std::lround(y0 + (y1 - y0) * t)); } return 0; }
inline int SDL_RenderSetClipRect(SDL_Renderer*, const SDL_Rect*) { return 0; }
inline int SDL_PollEvent(SDL_Event*) { return 0; }
inline const Uint8* SDL_GetKeyboardState(int*) { return g_keys; }
inline const char* SDL_GetScancodeName(SDL_Scancode) { return ""; }
inline SDL_AudioDeviceID SDL_OpenAudioDevice(const char*, int, const SDL_AudioSpec*, SDL_AudioSpec*, int) { return 0; }
inline void SDL_PauseAudioDevice(SDL_AudioDeviceID, int) {}
inline void SDL_CloseAudioDevice(SDL_AudioDeviceID) {}
inline void SDL_LockAudioDevice(SDL_AudioDeviceID) {}
inline void SDL_UnlockAudioDevice(SDL_AudioDeviceID) {}
