// Culling regression tests: (1) the traffic AI only looks at signals / cars that can change a car's speed, and the answer is identical to
// scanning everything; (2) vehicles, fallers and particles outside the view generate no draw calls.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)

// The original, unculled rule (every signal, every car).
static float referenceTarget(size_t i) {
    const TrafficCar& car = trafficCars[i];
    float targetSpeed = car.maxSpeed, nextSignalDist = 1e9f;
    const TrafficSignal* nextSignal = nullptr;
    for (const TrafficSignal& signal : trafficSignals) {
        const float d = (signal.x - car.x) * car.dir;
        if (d > 0 && d < nextSignalDist) { nextSignalDist = d; nextSignal = &signal; }
    }
    if (nextSignal && !trafficSignalGreen(*nextSignal, car.dir, gTime)) {
        const float usableGap = std::max(0.0f, nextSignalDist - car.width * 0.5f - 8.0f);
        targetSpeed = std::min(targetSpeed, sqrtf(2.0f * 520.0f * usableGap));
    }
    for (size_t j = 0; j < trafficCars.size(); ++j) {
        if (i == j) continue;
        const TrafficCar& ahead = trafficCars[j];
        if (ahead.dir != car.dir || ahead.lane != car.lane) continue;
        const float gap = (ahead.x - car.x) * car.dir - (ahead.width + car.width) * 0.5f;
        if (gap <= 0) continue;
        const float usableGap = std::max(0.0f, gap - 18.0f);
        targetSpeed = std::min(targetSpeed, ahead.speed + sqrtf(2.0f * 440.0f * usableGap));
    }
    return targetSpeed;
}
static int copiesOnSheet(const std::vector<g_CopyRec>& log) { int n = 0; for (auto& r : log) if (r.tex == gSheet) n++; return n; }

int main() {
    uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt();
    // 1) identical speeds on many random layouts
    Rng r(12345u);
    int compared = 0;
    for (int scenario = 0; scenario < 300; scenario++) {
        trafficCars.clear(); trafficSignals.clear(); resetChunks();
        float sx = 0;
        const int ns = r.range(0, 12);
        for (int k = 0; k < ns; k++) { sx += (float)r.range(100, 1500); trafficSignals.push_back({sx, r.f() * TRAFFIC_SIGNAL_CYCLE}); }
        const int nc = r.range(1, 14);
        for (int k = 0; k < nc; k++) {
            TrafficCar c; const int type = r.range(0, 4), dir = r.range(0, 1) ? 1 : -1;
            c.x = (float)r.range(-200, (int)sx + 800); c.speed = (float)r.range(0, 260); c.maxSpeed = (float)r.range(90, 265);
            c.width = trafficWidth(type); c.height = trafficHeight(type); c.type = type; c.lane = dir > 0 ? 0 : 1; c.dir = dir; c.color = 0xD0B040;
            trafficCars.push_back(c);
        }
        gTime = r.f() * 90.0;
        for (size_t i = 0; i < trafficCars.size(); i++) { CHECK(carTargetSpeed(i) == referenceTarget(i)); compared++; }
    }
    printf("[culling] %d car decisions identical to the unculled rule\n", compared);

    // 2) off-screen vehicles / fallers / particles draw nothing
    trafficCars.clear(); trafficSignals.clear(); resetChunks(); gFallers.clear();
    for (auto& p : parts) p.alive = false;
    gTime = 10.0; gSkyTime = 20.0;
    camX = 0; const float cy = 0;
    std::vector<g_CopyRec> log; g_copyLog = &log;
    auto streetCopies = [&]() { log.clear(); drawStreetScene(camX, cy); return copiesOnSheet(log); };
    const int base = streetCopies();
    TrafficCar c; c.x = 20000.0f; c.speed = 100; c.maxSpeed = 200; c.width = trafficWidth(1); c.height = trafficHeight(1); c.type = 1; c.lane = 0; c.dir = 1; c.color = 0xE8B72D; c.dip = 0;
    trafficCars.push_back(c);
    CHECK(streetCopies() == base);                      // far off to the right: nothing drawn
    trafficCars[0].x = -5000.0f;
    CHECK(streetCopies() == base);                      // far off to the left
    trafficCars[0].x = (float)uvzWorldWidth / 2;
    CHECK(streetCopies() > base);                       // on screen: drawn
    trafficCars.clear();
    gFallers.push_back({30000.0f, 100.0f, 0, 0, 0, true, 0});
    log.clear(); drawFallers(camX, cy); CHECK(copiesOnSheet(log) == 0);
    gFallers[0].x = 200.0f; log.clear(); drawFallers(camX, cy); CHECK(copiesOnSheet(log) == 1);
    g_copyLog = nullptr;
    printf("[culling] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
