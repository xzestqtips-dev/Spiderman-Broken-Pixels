#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static npc::Hero hero(float x, float feetY, float vx, bool sw, bool landed) { npc::Hero h; h.x = x; h.y = feetY - 26; h.vx = vx; h.vy = 0; h.swinging = sw; h.onGround = !sw; h.landedNow = landed; h.feetY = feetY; h.groundY = 0; return h; }
int main() {
    const float dt = 1.0f / 120.0f;
    { npc::State s; for (int i = 0; i < 240; i++) npc::update(s, 0, hero(900, 0, 200, false, false), dt);   // far away: nothing happens
      CHECK(s.startle == 0 && s.off == 0 && s.look == 0 && s.react < 0.01f); }
    { npc::State s; bool st = npc::update(s, 0, hero(40, 0, 0, false, true), dt);                         // landed next to them: startle + hop
      CHECK(st && s.startle > 0 && s.hopV < 0);
      float maxUp = 0, maxOff = 0, prevReact = s.react, maxJump = 0, peakSigned = 0;
      for (int i = 0; i < 600; i++) { npc::update(s, 0, hero(40, 0, 0, false, false), dt); maxUp = std::min(maxUp, s.hop); if (fabsf(s.off) > maxOff) { maxOff = fabsf(s.off); peakSigned = s.off; } maxJump = std::max(maxJump, fabsf(s.react - prevReact)); prevReact = s.react; if (s.hop > 0.001f) break; }
      CHECK(maxUp < -4.0f);                    // actually left the ground
      CHECK(maxOff <= npc::MAX_OFF + 0.01f);   // never pushed past the limit
      CHECK(maxJump < 0.2f);                   // pose weight eases, never snaps
      CHECK(peakSigned < -5.0f);                        // stepped away from the player (player is on the right)
      for (int i = 0; i < 4000; i++) npc::update(s, 0, hero(900, 0, 0, false, false), dt);
      CHECK(s.hop == 0 && fabsf(s.off) < 0.01f && s.react < 0.01f); }   // calms down and returns to the path
    { npc::State s; for (int i = 0; i < 90; i++) npc::update(s, 0, hero(60, -120, 0, true, false), dt);   // a swinger passes 120 px up: look up
      CHECK(s.look > 0.3f);
      npc::State t; for (int i = 0; i < 90; i++) npc::update(t, 0, hero(20, -90, 300, true, false), dt);   // swinging low overhead: startle
      CHECK(t.fear > 0.5f); }
    { npc::State s; npc::update(s, 0, hero(10, 0, 500, false, false), dt); CHECK(s.startle > 0); }       // sprinted right past them
    // walker rendering: the same walker at many times never produces NaN joints, and poses stay in the skeleton's range
    for (int c = -3; c < 4; c++) for (int k = 0; k < 3; k++) for (int t = 0; t < 400; t++) {
        const Walker w = walkerAt(c, k, t * 0.1f); npc::State st; st.look = (t % 10) / 10.0f; st.react = (t % 7) / 7.0f;
        const StkPose p = walkerPose(w, st, k); float jx[J_N], jy[J_N]; stkSolve(p, jx, jy);
        for (int i = 0; i < J_N; i++) if (!std::isfinite(jx[i]) || !std::isfinite(jy[i]) || fabsf(jx[i]) > 60 || jy[i] < -30 || jy[i] > 60) { printf("bad joint c=%d k=%d t=%d i=%d x=%.1f y=%.1f idle=%d\n", c, k, t, i, jx[i], jy[i], (int)w.idle); CHECK(false); return 1; }
    }
    CHECK(true);
    // updateWalkers wires into the player
    P = Player(); P.x = 300; P.y = -300; P.onGround = false; P.vy = 400; updateWalkers(0.01f);
    P.y = -26; P.onGround = true; P.vy = 0; for (int i = 0; i < 5; i++) updateWalkers(0.01f);
    // ---- street life: 11 styles, a denser population, stoops and rooftops, and a hard cap ----
    {   bool seen[NT_N] = {}; int total = 0, cells = 0; int wheeled = 0;
        for (int c = -300; c < 300; c++) { const int n = npcSideCount(c); CHECK(n >= 2 && n <= 5); total += n; cells++;
            for (int k = 0; k < n; k++) { const Walker w = walkerAt(c, k, 3.0f); seen[w.type] = true; CHECK(w.layer == NL_SIDEWALK); CHECK(w.type >= 0 && w.type < NT_N); wheeled += npcWheeled(w.type); } }
        for (int t = 0; t < NT_N; t++) { if (!seen[t]) printf("missing NPC style %s\n", NPC_NAME[t]); CHECK(seen[t]); }
        CHECK((float)total / cells > 2.8f);      // roughly double the old 1-3 per lane (avg 1.6)
        CHECK(wheeled > 0); }
    // every style's pose stays inside the skeleton's range at every phase, awake, startled or looking up, standing, walking or seated
    for (int type = 0; type < NT_N; type++) for (int mode = 0; mode < 4; mode++) for (int t = 0; t < 300; t++) {
        Walker w = walkerAt(1, 0, 0); w.type = type; w.q = 0x9E3779B1u * (u32)(t + 1); w.scale = NPC_SPEC[type].scale; w.female = (t & 1);
        w.idle = mode == 1 || mode == 3; w.seated = mode == 3 && type != NT_CONSTRUCTION; w.ph = t * 0.37f; w.act = (t % 5) / 4.0f; w.dir = (t & 2) ? 1.0f : -1.0f;
        npc::State st; st.look = (t % 10) / 10.0f; st.react = (t % 7) / 7.0f;
        gTime = t * 0.13;
        const StkPose p = walkerPose(w, st, t & 3); float jx[J_N], jy[J_N]; stkSolve(p, jx, jy);
        for (int i = 0; i < J_N; i++) if (!std::isfinite(jx[i]) || !std::isfinite(jy[i]) || fabsf(jx[i]) > 60 || jy[i] < -30 || jy[i] > 60) { printf("bad joint type=%s mode=%d t=%d i=%d x=%.1f y=%.1f\n", NPC_NAME[type], mode, t, i, jx[i], jy[i]); CHECK(false); type = NT_N; mode = 9; break; }
    }
    // the tourist and the dog walker really do stop and go; a pedestrian never does
    { Walker w; int found = 0; float minV = 1e9f, maxV = 0;
      for (int c = -200; c < 200 && !found; c++) for (int k = 0; k < npcSideCount(c); k++) { w = walkerAt(c, k, 0); if (w.type == NT_TOURIST && !w.idle) { found = 1; for (int c2 = c; c2 <= c; c2++) {
            for (int i = 0; i < 400; i++) { const float t = i * 0.05f; const float x0 = walkerAt(c, k, t).x, x1 = walkerAt(c, k, t + 0.05f).x; const float v = fabsf(x1 - x0) / 0.05f; if (v < 200) { minV = std::min(minV, v); maxV = std::max(maxV, v); } } } break; } }
      CHECK(found && maxV > 3.0f * std::max(minV, 1.0f)); }
    // stoops and rooftops: people stand where they should and never inside a rooftop prop
    {   bld.clear();
        for (int i = 0; i < 40; i++) { Building b; b.x = i * 340.0f; b.w = 320; b.roofY = -300.0f - (i % 5) * 60.0f; b.style = i % 6; b.seed = 1000u + (u32)i * 7919u;
            b.obs.push_back({0, b.x + 60.0f + (i % 4) * 30.0f, 40, 30, true, 0}); b.obs.push_back({1, b.x + 200.0f, 36, 50, true, 0}); bld.push_back(b); }
        int stoops = 0, roofs = 0, types[NT_N] = {};
        for (const Building& b : bldNear(-1000.0f, 20000.0f)) for (int k = 0; k < 2; k++) {
            Walker w;
            if (npcStoopAt(b, k, w)) { stoops++; types[w.type]++; CHECK(bldHasStoop(b) && w.layer == NL_STOOP && w.idle && w.x >= b.x && w.x <= b.x + b.w); CHECK(w.footY < STREET_GROUND_Y + 6.0f && w.footY > STREET_GROUND_Y - 30.0f); }
            for (int t = 0; t < 60; t++) { Walker r; if (npcRoofAt(b, k, t * 1.7f, r)) { if (t == 0) roofs++; types[r.type]++;
                CHECK(r.layer == NL_ROOF && r.x >= b.x + 10 && r.x <= b.x + b.w - 10 && fabsf(r.footY - (b.roofY + 1.0f)) < 0.01f);
                for (const Obs& o : b.obs) CHECK(!(r.x > o.x - 4.0f && r.x < o.x + o.w + 4.0f)); } } }
        CHECK(stoops > 5 && roofs > 5);
        int kinds = 0; for (int t = 0; t < NT_N; t++) kinds += types[t] > 0; CHECK(kinds >= 5); }
    // the crowd cap: never more than the budget, tighter on phones, tighter again with FEWER PARTICLES / a stressed frame
    {   uvzWorldWidth = 800; P = Player(); gTime = 5.0; gGov.reset(); cfg.reduced = false;
        gCaps.mobile = false; gNpcPlanT = -1; gNpcPlan.clear(); npcPlan(100.0f, -300.0f); const size_t desk = gNpcPlan.size(); CHECK(desk > 0 && (int)desk <= npcCap() && npcCap() <= 32);
        gCaps.mobile = true; gNpcPlanT = -1; gNpcPlan.clear(); npcPlan(100.0f, -300.0f); CHECK((int)gNpcPlan.size() <= 16 && npcCap() <= 16);
        cfg.reduced = true; CHECK(npcCap() < 16); cfg.reduced = false;
        gGov.level = 4; CHECK(npcCap() <= 8); gGov.reset();
        // the nearest to the screen centre are kept
        gCaps.mobile = true; gNpcPlanT = -1; gNpcPlan.clear(); npcPlan(100.0f, -300.0f);
        for (size_t i = 1; i < gNpcPlan.size(); i++) CHECK(gNpcPlan[i - 1].d <= gNpcPlan[i].d + 0.001f);
        // the whole world scene draws with the crowd, on and off the street, without leaving the frame budget
        gCaps.mobile = false; gState = PLAYING; P = Player(); P.alive = true; P.x = 3000; P.y = -26; camX = 3000 - 200; camY = -250;
        for (int i = 0; i < 20; i++) { gTime += 0.1; updateWalkers(0.1f); render(0.1); }
        CHECK(gWalkerState.size() < 400); }
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
