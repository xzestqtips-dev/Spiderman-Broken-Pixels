#!/bin/bash
# Pixel-equivalence check for the facade optimisation: renders the same frames with the optimised source and with culling + merging
# switched off (a patched copy), and diffs one checksum per frame. Prints "IDENTICAL" when every frame matches. Takes a minute or two.
# Usage: tests/compare_facade.sh
set -e
cd "$(dirname "$0")/.."
T=$(mktemp -d)
mkdir -p $T/src $T/tests
cp src/*.h $T/src/; cp -r assets $T/; cp -r tests/stub $T/tests/; cp tests/shot_facade_compare.cpp $T/tests/
sed -e 's/const int hideY = facade::hiddenFrom(y0, ground);/const int hideY = 1 << 30;/' \
    -e 's/const int maxRun = facade::STRIP_TILES;/const int maxRun = 1;/' src/main.cpp > $T/src/main.cpp
grep -q 'hideY = 1 << 30' $T/src/main.cpp && grep -q 'maxRun = 1;' $T/src/main.cpp || { echo "patterns not found: the reference could not be built"; exit 2; }
g++ -std=c++17 -O1 -w -Itests/stub tests/shot_facade_compare.cpp -o $T/new
(cd $T && g++ -std=c++17 -O1 -w -Itests/stub tests/shot_facade_compare.cpp -o $T/ref)
$T/new > $T/new.txt 2> $T/new.err
(cd $T && ./ref > ref.txt 2> ref.err)
echo "optimised: $(cat $T/new.err)"; echo "reference: $(cat $T/ref.err)"
if diff -q $T/new.txt $T/ref.txt > /dev/null && ! grep -q BLANK $T/new.txt; then echo "IDENTICAL ($(tail -1 $T/new.txt))"; rc=0; else echo "DIFFERENT"; diff $T/new.txt $T/ref.txt | head; rc=1; fi
rm -rf $T; exit $rc
