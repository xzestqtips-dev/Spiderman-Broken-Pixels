#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static const Btn* findBtn(int id) { for (auto& b : btns) if (b.id == id) return &b; return nullptr; }
using namespace gfxcfg;
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_gfx/", 1);
    if (system("rm -rf /tmp/pcity_gfx && mkdir -p /tmp/pcity_gfx") != 0) return 2;
    loadCfg(); loadControls(); uvzWindow = nullptr; uvzRenderer = nullptr;
    initFont(); recalculateDisplayLayout(); buildArt(); startRun(true);

    // ---- defaults & hardware scoring ----
    gfxcfg::Settings d = defaults();
    CHECK(d.rt && d.api == API_AUTO && d.quality == Q_MEDIUM && d.shadows && d.ao && d.reflections && d.perf == PERF_BALANCED);
    Caps strong; strong.cpus = 16; strong.ramMB = 32768; strong.maxTexture = 16384; strong.hasVulkan = true; scoreCaps(strong);
    Caps weak; weak.cpus = 2; weak.ramMB = 1024; weak.maxTexture = 2048; weak.mobile = true; scoreCaps(weak);
    Caps soft; soft.active = ACTIVE_SOFTWARE; soft.accelerated = false; scoreCaps(soft);
    CHECK(strong.score >= 75 && maxQualityFor(strong) == Q_ULTRA);
    CHECK(weak.score < strong.score && maxQualityFor(weak) <= Q_MEDIUM);
    CHECK(soft.score <= 15 && !rtSupported(soft));

    // ---- unsupported features are disabled with a warning ----
    { Warnings w; Effective e = resolve(d, soft, 0, &w);
      CHECK(!e.rt && !e.rtShadows && !e.rtAo && !e.reflections);
      CHECK(e.shadows && e.ao);                       // the cheap fallbacks stay on
      CHECK(w.has("DYNAMIC LIGHTING UNAVAILABLE")); }
    { gfxcfg::Settings s = d; s.rt = false; Warnings w; Effective e = resolve(s, strong, 0, &w);
      CHECK(!e.reflections && w.has("REFLECTIONS NEED DYNAMIC LIGHTING")); }
    { gfxcfg::Settings s = d; s.quality = Q_ULTRA; Warnings w; Effective e = resolve(s, weak, 0, &w);
      CHECK(e.quality <= maxQualityFor(weak) && w.has("LIMITED")); }
    { gfxcfg::Settings s = d; s.api = API_VULKAN; Warnings w; resolve(s, weak, 0, &w);          // weak has no Vulkan
      CHECK(w.has("VULKAN NOT AVAILABLE")); }
    { gfxcfg::Settings s = d; s.api = API_VULKAN; Caps c = strong; c.active = ACTIVE_OPENGL; Warnings w; resolve(s, c, 0, &w);
      CHECK(!w.has("NOT AVAILABLE") && w.restartNeeded && w.has("NEXT LAUNCH")); }   // supported, but needs a new renderer
    { gfxcfg::Settings s = d; s.api = API_OPENGL; Warnings w; resolve(s, strong, 0, &w); CHECK(!w.restartNeeded); }   // already on OpenGL

    // ---- performance modes and the governor ladder ----
    { gfxcfg::Settings s = d; s.quality = Q_HIGH; s.perf = PERF_FPS; Effective a = resolve(s, strong, 0);
      s.perf = PERF_QUALITY; Effective b = resolve(s, strong, 0);
      CHECK(a.quality < b.quality && b.quality == Q_HIGH); }
    { Effective e0 = resolve(d, strong, 0), e3 = resolve(d, strong, 3), e4 = resolve(d, strong, 4);
      CHECK(e0.reflections && !e3.reflections && e3.rtShadows && !e4.rtShadows && !e4.ao && e4.shadows);
      CHECK(e0.p.steps >= e4.p.steps); }
    { gfxcfg::Settings s = d; s.perf = PERF_QUALITY; Effective e = resolve(s, strong, 9); CHECK(e.governor == maxGovernorLevel(PERF_QUALITY) && e.shadows); }

    // ---- governor: reacts to a slow run, recovers, and does not flap ----
    { Governor g; int changes = 0;
      for (int i = 0; i < 600; i++) if (g.update(1.0f / 30.0f, 60.0f, PERF_BALANCED, 4)) changes++;   // 30 fps against a 60 fps target
      CHECK(g.level == 4 && changes == 4);
      Governor f; for (int i = 0; i < 90; i++) f.update(1.0f / 30.0f, 60.0f, PERF_FPS, 4);
      Governor q; for (int i = 0; i < 90; i++) q.update(1.0f / 30.0f, 60.0f, PERF_QUALITY, 2);
      CHECK(f.level > q.level); }                                                                    // FPS mode reacts sooner
    { Governor g; g.level = 3;
      for (int i = 0; i < 60 * 40; i++) g.update(1.0f / 60.0f, 60.0f, PERF_BALANCED, 4);
      CHECK(g.level == 0); }                                                                         // steady 60 fps wins detail back
    { Governor g; for (int i = 0; i < 200; i++) g.update(1.0f / 60.0f, 60.0f, PERF_BALANCED, 4); CHECK(g.level == 0); }   // never reacts when healthy
    { Governor g; g.update(2.0f, 60.0f, PERF_FPS, 4); CHECK(g.level == 0 && g.ema == 0); }          // a hitch is ignored
    CHECK(targetFpsFor(0, 144) == 60.0f && targetFpsFor(30, 60) == 30.0f && targetFpsFor(120, 60) == 60.0f);

    // ---- driver choice ----
    std::vector<std::string> dr = {"direct3d11", "opengl", "software"}, dv = {"opengl", "vulkan"}, dn = {"software"};
    CHECK(pickDriverIndex(API_AUTO, dr) == -1);
    CHECK(pickDriverIndex(API_OPENGL, dr) == 1);
    CHECK(pickDriverIndex(API_VULKAN, dr) == 1);        // no Vulkan driver: falls back to OpenGL
    CHECK(pickDriverIndex(API_VULKAN, dv) == 1);
    CHECK(pickDriverIndex(API_OPENGL, dn) == -1);
    CHECK(classifyDriver("opengles2") == ACTIVE_OPENGL && classifyDriver("vulkan") == ACTIVE_VULKAN && classifyDriver("metal") == ACTIVE_OTHER);

    // ---- the menu: there is no Graphics button or screen any more; the profile is fixed at the top setting ----
    gGfx = fixedGfx(); gfxChanged();
    CHECK(gGfx.rt && gGfx.quality == Q_ULTRA && gGfx.shadows && gGfx.ao && gGfx.reflections && gGfx.api == API_AUTO);
    gState = MAIN_MENU; navStack.clear(); trans = -1;
    gState = SETTINGS; buildUI();
    for (const Btn& b : btns) CHECK(strstr(b.label, "GRAPHICS") == nullptr && strstr(b.label, "LIGHTING") == nullptr);
    for (auto& b : btns) CHECK(b.y + b.h <= uvzWorldHeight);
    for (size_t i = 0; i < btns.size(); i++) for (size_t j = i + 1; j < btns.size(); j++) {   // no overlapping controls
        const Btn &a = btns[i], &b = btns[j];
        CHECK(a.x + a.w <= b.x || b.x + b.w <= a.x || a.y + a.h <= b.y || b.y + b.h <= a.y);
    }
    // a stale graphics.txt from an older version is ignored on load
    gGfx = defaults(); gGfx.quality = Q_LOW; gGfx.shadows = false; loadCfg();
    CHECK(gGfx == fixedGfx());
    // the settings that remain are still valid and resolve to the full effect on capable hardware
    gGfx = fixedGfx(); gGov.reset(); gfxRefresh(); CHECK(gFx.shadows && gFx.ao);
    gGfx = defaults(); gGfx.quality = 99; gGfx.api = -4; sanitize(gGfx); CHECK(gGfx.quality == Q_ULTRA && gGfx.api == API_AUTO);
    gGfx = fixedGfx();

    // ---- rendering every combination does not crash and stays inside the frame ----
    gState = PLAYING; P = Player(); P.alive = true; gMenuIdle = false;
    for (int mask = 0; mask < 32; mask++) for (int q = 0; q < Q_N; q++) {
        gGfx = defaults(); gGfx.rt = mask & 1; gGfx.shadows = mask & 2; gGfx.ao = mask & 4; gGfx.reflections = mask & 8; gGfx.perf = (mask >> 4) ? PERF_FPS : PERF_QUALITY; gGfx.quality = q;
        gGov.reset(); gfxRefresh();
        render(1.0 / 60);
    }
    gGfx = fixedGfx(); gfxRefresh(); gState = SETTINGS; navRoot = MAIN_MENU; render(1.0 / 60);
    printf("%d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
