#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
int main() {
    initFont(); uvzWindow = nullptr;
    const int sizes[][2] = {{1280,720},{1920,1080},{2400,1080},{2340,1080},{1600,720},{2560,1600},{1024,768},{800,600},{854,480},{3200,1440},{2960,1440},{1280,600},{4000,1080},{1080,2400},{2160,1080},{2520,1080},{3440,1440}};   // incl. 18:9, 21:9 and 21:9 ultrawide
    for (auto& z : sizes) {
        uvzOutputWidth = z[0]; uvzOutputHeight = z[1]; portrait = uvzOutputHeight > uvzOutputWidth;
        const int minD = std::min(uvzOutputWidth, uvzOutputHeight); uvzPixelScale = std::max(1, (int)lroundf(minD / 360.0f));
        uvzScaleX = uvzScaleY = (float)uvzPixelScale; uvzWorldWidth = (uvzOutputWidth + uvzPixelScale - 1) / uvzPixelScale; uvzWorldHeight = (uvzOutputHeight + uvzPixelScale - 1) / uvzPixelScale;
        uvzDisplayWidth = uvzWorldWidth * uvzPixelScale; uvzDisplayHeight = uvzWorldHeight * uvzPixelScale; uvzOffsetX = (uvzOutputWidth - uvzDisplayWidth) / 2; uvzOffsetY = (uvzOutputHeight - uvzDisplayHeight) / 2;
        CHECK(uvzScaleX == uvzScaleY && uvzPixelScale == (int)uvzPixelScale && uvzPixelScale >= 1);
        CHECK(uvzOffsetX <= 0 && uvzOffsetY <= 0 && uvzDisplayWidth >= uvzOutputWidth && uvzDisplayHeight >= uvzOutputHeight);
        CHECK(uvzDisplayWidth - uvzOutputWidth < uvzPixelScale && uvzDisplayHeight - uvzOutputHeight < uvzPixelScale);
        if (!portrait) CHECK(uvzWorldHeight >= 240 && uvzWorldHeight <= 480);
        if (!portrait) CHECK(uvzWorldHeight == (uvzOutputHeight + uvzPixelScale - 1) / uvzPixelScale);   // vertical world height is fixed by the screen height; only the width grows with the ratio
        float x, y; toInternal(0.5f, 0.5f, x, y); CHECK(fabsf(x - uvzWorldWidth / 2.0f) < 0.6f && fabsf(y - uvzWorldHeight / 2.0f) < 0.6f);
    }
    printf("[fit_screen] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
