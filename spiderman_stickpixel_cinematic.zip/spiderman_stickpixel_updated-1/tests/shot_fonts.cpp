// Preview renders of the font styles: g++ -std=c++17 -O1 -Itests/stub_gfx tests/shot_fonts.cpp -o /tmp/shotf && /tmp/shotf   (writes /tmp/shots/F_*.ppm)
#define main game_main
#include "../src/main.cpp"
#undef main
#include <sys/stat.h>
static void present() {
    SDL_SetRenderTarget(uvzRenderer, nullptr); SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255); SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight}; SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
}
static void dump(const char* name) {
    char p[160]; snprintf(p, sizeof p, "/tmp/shots/%s.ppm", name);
    FILE* f = fopen(p, "wb"); fprintf(f, "P6\n%d %d\n255\n", g_outW, g_outH);
    for (uint32_t c : g_screen) { unsigned char b[3] = {(unsigned char)(c >> 16), (unsigned char)(c >> 8), (unsigned char)c}; fwrite(b, 1, 3, f); }
    fclose(f);
}
int main() {
    mkdir("/tmp/shots", 0777); setenv("PCITY_PREF", "/tmp/pcity_f/", 1); if (system("mkdir -p /tmp/pcity_f")) {}
    g_outW = 960; g_outH = 540; g_screen.assign((size_t)g_outW * g_outH, 0xFF00FF00u);
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt(); startRun();
    // specimen
    SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
    SDL_SetRenderDrawBlendMode(uvzRenderer, SDL_BLENDMODE_BLEND);
    drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x10131F);
    static const char* nm[] = {"STD", "BOLD", "ITAL", "COMIC", "TINY", "LCD", "NEON", "LED"};
    for (int f = 0; f < FS_COUNT; f++) {
        const int rowH = (uvzWorldHeight - 8) / FS_COUNT, y = 6 + f * rowH;
        text(nm[f], 8, y + 8, 1, 0x8A93B5);
        const int sc = (rowH >= 40 && f == FS_LED) ? 3 : (rowH >= 30 ? 2 : 1);
        textF((FontStyle)f, "ABCDEFGHIJKLM 0123456789", 60, y, sc, f == FS_NEON ? 0xFF4F9A : 0xFFE9A0);
        textF((FontStyle)f, "NOPQRSTUVWXYZ .:-/!?+%", 60, y + 9 * sc + 3, sc, f == FS_NEON ? 0x4FE0FF : 0xBFD8FF);
    }
    present(); dump("F_specimen");
    // gameplay HUD with a combo on, then pop-ups
    gState = PLAYING; gTime = 10; gSkyTime = 20;
    for (int i = 0; i < 20; i++) { gTime += 0.016; updateGame(0.016); }
    gCombo.count = 7; gCombo.mult = 2.5f; gCombo.tier = 3; gCombo.awardT = 0.3f; gCombo.lastAward = 240; gCombo.lastKindShown = combo::STUNT;
    snprintf(gStuntName, sizeof gStuntName, "%s", "BACK FLIP");
    snprintf(gTrickMsg, sizeof gTrickMsg, "%s", "WEB ZIP +120"); gTrickMsgT = 1.0f; gTrickBad = false;
    gCombo.tierPop = 3; gCombo.tierPopT = 1.2f;
    P.vx = 600; P.vy = 100;
    for (int i = 0; i < 30; i++) { P.vx = 600; render(0.016); }
    present(); dump("F_hud");
    for (int sp : {200, 800, 1300, 2000}) { for (int i = 0; i < 30; i++) { P.vx = sp; render(0.016); } char nm[32]; snprintf(nm, sizeof nm, "F_gauge%d", sp); present(); dump(nm); }
    // menu + game over + pause
    gState = MAIN_MENU; for (int i = 0; i < 40; i++) { gTime += 0.016; render(0.016); } present(); dump("F_menu");
    gState = PAUSED; for (int i = 0; i < 40; i++) { gTime += 0.016; render(0.016); } present(); dump("F_pause");
    gState = GAME_OVER; P.alive = false; for (int i = 0; i < 40; i++) { gTime += 0.016; render(0.016); } present(); dump("F_gameover");
    return 0;
}
