// Pixel-level before/after check: software-renders (tests/stub rasteriser: g_blit) real gameplay frames (bot run + a speed ramp that sweeps the gauge and the zoom path)
// and prints a hash of the final screen for every Nth frame. Build once against the old source and once against the new, then diff.
//   g++ -std=c++17 -O1 -w -Itests/stub -DMAIN_SRC='"../src/main.cpp"' tests/frame_hash.cpp -o /tmp/fh && /tmp/fh > hashes.txt
#define main game_main
#include MAIN_SRC
#undef main
static uint64_t hashScreen() { uint64_t h = 1469598103934665603ull; for (uint8_t c : g_fb) { h ^= c; h *= 1099511628211ull; } return h; }
int main() {
    if (system("rm -rf /tmp/pcity_fh && mkdir -p /tmp/pcity_fh")) return 2;
    setenv("PCITY_PREF", "/tmp/pcity_fh/", 1);
    g_blit = true;   // keep texture pixels and let RenderCopy / FillRect paint into g_fb
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();
    int frame = 0; uint64_t all = 1469598103934665603ull; int n = 0;
    auto snap = [&](const char* tag) { const uint64_t h = hashScreen(); all ^= h; all *= 1099511628211ull; n++; printf("%s %04d %016llx\n", tag, frame, (unsigned long long)h); };
    for (unsigned seed = 1; seed <= 3; seed++) {   // bot-driven gameplay
        gProg = prog::Data(); startRun(); bld.clear(); wrng = Rng(seed * 7919u); addBuilding(true);
        P.x = 200; P.y = -26; P.px = P.x; P.py = P.y; startX = P.x; camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); gState = PLAYING; swingWas = false; gTime = 0;
        float relT = 0;
        for (int i = 0; i < 60 * 14; i++) {
            gTime += 1.0 / 60; bool want = false;
            if (P.alive) {
                if (P.onGround) { for (auto& c : trafficCars) { const float d = c.x - c.width * 0.5f - P.x; if (d > 0 && d < 150) jumpEdge = true; } }
                else { want = (P.swinging || P.webFlying) ? true : ((i / 4) % 2 == 0);
                       if (P.swinging) { const float rope = std::max(P.rope, 1.0f); if (P.x - P.ax > 0.55f * rope && P.vy < 0) relT = 0.22f; }
                       if (relT > 0) { relT -= 1.0f / 60; want = false; } }
            }
            tch[0] = Touch(); tch[0].on = want; tch[0].role = R_SWING;
            updateGame(1.0 / 60); camX = P.x - uvzWorldWidth * 0.30f; ensureWorld(); ensureTraffic(); render(1.0 / 60); frame++;
            if (i % 12 == 0) snap("bot");
            if (!P.alive && P.deadT > 1.2f) break;
        }
    }
    // speed ramp: empty sky, velocity 0 -> 2400 -> 0, so the gauge lights up and falls and the camera zoom engages
    gState = PLAYING; P = Player(); P.alive = true; P.onGround = false; gZoom = 1.0f; cfg.reduced = false;
    bld.clear(); { Building b; b.x = -3000; b.w = 12000; b.roofY = 20000; b.style = 0; b.seed = 1; bld.push_back(b); }
    camX = -uvzWorldWidth * 0.3f; camY = -3000 - uvzWorldHeight * 0.58f;
    for (int i = 0; i < 480; i++) {
        const float v = i < 240 ? 10.0f * i : 10.0f * (480 - i);
        P.vx = v; P.vy = 0; P.x = 0; P.y = -3000; P.px = 0; P.py = -3000; gTime += 1.0 / 60; updateGame(1.0 / 60); render(1.0 / 60); frame++;
        if (i % 10 == 0) snap("ramp");
    }
    printf("TOTAL %d snapshots, combined %016llx\n", n, (unsigned long long)all);
    return 0;
}
