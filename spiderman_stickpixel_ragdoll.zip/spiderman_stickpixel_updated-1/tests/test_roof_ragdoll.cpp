// Fall damage on vehicle roofs (same classes as the street, softened by ROOF_CUSHION), the death ragdoll, and NPC size = player size.
#define main game_main
#include "../src/main.cpp"
#undef main
static int fails = 0, checks = 0;
#define CHECK(c) do { checks++; if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static TrafficCar mkCar(float x, int dir, int type, float speed) {
    TrafficCar c; c.x = x; c.speed = speed; c.maxSpeed = speed; c.width = trafficWidth(type); c.height = trafficHeight(type);
    c.type = type; c.dir = dir; c.lane = dir > 0 ? 0 : 1; c.color = 0xD0B040; c.id = 1000 + type * 10 + (dir > 0 ? 0 : 1); return c;
}
static void blank() {
    bld.clear(); trafficCars.clear(); trafficSignals.clear(); nextTrafficSpawnX = 1e9f; addBuilding(true);
    P = Player(); P.alive = true; steer = 0; swingHeld = false; jumpEdge = slideEdge = jumpRel = false; gImpactT = 0; gState = PLAYING; gTime = 100; gSafeLandUntil = 0; gRag.on = false;
    gTrickMsg[0] = 0; gTrickMsgT = 0;
}
static void step(int n) { for (int i = 0; i < n; i++) { updateTraffic(1.0f / 120); stepPhysics(1.0f / 120); } }
// Drop onto a parked car's roof from `h` px above it.
static void dropOnRoof(float h) {
    blank(); trafficCars.push_back(mkCar(1400, 1, 0, 0.0f));
    const float top = carTopY(trafficCars[0]);
    P.x = 1400; P.y = top - 26.0f - h; P.px = P.x; P.py = P.y; P.vx = 0; P.vy = 0; P.onGround = false; P.groundedPrev = false;
}
int main() {
    setenv("PCITY_PREF", "/tmp/pcity_t/", 1); system("mkdir -p /tmp/pcity_t");
    loadCfg(); loadControls(); initFont(); recalculateDisplayLayout(); buildArt();

    dropOnRoof(100); step(100);                                   // short drop: free
    CHECK(P.alive && P.onGround && P.rideId >= 0 && strcmp(gTrickMsg, "HARD LANDING") != 0);
    dropOnRoof(480); step(140);                                   // ~2.5 storeys: hurts, survives
    CHECK(P.alive && P.onGround && strcmp(gTrickMsg, "HARD LANDING") == 0);
    dropOnRoof(1500); step(240);                                  // huge drop: fatal on a roof too
    CHECK(!P.alive && gRag.on);
    step(400);                                                    // the ragdoll settles on the roof, not through it
    {
        const float top = carTopY(trafficCars[0]);
        float maxY = -1e9f; for (int i = 0; i < J_N; i++) maxY = std::max(maxY, gRag.y[i]);
        CHECK(maxY <= top + 0.5f);
        CHECK(fabsf(gRag.x[J_HIP] - trafficCars[0].x) < trafficCars[0].width);
        float spread = 0; for (int i = 0; i < J_N; i++) spread = std::max(spread, hypotf(gRag.x[i] - gRag.x[J_HIP], gRag.y[i] - gRag.y[J_HIP]));
        CHECK(spread < 40.0f);                                    // bones stayed connected
        float v = 0; for (int i = 0; i < J_N; i++) v = std::max(v, hypotf(gRag.x[i] - gRag.px[i], gRag.y[i] - gRag.py[i]));
        CHECK(v < 1.0f);                                          // at rest
    }
    // A roll (slide buffered) turns a fatal-on-the-edge roof drop into a survivable one.
    dropOnRoof(800); step(200); CHECK(!P.alive);                  // without a roll this drop is fatal
    dropOnRoof(800); for (int i = 0; i < 200; i++) { P.slideBuf = 1.0f; step(1); } CHECK(P.alive);
    // Street death: ragdoll starts, falls/tumbles, ends up lying on the street.
    blank(); P.x = 1400; P.y = -1500; P.px = P.x; P.py = P.y; P.vx = 200; P.vy = 0; P.onGround = false; P.groundedPrev = false;
    for (int i = 0; i < 400 && P.alive; i++) stepPhysics(1.0f / 120);
    CHECK(!P.alive && gRag.on && P.deadGround);
    step(360);
    { float maxY = -1e9f, minY = 1e9f; for (int i = 0; i < J_N; i++) { maxY = std::max(maxY, gRag.y[i]); minY = std::min(minY, gRag.y[i]); }
      CHECK(maxY <= STREET_GROUND_Y + 0.5f); CHECK(minY > STREET_GROUND_Y - 30.0f); }   // lying down, not standing
    // Air death (hit a wall): ragdoll starts with momentum and falls to the street.
    blank(); P.x = 1400; P.y = -400; P.px = P.x; P.py = P.y; P.vx = 400; P.vy = 0; P.onGround = false;
    killPlayer(); CHECK(gRag.on && !P.alive);
    step(600);
    { float maxY = -1e9f; for (int i = 0; i < J_N; i++) maxY = std::max(maxY, gRag.y[i]); CHECK(maxY <= STREET_GROUND_Y + 0.5f && P.x > 1400); }
    // Restart clears the ragdoll.
    startRun(false); CHECK(!gRag.on && P.alive);
    // NPCs are the runner's size.
    for (int c = -5; c < 5; c++) for (int k = 0; k < 3; k++) { const Walker w = walkerAt(c, k, 12.0f); CHECK(w.scale == 1.0f); }
    printf("[roof_ragdoll] %d checks, %d failed\n", checks, fails);
    return fails ? 1 : 0;
}
