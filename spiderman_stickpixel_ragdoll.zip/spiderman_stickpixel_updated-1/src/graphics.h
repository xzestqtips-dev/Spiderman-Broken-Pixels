#pragma once
// Graphics settings: ray-traced lighting for the 2D side-scroller, hardware detection, automatic optimisation.
//
// "Dynamic lighting" here is a CPU/fill-rate friendly 2D version: rays are marched through the skyline height-field to get soft sun / moon shadows,
// roof-corner ambient occlusion and planar street reflections. It runs on any SDL_Renderer backend, so there is no RT hardware requirement.
// This header is pure logic (no SDL calls), so the headless tests can drive it directly.
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace gfxcfg {

enum Api { API_AUTO = 0, API_OPENGL, API_VULKAN, API_N };
enum Quality { Q_LOW = 0, Q_MEDIUM, Q_HIGH, Q_ULTRA, Q_N };
enum Perf { PERF_FPS = 0, PERF_BALANCED, PERF_QUALITY, PERF_N };

static const char* const API_NAME[API_N] = {"AUTO", "OPENGL", "VULKAN"};
static const char* const QUALITY_NAME[Q_N] = {"LOW", "MEDIUM", "HIGH", "ULTRA"};
static const char* const PERF_NAME[PERF_N] = {"PRIORITIZE FPS", "BALANCED", "PRIORITIZE QUALITY"};

struct Settings {
    bool rt = true;
    int api = API_AUTO;
    int quality = Q_MEDIUM;
    bool shadows = true, ao = true, reflections = true;
    int perf = PERF_BALANCED;
    bool operator==(const Settings& o) const {
        return rt == o.rt && api == o.api && quality == o.quality && shadows == o.shadows && ao == o.ao && reflections == o.reflections && perf == o.perf;
    }
};
inline Settings defaults() { return Settings(); }
inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline void sanitize(Settings& s) {
    s.api = clampi(s.api, 0, API_N - 1); s.quality = clampi(s.quality, 0, Q_N - 1); s.perf = clampi(s.perf, 0, PERF_N - 1);
}

// ---- Hardware ---------------------------------------------------------------------------------------------
enum ActiveApi { ACTIVE_OTHER = 0, ACTIVE_OPENGL, ACTIVE_VULKAN, ACTIVE_SOFTWARE };
struct Caps {
    bool accelerated = true, targetTextures = true;
    bool hasOpenGL = true, hasVulkan = false;   // render drivers this SDL build offers
    int active = ACTIVE_OPENGL;                 // the backend the running renderer actually uses
    int maxTexture = 8192, cpus = 4, ramMB = 4096;
    bool mobile = false;
    char renderer[24] = "opengl";
    int score = 60;                             // 0..100, higher is stronger (scoreCaps() fills it from the fields above)
};
// Backend names from SDL_RendererInfo::name.
inline int classifyDriver(const char* name) {
    if (!name) return ACTIVE_OTHER;
    if (!strcmp(name, "software")) return ACTIVE_SOFTWARE;
    if (!strcmp(name, "vulkan")) return ACTIVE_VULKAN;
    if (!strncmp(name, "opengl", 6)) return ACTIVE_OPENGL;   // opengl, opengles, opengles2
    return ACTIVE_OTHER;                                    // direct3d*, metal, ...
}
inline void scoreCaps(Caps& c) {
    int s = 0;
    s += c.accelerated ? 40 : 0;
    s += c.hasVulkan ? 8 : 0;
    s += c.maxTexture >= 16384 ? 12 : (c.maxTexture >= 8192 ? 9 : (c.maxTexture >= 4096 ? 5 : 0));
    s += c.cpus >= 8 ? 18 : (c.cpus >= 4 ? 11 : (c.cpus >= 2 ? 5 : 0));
    s += c.ramMB >= 8192 ? 18 : (c.ramMB >= 4096 ? 11 : (c.ramMB >= 2048 ? 5 : 0));
    if (c.mobile) s -= 12;
    if (c.active == ACTIVE_SOFTWARE || !c.accelerated) s = std::min(s, 15);
    c.score = clampi(s, 0, 100);
}
inline int maxQualityFor(const Caps& c) { return c.score >= 75 ? Q_ULTRA : (c.score >= 55 ? Q_HIGH : (c.score >= 35 ? Q_MEDIUM : Q_LOW)); }
inline bool rtSupported(const Caps& c, const char** why = nullptr) {
    if (c.active == ACTIVE_SOFTWARE || !c.accelerated) { if (why) *why = "NEEDS A GPU RENDERER"; return false; }
    if (!c.targetTextures) { if (why) *why = "NEEDS RENDER TARGETS"; return false; }
    if (c.score < 30) { if (why) *why = "DEVICE TOO SLOW"; return false; }
    return true;
}
inline bool apiSupported(int api, const Caps& c) { return api == API_AUTO || (api == API_OPENGL && c.hasOpenGL) || (api == API_VULKAN && c.hasVulkan); }
// Which backend a request resolves to for the NEXT launch (Vulkan falls back to OpenGL, then to whatever SDL prefers).
inline int resolveApi(int api, const Caps& c) {
    if (api == API_VULKAN && c.hasVulkan) return ACTIVE_VULKAN;
    if ((api == API_VULKAN || api == API_OPENGL) && c.hasOpenGL) return ACTIVE_OPENGL;
    return ACTIVE_OTHER;   // AUTO (or nothing better): SDL's own choice, i.e. the current backend
}
// Index into the SDL render driver list for the renderer to create at start-up, -1 = let SDL choose.
inline int pickDriverIndex(int api, const std::vector<std::string>& names) {
    auto find = [&](const char* n) { for (size_t i = 0; i < names.size(); i++) if (names[i] == n) return (int)i; return -1; };
    if (api == API_VULKAN) { int i = find("vulkan"); if (i >= 0) return i; api = API_OPENGL; }
    if (api == API_OPENGL) { int i = find("opengl"); if (i < 0) i = find("opengles2"); return i; }
    return -1;
}

// ---- Quality tables -----------------------------------------------------------------------------------------
struct Params {
    int steps;      // ray-march steps through the skyline (x 8 px of reach)
    int penumbra;   // shadow rays per column (soft edges)
    int colStep;    // pixel width of one shaded column
    int aoRays, aoReach;
    int bands;      // gradient bands for AO / reflections
};
inline Params paramsFor(int q) {
    static const Params T[Q_N] = {{20, 1, 8, 3, 24, 2}, {36, 3, 6, 5, 32, 3}, {56, 3, 4, 7, 40, 5}, {80, 5, 2, 9, 48, 8}};
    return T[clampi(q, 0, Q_N - 1)];
}

// ---- Effective settings (what is really drawn) --------------------------------------------------------------
struct Effective {
    bool rt = false;           // ray-marched path available and on
    bool shadows = false, rtShadows = false;
    bool ao = false, rtAo = false;
    bool reflections = false;
    int quality = Q_LOW;
    Params p = paramsFor(Q_LOW);
    int governor = 0;          // automatic reduction currently applied (0 = none)
};
struct Warnings {
    static const int MAX = 5;
    char line[MAX][64]; int n = 0;
    bool restartNeeded = false;
    void add(const char* s) { if (n < MAX) { snprintf(line[n], sizeof line[n], "%s", s); n++; } }
    bool has(const char* sub) const { for (int i = 0; i < n; i++) if (strstr(line[i], sub)) return true; return false; }
};
inline int maxGovernorLevel(int perf) { return perf == PERF_QUALITY ? 2 : 4; }

// Combines the player's choices, the hardware limits and the governor's reduction. Also builds the warning list for the menu.
inline Effective resolve(const Settings& in, const Caps& caps, int governor, Warnings* w = nullptr) {
    Settings s = in; sanitize(s);
    Effective e;
    const char* why = nullptr;
    const bool rtOk = rtSupported(caps, &why);
    e.rt = s.rt && rtOk;
    int q = s.quality;
    const int hw = maxQualityFor(caps);
    if (q > hw) { q = hw; if (w && e.rt) { char b[64]; snprintf(b, sizeof b, "QUALITY LIMITED TO %s BY HARDWARE", QUALITY_NAME[hw]); w->add(b); } }
    if (s.perf == PERF_FPS) q = std::max((int)Q_LOW, q - 1);
    if (s.perf == PERF_FPS && s.quality == Q_ULTRA && q > Q_HIGH) q = Q_HIGH;
    int g = clampi(governor, 0, maxGovernorLevel(s.perf));
    // governor ladder: 1-2 quality tiers down, 3 reflections off, 4 AO off + basic shadows
    q = std::max((int)Q_LOW, q - std::min(g, 2));
    e.governor = g;
    e.quality = q; e.p = paramsFor(q);
    e.shadows = s.shadows;
    e.rtShadows = s.shadows && e.rt && g < 4;
    e.ao = s.ao && g < 4;
    e.rtAo = e.ao && e.rt;
    e.reflections = s.reflections && e.rt && g < 3;
    if (w) {
        if (s.rt && !rtOk) { char b[64]; snprintf(b, sizeof b, "DYNAMIC LIGHTING UNAVAILABLE: %s", why ? why : "UNSUPPORTED"); w->add(b); }
        if (!s.rt && s.reflections) w->add("REFLECTIONS NEED DYNAMIC LIGHTING");
        if (s.api != API_AUTO && !apiSupported(s.api, caps)) {
            char b[64]; snprintf(b, sizeof b, "%s NOT AVAILABLE ON THIS DEVICE", API_NAME[s.api]); w->add(b);
        }
        const int next = resolveApi(s.api, caps);
        if (s.api != API_AUTO && next != ACTIVE_OTHER && next != caps.active) { w->add("API CHANGE APPLIES ON NEXT LAUNCH"); w->restartNeeded = true; }
        else if (s.api != API_AUTO && next == ACTIVE_OTHER && caps.active != ACTIVE_OPENGL && caps.active != ACTIVE_VULKAN) { /* nothing better exists: stay put */ }
        if (g > 0) w->add("AUTO-TUNING ACTIVE: DETAIL REDUCED FOR FPS");
    }
    return e;
}

// ---- Automatic optimisation ---------------------------------------------------------------------------------
// Watches real frame times while playing. It lowers the effect level when the frame rate stays under target, and later probes one step back up;
// a probe that fails soon after backs the next attempt off, so it never flaps. Prioritize FPS reacts fast, Prioritize Quality reacts late.
struct Governor {
    int level = 0;
    float ema = 0;            // smoothed frame time, seconds
    float slowT = 0;          // time spent over budget
    float calmT = 0;          // time spent at the current level without trouble
    float probeDelay = 10.0f; // calm time required before trying a higher level
    float sinceUp = 99.0f;    // time since the last probe upward
    void reset() { *this = Governor(); }
    // raw frame time in seconds (not clamped); returns true if the level changed
    bool update(float dt, float targetFps, int perf, int maxLevel) {
        if (dt <= 0 || dt > 0.5f) return false;   // hitches (window drag, load) are not evidence
        const float budget = 1.0f / std::max(20.0f, targetFps);
        ema = ema <= 0 ? dt : ema + (dt - ema) * 0.12f;
        const float over = perf == PERF_FPS ? 1.08f : (perf == PERF_QUALITY ? 1.40f : 1.18f);
        const float need = perf == PERF_FPS ? 0.6f : (perf == PERF_QUALITY ? 2.5f : 1.2f);
        sinceUp += dt;
        if (ema > budget * over) { slowT += dt; calmT = 0; } else { slowT = std::max(0.0f, slowT - dt * 0.5f); calmT += dt; }
        if (slowT >= need && level < maxLevel) {
            if (sinceUp < 5.0f) probeDelay = std::min(90.0f, probeDelay * 2.0f);   // the last step up did not hold
            level++; slowT = 0; calmT = 0; ema = budget; return true;
        }
        if (level > 0 && calmT >= probeDelay) { level--; calmT = 0; slowT = 0; sinceUp = 0; return true; }
        if (level > maxLevel) { level = maxLevel; return true; }
        return false;
    }
};
inline float targetFpsFor(int fpsCap, int displayHz) {
    int hz = displayHz > 0 ? displayHz : 60;
    int t = fpsCap > 0 ? std::min(fpsCap, hz) : hz;
    return (float)clampi(t, 30, 60);
}

// ---- Persistence --------------------------------------------------------------------------------------------
inline bool saveFile(const std::string& path, const Settings& s) {
    FILE* f = fopen(path.c_str(), "w");
    if (!f) return false;
    fprintf(f, "1 %d %d %d %d %d %d %d\n", s.rt, s.api, s.quality, s.shadows, s.ao, s.reflections, s.perf);
    fclose(f);
    return true;
}
inline bool loadFile(const std::string& path, Settings& s) {
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return false;
    int ver, rt, api, q, sh, ao, rf, pf;
    const bool ok = fscanf(f, "%d %d %d %d %d %d %d %d", &ver, &rt, &api, &q, &sh, &ao, &rf, &pf) == 8 && ver == 1;
    fclose(f);
    if (!ok) return false;
    s.rt = rt != 0; s.api = api; s.quality = q; s.shadows = sh != 0; s.ao = ao != 0; s.reflections = rf != 0; s.perf = pf;
    sanitize(s);
    return true;
}

}  // namespace gfxcfg
