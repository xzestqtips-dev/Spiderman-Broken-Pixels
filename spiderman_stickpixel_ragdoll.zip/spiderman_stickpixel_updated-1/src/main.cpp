#include <SDL.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <deque>
#include <string>
#include <unordered_map>
#include <vector>

#include "progression.h"
#include "combo.h"
#include "difficulty.h"
#include "falldamage.h"
#include "npc.h"
#include "audio.h"
#include "graphics.h"
#include "png.h"
#include "chunks.h"
#include "facade_tiles.h"
#include "pool.h"

typedef uint32_t u32;
static const float pi = 3.14159265f;
static float clampValue(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static float lerpValue(float a, float b, float t) { return a + (b - a) * t; }
static int clampInt(int v, int a, int b) { return v < a ? a : (v > b ? b : v); }
static int positiveModulo(int a, int m) { a %= m; return a < 0 ? a + m : a; }
static u32 hashCoordinates(u32 a, u32 b, u32 c) {
    u32 h = a * 374761393u + b * 668265263u + c * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}
struct Rng {
    u32 s;
    explicit Rng(u32 seed = 1) : s(seed ? seed : 1) {}
    u32 next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float f() { return (next() & 0xFFFFFF) / 16777216.0f; }
    int range(int a, int b) { if (b < a) b = a; return a + (int)(f() * (b - a + 1)); }
};

static SDL_Window* uvzWindow = nullptr;
static SDL_Renderer* uvzRenderer = nullptr;
static SDL_Texture* uvzRenderTarget = nullptr;
static SDL_Texture* uvzZoomTex = nullptr;   // oversized scratch target used only while the camera is pulled back
static float gZoom = 1.0f;                  // 1 = normal framing, ~0.9 = pulled back at speed
static const float ZOOM_MIN = 0.88f;         // scratch-texture size limit: never zoom out further than this
// Speed-driven pull-back (all in world px/s): no zoom below ZOOM_SPEED_START, full pull-back (ZOOM_FAR) at ZOOM_SPEED_FULL.
static const float ZOOM_FAR = 0.90f, ZOOM_SPEED_START = 800.0f, ZOOM_SPEED_FULL = 1800.0f;
static const float ZOOM_OUT_RATE = 2.5f, ZOOM_IN_RATE = 1.8f;   // lerp rates (1/s): easing out as speed builds / easing back in when slowing
static int uvzOutputWidth = 1280, uvzOutputHeight = 720;
static int uvzWorldWidth = 640, uvzWorldHeight = 360, uvzPixelScale = 3;
static int uvzBaseW = 640, uvzBaseH = 360;   // un-zoomed world size (the sky is built once at this size and stretched while the camera pulls back)
static int uvzOffsetX = 0, uvzOffsetY = 0;
static float uvzScaleX = 3.0f, uvzScaleY = 3.0f;
static int uvzDisplayWidth = 1280, uvzDisplayHeight = 720;
static bool portrait = false;
static float uvzSafeLeft = 14, uvzSafeRight = 14, uvzSafeTop = 8, uvzSafeBottom = 10;
static float uvzMinimumTouchSize = 40;

#ifdef __ANDROID__
#include <jni.h>
// Real display-cutout / rounded-corner / gesture-bar insets in physical pixels (0 when unknown).
static bool androidSafeInsets(float& l, float& t, float& r, float& b) {
    l = t = r = b = 0;
    JNIEnv* env = (JNIEnv*)SDL_AndroidGetJNIEnv();
    if (!env) return false;
    // Every jclass / jobject below is a JNI local reference. This runs on the native SDL thread (never returns to Java between calls), so
    // without a frame they pile up on every relayout until the 512-entry local reference table overflows and the VM aborts.
    if (env->PushLocalFrame(32) < 0) { env->ExceptionClear(); return false; }
    jobject act = (jobject)SDL_AndroidGetActivity();
    bool ok = false;
    do {
        if (!act) break;
        jclass cAct = env->GetObjectClass(act);
        jobject win = env->CallObjectMethod(act, env->GetMethodID(cAct, "getWindow", "()Landroid/view/Window;"));
        if (env->ExceptionCheck() || !win) break;
        jobject dec = env->CallObjectMethod(win, env->GetMethodID(env->GetObjectClass(win), "getDecorView", "()Landroid/view/View;"));
        if (env->ExceptionCheck() || !dec) break;
        jobject ins = env->CallObjectMethod(dec, env->GetMethodID(env->GetObjectClass(dec), "getRootWindowInsets", "()Landroid/view/WindowInsets;"));
        if (env->ExceptionCheck() || !ins) break;
        jclass cIns = env->GetObjectClass(ins);
        const int sdk = SDL_GetAndroidSDKVersion();
        if (sdk >= 28) {
            jobject cut = env->CallObjectMethod(ins, env->GetMethodID(cIns, "getDisplayCutout", "()Landroid/view/DisplayCutout;"));
            if (!env->ExceptionCheck() && cut) {
                jclass cC = env->GetObjectClass(cut);
                l = (float)env->CallIntMethod(cut, env->GetMethodID(cC, "getSafeInsetLeft", "()I"));
                t = (float)env->CallIntMethod(cut, env->GetMethodID(cC, "getSafeInsetTop", "()I"));
                r = (float)env->CallIntMethod(cut, env->GetMethodID(cC, "getSafeInsetRight", "()I"));
                b = (float)env->CallIntMethod(cut, env->GetMethodID(cC, "getSafeInsetBottom", "()I"));
            }
        }
        if (sdk >= 29) {   // bottom gesture bar (the left/right gesture strips are left alone so the HUD is not pushed far in)
            jobject g = env->CallObjectMethod(ins, env->GetMethodID(cIns, "getSystemGestureInsets", "()Landroid/graphics/Insets;"));
            if (!env->ExceptionCheck() && g) {
                jclass cG = env->GetObjectClass(g);
                b = std::max(b, (float)env->GetIntField(g, env->GetFieldID(cG, "bottom", "I")));
            }
        }
        ok = true;
    } while (0);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->PopLocalFrame(nullptr);   // releases act and every reference created inside the frame
    return ok;
}
#endif
static void recalculateDisplayLayout() {
    SDL_GetRendererOutputSize(uvzRenderer, &uvzOutputWidth, &uvzOutputHeight);
    portrait = uvzOutputHeight > uvzOutputWidth;
    const int minD = std::min(uvzOutputWidth, uvzOutputHeight);
    uvzPixelScale = std::max(1, (int)lroundf(minD / 360.0f));

    uvzScaleX = uvzScaleY = (float)uvzPixelScale;
    uvzWorldWidth = std::max(1, (uvzOutputWidth + uvzPixelScale - 1) / uvzPixelScale); uvzWorldHeight = std::max(1, (uvzOutputHeight + uvzPixelScale - 1) / uvzPixelScale);
    uvzBaseW = uvzWorldWidth; uvzBaseH = uvzWorldHeight;
    uvzDisplayWidth = uvzWorldWidth * uvzPixelScale; uvzDisplayHeight = uvzWorldHeight * uvzPixelScale;
    uvzOffsetX = (uvzOutputWidth - uvzDisplayWidth) / 2; uvzOffsetY = (uvzOutputHeight - uvzDisplayHeight) / 2;
    {   // relayout also fires on focus / expose (always on Android): keep the existing targets when the world size is unchanged
        static int zoomW = -1, zoomH = -1, targetW = -1, targetH = -1;
        const int zw = (int)ceilf(uvzWorldWidth / ZOOM_MIN) + 2, zh = (int)ceilf(uvzWorldHeight / ZOOM_MIN) + 2;
        if (!uvzZoomTex || zw != zoomW || zh != zoomH) {
            if (uvzZoomTex) SDL_DestroyTexture(uvzZoomTex);
            SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");   // the pull-back is a down-scale, so it is the one place that filters
            uvzZoomTex = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, zw, zh);
            SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
            zoomW = zw; zoomH = zh;
        }
        if (!uvzRenderTarget || uvzWorldWidth != targetW || uvzWorldHeight != targetH) {
            if (uvzRenderTarget) SDL_DestroyTexture(uvzRenderTarget);
            uvzRenderTarget = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, uvzWorldWidth, uvzWorldHeight);
            targetW = uvzWorldWidth; targetH = uvzWorldHeight;
        }
    }
    uvzSafeLeft = uvzSafeRight = std::max(14.0f, uvzWorldWidth * ((float)uvzOutputWidth / std::max(1, uvzOutputHeight) > 2.0f ? 0.05f : 0.035f));   // extra side margin on long phones (notch / rounded corners)
    uvzSafeTop = 8; uvzSafeBottom = 10;
#ifdef __ANDROID__
    {   // anchor the HUD inside the real notch / rounded-corner / gesture-bar insets (+ a small margin for rounded corners)
        float il, it, ir, ib;
        if (androidSafeInsets(il, it, ir, ib)) {
            uvzSafeLeft = std::max(uvzSafeLeft, il / uvzScaleX + 8.0f);
            uvzSafeRight = std::max(uvzSafeRight, ir / uvzScaleX + 8.0f);
            uvzSafeTop = std::max(uvzSafeTop, it / uvzScaleY + 6.0f);
            uvzSafeBottom = std::max(uvzSafeBottom, ib / uvzScaleY + 6.0f);
        }
    }
#endif
    float ddpi = 0;
    if (SDL_GetDisplayDPI(0, &ddpi, nullptr, nullptr) != 0 || ddpi < 80) ddpi = 400;
    uvzMinimumTouchSize = clampValue(48.0f * ddpi / 160.0f / uvzScaleY, 36.0f, 56.0f);
}

static void setDrawColor(u32 c, int a = 255) {
    SDL_SetRenderDrawColor(uvzRenderer, (c >> 16) & 255, (c >> 8) & 255, c & 255, (Uint8)a);
}
static void drawFilledRect(int x, int y, int w, int h, u32 c, int a = 255) {
    if (w <= 0 || h <= 0) return;
    setDrawColor(c, a);
    SDL_Rect r = {x, y, w, h};
    SDL_RenderFillRect(uvzRenderer, &r);
}
static void drawDisc(int cx, int cy, int r, u32 c, int a = 255) {
    // scanlines never overlap, so they go out as one batched fill with the same colour/alpha (pixel-identical to one call per row)
    static std::vector<SDL_Rect> rows; rows.clear();
    for (int dy = -r; dy <= r; dy++) {
        int dx = (int)sqrtf((float)(r * r - dy * dy));
        rows.push_back({cx - dx, cy + dy, dx * 2 + 1, 1});
    }
    if (rows.empty()) return;
    setDrawColor(c, a);
    SDL_RenderFillRects(uvzRenderer, rows.data(), (int)rows.size());
}
static void drawLine(float x0, float y0, float x1, float y1, u32 c, int a = 255) {
    setDrawColor(c, a);
    SDL_RenderDrawLine(uvzRenderer, (int)x0, (int)y0, (int)x1, (int)y1);
}

struct Glyph { char c; uint8_t r[7]; };
static const Glyph fontGlyphs[] = {
    {'A',{0x0E,0x11,0x11,0x1F,0x11,0x11,0x11}}, {'B',{0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E}},
    {'C',{0x0E,0x11,0x10,0x10,0x10,0x11,0x0E}}, {'D',{0x1E,0x11,0x11,0x11,0x11,0x11,0x1E}},
    {'E',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}}, {'F',{0x1F,0x10,0x10,0x1E,0x10,0x10,0x10}},
    {'G',{0x0E,0x11,0x10,0x17,0x11,0x11,0x0F}}, {'H',{0x11,0x11,0x11,0x1F,0x11,0x11,0x11}},
    {'I',{0x0E,0x04,0x04,0x04,0x04,0x04,0x0E}}, {'J',{0x07,0x02,0x02,0x02,0x02,0x12,0x0C}},
    {'K',{0x11,0x12,0x14,0x18,0x14,0x12,0x11}}, {'L',{0x10,0x10,0x10,0x10,0x10,0x10,0x1F}},
    {'M',{0x11,0x1B,0x15,0x15,0x11,0x11,0x11}}, {'N',{0x11,0x11,0x19,0x15,0x13,0x11,0x11}},
    {'O',{0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'P',{0x1E,0x11,0x11,0x1E,0x10,0x10,0x10}},
    {'Q',{0x0E,0x11,0x11,0x11,0x15,0x12,0x0D}}, {'R',{0x1E,0x11,0x11,0x1E,0x14,0x12,0x11}},
    {'S',{0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E}}, {'T',{0x1F,0x04,0x04,0x04,0x04,0x04,0x04}},
    {'U',{0x11,0x11,0x11,0x11,0x11,0x11,0x0E}}, {'V',{0x11,0x11,0x11,0x11,0x11,0x0A,0x04}},
    {'W',{0x11,0x11,0x11,0x15,0x15,0x15,0x0A}}, {'X',{0x11,0x11,0x0A,0x04,0x0A,0x11,0x11}},
    {'Y',{0x11,0x11,0x11,0x0A,0x04,0x04,0x04}}, {'Z',{0x1F,0x01,0x02,0x04,0x08,0x10,0x1F}},
    {'0',{0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}}, {'1',{0x04,0x0C,0x04,0x04,0x04,0x04,0x0E}},
    {'2',{0x0E,0x11,0x01,0x02,0x04,0x08,0x1F}}, {'3',{0x1F,0x02,0x04,0x02,0x01,0x11,0x0E}},
    {'4',{0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}}, {'5',{0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E}},
    {'6',{0x06,0x08,0x10,0x1E,0x11,0x11,0x0E}}, {'7',{0x1F,0x01,0x02,0x04,0x08,0x08,0x08}},
    {'8',{0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}}, {'9',{0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C}},
    {'.',{0,0,0,0,0,0x0C,0x0C}}, {':',{0,0x0C,0x0C,0,0x0C,0x0C,0}},
    {'-',{0,0,0,0x1F,0,0,0}}, {'/',{0x01,0x02,0x02,0x04,0x08,0x08,0x10}},
    {'!',{0x04,0x04,0x04,0x04,0x04,0,0x04}}, {'?',{0x0E,0x11,0x01,0x02,0x04,0,0x04}},
    {'+',{0,0x04,0x04,0x1F,0x04,0x04,0}}, {'%',{0x19,0x19,0x02,0x04,0x08,0x13,0x13}}, {',',{0,0,0,0,0x0C,0x04,0x08}},
    {'<',{0x02,0x04,0x08,0x10,0x08,0x04,0x02}}, {'>',{0x08,0x04,0x02,0x01,0x02,0x04,0x08}},
};
static uint8_t gGl[128][7];
static void buildFontSets();   // the extra font styles (see "font styles" below)
static void initFont() {
    memset(gGl, 0, sizeof(gGl));
    for (const Glyph& g : fontGlyphs) memcpy(gGl[(int)g.c], g.r, 7);
    buildFontSets();
}
static int measureTextWidth(const char* s, int sc) { return (int)strlen(s) * 6 * sc - sc; }
static bool sprDrawGlyph(unsigned char ch, int x, int y, int sc, u32 c, int a);   // defined in sprites.h; false if the sheet has no such glyph
static void text(const char* s, int x, int y, int sc, u32 c, int a = 255) {
    static std::vector<SDL_Rect> rs;
    rs.clear();
    int cx = x;
    for (; *s; ++s) {
        unsigned char ch = (unsigned char)toupper((unsigned char)*s);
        if (ch < 128 && sprDrawGlyph(ch, cx, y, sc, c, a)) {   // glyph from the sprite sheet (white), tinted with the text colour
        } else if (ch < 128) {   // sheet missing or glyph absent: draw it from the built-in bitmap
            for (int r = 0; r < 7; r++) {
                uint8_t bits = gGl[ch][r];
                for (int b = 0; b < 5; b++)
                    if (bits & (16 >> b)) rs.push_back({cx + b * sc, y + r * sc, sc, sc});
            }
        }
        cx += 6 * sc;
    }
    setDrawColor(c, a);
    if (!rs.empty()) SDL_RenderFillRects(uvzRenderer, rs.data(), (int)rs.size());
}
static void drawTextWithShadow(const char* s, int x, int y, int sc, u32 c, u32 sh = 0x05060F) {
    text(s, x + std::max(1, sc / 2), y + std::max(1, sc / 2), sc, sh, 220);
    text(s, x, y, sc, c);
}
static void drawCenteredText(const char* s, int cx, int y, int sc, u32 c) { drawTextWithShadow(s, cx - measureTextWidth(s, sc) / 2, y, sc, c); }
static int fitTextScale(const char* s, int maxW, int maxSc) {
    int sc = maxSc;
    while (sc > 1 && measureTextWidth(s, sc) > maxW) sc--;
    return sc;
}

// ---- font styles -----------------------------------------------------------------------------------------------------
// STD is the 5x7 sheet font above. The other styles are built from its glyphs (or from their own small tables) when initFont() runs and are
// drawn from code, so they need nothing extra in the sprite sheet.
//   BOLD   chunky title / sign lettering          ITAL   slanted, same advance as STD (matches the slanted menu bars and speed)
//   COMIC  bold + slanted + dark comic outline    TINY   3x5 for small HUD labels
//   LCD    seven-segment readout with ghost cells NEON   glowing tube lettering (sign halo)
//   LED    dot-matrix lettering for scrolling ad boards
enum FontStyle { FS_STD, FS_BOLD, FS_ITAL, FS_COMIC, FS_TINY, FS_LCD, FS_NEON, FS_LED, FS_COUNT };
struct FontSet { int w, h, adv; uint16_t rows[128][9]; bool has[128]; };   // column 0 is the top bit of the w-bit row
static FontSet gFS[FS_COUNT];
static inline const FontSet& fsOf(FontStyle f) { return gFS[(f == FS_NEON || f == FS_LED) ? FS_STD : f]; }
struct TinyGlyph { char c; uint8_t r[5]; };
static const TinyGlyph tinyGlyphs[] = {
    {'A',{2,5,7,5,5}}, {'B',{6,5,6,5,6}}, {'C',{3,4,4,4,3}}, {'D',{6,5,5,5,6}}, {'E',{7,4,6,4,7}}, {'F',{7,4,6,4,4}},
    {'G',{3,4,5,5,3}}, {'H',{5,5,7,5,5}}, {'I',{7,2,2,2,7}}, {'J',{1,1,1,5,2}}, {'K',{5,5,6,5,5}}, {'L',{4,4,4,4,7}},
    {'M',{5,7,7,5,5}}, {'N',{6,5,5,5,5}}, {'O',{2,5,5,5,2}}, {'P',{6,5,6,4,4}}, {'Q',{2,5,5,6,3}}, {'R',{6,5,6,5,5}},
    {'S',{3,4,2,1,6}}, {'T',{7,2,2,2,2}}, {'U',{5,5,5,5,7}}, {'V',{5,5,5,5,2}}, {'W',{5,5,7,7,5}}, {'X',{5,5,2,5,5}},
    {'Y',{5,5,2,2,2}}, {'Z',{7,1,2,4,7}},
    {'0',{7,5,5,5,7}}, {'1',{2,6,2,2,7}}, {'2',{6,1,2,4,7}}, {'3',{6,1,2,1,6}}, {'4',{5,5,7,1,1}},
    {'5',{7,4,6,1,6}}, {'6',{3,4,7,5,7}}, {'7',{7,1,2,2,2}}, {'8',{7,5,7,5,7}}, {'9',{7,5,7,1,6}},
    {'.',{0,0,0,0,2}}, {':',{0,2,0,2,0}}, {'-',{0,0,7,0,0}}, {'/',{1,1,2,4,4}}, {'!',{2,2,2,0,2}}, {'?',{6,1,2,0,2}},
    {'+',{0,2,7,2,0}}, {'%',{5,1,2,4,5}}, {',',{0,0,0,2,4}}, {'<',{1,2,4,2,1}}, {'>',{4,2,1,2,4}},
};
static void buildFontSets() {
    memset(gFS, 0, sizeof(gFS));
    auto dims = [](FontSet& s, int w, int h, int adv) { s.w = w; s.h = h; s.adv = adv; };
    dims(gFS[FS_STD], 5, 7, 6); dims(gFS[FS_BOLD], 6, 7, 7); dims(gFS[FS_ITAL], 7, 7, 6); dims(gFS[FS_COMIC], 8, 7, 7);
    dims(gFS[FS_TINY], 3, 5, 4); dims(gFS[FS_LCD], 5, 9, 7);
    for (const Glyph& g : fontGlyphs) {
        const int ch = (unsigned char)g.c;
        for (int r = 0; r < 7; r++) {
            const unsigned v = g.r[r], bold = (v << 1) | v;   // bold: every pixel doubled to the right
            const int lean = (6 - r) / 3;                      // slant: the top rows lean 2 columns right, the middle 1, the bottom 0
            gFS[FS_STD].rows[ch][r] = (uint16_t)v;
            gFS[FS_BOLD].rows[ch][r] = (uint16_t)bold;
            gFS[FS_ITAL].rows[ch][r] = (uint16_t)(v << (2 - lean));
            gFS[FS_COMIC].rows[ch][r] = (uint16_t)(bold << (2 - lean));
        }
        gFS[FS_STD].has[ch] = gFS[FS_BOLD].has[ch] = gFS[FS_ITAL].has[ch] = gFS[FS_COMIC].has[ch] = true;
    }
    for (const TinyGlyph& t : tinyGlyphs) {
        const int ch = (unsigned char)t.c;
        for (int r = 0; r < 5; r++) gFS[FS_TINY].rows[ch][r] = t.r[r];
        gFS[FS_TINY].has[ch] = true;
    }
    // seven segments on a 5x9 grid: a top, b upper right, c lower right, d bottom, e lower left, f upper left, g middle
    static const struct { char c; const char* seg; } lcd[] = {
        {'0',"abcdef"}, {'1',"bc"}, {'2',"abdeg"}, {'3',"abcdg"}, {'4',"bcfg"}, {'5',"acdfg"}, {'6',"acdefg"}, {'7',"abc"}, {'8',"abcdefg"}, {'9',"abcdfg"},
        {'-',"g"}, {'A',"abcefg"}, {'B',"cdefg"}, {'C',"adef"}, {'D',"bcdeg"}, {'E',"adefg"}, {'F',"aefg"}, {'G',"acdef"}, {'H',"bcefg"},
        {'I',"ef"}, {'J',"bcde"}, {'L',"def"}, {'N',"ceg"}, {'O',"abcdef"}, {'P',"abefg"}, {'R',"eg"}, {'S',"acdfg"}, {'T',"defg"}, {'U',"bcdef"}, {'Y',"bcdfg"},
    };
    for (const auto& e : lcd) {
        uint16_t* rw = gFS[FS_LCD].rows[(int)(unsigned char)e.c];
        for (const char* q = e.seg; *q; ++q) switch (*q) {
            case 'a': rw[0] |= 0x0E; break;
            case 'g': rw[4] |= 0x0E; break;
            case 'd': rw[8] |= 0x0E; break;
            case 'b': for (int r = 1; r <= 3; r++) rw[r] |= 0x01; break;
            case 'c': for (int r = 5; r <= 7; r++) rw[r] |= 0x01; break;
            case 'f': for (int r = 1; r <= 3; r++) rw[r] |= 0x10; break;
            case 'e': for (int r = 5; r <= 7; r++) rw[r] |= 0x10; break;
        }
        gFS[FS_LCD].has[(int)(unsigned char)e.c] = true;
    }
    gFS[FS_LCD].rows[(int)':'][2] = gFS[FS_LCD].rows[(int)':'][6] = 0x04; gFS[FS_LCD].has[(int)':'] = true;
    gFS[FS_LCD].rows[(int)'.'][8] = 0x04; gFS[FS_LCD].has[(int)'.'] = true;
}
// Pixel width of a string in a style at integer scale sc (STD gives exactly measureTextWidth).
static int fontWidth(FontStyle f, const char* s, int sc) {
    const FontSet& fs = fsOf(f); const int n = (int)strlen(s);
    return n <= 0 ? 0 : (n * fs.adv - (fs.adv - fs.w)) * sc;
}
static int fontWidthSp(FontStyle f, const char* s, int sc, int gap) {   // letter-spaced (gap pixels between letters), like textWSp
    const FontSet& fs = fsOf(f); const int n = (int)strlen(s);
    return n <= 0 ? 0 : n * (fs.adv * sc + gap) - gap - (fs.adv - fs.w) * sc;
}
static int fontHeight(FontStyle f, int sc) { return fsOf(f).h * sc; }
static int fitFontScale(FontStyle f, const char* s, int maxW, int maxSc) {
    int sc = maxSc;
    while (sc > 1 && fontWidth(f, s, sc) > maxW) sc--;
    return sc;
}
static FontStyle fitFont(FontStyle pref, const char* s, int sc, int maxW) { return fontWidth(pref, s, sc) <= maxW ? pref : FS_STD; }   // fall back to STD when the styled text would not fit
static void fontGlyphRects(const FontSet& fs, int ch, int x, int y, int sc, std::vector<SDL_Rect>& out) {
    if (ch < 0 || ch >= 128 || !fs.has[ch]) return;
    for (int r = 0; r < fs.h; r++) {
        const unsigned bits = fs.rows[ch][r];
        for (int c = 0; c < fs.w;) {
            if (!(bits & (1u << (fs.w - 1 - c)))) { c++; continue; }
            int e = c;
            while (e < fs.w && (bits & (1u << (fs.w - 1 - e)))) e++;
            out.push_back({x + c * sc, y + r * sc, (e - c) * sc, sc});
            c = e;
        }
    }
}
static void textF(FontStyle f, const char* s, int x, int y, int sc, u32 c, int a = 255) {
    if (f == FS_STD) { text(s, x, y, sc, c, a); return; }
    static std::vector<SDL_Rect> front, back;
    front.clear(); back.clear();
    const FontSet& fs = fsOf(f);
    int cx = x;
    for (const char* p = s; *p; ++p, cx += fs.adv * sc) {
        const int ch = toupper((unsigned char)*p);
        if (ch >= 128) continue;
        switch (f) {
            case FS_LCD:   // unlit segments (a ghost 8) behind the lit ones, like a real display
                fontGlyphRects(fs, '8', cx, y, sc, back);
                fontGlyphRects(fs, ch, cx, y, sc, front);
                break;
            case FS_COMIC: {   // dark outline all round
                const int o = std::max(1, sc / 2);
                static const int dx[8] = {-1, 0, 1, -1, 1, -1, 0, 1}, dy[8] = {-1, -1, -1, 0, 0, 1, 1, 1};
                for (int k = 0; k < 8; k++) fontGlyphRects(fs, ch, cx + dx[k] * o, y + dy[k] * o, sc, back);
                fontGlyphRects(fs, ch, cx, y, sc, front);
                break;
            }
            case FS_NEON: {   // soft halo one pixel (one scale step) out, then the tube
                static const int dx[4] = {-1, 1, 0, 0}, dy[4] = {0, 0, -1, 1};
                for (int k = 0; k < 4; k++) fontGlyphRects(fs, ch, cx + dx[k] * sc, y + dy[k] * sc, sc, back);
                fontGlyphRects(fs, ch, cx, y, sc, front);
                break;
            }
            case FS_LED: {   // every pixel of the glyph is a round-ish dot; unlit dots stay faintly visible
                const int d = std::max(1, sc - 1);
                for (int r = 0; r < fs.h; r++) for (int b = 0; b < fs.w; b++) {
                    const bool on = fs.has[ch] && (fs.rows[ch][r] & (1u << (fs.w - 1 - b)));
                    (on ? front : back).push_back({cx + b * sc, y + r * sc, d, d});
                }
                break;
            }
            default: fontGlyphRects(fs, ch, cx, y, sc, front); break;
        }
    }
    if (!back.empty()) {
        if (f == FS_COMIC) setDrawColor(0x05060F, a);
        else setDrawColor(c, f == FS_LCD ? a * 38 / 255 : (f == FS_LED ? a * 46 / 255 : a * 70 / 255));
        SDL_RenderFillRects(uvzRenderer, back.data(), (int)back.size());
    }
    if (!front.empty()) {
        u32 fc = c;
        if (f == FS_NEON) fc = (((((c >> 16) & 255) + 255) / 2) << 16) | (((((c >> 8) & 255) + 255) / 2) << 8) | ((((c & 255) + 255) / 2));   // a hotter core
        setDrawColor(fc, a);
        SDL_RenderFillRects(uvzRenderer, front.data(), (int)front.size());
    }
}
static void textShadowF(FontStyle f, const char* s, int x, int y, int sc, u32 c, u32 sh = 0x05060F) {
    textF(f, s, x + std::max(1, sc / 2), y + std::max(1, sc / 2), sc, sh, 220);
    textF(f, s, x, y, sc, c);
}
static void textSpF(FontStyle f, const char* s, int x, int y, int sc, u32 c, int gap, int a = 255) {
    char b[2] = {0, 0};
    for (; *s; ++s) { b[0] = *s; textF(f, b, x, y, sc, c, a); x += fsOf(f).adv * sc + gap; }
}
static void textSpCF(FontStyle f, const char* s, int cx, int y, int sc, u32 c, int gap, int a = 255) { textSpF(f, s, cx - fontWidthSp(f, s, sc, gap) / 2, y, sc, c, gap, a); }

struct Img {
    int w, h;
    std::vector<u32> p;
    Img(int w_, int h_) : w(w_), h(h_), p((size_t)w_ * h_, 0) {}
    void set(int x, int y, u32 c) { if (x >= 0 && y >= 0 && x < w && y < h) p[(size_t)y * w + x] = c; }
    u32 get(int x, int y) const { return (x >= 0 && y >= 0 && x < w && y < h) ? p[(size_t)y * w + x] : 0; }
    void fill(int x, int y, int ww, int hh, u32 c) {
        for (int yy = y; yy < y + hh; yy++) for (int xx = x; xx < x + ww; xx++) set(xx, yy, c);
    }
};
static SDL_Texture* createTexture(const Img& im) {
    SDL_Texture* t = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STATIC, im.w, im.h);
    if (!t) return nullptr;
    SDL_UpdateTexture(t, nullptr, im.p.data(), im.w * 4);
    SDL_SetTextureBlendMode(t, SDL_BLENDMODE_BLEND);
    return t;
}

// ONE texture holds every facade tile. Row = building style (6), column = variant (3). Each cell is a strip: the tile repeated
// facade::STRIP_TILES times side by side, so one copy draws a whole run of equal neighbours and a single tile is just the first TILE px of its
// strip. (Previously: 18 tile textures + 18 strip textures + 3 unused far-building textures, 39 in all, with every tile stored twice.)
static SDL_Texture* gFacadeAtlas;
#include "sprites.h"   // sprite sheet loader (assets/spritesheet.tga); the art itself is generated by tools/gen_spritesheet.cpp

// ---- New York facades --------------------------------------------------------------------
// Life-size: the stickman is ~52 px = 1.75 m, so a storey is 96 px (~3.2 m) and a window ~1 m x 1.7 m.
// Every style is a TILE x TILE texture that repeats; WIN_GEO says where its windows are so the night
// glow and the fire escapes line up with them.
static const int TILE = 96;
struct WinGeo { int cols, colPitch, rows, rowPitch, x0, y0, w, h; };
static const WinGeo WIN_GEO[6] = {
    {3, 32, 2, 48, 3, 5, 26, 38},     // 0 glass curtain wall
    {2, 48, 1, 96, 11, 22, 26, 52},   // 1 limestone art deco
    {2, 48, 1, 96, 12, 20, 24, 54},   // 2 red brick walk-up
    {2, 48, 1, 96, 10, 26, 28, 48},   // 3 brownstone
    {2, 48, 1, 96, 6, 18, 36, 58},    // 4 warehouse loft
    {2, 48, 1, 96, 13, 24, 22, 48},   // 5 terracotta deco
};
static const u32 FACADE_STONE[6] = {0x62758C, 0xCBC0A8, 0xD4C8AE, 0x9E8C7A, 0x8C867A, 0xDACBAD};   // cornice / trim
static const u32 FACADE_BASE[6]  = {0x2B3745, 0x8C816B, 0x55302B, 0x45342E, 0x383D46, 0x978868};   // ground-floor plinth


enum Frame {
    F_IDLE,
    F_RUN,
    F_SHOOT,
    F_ATTACH,
    F_SWING,
    F_JUMP,
    F_FALL,
    F_FLIP,
    F_RELEASE,
    F_LAND,
    F_HERO,
    F_HIT,
    F_DEAD,
    F_CLING,
    F_CLIMB,
    F_SLIDE,
    F_WALLJUMP,
    F_TWIST,
    F_STAR,
    F_DIVE,
    F_VAULT,
    F_ROLL,
    F_BACKFLIP,
    F_FLIPOPEN,
    F_COUNT
};
static const int STK_FEET_Y = 26;
static const u32 STK_BODY = 0x0B0B12;
static const u32 STK_OUTLINE = 0xE8ECFF;
static const u32 STK_SUIT_RED = 0x241AD2, STK_SUIT_RED_D = 0x18108E, STK_SUIT_BLUE = 0x9A3F1E, STK_SUIT_BLUE_D = 0x662A14;   // Spider-Man suit colours (stkLayer takes 0xBBGGRR)

enum StkJoint { J_HIP, J_NECK, J_HEAD, J_KNF, J_FTF, J_KNB, J_FTB, J_ELF, J_HNF, J_ELB, J_HNB, J_N };
struct StkPose {
    float hipX = 0, hipY = 2, lean = 0, tilt = 0;
    float thF = 0, shF = 0, thB = 0, shB = 0;
    float upF = 0, foF = 0, upB = 0, foB = 0;
    float snap = 0;
};
static const float STK_TORSO = 16, STK_THIGH = 12, STK_SHIN = 12, STK_UARM = 8, STK_FARM = 8, STK_HEADD = 6;

static void stkSolve(const StkPose& p, float jx[J_N], float jy[J_N]) {
    auto dir = [](float deg, float len, float& dx, float& dy) { float a = deg * pi / 180.0f; dx = sinf(a) * len; dy = cosf(a) * len; };
    float dx, dy, hy = p.hipY;
    for (int pass = 0; pass < 2; pass++) {
        jx[J_HIP] = p.hipX; jy[J_HIP] = hy;
        dir(p.thF, STK_THIGH, dx, dy); jx[J_KNF] = jx[J_HIP] + dx; jy[J_KNF] = jy[J_HIP] + dy;
        dir(p.shF, STK_SHIN, dx, dy);  jx[J_FTF] = jx[J_KNF] + dx; jy[J_FTF] = jy[J_KNF] + dy;
        dir(p.thB, STK_THIGH, dx, dy); jx[J_KNB] = jx[J_HIP] + dx; jy[J_KNB] = jy[J_HIP] + dy;
        dir(p.shB, STK_SHIN, dx, dy);  jx[J_FTB] = jx[J_KNB] + dx; jy[J_FTB] = jy[J_KNB] + dy;
        if (p.snap > 0.001f && pass == 0) hy += clampValue(p.snap, 0.0f, 1.0f) * (float)STK_FEET_Y - std::max(jy[J_FTF], jy[J_FTB]);
        else break;
    }
    dir(180.0f - p.lean, STK_TORSO, dx, dy);
    jx[J_NECK] = jx[J_HIP] + dx; jy[J_NECK] = jy[J_HIP] + dy;
    dir(180.0f - p.lean - p.tilt, STK_HEADD, dx, dy);
    jx[J_HEAD] = jx[J_NECK] + dx; jy[J_HEAD] = jy[J_NECK] + dy;
    dir(p.upF, STK_UARM, dx, dy); jx[J_ELF] = jx[J_NECK] + dx; jy[J_ELF] = jy[J_NECK] + dy;
    dir(p.foF, STK_FARM, dx, dy); jx[J_HNF] = jx[J_ELF] + dx;  jy[J_HNF] = jy[J_ELF] + dy;
    dir(p.upB, STK_UARM, dx, dy); jx[J_ELB] = jx[J_NECK] + dx; jy[J_ELB] = jy[J_NECK] + dy;
    dir(p.foB, STK_FARM, dx, dy); jx[J_HNB] = jx[J_ELB] + dx;  jy[J_HNB] = jy[J_ELB] + dy;
}

static float StkPose::* const STK_F[] = {
    &StkPose::hipX, &StkPose::hipY, &StkPose::lean, &StkPose::tilt,
    &StkPose::thF, &StkPose::shF, &StkPose::thB, &StkPose::shB,
    &StkPose::upF, &StkPose::foF, &StkPose::upB, &StkPose::foB, &StkPose::snap };

static StkPose stkBlend(const StkPose& a, const StkPose& b, float t) {
    StkPose o;
    for (auto m : STK_F) o.*m = lerpValue(a.*m, b.*m, t);
    return o;
}

static void stkRunLeg(float ph, float amp, float& thigh, float& shin) {
    thigh = amp * sinf(ph);
    float k = std::max(0.0f, cosf(ph));
    shin = thigh - (12.0f + 88.0f * powf(k, 1.4f));
}
static StkPose stkMakePose(int f, float phase, float swing, int style = 0, float j = 0) {
    StkPose p;
    switch (f) {
        case F_IDLE: {
            float b = sinf(phase * 2.0f * pi);
            p.snap = true; p.lean = 16 + 2 * b; p.tilt = -8 + b;
            p.thF = 42 + 2 * b; p.shF = -14; p.thB = -20; p.shB = -58 - 2 * b;
            p.upF = 28 + 3 * b; p.foF = 8; p.upB = -34 - 2 * b; p.foB = -62;
            break; }
        case F_RUN: {
            float ph = phase * 2.0f * pi, amp = 46 + 6 * j, lc = sinf(ph * 2.0f);
            p.snap = true;
            stkRunLeg(ph, amp, p.thF, p.shF);
            stkRunLeg(ph + pi, amp, p.thB, p.shB);
            if (style == 1) {
                p.lean = 30 + 2 * lc; p.tilt = -14;
                p.upF = -35 + 25 * sinf(ph + pi); p.foF = p.upF + 35;
                p.upB = -35 + 25 * sinf(ph);      p.foB = p.upB + 35;
            } else if (style == 2) {
                p.lean = 20 + lc; p.tilt = -8;
                p.upF = (60 + 6 * j) * sinf(ph + pi); p.foF = p.upF + 100;
                p.upB = (60 + 6 * j) * sinf(ph);      p.foB = p.upB + 100;
            } else {
                p.lean = 14 + 1.5f * lc; p.tilt = -6;
                p.upF = (50 + 8 * j) * sinf(ph + pi); p.foF = p.upF + 85;
                p.upB = (50 + 8 * j) * sinf(ph);      p.foB = p.upB + 85;
            }
            break; }
        case F_SHOOT:
            if (style == 1) {
                p.hipY = 0; p.lean = 14; p.thF = 52; p.shF = 28; p.thB = -48; p.shB = -34;
                p.upF = 122; p.foF = 128; p.upB = -70; p.foB = -48;
            } else {
                p.hipY = 0; p.lean = 8; p.thF = 62; p.shF = 8; p.thB = -22; p.shB = -68;
                p.upF = 146; p.foF = 150; p.upB = -55; p.foB = -25;
            }
            break;
        case F_ATTACH:
            p.hipY = 3; p.lean = 0; p.thF = 18; p.shF = 6; p.thB = -12; p.shB = -42;
            p.upF = 176; p.foF = 176; p.upB = 35; p.foB = 65; break;
        case F_SWING: {
            StkPose a, b;
            a.hipY = 3; a.lean = 4; a.thF = -8; a.shF = -26; a.thB = -24; a.shB = -48;
            a.upF = 177; a.foF = 177; a.upB = -42; a.foB = -62;
            b.hipY = 3; b.lean = -4; b.thF = 40; b.shF = 12; b.thB = 14; b.shB = -10;
            b.upF = 177; b.foF = 177; b.upB = 75; b.foB = 105;
            if (style == 1) {
                a.thF = 40; a.shF = -50; a.thB = 20; a.shB = -80; a.lean = 14; a.upB = -20; a.foB = 5;
                b.thF = 75; b.shF = -15; b.thB = 55; b.shB = -45; b.lean = 2; b.upB = 40; b.foB = 70;
            } else if (style == 2) {
                a.thF = 22; a.shF = 4; a.thB = -38; a.shB = -14; a.upB = -75; a.foB = -80;
                b.thF = 52; b.shF = 18; b.thB = -12; b.shB = 6; b.upB = 110; b.foB = 128;
            } else if (style == 3) {
                a.thF = -14; a.shF = -16; a.thB = -20; a.shB = -22; a.lean = 8; a.upB = -20; a.foB = -25;
                b.thF = 22; b.shF = 18; b.thB = 12; b.shB = 8; b.lean = -2; b.upB = 40; b.foB = 50;
            }
            a.thB += 8 * j; b.thB -= 8 * j; a.lean += 3 * j;
            p = stkBlend(a, b, clampValue(swing, 0.0f, 1.0f)); break; }
        case F_JUMP:
            if (style == 1) {
                p.hipY = -2; p.lean = 22; p.thF = 95; p.shF = -60; p.thB = 70; p.shB = -80;
                p.upF = 90; p.foF = 110; p.upB = -60; p.foB = -40;
            } else if (style == 2) {
                p.hipY = -2; p.lean = 0; p.thF = 40; p.shF = 30; p.thB = -40; p.shB = -30;
                p.upF = 140; p.foF = 150; p.upB = -140; p.foB = -150;
            } else {
                p.hipY = -2; p.lean = 10 + 3 * j; p.thF = 78; p.shF = 6; p.thB = -24; p.shB = -76;
                p.upF = 118; p.foF = 138; p.upB = -68; p.foB = -30;
            }
            break;
        case F_FALL:
            if (style == 1) {
                p.hipY = 0; p.lean = 20; p.thF = 60; p.shF = -20; p.thB = 40; p.shB = -50;
                p.upF = 70; p.foF = 100; p.upB = 60; p.foB = 90;
            } else {
                p.hipY = 0; p.lean = 0; p.thF = 32; p.shF = 6; p.thB = -22; p.shB = -34;
                p.upF = 112; p.foF = 100; p.upB = -104; p.foB = -112;
            }
            break;
        case F_FLIP:
            p.hipY = 2; p.lean = 38; p.tilt = -10; p.thF = 112; p.shF = -30; p.thB = 98; p.shB = -42;
            p.upF = 70; p.foF = 118; p.upB = 55; p.foB = 108; break;
        case F_CLING:
            p.hipY = 1; p.lean = 2; p.tilt = 0; p.thF = 46; p.shF = -25; p.thB = -42; p.shB = 24;
            p.upF = 128; p.foF = 158; p.upB = -108; p.foB = -142; break;
        case F_CLIMB: {
            float c = sinf(phase * 2.0f * pi), d = cosf(phase * 2.0f * pi);
            p.hipY = 1; p.lean = 1; p.tilt = 0;
            p.thF = 34 + 24*c; p.shF = -12 - 30*std::max(0.0f,d);
            p.thB = -34 - 24*c; p.shB = 12 + 30*std::max(0.0f,-d);
            p.upF = 100 + 55*d; p.foF = 135 + 22*d;
            p.upB = -100 - 55*d; p.foB = -135 - 22*d; break; }
        case F_WALLJUMP:
            p.hipY = 0; p.lean = -14; p.tilt = 6; p.thF = 18; p.shF = -8; p.thB = -22; p.shB = -34;
            p.upF = 150; p.foF = 158; p.upB = 138; p.foB = 150; break;
        case F_TWIST:
            p.hipY = 1; p.lean = 0; p.tilt = 0; p.thF = 8; p.shF = 4; p.thB = -8; p.shB = -6;
            p.upF = 35; p.foF = 135; p.upB = -35; p.foB = -135; break;
        case F_DIVE:

            p.hipY = 1; p.lean = 72; p.tilt = -6; p.thF = 6; p.shF = -4; p.thB = -14; p.shB = -10;
            p.upF = 158; p.foF = 164; p.upB = 148; p.foB = 158; break;
        case F_STAR:
            p.hipY = 1; p.lean = 0; p.tilt = 0; p.thF = 38; p.shF = 40; p.thB = -38; p.shB = -40;
            p.upF = 122; p.foF = 128; p.upB = -122; p.foB = -128; break;
        case F_SLIDE:
            p.snap = 1;
            if (style == 1) {
                p.lean = 55 + 4 * j; p.tilt = -18; p.thF = 75; p.shF = -20; p.thB = -80; p.shB = -88;
                p.upF = 40; p.foF = 15; p.upB = -50; p.foB = -90;
            } else if (style == 2) {
                p.lean = 28 + 4 * j; p.tilt = -10; p.thF = 95; p.shF = 40; p.thB = -70; p.shB = -118;
                p.upF = 70; p.foF = 85; p.upB = -75; p.foB = -100;
            } else {
                p.lean = -35 + 4 * j; p.tilt = 10; p.thF = 85; p.shF = 82; p.thB = 76; p.shB = 70;
                p.upF = 70; p.foF = 40; p.upB = -60; p.foB = -78;
            }
            break;
        case F_RELEASE:
            p.hipX = -3; p.hipY = 3; p.lean = 55; p.thF = -50; p.shF = -60; p.thB = -58; p.shB = -62;
            p.upF = 128; p.foF = 130; p.upB = 122; p.foB = 125; break;
        case F_LAND:
            p.snap = true;
            if (style == 1) {
                p.lean = 50; p.tilt = -20; p.thF = 95; p.shF = -50; p.thB = 80; p.shB = -70;
                p.upF = 40; p.foF = 15; p.upB = 20; p.foB = 0;
            } else if (style == 2) {
                p.lean = 40; p.tilt = -14; p.thF = 70; p.shF = -22; p.thB = -40; p.shB = -100;
                p.upF = 60; p.foF = 25; p.upB = -60; p.foB = -30;
            } else {
                p.lean = 36 + 4 * j; p.tilt = -12; p.thF = 78; p.shF = -32; p.thB = 56; p.shB = -58;
                p.upF = 55; p.foF = 92; p.upB = 28; p.foB = 70;
            }
            p.hipY += 3.0f * swing; p.thF += 14.0f * swing; p.thB += 10.0f * swing; p.lean += 6.0f * swing;   // deeper crouch for harder landings
            break;
        case F_HERO:
            p.snap = true; p.lean = 44; p.tilt = -24; p.thF = 88; p.shF = -4; p.thB = -34; p.shB = -118;
            p.upF = 52; p.foF = 22; p.upB = -48; p.foB = -78; break;
        case F_BACKFLIP:   // tucked backflip: arms thrown up, knees pulled in behind
            p.hipY = 2; p.lean = -18; p.tilt = 8; p.thF = 100; p.shF = -96; p.thB = 94; p.shB = -90;
            p.upF = 150; p.foF = 130; p.upB = 138; p.foB = 120; break;
        case F_FLIPOPEN:   // end of a flip: body opens and the feet reach for the landing
            p.hipY = 0; p.lean = 8 + 2 * j; p.tilt = -4; p.thF = 36; p.shF = 8; p.thB = -18; p.shB = -26;
            p.upF = 112; p.foF = 98; p.upB = -100; p.foB = -92; break;
        case F_ROLL:       // forward roll: a tight ball (the whole body is rotated by the draw code)
            p.snap = true; p.hipY = 4; p.lean = 62; p.tilt = -18; p.thF = 122; p.shF = -132; p.thB = 116; p.shB = -126;
            p.upF = 62; p.foF = 142; p.upB = 52; p.foB = 136; break;
        case F_VAULT: {    // one-handed vault: plant the front hand, swing the legs over, release (phase = progress 0..1)
            const float u = clampValue(phase, 0.0f, 1.0f);
            struct K { float hipY, lean, tilt, thF, shF, thB, shB, upF, foF, upB, foB; };
            static const K K0 = {1, 42, -10, 70, -60, -30, -70, 52, 34, -42, -30};     // reach and plant
            static const K K1 = {-7, 12, -4, 100, -22, 92, -34, 22, 8, -70, -50};       // legs swung over, one hand down
            static const K K2 = {0, 18, -6, 38, 8, -12, -40, 100, 118, -56, -36};       // push off and release
            const float w = u < 0.5f ? u / 0.5f : (u - 0.5f) / 0.5f, e = w * w * (3 - 2 * w);
            const K& a = u < 0.5f ? K0 : K1; const K& b = u < 0.5f ? K1 : K2;
            auto L = [&](float x, float y) { return x + (y - x) * e; };
            p.hipY = L(a.hipY, b.hipY); p.lean = L(a.lean, b.lean); p.tilt = L(a.tilt, b.tilt);
            p.thF = L(a.thF, b.thF); p.shF = L(a.shF, b.shF); p.thB = L(a.thB, b.thB); p.shB = L(a.shB, b.shB);
            p.upF = L(a.upF, b.upF); p.foF = L(a.foF, b.foF); p.upB = L(a.upB, b.upB); p.foB = L(a.foB, b.foB);
            break; }
        case F_HIT:
            p.hipY = 1; p.lean = -22; p.tilt = 10; p.thF = 40; p.shF = 12; p.thB = -30; p.shB = -8;
            p.upF = 140; p.foF = 162; p.upB = 98; p.foB = 122; break;
        default:
            p.hipY = 1; p.lean = 0; p.tilt = 12; p.thF = 36; p.shF = 40; p.thB = -36; p.shB = -40;
            p.upF = 100; p.foF = 78; p.upB = -100; p.foB = -78; break;
    }
    return p;
}

struct StkAnim { StkPose cur, vel; bool init = false; double last = 0, ang = 0; int lastFrame = -1; float dt = 0, t = 0; };
static double stkNow() { return (double)SDL_GetTicks() / 1000.0; }
static float stkRate(int from, int to) {
    if (to == F_RUN || to == F_IDLE) return (from == to) ? 60.0f : 18.0f;
    if (to == F_SWING) return 22.0f;
    if (to == F_DIVE) return 24.0f;
    if (to == F_VAULT) return 26.0f;
    if (to == F_ROLL) return 30.0f;
    if (to == F_FLIPOPEN || to == F_BACKFLIP) return 24.0f;
    if (to == F_TWIST || to == F_STAR || to == F_WALLJUMP) return 26.0f;
    if (to == F_SLIDE) return 26.0f;
    if (to == F_SHOOT || to == F_ATTACH || to == F_RELEASE || to == F_HIT) return 28.0f;
    if (to == F_HERO || to == F_LAND) return 32.0f;
    return 18.0f;
}
static const StkPose& stkAdvance(StkAnim& an, int frame, float phase, float swing, int style = 0, float j = 0) {
    StkPose tgt = stkMakePose(frame, phase, swing, style, j);
    double now = stkNow();
    an.dt = clampValue((float)(now - an.last), 0.0f, 0.05f);
    an.last = now;
    if (!an.init) {
        an.cur = tgt; an.init = true;
        for (auto m : STK_F) an.vel.*m = 0;
    } else {
        float ease = clampValue(an.t / 0.15f, 0.0f, 1.0f);
        float w = stkRate(an.lastFrame, frame) * (0.45f + 0.55f * ease * ease * (3 - 2 * ease));
        float zeta = (frame == F_RUN || frame == F_IDLE) ? 1.0f : 0.7f;
        int n = (int)ceilf(an.dt * 240.0f);
        float h = n ? an.dt / n : 0;
        for (int i = 0; i < n; i++)
            for (auto m : STK_F) {
                float& x = an.cur.*m; float& v = an.vel.*m;
                v += (w * w * (tgt.*m - x) - 2 * zeta * w * v) * h;
                x += v * h;
            }
    }
    an.t = frame == an.lastFrame ? an.t + an.dt : 0;
    an.lastFrame = frame;
    return an.cur;
}
static double stkAngle(StkAnim& an, double target, bool spin) {
    if (spin) an.ang = fmod(target, 360.0);
    else {
        double d = fmod(target - an.ang, 360.0);
        if (d > 180) d -= 360; else if (d < -180) d += 360;
        an.ang += d * (1.0 - exp(-8.0 * an.dt));
    }
    return an.ang;
}

static bool gStkMirror = false;
static void stkPlace(const StkPose& pose, float cx, float feetY, double angleDeg, float X[J_N], float Y[J_N]) {
    float jx[J_N], jy[J_N];
    stkSolve(pose, jx, jy);
    float a = (float)(angleDeg * pi / 180.0), c = cosf(a), s = sinf(a);
    float ox = cx, oy = feetY - (float)STK_FEET_Y;
    for (int i = 0; i < J_N; i++) { X[i] = ox + jx[i] * c - jy[i] * s; Y[i] = oy + jx[i] * s + jy[i] * c; if (gStkMirror) X[i] = 2.0f * cx - X[i]; }
}

static const int STK_TEX = 112;
static SDL_Texture* gStkTex = nullptr;
static float gStkBuf[STK_TEX * STK_TEX * 4];
// Dirty rectangles (inclusive pixel bounds; x0 > x1 means empty). gStkDirty = pixels touched this frame, gStkPrev = pixels that may
// still be non-zero in gStkBuf and in the GPU texture from the previous frame. Only their union is cleared, converted and uploaded.
static int gStkDirty[4], gStkPrev[4] = {0, 0, STK_TEX - 1, STK_TEX - 1};
struct StkBone { int a, b; };
static float stkDistSeg(float px, float py, float x0, float y0, float x1, float y1) {
    float vx = x1 - x0, vy = y1 - y0, wx = px - x0, wy = py - y0;
    float l2 = vx * vx + vy * vy, t = l2 > 1e-6f ? clampValue((wx * vx + wy * vy) / l2, 0.0f, 1.0f) : 0.0f;
    float dx = wx - vx * t, dy = wy - vy * t;
    return sqrtf(dx * dx + dy * dy);
}
static void stkLayer(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float rLimb, float rHead, u32 c, float ox, float oy) {
    float cr = ((c >> 16) & 255) / 255.0f, cg = ((c >> 8) & 255) / 255.0f, cb = (c & 255) / 255.0f;
    float r = rLimb + 0.5f;
    float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
    auto grow = [&](float x, float y, float pad) { minX = std::min(minX, x - pad); maxX = std::max(maxX, x + pad); minY = std::min(minY, y - pad); maxY = std::max(maxY, y + pad); };
    for (int i = 0; i < n; i++) { grow(X[bones[i].a] - ox, Y[bones[i].a] - oy, r + 1); grow(X[bones[i].b] - ox, Y[bones[i].b] - oy, r + 1); }
    if (head) grow(X[J_HEAD] - ox, Y[J_HEAD] - oy, rHead + 1.5f);
    int x0 = std::max(0, (int)floorf(minX)), x1 = std::min(STK_TEX - 1, (int)ceilf(maxX));
    int y0 = std::max(0, (int)floorf(minY)), y1 = std::min(STK_TEX - 1, (int)ceilf(maxY));
    if (x0 > x1 || y0 > y1) return;
    gStkDirty[0] = std::min(gStkDirty[0], x0); gStkDirty[1] = std::min(gStkDirty[1], y0);
    gStkDirty[2] = std::max(gStkDirty[2], x1); gStkDirty[3] = std::max(gStkDirty[3], y1);
    // Per-bone constants hoisted out of the pixel loop, plus each segment's reach (its box grown by the AA radius):
    // a pixel outside it has coverage 0 from that bone, so the distance maths is skipped (output is unchanged).
    struct Seg { float ax, ay, vx, vy, l2, lox, hix, loy, hiy; } sg[4];
    for (int i = 0; i < n; i++) {
        const float ax = X[bones[i].a], ay = Y[bones[i].a], bx = X[bones[i].b], by = Y[bones[i].b];
        sg[i] = { ax, ay, bx - ax, by - ay, (bx - ax) * (bx - ax) + (by - ay) * (by - ay),
                  std::min(ax, bx) - r, std::max(ax, bx) + r, std::min(ay, by) - r, std::max(ay, by) + r };
    }
    const float hx = X[J_HEAD], hy = Y[J_HEAD], hr = rHead + 0.5f;
    for (int py = y0; py <= y1; py++) for (int px = x0; px <= x1; px++) {
        float fx = px + 0.5f + ox, fy = py + 0.5f + oy, d = 1e9f;
        float d2 = 1e18f;   // min squared distance to any segment in reach: sqrt is monotonic, so one sqrtf gives the same minimum
        for (int i = 0; i < n; i++) {
            const Seg& q = sg[i];
            if (fx < q.lox || fx > q.hix || fy < q.loy || fy > q.hiy) continue;
            float wx = fx - q.ax, wy = fy - q.ay;
            float t = q.l2 > 1e-6f ? clampValue((wx * q.vx + wy * q.vy) / q.l2, 0.0f, 1.0f) : 0.0f;
            float dx = wx - q.vx * t, dy = wy - q.vy * t;
            d2 = std::min(d2, dx * dx + dy * dy);
        }
        if (d2 < 1e18f) d = sqrtf(d2) - rLimb;
        if (head && fabsf(fx - hx) <= hr && fabsf(fy - hy) <= hr) d = std::min(d, hypotf(fx - hx, fy - hy) - rHead);
        float cov = clampValue(0.5f - d, 0.0f, 1.0f);
        if (cov <= 0) continue;
        float* q = &gStkBuf[(py * STK_TEX + px) * 4];
        float inv = 1.0f - cov;
        q[0] = cr * cov + q[0] * inv; q[1] = cg * cov + q[1] * inv; q[2] = cb * cov + q[2] * inv; q[3] = cov + q[3] * inv;
    }
}
static void stkDrawBones(const float X[J_N], const float Y[J_N], const StkBone* bones, int n, bool head, float ox, float oy, u32 body = STK_BODY) {
    stkLayer(X, Y, bones, n, head, 2.35f, 5.9f, STK_OUTLINE, ox, oy);
    stkLayer(X, Y, bones, n, head, 1.5f, 4.95f, body, ox, oy);
}
static void drawStickmanJoints(const float X[J_N], const float Y[J_N], int cx, int feetY) {
    if (!gStkTex) {
        gStkTex = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_ABGR8888, SDL_TEXTUREACCESS_STREAMING, STK_TEX, STK_TEX);
        if (!gStkTex) return;
        SDL_SetTextureBlendMode(gStkTex, SDL_BLENDMODE_BLEND);
        gStkPrev[0] = 0; gStkPrev[1] = 0; gStkPrev[2] = STK_TEX - 1; gStkPrev[3] = STK_TEX - 1;   // new streaming texture is undefined: upload all of it once
    }
    const float ox = (float)cx - STK_TEX / 2, oy = (float)(feetY - STK_FEET_Y) - STK_TEX / 2;
    // clear only what the previous frame wrote (everything else in gStkBuf is already zero)
    if (gStkPrev[0] <= gStkPrev[2] && gStkPrev[1] <= gStkPrev[3])
        for (int row = gStkPrev[1]; row <= gStkPrev[3]; row++)
            memset(&gStkBuf[(row * STK_TEX + gStkPrev[0]) * 4], 0, sizeof(float) * 4 * (gStkPrev[2] - gStkPrev[0] + 1));
    gStkDirty[0] = gStkDirty[1] = STK_TEX; gStkDirty[2] = gStkDirty[3] = -1;
    static const StkBone farLeg[] = { {J_HIP, J_KNB}, {J_KNB, J_FTB} };
    static const StkBone farTorso[] = { {J_NECK, J_ELB}, {J_ELB, J_HNB}, {J_HIP, J_NECK} };
    static const StkBone nearLeg[] = { {J_HIP, J_KNF}, {J_KNF, J_FTF} };
    static const StkBone nearArm[] = { {J_NECK, J_ELF}, {J_ELF, J_HNF} };
    stkDrawBones(X, Y, farLeg, 2, false, ox, oy, STK_SUIT_BLUE_D);
    stkDrawBones(X, Y, farTorso, 3, true, ox, oy, STK_SUIT_RED_D);
    stkDrawBones(X, Y, nearLeg, 2, false, ox, oy, STK_SUIT_BLUE);
    stkDrawBones(X, Y, nearArm, 2, false, ox, oy, STK_SUIT_RED);
    // convert + upload the union of this frame's and last frame's regions (pixels last frame wrote but this frame didn't become transparent)
    static Uint32 px[STK_TEX * STK_TEX];
    const int ux0 = std::min(gStkDirty[0], gStkPrev[0]), uy0 = std::min(gStkDirty[1], gStkPrev[1]);
    const int ux1 = std::max(gStkDirty[2], gStkPrev[2]), uy1 = std::max(gStkDirty[3], gStkPrev[3]);
    if (ux0 <= ux1 && uy0 <= uy1) {
        for (int py = uy0; py <= uy1; py++) for (int pxl = ux0; pxl <= ux1; pxl++) {
            const int i = py * STK_TEX + pxl;
            const float* q = &gStkBuf[i * 4];
            float a = q[3];
            if (a <= 0.001f) { px[i] = 0; continue; }
            Uint32 r = (Uint32)clampValue(q[0] / a * 255.0f + 0.5f, 0, 255), g = (Uint32)clampValue(q[1] / a * 255.0f + 0.5f, 0, 255);
            Uint32 b = (Uint32)clampValue(q[2] / a * 255.0f + 0.5f, 0, 255), al = (Uint32)clampValue(a * 255.0f + 0.5f, 0, 255);
            px[i] = r | (g << 8) | (b << 16) | (al << 24);
        }
        SDL_Rect ur = { ux0, uy0, ux1 - ux0 + 1, uy1 - uy0 + 1 };
        SDL_UpdateTexture(gStkTex, &ur, &px[uy0 * STK_TEX + ux0], STK_TEX * (int)sizeof(Uint32));
    }
    memcpy(gStkPrev, gStkDirty, sizeof(gStkPrev));
    SDL_Rect dst = { (int)floorf(ox), (int)floorf(oy), STK_TEX, STK_TEX };
    SDL_RenderCopy(uvzRenderer, gStkTex, nullptr, &dst);
}
static void drawStickman(const StkPose& pose, int cx, int feetY, double angleDeg) {
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    drawStickmanJoints(X, Y, cx, feetY);
}
static void stickHand(const StkPose& pose, int cx, int feetY, double angleDeg, float& hx, float& hy) {
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)cx, (float)feetY, angleDeg, X, Y);
    hx = X[J_HNF]; hy = Y[J_HNF];
}
static float gRunPhase = 0;
static StkAnim gPlayerAnim, gMenuAnim;

static Img flatTile(int w, int h, u32 c) { Img im(w, h); im.fill(0, 0, w, h, c); return im; }
// Source rectangle of the (style, variant) strip inside the facade atlas.
static SDL_Rect facadeCell(int st, int v) { return SDL_Rect{v * TILE * facade::STRIP_TILES, st * TILE, TILE * facade::STRIP_TILES, TILE}; }
static void buildArt() {
    const bool ok = loadSpriteSheet();
    bindSprites();
    char nm[48];
    const int cellW = TILE * facade::STRIP_TILES;
    Img atlas(cellW * 3, TILE * 6);   // transient CPU copy (~2.6 MB), gone when this function returns
    for (int st = 0; st < 6; st++) for (int v = 0; v < 3; v++) {
        snprintf(nm, sizeof nm, "tile_%d_%d", st, v);
        const SprRect* r = sprFind(nm);
        const Img tile = ok && r ? sprCut(*r) : flatTile(TILE, TILE, 0xFF4A4F5C);   // flat grey if the sheet is missing: still playable
        const int cw = std::min(tile.w, TILE), ch = std::min(tile.h, TILE);
        for (int y = 0; y < ch; y++) for (int k = 0; k < facade::STRIP_TILES; k++)
            std::copy(tile.p.begin() + (size_t)y * tile.w, tile.p.begin() + (size_t)y * tile.w + cw,
                      atlas.p.begin() + (size_t)(st * TILE + y) * atlas.w + (size_t)v * cellW + (size_t)k * TILE);
    }
    gFacadeAtlas = createTexture(atlas);
    sprReleaseSheetImage();   // every cut-out is on the GPU now: drop the ~10 MB CPU copy of the whole sheet
}
static void tileMod(int r, int g, int b) {
    if (gFacadeAtlas) SDL_SetTextureColorMod(gFacadeAtlas, (Uint8)r, (Uint8)g, (Uint8)b);   // one call tints every tile
}

struct Settings { float music = 0.6f, sfx = 0.8f, sens = 1.0f; bool shake = true, reduced = false, full = true, targetHints = true, showFps = true; int fpsIdx = 1; float best = 0; };
// Frame limiter choices (index saved in the settings file). 0 = uncapped: no sleeping and vsync off, so the game runs as fast as the device allows.
static const int FPS_CAPS[] = {30, 60, 120, 0};
static const int FPS_CAP_N = 4;
static Settings cfg;
static void applyFramePacing();
// ---- Graphics settings (see graphics.h) ------------------------------------------------------------------------
static gfxcfg::Settings gGfx;                 // what the player chose
static gfxcfg::Caps gCaps;                    // what the device offers (filled after the renderer exists)
static gfxcfg::Effective gFx;                 // what is actually drawn right now
static gfxcfg::Warnings gGfxWarn;             // shown on the Graphics screen
static gfxcfg::Governor gGov;                 // automatic optimiser
static std::string gfxPath;
static int gDisplayHz = 60;
static void gfxRefresh() { gGfxWarn = gfxcfg::Warnings(); gFx = gfxcfg::resolve(gGfx, gCaps, gGov.level, &gGfxWarn); }
static void gfxSave() { if (!gfxPath.empty()) gfxcfg::saveFile(gfxPath, gGfx); }
// Every option except the graphics API takes effect on the next frame. The API needs a new renderer, so it is saved and applied on the next launch.
static void gfxChanged() { gGov.reset(); gfxRefresh(); gfxSave(); }
// ---- Fullscreen ----------------------------------------------------------------------------------------
// One entry point for every way in (SETTINGS button, F11, Alt+Enter) and out (the same, plus Esc on the main menu). SDL_WINDOW_FULLSCREEN_DESKTOP keeps the
// desktop resolution (no mode switch), then recalculateDisplayLayout() picks the new integer pixel scale from the SIZE_CHANGED event: the scale is never
// fractional, so pixels stay square and sharp, and the oversize remainder is cropped evenly instead of leaving borders. Nothing in the run is rebuilt.
static Uint32 gFsReqTicks = 0;   // when fullscreen was last requested (0 = never); the OS needs a moment to apply it
static bool fsRecent() { return gFsReqTicks != 0 && SDL_GetTicks() - gFsReqTicks < 1000; }
static bool windowIsFullscreen() { return uvzWindow && (SDL_GetWindowFlags(uvzWindow) & SDL_WINDOW_FULLSCREEN) != 0; }   // the DESKTOP flag includes this bit
static void saveCfg();
static void setFullscreen(bool on) {
#ifdef __ANDROID__
    (void)on; cfg.full = true; return;   // the Android activity is always immersive (edge-to-edge, hidden system bars): never leave it
#endif
    cfg.full = on; gFsReqTicks = SDL_GetTicks() | 1u;
    if (uvzWindow) SDL_SetWindowFullscreen(uvzWindow, on ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
    saveCfg();
}
static int fpsCap() { return FPS_CAPS[clampInt(cfg.fpsIdx, 0, FPS_CAP_N - 1)]; }
static std::string savePath, ctlPath, progPath;
static combo::State gCombo;
static std::string comboPath;
static prog::Data gProg;
static int coinMilestones = 0, runCoins = 0;
static void saveProg() { prog::saveFile(progPath, gProg); }
static void fmtNum(long long v, char* out, size_t n) {
    char t[32]; snprintf(t, sizeof t, "%lld", v);
    int len = (int)strlen(t), o = 0;
    for (int i = 0; i < len && o < (int)n - 2; i++) { if (i > 0 && (len - i) % 3 == 0) out[o++] = ','; out[o++] = t[i]; }
    out[o] = 0;
}
static const float PHYS_CAP = 8.0f;
static float runMult() { return std::min(prog::totalMult(gProg, prog::RUN), PHYS_CAP); }
static float swingMult() { return std::min(prog::totalMult(gProg, prog::SWING), PHYS_CAP); }
// Newer abilities are capped tighter than speed: a higher jump means a harder landing, and steering is only a nudge.
static const float JUMP_CAP = 1.30f, AIR_CAP = 3.0f, WEB_CAP = 2.2f;
static float jumpMult() { return std::min(prog::totalMult(gProg, prog::JUMP), JUMP_CAP); }   // scales jump launch speed
static float airMult()  { return std::min(prog::totalMult(gProg, prog::AIR), AIR_CAP); }     // scales mid-air steering
static float webMult()  { return std::min(prog::totalMult(gProg, prog::WEB), WEB_CAP); }     // scales steering force while swinging
static void loadCfg() {
    char* pp = SDL_GetPrefPath("PixelCity", "StickmanPixelCity");
    std::string dir = pp ? pp : "";
    savePath = dir + "save.txt";
    ctlPath = dir + "controls.txt";
    progPath = dir + "progress.txt";
    comboPath = dir + "combo.txt";
    gfxPath = dir + "graphics.txt";
    gfxcfg::loadFile(gfxPath, gGfx);
    if (pp) SDL_free(pp);
    prog::loadFile(progPath, gProg);
    combo::loadFile(comboPath, gCombo.best);
    FILE* f = fopen(savePath.c_str(), "r");
    if (!f) return;
    int sh = 1, rd = 0, fu = 1;
    float m, s, se, b;
    if (fscanf(f, "%f %f %f %d %d %d %f", &m, &s, &se, &sh, &rd, &fu, &b) == 7) {
        cfg.music = clampValue(m, 0, 1); cfg.sfx = clampValue(s, 0, 1); cfg.sens = clampValue(se, 0.5f, 1.5f);
        cfg.shake = sh != 0; cfg.reduced = rd != 0; cfg.full = fu != 0; cfg.best = std::max(0.0f, b);
        float legacy = 0.0f; int hints = 1;   // the 8th field is a retired setting; still read so old save files load
        if (fscanf(f, "%f %d", &legacy, &hints) >= 1) cfg.targetHints = hints != 0;
        int ver = 0, fi = 1, sf = 1;   // trailing fields added later: version marker, frame-limit index, show-FPS flag (absent in old saves)
        if (fscanf(f, " %d %d %d", &ver, &fi, &sf) == 3) { cfg.fpsIdx = clampInt(fi, 0, FPS_CAP_N - 1); cfg.showFps = sf != 0; }
    }
    fclose(f);
}
static void saveCfg() {
    FILE* f = fopen(savePath.c_str(), "w");
    if (!f) return;
    fprintf(f, "%f %f %f %d %d %d %f 0 %d 2 %d %d\n", cfg.music, cfg.sfx, cfg.sens, cfg.shake, cfg.reduced, cfg.full, cfg.best, cfg.targetHints, cfg.fpsIdx, cfg.showFps);
    fclose(f);
    saveProg();
}

enum Act { A_LEFT, A_RIGHT, A_JUMP, A_SLIDE, A_SWING, A_PAUSE, A_N };
static const char* const ACT_LABEL[A_N] = {"STEER LEFT", "STEER RIGHT", "JUMP", "SLIDE", "SWING", "PAUSE"};
static const SDL_Scancode ACT_DEFAULT[A_N] = {SDL_SCANCODE_A, SDL_SCANCODE_D, SDL_SCANCODE_SPACE, SDL_SCANCODE_S, SDL_SCANCODE_LSHIFT, SDL_SCANCODE_P};
struct Controls {
    SDL_Scancode key[A_N];
    float scale = 1.0f, alpha = 0.7f;
    bool lefty = false;
    float px[3], py[3];
    Controls() { resetKeys(); resetTouch(); }
    void resetKeys() { for (int i = 0; i < A_N; i++) key[i] = ACT_DEFAULT[i]; }
    void resetTouch() { scale = 1.0f; alpha = 0.7f; lefty = false; for (int i = 0; i < 3; i++) px[i] = py[i] = -1.0f; }
};
static Controls ctl;
static void loadControls() {
    FILE* f = fopen(ctlPath.c_str(), "r");
    if (!f) return;
    int k[A_N], lf = 0;
    float sc, al, px[3], py[3];
    int n = fscanf(f, "%d %d %d %d %d %d %f %f %d %f %f %f %f %f %f", &k[0], &k[1], &k[2], &k[3], &k[4], &k[5],
                   &sc, &al, &lf, &px[0], &py[0], &px[1], &py[1], &px[2], &py[2]);
    if (n == 15) {
        for (int i = 0; i < A_N; i++) if (k[i] > 0 && k[i] < SDL_NUM_SCANCODES) ctl.key[i] = (SDL_Scancode)k[i];
        ctl.scale = clampValue(sc, 0.7f, 1.4f); ctl.alpha = clampValue(al, 0.2f, 1.0f); ctl.lefty = lf != 0;
        for (int i = 0; i < 3; i++) { ctl.px[i] = px[i] < 0 ? -1.0f : clampValue(px[i], 0, 1); ctl.py[i] = px[i] < 0 ? -1.0f : clampValue(py[i], 0, 1); }
    }
    fclose(f);
}
static void saveControls() {
    FILE* f = fopen(ctlPath.c_str(), "w");
    if (!f) return;
    for (int i = 0; i < A_N; i++) fprintf(f, "%d ", (int)ctl.key[i]);
    fprintf(f, "%f %f %d", ctl.scale, ctl.alpha, ctl.lefty ? 1 : 0);
    for (int i = 0; i < 3; i++) fprintf(f, " %f %f", ctl.px[i], ctl.py[i]);
    fprintf(f, "\n");
    fclose(f);
}

static SDL_AudioDeviceID gAud = 0;
static audio::Synth gSynth;   // all sound is synthesized in audio.h; the callback only mixes it down to stereo
static std::atomic<float> aMusic{0.6f}, aSfx{0.8f}, aWind{0.0f};
static std::atomic<int> aMode{0};
static bool audioStarted = false;

static void audioCB(void*, Uint8* stream, int len) {
    float* o = (float*)stream;
    int n = len / (int)(sizeof(float) * 2);
    static float mono[8192];
    while (n > 0) {
        int c = n < 8192 ? n : 8192;
        gSynth.render(mono, c, aMusic.load(), aSfx.load(), aWind.load(), aMode.load());
        for (int i = 0; i < c; i++) { o[i * 2] = mono[i]; o[i * 2 + 1] = mono[i]; }
        o += c * 2; n -= c;
    }
}
// Sampled sound effects (assets/audio/sfx/<name>_<n>.wav, n = 0..7). Missing files fall back to the synthesized sounds in audio.h.
static void loadSfxClips() {
    static const char* const NAMES[audio::kSfxCount] = {"web_shoot", "web_attach", "wall_hit", "reward", "ui", "splat", "land", "jump", "release"};
    static const char* const DIRS[] = {"assets/audio/sfx/", "../assets/audio/sfx/", "../../assets/audio/sfx/"};
    std::vector<unsigned char> d;   // one read buffer reused for every clip (the decoded floats are copied into the synth)
    for (int t = 0; t < audio::kSfxCount; t++) {
        for (int n = 0; n < audio::kMaxVariants; n++) {
            bool got = false;
            for (const char* dir : DIRS) {
                char fn[160]; snprintf(fn, sizeof fn, "%s%s_%d.wav", dir, NAMES[t], n);
                if (sprReadFile(fn, d)) { got = gSynth.addClip(t, d.data(), d.size()); break; }
            }
            if (!got) break;
        }
    }
}
static void loadLoops() {
    static const char* const FILES[4] = {"music_menu_loop.wav", "music_gameplay_loop.wav", "ambient_rumble_idle.wav", "ambient_wind_fast.wav"};
    static const char* const DIRS[] = {"assets/audio/", "../assets/audio/", "../../assets/audio/"};
    for (int i = 0; i < 4; i++) for (const char* dir : DIRS) {
        std::vector<unsigned char> d; std::string fn = std::string(dir) + FILES[i];
        if (sprReadFile(fn.c_str(), d)) { if (!gSynth.setLoop(i, d.data(), d.size())) fprintf(stderr, "audio: could not decode %s\n", fn.c_str()); break; }
    }
}
static void initAudio() {
    loadSfxClips();
    loadLoops();
    SDL_AudioSpec want, have;
    SDL_zero(want);
    want.freq = 44100; want.format = AUDIO_F32SYS; want.channels = 2; want.samples = 1024; want.callback = audioCB;
    gAud = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    if (!gAud) fprintf(stderr, "audio: SDL_OpenAudioDevice failed: %s\n", SDL_GetError());
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void sfx(int type) {
    if (!gAud) return;
    SDL_LockAudioDevice(gAud);
    gSynth.trigger(type);
    SDL_UnlockAudioDevice(gAud);
}

enum State { TITLE, MAIN_MENU, SETTINGS, GRAPHICS, CONTROLS, LAYOUT_EDIT, HOW_TO_PLAY, CREDITS, SKILLS, PLAYING, PAUSED, GAME_OVER };
static State gState = TITLE, navRoot = MAIN_MENU;
static std::vector<State> navStack;
static bool isSub(State s) { return s == SETTINGS || s == GRAPHICS || s == CONTROLS || s == LAYOUT_EDIT || s == HOW_TO_PLAY || s == CREDITS || s == SKILLS; }
static void openSub(State s) { if (!isSub(gState)) { navRoot = gState; navStack.clear(); } navStack.push_back(gState); gState = s; }
static void goBack() { if (!navStack.empty()) { gState = navStack.back(); navStack.pop_back(); } else gState = navRoot; }
static double gTime = 0;
static double gSkyTime = 0;   // lighting clock (seconds into the 180 s cycle); see the sky module
static double gSafeLandUntil = 0;   // after the menu handoff the first street landing is forgiven (gTime)
static double gRunT0 = 0;     // gTime when the current run started
struct Ragdoll { bool on = false; float x[J_N] = {}, y[J_N] = {}, px[J_N] = {}, py[J_N] = {}; };
static Ragdoll gRag;   // the dead runner's limp body (see ragStart)
static StkPose gLastPose; static double gLastAng = 0; static bool gLastMirror = false;   // last live pose (saved by the draw code)

static const float ROOF_CUSHION = 1.15f;   // vehicle suspension: a roof landing counts as this much softer than the same drop onto asphalt
#ifdef PCITY_TEST_STREET_Y
static const float STREET_GROUND_Y = PCITY_TEST_STREET_Y;   // test-only: lets physics tests move the deadly street out of the way
#else
static const float STREET_GROUND_Y = 0.0f;
#endif
static const float TRAFFIC_SIGNAL_CYCLE = 14.0f;
struct Obs { int type; float x, w, h; bool solid; int param; };
struct Building {
    float x, w, roofY; int style; u32 seed;
    int uid = 0;        // stable id assigned when the building is registered in the chunk grid (shadow / AO ownership)
    int setbacks = 0;   // wedding-cake tiers on tall towers (visual)
    int landmark = 0;   // 0 none, 1 Empire State, 2 Chrysler, 3 One World Trade, 4 Flatiron-style
    std::vector<Obs> obs;
    bool mastL = false, mastR = false, cable = false;
    bool startRoof = false;   // the opening rooftop: a safe platform to stand on (everything else stays deadly)
    float cx0 = 0, cy0 = 0, cx1 = 0, cy1 = 0;
};
struct TrafficSignal { float x, offset; };
struct TrafficCar {
    float x, speed, maxSpeed, width, height;
    int type, lane, dir;
    u32 color;
    int id = -1;      // stable id so a rider can find "its" vehicle again
    float dx = 0;     // how far the vehicle moved in the last traffic step
    float dip = 0, dipV = 0;   // suspension squash (px, >= 0): a landing on the roof pushes the body down, a damped spring eases it back
};
struct Part { float x, y, vx, vy, life, max; u32 c; int sz; bool alive; };

static std::deque<Building> bld;
// Rooftop-prop vectors of unloaded buildings are kept and reused by the next building (see pool.h): no malloc/free per spawned building.
static pool::VecPool<Obs> gObsPool;
static std::deque<TrafficSignal> trafficSignals;
static std::deque<TrafficCar> trafficCars;
struct StreetCrate { float x, w, h; int variant; };   // street-level obstacle the runner vaults (low) or jumps (tall); never lethal
static std::deque<StreetCrate> gCrates;
static float nextCrateX = 0;
static float nextTrafficSpawnX = 0;
static int trafficSerial = 0;

// ======================================================================================
// Chunked world. The world is cut into CHUNK_W px wide slabs (chunks.h). Buildings, traffic signals and street crates are
// registered in every chunk they touch when they are generated and removed when they fall behind the runner, so drawing,
// collision and web targeting only look at the chunks around the point or range they care about instead of the whole list.
//   load   : the generator (addBuilding / ensureCrates) runs ahead of the camera; new objects open chunks on demand.
//   unload : ensureWorld pops what is behind the aligned unload edge, erases it from its chunks and frees the empty ones.
// The grids are caches over the deques: every query first checks a cheap signature (size, ends, extents) and rebuilds the
// grid if somebody changed a deque directly (tests, restarts), so they can never go stale or dangle.
// ======================================================================================
static chunks::Grid<Building> gBldGrid;
static chunks::Grid<TrafficSignal> gSigGrid;
static chunks::Grid<StreetCrate> gCrateGrid;
static const chunks::Window gChunkWin{};   // behind = 800 px, ahead = 1400 px (the former prune / look-ahead distances)
static chunks::Stats gChunkStats;          // chunks touched / objects visited by the most recent building query
static int gBldUid = 0;
static const float SCENE_MARGIN = 160.0f;  // facades, masts and fx stick out of a building by up to this much
static const float CABLE_REACH = 1100.0f;  // a cable spans the gap to the next building (the widest gap is ~1020 px)
static const float OBS_PAD = 48.0f;        // rooftop props are inside their building; the pad covers antenna arms and similar overhangs
struct GridSig { size_t n = 0; const void* f = nullptr; const void* b = nullptr; float flo = 0, fhi = 0, blo = 0, bhi = 0; };
static GridSig gBldSig, gSigSig, gCrateSig;
static void bldExt(const Building& b, float& lo, float& hi) { lo = b.x; hi = b.x + b.w; }
static void sigExt(const TrafficSignal& s, float& lo, float& hi) { lo = hi = s.x; }
static void crateExt(const StreetCrate& c, float& lo, float& hi) { lo = c.x; hi = c.x + c.w; }
template <class Dq, class Ext>
static GridSig makeSig(const Dq& dq, Ext ext) {
    GridSig g; g.n = dq.size();
    if (!dq.empty()) { g.f = &dq.front(); g.b = &dq.back(); ext(dq.front(), g.flo, g.fhi); ext(dq.back(), g.blo, g.bhi); }
    return g;
}
static bool sigEq(const GridSig& a, const GridSig& b) {
    return a.n == b.n && a.f == b.f && a.b == b.b && a.flo == b.flo && a.fhi == b.fhi && a.blo == b.blo && a.bhi == b.bhi;
}
template <class T, class Dq, class Ext, class Reg>
static void syncGrid(chunks::Grid<T>& g, GridSig& sig, Dq& dq, Ext ext, Reg onReg) {
    const GridSig now = makeSig(dq, ext);
    if (sigEq(now, sig)) return;
    if (sig.n >= 1 && now.n == sig.n + 1 && now.f == sig.f && now.flo == sig.flo && now.fhi == sig.fhi) {   // the common case: one object appended
        T& prev = dq[dq.size() - 2];
        float lo, hi; ext(prev, lo, hi);
        if ((const void*)&prev == sig.b && lo == sig.blo && hi == sig.bhi) {
            T& nb = dq.back(); float l2, h2; ext(nb, l2, h2); onReg(nb); g.insert(&nb, l2, h2); sig = now; return;
        }
    }
    g.clear();
    for (T& e : dq) { float lo, hi; ext(e, lo, hi); onReg(e); g.insert(&e, lo, hi); }
    sig = now;
}
static void syncBldGrid()   { syncGrid(gBldGrid, gBldSig, bld, bldExt, [](Building& b) { if (b.uid == 0) b.uid = ++gBldUid; }); }
static void syncSigGrid()   { syncGrid(gSigGrid, gSigSig, trafficSignals, sigExt, [](TrafficSignal&) {}); }
static void syncCrateGrid() { syncGrid(gCrateGrid, gCrateSig, gCrates, crateExt, [](StreetCrate&) {}); }
static void syncWorldGrids() { syncBldGrid(); syncSigGrid(); syncCrateGrid(); }
static void resetChunks() { gBldGrid.clear(); gSigGrid.clear(); gCrateGrid.clear(); gBldSig = gSigSig = gCrateSig = GridSig(); gChunkStats = chunks::Stats(); }
// Everything whose footprint touches [x0, x1], in left-to-right order. Callers keep their own precise overlap tests.
static chunks::Hits<Building> bldNear(float x0, float x1) { syncBldGrid(); return gBldGrid.hits(x0, x1, &gChunkStats); }
static chunks::Hits<TrafficSignal> sigNear(float x0, float x1) { syncSigGrid(); return gSigGrid.hits(x0, x1); }
static chunks::Hits<StreetCrate> crateNear(float x0, float x1) { syncCrateGrid(); return gCrateGrid.hits(x0, x1); }
// Exact-extent variants for collision: only objects whose footprint touches [x0, x1] (same order as the coarse queries). Callers that do their own
// overlap test against the same range can swap to these with identical results; the coarse ones hand back everything in the 1024 px chunks.
static bool gCoarseCollisionQueries = false;   // tests only: route the exact queries through the coarse chunk query to prove both give identical physics
static chunks::Hits<Building> bldNearExact(float x0, float x1) { syncBldGrid(); return gCoarseCollisionQueries ? gBldGrid.hits(x0, x1, &gChunkStats) : gBldGrid.hitsExact(x0, x1, &gChunkStats); }
static chunks::Hits<StreetCrate> crateNearExact(float x0, float x1) { syncCrateGrid(); return gCoarseCollisionQueries ? gCrateGrid.hits(x0, x1) : gCrateGrid.hitsExact(x0, x1); }
// collide() can shove the runner sideways mid-loop (a bump moves P.x by at most the width of the solid thing hit: rooftop props <= 30 px, crates <= 60 px,
// building faces 2 px), and its per-object tests read the live P.x. Querying this much extra on each side keeps every object it could still reach.
static const float COLLIDE_PUSH_PAD = 160.0f;
// Unload helpers: erase from the chunks first, then drop the object, then free chunks that became empty.
static void popFrontBuilding() { syncBldGrid(); Building& f = bld.front(); gBldGrid.erase(&f, f.x, f.x + f.w); gObsPool.give(f.obs); bld.pop_front(); gBldSig = makeSig(bld, bldExt); }
static void popFrontSignal()   { syncSigGrid(); const TrafficSignal& f = trafficSignals.front(); gSigGrid.erase(&f, f.x, f.x); trafficSignals.pop_front(); gSigSig = makeSig(trafficSignals, sigExt); }
static void popFrontCrate()    { syncCrateGrid(); const StreetCrate& f = gCrates.front(); gCrateGrid.erase(&f, f.x, f.x + f.w); gCrates.pop_front(); gCrateSig = makeSig(gCrates, crateExt); }
static Part parts[220];
static int partHead = 0;
static Rng wrng(1);
static const float LANE_FAR_Y = 14.0f, LANE_NEAR_Y = 28.0f, LANE_DIV_Y = 21.0f;   // wheel lines of the two lanes and the dashed divider, below the street plane: both on the asphalt (the sidewalk and curb end at +11)
static float carBottomY(const TrafficCar& c) { return STREET_GROUND_Y + (c.lane ? LANE_NEAR_Y : LANE_FAR_Y); }
static float carTopY(const TrafficCar& c) { return carBottomY(c) - c.height + c.dip; }   // the roof follows the squash, so a rider is carried smoothly down and back up
static const TrafficCar* findCar(int id) {
    if (id < 0) return nullptr;
    for (const TrafficCar& c : trafficCars) if (c.id == id) return &c;
    return nullptr;
}

struct Player {
    float x = 0, y = 0, px = 0, py = 0;
    float vx = 0, vy = 0;
    bool onGround = false, swinging = false, alive = true, usedAir = false;
    bool wallCling = false, webFlying = false;
    float wallX = 0, wallDir = 1;
    float webX = 0, webY = 0, webStartX = 0, webStartY = 0, webT = 0, webDur = 0.18f;
    float ax = 0, ay = 0, rope = 0, ropeEff = 0;   // ropeEff: the reeled-in length actually used through the bottom and upswing
    float hangT = 0;   // short low-gravity window right after a web release
    float coyote = 0, jumpBuf = 0;
    float landT = 0, shootT = 0, attachT = 0, releaseT = 0, deadT = 0, flipT = 0;
    bool hero = false;
    int runStyle = 0, jumpStyle = 0, fallStyle = 0, swingStyle = 0, landStyle = 0, shootStyle = 0;
    float slideT = 0, slideBuf = 0;
    int slideStyle = 0;
    float boostT = 0, boostDur = 1, boostExtra = 0;
    float jit = 0;
    bool releaseFlip = false;
    float flipDir = 1;
    int chain = 0;
    float swingT = 0;
    float launchT = 0, launchK = 0, launchDur = 0.25f;
    float perfectT = 0;
    int wrapN = 0; float wrapCool = 0;
    float vaultT = 0;
    float wallEdge = 0;
    float climbPhase = 0;
    float wallCool = 0;
    float wallLastEdge = -1e9f, wallLastCool = 0;
    float wallJumpT = 0;
    float wallImpact = 0;
    int trickType = 0;
    float trickT = 0, trickDur = 0, trickCool = 0, trickDoneT = 0, trickApexQ = 0;
    bool trickReady = false, trickNear = false;
    int trickLast = 0;
    float mantleT = 0, mantleX0 = 0, mantleY0 = 0, mantleX1 = 0, mantleY1 = 0;
    bool zipping = false; float zipX = 0, zipY = 0, zipT = 0, zipCool = 0;
    bool diving = false; float diveT = 0, diveCool = 0, diveMemT = 0;   // diveMemT: counts down after a dive ends, so a web fired just after still counts as dive-to-swing
    int rideId = -1;           // id of the vehicle the player is standing on (-1 = none)
    bool groundedPrev = false; // was supported (street or vehicle) at the end of the previous physics step
    bool deadGround = false;   // died by hitting the street
    float vaultOneT = 0, vaultOneDur = 0.5f;   // one-handed vault over a street crate (animation + a short hop)
    float rollT = 0, rollDur = 0.45f;          // landing roll (animation; hitbox unchanged)
    float streetImpact = 0; bool streetRoll = false;   // set by collide() on a street touchdown, read by the landing code
    float landDepth = 0;
};
static Player P;
enum { T_NONE, T_FRONT, T_BACK, T_TWIST, T_CART };
static float gTrickHeat = 0;
static float gTrickMsgT = 0; static char gTrickMsg[40] = ""; static char gStuntName[28] = ""; static bool gTrickBad = false;
static float camX = 0, camY = 0, startX = 0, shakeT = 0, chainShowT = 0;
static float distM = 0, bonus = 0, speedBonus = 0;
static bool newBest = false;
static bool zipEdge = false, diveHeld = false, slideHeld = false;
static float gSlideHoldT = 0;
static float gSense = 0, gSenseTgt = 0, gSenseAng = 0, gSenseT = 0;
static bool jumpEdge = false, slideEdge = false, jumpRel = false, swingHeld = false, swingWas = false;
static float steer = 0;
static float gFlow = 0;
// ---- Iron Arms: four mechanical back arms. TAP = upward launch, HOLD + SLIDE = forward launch. ONE shared 12 s cooldown. ----
static const float IRON_COOLDOWN = 12.0f;   // seconds of play; starts the moment either launch activates
static float gIronCd = 0;                   // > 0 = cooling down: the button is hidden and inert (no countdown is drawn)
static bool gIronUpEdge = false, gIronFwdEdge = false, gIronHeld = false, gIronKeyDown = false, gIronKeyUsed = false;
static float gIronReadyPop = 0;             // short pop-in when the button comes back
static int gIronKind = 0;                   // last launch: 1 = up, 2 = forward
static float gIronFxT = 0, gIronFxDur = 0.5f, gIronRingT = 0, gIronRingX = 0, gIronRingY = 0;
struct IronArm { float a1 = 0.5f, a2 = -1.8f, ext = 0.0f; };   // joint angles (rad, measured from "back" toward "up") and reach, per arm
static IronArm gIronArm[4];
static float gIronVis = 0;                  // 0..1 how far the arms are deployed: hidden (0) unless a launch is in progress
static void ironReset() {
    gIronCd = 0; gIronUpEdge = gIronFwdEdge = gIronHeld = gIronKeyDown = gIronKeyUsed = false;
    gIronReadyPop = 0; gIronKind = 0; gIronFxT = gIronRingT = 0; gIronVis = 0;
}
static bool ironUnlocked() { return prog::ironUnlocked(gProg); }
// The primary button exists only while the ability is unlocked AND its cooldown is over (and the runner is alive in a run).
static bool ironButtonShown() { return gState == PLAYING && ironUnlocked() && gIronCd <= 0.0f && P.alive; }
// Web Catch: civilians fall from the sky ahead of you; touch one in the air to rescue it (no combat involved).
struct Faller { float x, y, vx, vy, t; bool alive; int shirt; };
static const size_t FALLER_SLOTS = 32;   // a faller spawns every 1800+ px and is gone 400 px behind the camera: a handful is alive at once
static std::vector<Faller> gFallers;      // capacity reserved once (rescueTick), so spawning never reallocates and removal never shifts the tail
static float gNextFallerX = 0; static u32 gFallerSerial = 0; static int gRescues = 0, gRescueStreak = 0;
static int gPerfectStreak = 0;
static float gPerfectShowT = 0;
static int gComboNm = -1, gComboNmPrev = -2;
static float gComboNmX = 0, gComboNmGap = 1e9f;
static float camPunch = 0;
struct Trail { float x, y, t, max; u32 c; };
static Trail gTrail[16];
static int gTrailHead = 0;
static float gTrailTick = 0;
static bool haveTarget = false;
static float tgtX = 0, tgtY = 0;
static float gAirT = 0, hintT = 0;
static bool hintFound = false;
static const float WEB_BUF = 0.15f;   // a web tap made up to this long before it can fire (still on the ground / on a wall) or before an anchor is in reach is kept and retried
static float gWebBufT = 0, gWebRetryT = 0;
static float hintX = 0, hintY = 0;
static void badClear();
static float gLastPickX = 1e9f, gLastPickY = 1e9f;
static float trans = -1, menuT = 0, fadeIn = 0;

static const float GRAV = 1400.0f;
static const float SLIDE_BOOST = 0.001f;   // a plain slide gives +0.1% speed (x1.001), held for the whole slide
static float difficulty() { return diff::ramp(distM); }   // 0 at the start, 1.0 when MASTER begins, then creeps to 1.25 (endless)
static int gTier = 0; static float gTierMsgT = 0;
static int scoreVal() { return (int)(distM + bonus + speedBonus); }

static void spawnPart(float x, float y, float vx, float vy, float life, u32 c, int sz = 2) {
    if (cfg.reduced && (partHead & 1)) { partHead = (partHead + 1) % 220; return; }
    parts[partHead] = {x, y, vx, vy, life, life, c, sz, true};
    partHead = (partHead + 1) % 220;
}
static void burst(float x, float y, int n, u32 c, float spd) {
    for (int i = 0; i < n; i++) {
        float a = (float)i / n * 2 * pi + wrng.f();
        spawnPart(x, y, cosf(a) * spd * (0.4f + wrng.f()), sinf(a) * spd * (0.4f + wrng.f()), 0.35f + wrng.f() * 0.3f, c);
    }
}
static void doShake(float t) { if (cfg.shake) shakeT = std::max(shakeT, t); }

// Life-size Manhattan at ~30 px/m: a cross street is ~18 m (540 px) kerb to kerb, an avenue ~30 m (900 px) between building faces.
static const int CITY_GAP_MIN = 500, CITY_GAP_MAX = 960, CITY_W_MIN = 224, CITY_W_MAX = 1536;
// Life-size scale: the stickman is ~52 px = 1.75 m (about 30 px/m). Each vehicle keeps its original art
// (designed in a small local grid) and is drawn at SCALE x so cars are ~1.5 m tall, buses ~3 m, and so on; lengths follow real vehicles.
static float trafficScale(int type) {
    static const float sc[] = {1.65f, 1.65f, 2.2f, 2.4f, 1.65f};
    return sc[type % 5];
}
static float trafficWidth(int type) {
    static const float widths[] = {87.0f, 82.0f, 164.0f, 88.0f, 38.0f};   // life size at ~30 px/m: taxi 4.8 m, car 4.5 m, bus 12 m, box truck 7 m, motorcycle 2.1 m
    return widths[type % 5] * trafficScale(type);
}
static float trafficHeight(int type) {
    static const float heights[] = {27.0f, 24.0f, 38.0f, 34.0f, 20.0f};
    return heights[type % 5] * trafficScale(type);
}
static bool trafficSignalGreen(const TrafficSignal& s, int dir, double time) {
    float phase = fmodf((float)time + s.offset, TRAFFIC_SIGNAL_CYCLE);
    if (phase < 0) phase += TRAFFIC_SIGNAL_CYCLE;
    const bool eastbound = phase < TRAFFIC_SIGNAL_CYCLE * 0.5f;
    return dir > 0 ? eastbound : !eastbound;
}
static int gBlockLeft = 0, gZone = 1;   // New York generator state: buildings left in this block, district type
static void addBuilding(bool first) {
    float d = diff::cityRamp(distM);
    Building b;
    b.obs = gObsPool.take();   // a retired building's vector (capacity kept) instead of a fresh allocation
    b.seed = wrng.next();
    b.style = wrng.range(0, 5);
    float gap = 0;
    if (first) { b.x = -300; b.w = 1100; b.roofY = -520; b.style = 2; gBlockLeft = 0; gZone = 1; b.startRoof = true; }
    else {
        Building& p = bld.back();
        // New York street grid: buildings are built flush in blocks (party walls, no gap); a cross street / avenue opens between
        // blocks. Each block is a district: brownstone row (low, narrow lots), midtown mid-rise, or tower cluster.
        bool newBlock = gBlockLeft <= 0;
        if (newBlock) {
            // Zones (heights at 30 px/m): 0 = walk-up / brownstone rows, 6-9 floors (~20-30 m); 1 = midtown mid-rise, 40-120 m;
            // 2 = tower cluster, 120-300 m. Towers become more common the further you run.
            const float z = wrng.f(), pt = 0.08f + 0.27f * d;
            gZone = z < pt ? 2 : (z < pt + 0.42f ? 1 : 0);
            gBlockLeft = gZone == 0 ? wrng.range(5, 9) : wrng.range(3, 5);   // narrow brownstone lots (~7-12 m) pack more per block
            const bool avenue = wrng.f() < 0.35f;
            gap = avenue ? (float)wrng.range(840, 960 + (int)(60 * d)) : (float)wrng.range(CITY_GAP_MIN, 600 + (int)(60 * d));   // avenue ~30 m, cross street ~18 m
        }
        gBlockLeft--;
        static const int WLO[3] = {224, 448, 768}, WHI[3] = {352, 832, 1536};   // lot widths: ~7-12 m, 15-28 m, 26-50 m
        static const int RLO[3] = {-900, -3600, -9000}, RHI[3] = {-560, -1200, -3600};   // roofY ranges per district (negative = up): ~19-30 m, 40-120 m, 120-300 m
        b.w = (float)((wrng.range(WLO[gZone], WHI[gZone] - (int)(32 * d)) / 16) * 16);
        const int maxRise = newBlock ? 1500 : (gZone == 0 ? 160 : (gZone == 1 ? 600 : 1100));
        const float target = (float)wrng.range(RLO[gZone], RHI[gZone]);
        b.roofY = clampValue(clampValue(target, p.roofY - maxRise, p.roofY + maxRise), (float)RLO[gZone] - 40.0f, (float)RHI[gZone] + 40.0f);
        b.roofY = clampValue(b.roofY, -9400.0f, -520.0f);
        static const int ZSTYLE[3][4] = {{2, 3, 3, 2}, {1, 5, 4, 2}, {0, 1, 5, 0}};
        b.style = ZSTYLE[gZone][wrng.range(0, 3)];
        b.x = p.x + p.w + gap;
        if (bld.size() >= 3 && p.landmark == 0 && gZone > 0 && wrng.f() < 0.18f) {   // New York landmark: taller, and its spire is a web anchor
            b.landmark = wrng.range(1, 4);
            static const int LM_STYLE[5] = {0, 1, 5, 0, 2};
            b.style = LM_STYLE[b.landmark];
            if (b.landmark == 4) b.w = 320.0f; else b.w = std::max(b.w, 400.0f);
            b.roofY = std::min(b.roofY, -6000.0f);   // landmarks are real supertalls (Empire State ~380 m)
        }
        if (b.landmark == 0 && gZone == 2 && b.w >= 512 && b.roofY <= -3600.0f) b.setbacks = 1 + (int)(wrng.range(0, 1));
        if (gap > 150) trafficSignals.push_back({p.x + p.w + gap * 0.5f, wrng.f() * TRAFFIC_SIGNAL_CYCLE});
        if (b.style == p.style && gap < 1.0f) b.style = (b.style + 1 + wrng.range(0, 4)) % 6;
        if (gap > 150) {
            p.mastR = true; b.mastL = true; p.cable = fabsf(p.roofY - b.roofY) < 500.0f;   // a cable only between neighbours of similar height
            p.cx0 = p.x + p.w - 10; p.cy0 = p.roofY - 280; p.cx1 = b.x + 10; p.cy1 = b.roofY - 280;
        }
    }
    if (!first && b.landmark == 0 && b.setbacks == 0 && b.w >= 400 && wrng.f() < 0.3f + 0.5f * d) {
        int n = (b.w >= 700 && wrng.f() < 0.5f) ? 2 : 1;
        float x = b.x + 220;
        for (int i = 0; i < n; i++) {
            int ty = wrng.range(0, 2);
            float w = ty == 0 ? 28.0f : (ty == 1 ? 30.0f : 24.0f), h = ty == 0 ? 20.0f : (ty == 1 ? 46.0f : 14.0f);
            float span = (b.x + b.w - 200) - x - w;
            if (span < 0) break;
            x += wrng.range(0, (int)std::min(span, 160.0f));
            b.obs.push_back({ty, x, w, h, true, 0});
            x += w + 230;
        }
    }
    // No dedicated web anchors: the web sticks to whatever surface it hits (roofs, walls, rooftop props, cranes, cables).
    if (b.landmark == 0 && b.setbacks == 0 && b.w > 320 && wrng.f() < (b.style == 5 ? 0.95f : 0.65f)) {
        float x = b.x + wrng.range(40, (int)b.w - 170), h = (float)wrng.range(220, 300);
        b.obs.push_back({4, x, 110, h, false, 0});
    }
    if (b.landmark == 0 && b.setbacks == 0 && b.w > 320 && wrng.f() < 0.65f) {
        float x = b.x + wrng.range(20, (int)b.w - 130);
        b.obs.push_back({5, x, 96, 114, false, wrng.range(0, 3)});
    }
    if (wrng.f() < 0.4f) b.obs.push_back({6, b.x + wrng.range(20, std::max(21, (int)b.w - 20)), 12, 16, false, 0});
    bld.push_back(std::move(b));
    syncBldGrid();   // load: the new building opens / joins the chunks it touches
}
static void ensureWorld() {
    syncWorldGrids();
    while (bld.back().x + bld.back().w < gChunkWin.loadEdge(camX, (float)uvzWorldWidth)) addBuilding(false);   // load ahead
    const float edge = gChunkWin.unloadEdge(camX);   // unload behind, on a chunk boundary
    while (bld.size() > 3 && bld.front().x + bld.front().w < edge) popFrontBuilding();
    while (trafficSignals.size() > 2 && trafficSignals.front().x < edge) popFrontSignal();
    gBldGrid.unloadBefore(edge); gSigGrid.unloadBefore(edge);
}
static void ensureTraffic() {
    if (nextTrafficSpawnX <= 0) nextTrafficSpawnX = std::max(P.x + 380.0f, camX + uvzWorldWidth * 0.25f);
    while (nextTrafficSpawnX < camX + uvzWorldWidth + 850.0f) {
        const u32 seed = hashCoordinates((u32)(trafficSerial + 1), 0x4E5943u, 29u);
        Rng r(seed);
        const int dir = (trafficSerial & 1) ? -1 : 1;
        Rng tr(hashCoordinates((u32)(trafficSerial + 1), 0x7E57u, 3u));
        const int type = diff::pickTrafficType(diff::tierFor(distM), tr.f());   // taxi, car, bus, truck, motorcycle: heavier / faster types unlock with the tier
        static const u32 colors[] = {0xE8B72D, 0xB7473F, 0x3F92B5, 0x747C86, 0x5D9B69, 0xC66F9A};
        TrafficCar car;
        car.x = nextTrafficSpawnX + r.range(0, 90);
        car.speed = 0;
        car.maxSpeed = (float)r.range(type == 2 ? 90 : (type == 4 ? 150 : 120), type == 2 ? 165 : (type == 4 ? 265 : 235)) * diff::trafficSpeedScale(distM);
        car.width = trafficWidth(type);
        car.height = trafficHeight(type);
        car.type = type;
        car.dir = dir;
        car.lane = dir > 0 ? 0 : 1;
        car.color = type == 0 ? 0xE8B72D : colors[1 + r.range(0, 4)];
        car.id = trafficSerial;
        trafficCars.push_back(car);
        nextTrafficSpawnX += car.width * 0.5f + (float)r.range(430, 660) * diff::trafficSpacingScale(distM);   // wider spacing for life-size vehicles
        trafficSerial++;
    }
    for (auto it = trafficCars.begin(); it != trafficCars.end();) {
        if (it->x < camX - 620.0f || it->x > camX + uvzWorldWidth + 1900.0f) it = trafficCars.erase(it);
        else ++it;
    }
}
static void ensureCrates() {
    if (!diff::crateEnabled(distM)) return;
    const int tier = diff::tierFor(distM);
    if (nextCrateX <= 0) nextCrateX = std::max(P.x + 700.0f, camX + uvzWorldWidth + 300.0f);
    while (nextCrateX < camX + uvzWorldWidth + 900.0f) {
        Rng r(hashCoordinates((u32)(nextCrateX * 0.5f) + 11u, 0xC4A7Eu, (u32)tier));
        StreetCrate c;
        c.variant = r.range(0, diff::crateVariants(tier) - 1);
        const float maxH = diff::crateMaxHeight(tier);
        static const float VW[4] = {28.0f, 46.0f, 28.0f, 60.0f}, VH[4] = {22.0f, 24.0f, 36.0f, 24.0f};
        c.w = VW[c.variant]; c.h = std::min(VH[c.variant], maxH);
        c.x = nextCrateX;
        bool nearCar = false;                                   // never drop a crate right next to a vehicle
        for (const TrafficCar& car : trafficCars) if (fabsf(car.x - c.x) < 120.0f + car.width * 0.5f) nearCar = true;
        if (nearCar) { nextCrateX += 120.0f; continue; }
        gCrates.push_back(c);
        nextCrateX = c.x + c.w + diff::crateGap(distM, r.f());
    }
    while (!gCrates.empty() && gCrates.front().x + gCrates.front().w < camX - 400.0f) popFrontCrate();
    gCrateGrid.unloadBefore(camX - 400.0f);
}
// Roof landings press the suspension: the body dips a few px by a damped spring and settles. No damage, no rebound above rest height.
static const float SUSP_K = 260.0f, SUSP_C = 17.0f, SUSP_MAX = 5.0f;
static float suspensionKick(int type, float impactVy) {          // initial downward speed (px/s) of the body for a touchdown at impactVy
    static const float mass[5] = {1.0f, 1.0f, 0.45f, 0.55f, 1.3f};   // taxi, car, bus, truck, motorcycle: heavier vehicles barely move
    return clampValue(impactVy, 0.0f, 900.0f) * 0.11f * mass[type % 5];
}
static void suspensionStep(TrafficCar& c, float dt) {
    if (c.dip <= 0.0f && c.dipV <= 0.0f) { c.dip = 0; c.dipV = 0; return; }
    c.dipV += (-SUSP_K * c.dip - SUSP_C * c.dipV) * dt;
    c.dip += c.dipV * dt;
    if (c.dip < 0.0f) { c.dip = 0.0f; if (c.dipV < 0.0f) c.dipV = 0.0f; }
    if (c.dip > SUSP_MAX) { c.dip = SUSP_MAX; if (c.dipV > 0.0f) c.dipV = 0.0f; }
    if (c.dip < 0.01f && fabsf(c.dipV) < 0.5f) { c.dip = 0.0f; c.dipV = 0.0f; }
}
static void updateWalkers(float dt);
// The speed car i wants this frame: its own limit, braked for a red light ahead and for the car in front.
static float carTargetSpeed(size_t i) {
    const TrafficCar& car = trafficCars[i];
    float targetSpeed = car.maxSpeed;
    float nextSignalDist = 1e9f;
    const TrafficSignal* nextSignal = nullptr;
    // Only what can change the car's speed is looked at. A signal (or car) farther away than the distance at which the braking curve
    // sqrt(2*a*gap) already exceeds maxSpeed cannot lower targetSpeed, so it is skipped: same result, no scan of the whole list.
    const float sigReach = car.maxSpeed * car.maxSpeed / (2.0f * 520.0f) + car.width * 0.5f + 8.0f + 2.0f;
    const float followReach = car.maxSpeed * car.maxSpeed / (2.0f * 440.0f) + 18.0f + 2.0f;
    for (const TrafficSignal& signal : sigNear(car.x - sigReach, car.x + sigReach)) {
        const float d = (signal.x - car.x) * car.dir;
        if (d > 0 && d < nextSignalDist) { nextSignalDist = d; nextSignal = &signal; }
    }
    if (nextSignal && !trafficSignalGreen(*nextSignal, car.dir, gTime)) {
        const float usableGap = std::max(0.0f, nextSignalDist - car.width * 0.5f - 8.0f);
        targetSpeed = std::min(targetSpeed, sqrtf(2.0f * 520.0f * usableGap));
    }
    for (size_t j = 0; j < trafficCars.size(); ++j) {
        if (i == j) continue;
        const TrafficCar& ahead = trafficCars[j];
        if (fabsf(ahead.x - car.x) > followReach + (ahead.width + car.width) * 0.5f) continue;   // too far to matter
        if (ahead.dir != car.dir || ahead.lane != car.lane) continue;
        const float gap = (ahead.x - car.x) * car.dir - (ahead.width + car.width) * 0.5f;
        if (gap <= 0) continue;
        const float usableGap = std::max(0.0f, gap - 18.0f);
        const float followSpeed = ahead.speed + sqrtf(2.0f * 440.0f * usableGap);
        targetSpeed = std::min(targetSpeed, followSpeed);
    }
    return targetSpeed;
}
static void updateTraffic(float dt) {
    updateWalkers(dt);
    ensureTraffic();
    ensureCrates();
    for (size_t i = 0; i < trafficCars.size(); ++i) {
        TrafficCar& car = trafficCars[i];
        const float targetSpeed = carTargetSpeed(i);
        const float accel = targetSpeed < car.speed ? 560.0f : 230.0f;
        car.speed += clampValue(targetSpeed - car.speed, -accel * dt, accel * dt);
        car.dx = car.dir * car.speed * dt;
        car.x += car.dx;
        suspensionStep(car, dt);
    }
}

static const float START_ROOF_LIFT = 7.0f;   // feet stand on the roof surface, not the front lip (roofY is the top of the cornice)
static bool gMenuIdle = false;   // true while the player waits on the opening rooftop behind the main menu
static void startRun(bool toMenu = false) {
    bld.clear();
    trafficSignals.clear(); trafficCars.clear(); nextTrafficSpawnX = 0; trafficSerial = 0;
    gCrates.clear(); nextCrateX = 0; gTier = 0; gTierMsgT = 0;
    resetChunks();
    for (auto& p : parts) p.alive = false;
    wrng = Rng(SDL_GetTicks() * 2654435761u + 17u);
    P = Player();
    gRunT0 = gTime; gSafeLandUntil = 0; gRag.on = false; ironReset();
    badClear(); gLastPickX = gLastPickY = 1e9f; gAirT = hintT = 0; hintFound = false; gWebBufT = 0; gWebRetryT = 0;
    gPlayerAnim = StkAnim(); gRunPhase = 0;
    distM = bonus = speedBonus = 0; coinMilestones = runCoins = 0; newBest = false; chainShowT = 0; shakeT = 0;
    combo::resetRun(gCombo); gComboNm = -1; gComboNmPrev = -2;
    gTrickHeat = 0; gTrickMsgT = 0; gTrickBad = false;
    zipEdge = diveHeld = slideHeld = false; gSlideHoldT = 0; gSense = gSenseTgt = gSenseT = 0;
    gFallers.clear(); gNextFallerX = 0; gFallerSerial = 0; gRescues = gRescueStreak = 0;
    gFlow = 0; gZoom = 1.0f; gPerfectStreak = 0; gPerfectShowT = 0; camPunch = 0; gTrailTick = 0; for (auto& t : gTrail) t.t = 0;
    addBuilding(true);
    // Every run opens on the starting rooftop: the street is deadly, so the player never begins down there.
    P.x = 200; P.y = bld.front().roofY - START_ROOF_LIFT - 26.0f; P.px = P.x; P.py = P.y; P.vx = toMenu ? 0.0f : 230.0f; P.onGround = true; P.groundedPrev = true;
    gMenuIdle = toMenu;
    startX = P.x;
    P.runStyle = wrng.range(0, 2);
    camX = P.x - uvzWorldWidth * 0.30f; camY = P.y - uvzWorldHeight * 0.58f;
    ensureWorld();
    ensureTraffic();
    if (!toMenu) { gState = PLAYING; aMode = 2; }
}

static void attachWeb(float ax, float ay);
static const float MENU_SEQ_SECS = 1.6f;   // length of the camera pan from the menu view to the player, before control starts
// The menu already shows the real world with the player standing on the opening rooftop; PLAY only pans the camera in.
// When the pan ends, the run simply begins right there: nothing is rebuilt, so there is no jump or cut.
static void beginRunFromMenu() {
    gMenuIdle = false;
    gRunT0 = gTime; gSafeLandUntil = 0; gRag.on = false; ironReset();
    P.vx = 230; P.onGround = true; P.groundedPrev = true;
    gState = PLAYING; aMode = 2;
}
static const float AIM_DEF_X = 0.8192f, AIM_DEF_Y = -0.5736f;   // direction of the "missed shot" puff when no anchor is in reach

// The web target is always chosen by the game: these are the picker's fixed limits.
static const float PICK_REACH = 3000.0f, PICK_MAX_UP = 2000.0f, PICK_MAX_LEN = 3000.0f, PICK_BEHIND_MIN = 40.0f;

static const float BAD_R = 40.0f;
struct BadAnchor { float x, y, t; };
static BadAnchor gBad[10];
static void markBad(float x, float y, float secs) {
    int slot = 0;
    for (int i = 0; i < 10; i++) {
        if (gBad[i].t > 0 && hypotf(gBad[i].x - x, gBad[i].y - y) < BAD_R) { gBad[i].t = std::max(gBad[i].t, secs); return; }
        if (gBad[i].t < gBad[slot].t) slot = i;
    }
    gBad[slot] = {x, y, secs};
}
static void badClear() { for (auto& b : gBad) b.t = 0; }
static bool isBad(float x, float y) {
    for (auto& b : gBad) if (b.t > 0 && hypotf(b.x - x, b.y - y) < BAD_R) return true;
    return false;
}
static void badTick(float dt) { for (auto& b : gBad) if (b.t > 0) b.t -= dt; }

static bool segBox(float x0, float y0, float x1, float y1, float L, float T, float R, float Bt, float* tIn = nullptr, bool* top = nullptr) {
    const float d[2] = {x1 - x0, y1 - y0}, o[2] = {x0, y0}, lo[2] = {L, T}, hi[2] = {R, Bt};
    float t0 = 0, t1 = 1; bool enterTop = false;
    for (int i = 0; i < 2; i++) {
        if (fabsf(d[i]) < 1e-6f) { if (o[i] < lo[i] || o[i] > hi[i]) return false; continue; }
        float ta = (lo[i] - o[i]) / d[i], tb = (hi[i] - o[i]) / d[i];
        const bool lowFirst = ta <= tb;
        if (!lowFirst) std::swap(ta, tb);
        if (ta > t0) { t0 = ta; enterTop = (i == 1 && lowFirst); }
        if (tb < t1) t1 = tb;
        if (t0 > t1) return false;
    }
    if (tIn) *tIn = t0;
    if (top) *top = enterTop;
    return true;
}
static bool gWallsSolid = false;  // building bodies are untouchable (pass-through); roofs are landing spots. Set true for climbable walls
static bool webBlocked(float x0, float y0, float x1, float y1) {
    const float lx = std::min(x0, x1) - 4, hx = std::max(x0, x1) + 4;
    for (auto& b : bldNearExact(lx, hx)) {
        if (b.x > hx || b.x + b.w < lx) continue;
        if (!gWallsSolid && x0 > b.x && x0 < b.x + b.w && y0 > b.roofY) continue;   // untouchable walls: a runner inside a building body is not occluded by it
        float t;
        // At street height the player is in front of the facade; allow a web to reach its roofline.
        // Higher airborne paths still respect the building wall as an occluder.
        if (y0 < STREET_GROUND_Y - 140.0f &&
            segBox(x0, y0, x1, y1, b.x, b.roofY + 3, b.x + b.w, STREET_GROUND_Y - 56.0f, &t) && t < 0.97f) return true;
        for (auto& o : b.obs)
            if (o.solid && segBox(x0, y0, x1, y1, o.x, b.roofY - o.h, o.x + o.w, b.roofY, &t) && t < 0.97f) return true;
    }
    return false;
}
static const float WEB_PAD = 18.0f;
struct WebHit { float x, y, t; };
static void rayBox(float x0, float y0, float x1, float y1, float L, float T, float R, float Bt, float pad, WebHit& best) {
    float t;
    if (!segBox(x0, y0, x1, y1, L - pad, T - pad, R + pad, Bt + pad, &t)) return;
    if (t <= 0.0005f || t >= best.t) return;
    best.x = clampValue(lerpValue(x0, x1, t), L, R); best.y = clampValue(lerpValue(y0, y1, t), T, Bt); best.t = t;
}
static bool rayTarget(float x0, float y0, float dx, float dy, float len, float& hx, float& hy) {
    const float x1 = x0 + dx * len, y1 = y0 + dy * len;
    const float lx = std::min(x0, x1) - 60, rx = std::max(x0, x1) + 60;
    WebHit best = {0, 0, 2.0f};
    for (auto& b : bldNearExact(lx, rx)) {
        if (b.x > rx || b.x + b.w < lx) continue;
        rayBox(x0, y0, x1, y1, b.x, b.roofY, b.x + b.w, STREET_GROUND_Y + 60.0f, 0, best);
        for (auto& o : b.obs) {
            const float top = b.roofY - o.h;
            switch (o.type) {
                case 0: case 1: case 2: rayBox(x0, y0, x1, y1, o.x, top, o.x + o.w, b.roofY, 0, best); break;
                case 3: rayBox(x0, y0, x1, y1, o.x, top, o.x + o.w, b.roofY, WEB_PAD, best); break;
                case 4: rayBox(x0, y0, x1, y1, o.x, top, o.x + 6, b.roofY, WEB_PAD, best);
                        rayBox(x0, y0, x1, y1, o.x - 30, top, o.x + o.w, top + 4, WEB_PAD, best); break;
                case 5: rayBox(x0, y0, x1, y1, o.x, b.roofY - 114, o.x + o.w, b.roofY - 68, WEB_PAD * 0.6f, best); break;
                default: break;
            }
        }
        if (b.cable) {
            float px = b.cx0, py = b.cy0;
            for (int i = 1; i <= 8; i++) {
                const float u = i / 8.0f, qx = lerpValue(b.cx0, b.cx1, u), qy = lerpValue(b.cy0, b.cy1, u) + 22 * 4 * u * (1 - u);
                rayBox(x0, y0, x1, y1, std::min(px, qx), std::min(py, qy), std::max(px, qx), std::max(py, qy), WEB_PAD, best);
                px = qx; py = qy;
            }
        }
    }
    if (best.t > 1.0f) return false;
    hx = best.x; hy = best.y;
    return true;
}
static int chainN() { return std::min(P.chain, 6); }
static float swingSpeedCap(float sm) { return 1400.0f + 300.0f * sm + 450.0f * gFlow + 50.0f * chainN(); }   // Flow and a running chain raise the ceiling
static float swingMaxFwd(float rope) { return std::max(200.0f, 0.8f * rope); }
static float swingDamping() { return std::max(0.02f, 0.06f - 0.03f * gFlow - 0.004f * chainN()); }   // was a flat 0.12 (~11 % per second); now ~6 % at worst, ~2 % in a flowing chain
struct ReleaseFx { float base, extra; bool perfect; };
static ReleaseFx releaseEval(float vx, float vy) {
    ReleaseFx r;
    const float sp = hypotf(vx, vy);
    r.base = 0.14f * clampValue((sp - 450.0f) / 700.0f, 0.0f, 1.0f);
    const float ang = atan2f(-vy, vx) * 180.0f / pi;
    const float angleQ = vx > 0 ? clampValue(1.0f - fabsf(ang - 40.0f) / 30.0f, 0.0f, 1.0f) : 0.0f;
    r.perfect = angleQ >= 0.5f && sp >= 380.0f;
    r.extra = r.perfect ? 0.07f + 0.09f * angleQ * clampValue((sp - 300.0f) / 500.0f, 0.0f, 1.0f) : 0.0f;
    return r;
}
static float releaseBoostK(float vx, float vy) { const ReleaseFx r = releaseEval(vx, vy); return r.base + r.extra; }
static const float POP_NOW = 0.6f;       // share of the release boost delivered as an instant pop along the velocity; the rest eases in over launchDur
static const float HANG_TIME = 0.15f, HANG_GRAV = 0.45f;   // reduced gravity right after letting go
// Release launch shape (Marvel-style): where on the arc you let go decides the launch. Up on the rising side the velocity is steered
// further upward (a high ballistic jump with extra hang time); near the bottom, moving flat, you get a low, fast dive (a speed bonus and almost no hang).
// Between the two the release is unchanged. vx <= 0 or a slow release is never shaped.
struct ReleaseShape { float rot, speedK, hangK, hi, lo; };   // rot: radians added to the velocity angle (up is positive); hangK scales the hang time
static ReleaseShape releaseShape(float vx, float vy) {
    ReleaseShape r{0, 0, 1, 0, 0};
    const float sp = hypotf(vx, vy);
    if (vx <= 0.0f || sp < 350.0f) return r;
    const float ang = atan2f(-vy, vx) * 180.0f / pi;                       // degrees above the horizontal
    const float fast = clampValue((sp - 350.0f) / 500.0f, 0.0f, 1.0f);      // the effect fades in with speed
    r.hi = clampValue((ang - 28.0f) / 30.0f, 0.0f, 1.0f) * fast;            // 28 deg and under: none, 58 deg and over: full
    r.lo = clampValue((20.0f - ang) / 20.0f, 0.0f, 1.0f) * clampValue((ang + 40.0f) / 15.0f, 0.0f, 1.0f) * fast;   // flat or gently falling: full from 0 to -25 deg, fading out by -40 (a steep plunge is not a dive release)
    r.rot = (12.0f * r.hi + r.lo * (-4.0f - ang) * 0.6f) * pi / 180.0f;    // hi: up to +12 deg; lo: flatten toward -4 deg
    r.speedK = 0.07f * r.lo + 0.02f * r.hi;
    r.hangK = 1.0f + 0.9f * r.hi - 0.7f * r.lo;
    return r;
}
// A forced let-go (past the forward limit) used to carry only the speed-scaled base boost; give it a floor so it still launches.
static float forcedReleaseK(float vx, float vy) { return std::max(releaseBoostK(vx, vy), 0.10f * clampValue((hypotf(vx, vy) - 300.0f) / 600.0f, 0.0f, 1.0f)); }
static float webTravelTime(float dist, float sm) { return clampValue(dist / (3600.0f * sm), 0.08f / sm, 0.2f / sqrtf(sm)); }   // was up to 0.65 s
static const float WEB_PULL = 1100.0f, WEB_FLIGHT_GRAV = 0.6f;   // px/s^2 toward the anchor and gravity share while the web is travelling
static bool autoLetGo(float dxp, float rope, float swT, float vx, float vy) {
    const float relAt = clampValue(0.28f * rope, 45.0f, 170.0f);
    return swT > 0.3f && dxp > relAt && (releaseEval(vx, vy).perfect || dxp > 0.6f * rope);
}
// Marvel-style whip: from just before the lowest point and through the upswing the rope is reeled in by up to ~13 %. Angular momentum is
// conserved (tangential speed scales by oldLength / newLength), which is what makes speed jump as you pass the bottom.
static const float REEL_FRAC = 0.13f;
static void reelStep(float& x, float& y, float ax, float ay, float& vx, float& vy, float rope, float& ropeEff, float dt) {
    if (ropeEff <= 0.0f) ropeEff = rope;
    float dx = x - ax, dy = y - ay; const float d = hypotf(dx, dy);
    if (d < 1.0f) return;
    const float nx = dx / d, ny = dy / d;
    float want = 0.0f;
    if (vx > 0 && ny > 0) want = clampValue((nx + 0.3f) / 0.4f, 0.0f, 1.0f);   // ramps in from ~17 deg behind the bottom, held through the upswing
    want = want * want * (3.0f - 2.0f * want);
    const float target = rope * (1.0f - REEL_FRAC * want);
    const float rate = (target < ropeEff ? 0.7f : 0.35f) * rope * dt;   // reel in quickly, pay out slowly
    const float next = ropeEff + clampValue(target - ropeEff, -rate, rate);
    if (next < ropeEff - 1e-4f) {
        const float vr = vx * nx + vy * ny;
        const float k = ropeEff / std::max(next, 1.0f);
        vx = nx * vr + (vx - nx * vr) * k; vy = ny * vr + (vy - ny * vr) * k;   // keep the radial part, scale the tangential part
    }
    else if (next > ropeEff + 1e-4f && d >= ropeEff - 1.0f) {   // paying out while taut: carry the player outward with the rope so nothing goes slack and snaps back
        const float vr0 = vx * nx + vy * ny, k = ropeEff / next, vr = std::min(vr0, (next - ropeEff) / std::max(dt, 1e-4f));   // outward speed can't exceed the pay-out rate
        vx = nx * vr + (vx - nx * vr0) * k; vy = ny * vr + (vy - ny * vr0) * k;
        x = ax + nx * next; y = ay + ny * next;
    }
    ropeEff = next;
}
static void swingStep(float& x, float& y, float& vx, float& vy, float ax, float ay, float rope, float sm, float steerIn, float dt) {
    float dx = x - ax, dy = y - ay, d = hypotf(dx, dy);
    const float cap = swingSpeedCap(sm);
    if (d > 0.001f) {
        const float nx = dx / d, ny = dy / d;
        if (fabsf(steerIn) > 0.01f) {
            const float f = steerIn * 420.0f * sqrtf(sm) * dt;
            vx += f * (1.0f - nx * nx); vy += f * (-nx * ny);
        }

        if (vx > 0 && vy > 0 && ny > 0) {
            const float w = ny * ny, sp = hypotf(vx, vy), room = clampValue(1.0f - sp / cap, 0.0f, 1.0f);
            const float g = 190.0f * sm * (1.0f + 0.6f * gFlow) * (1.0f + 0.08f * chainN()) * w * room * dt / std::max(sp, 1.0f);
            vx += vx * g; vy += vy * g;
        }
        if (d > rope) {
            x = ax + nx * rope; y = ay + ny * rope;
            const float vr = vx * nx + vy * ny;
            if (vr > 0) { vx -= vr * nx; vy -= vr * ny; }
        }
    }
    const float dr = expf(-swingDamping() * dt); vx *= dr; vy *= dr;
    const float sp = hypotf(vx, vy);
    if (sp > cap) { vx *= cap / sp; vy *= cap / sp; }
}
static const float STREET_FALL_COST = 1800.0f;
static float simSwing(float px, float py, float vx, float vy, float ax, float ay, float sm) {
    const float dt = 1.0f / 40.0f;
    float x = px, y = py, t = 0, rope = 0, ropeEff = 0, swT = 0, hang = 0;
    const float fl = webTravelTime(hypotf(ax - x, ay - (y - 10)), sm);
    bool sw = false, flew = false;
    for (int i = 0; i < 120; i++) {
        if (!sw && !flew && t >= fl) { sw = true; flew = true; rope = std::max(90.0f, hypotf(x - ax, y - ay)); ropeEff = rope; swT = 0; }
        vy += GRAV * (sw ? sm : (hang > 0 ? HANG_GRAV : 1.0f)) * dt; hang -= dt;
        x += vx * dt; y += vy * dt;
        if (sw) {
            reelStep(x, y, ax, ay, vx, vy, rope, ropeEff, dt);
            swingStep(x, y, vx, vy, ax, ay, ropeEff, sm, 0.0f, dt);
            swT += dt;
            const float dxp = x - ax;
            if (autoLetGo(dxp, rope, swT, vx, vy) || dxp > swingMaxFwd(rope) || swT > 2.4f) {
                sw = false;
                const float k = releaseBoostK(vx, vy); vx *= 1 + k; vy *= 1 + k; hang = HANG_TIME;
            }
        } else vx *= expf(-0.05f * dt);
        t += dt;
        const float pl = x - 8, pr = x + 8, pt = y - 24, pb = y + 26;
        if (pb >= STREET_GROUND_Y && vy >= 0) return STREET_FALL_COST;   // the street is deadly: prefer swings that stay up
        for (auto& b : bldNearExact(pl - OBS_PAD, pr + OBS_PAD)) for (auto& o : b.obs) if (o.solid) {
            const float top = b.roofY - o.h;
            if (pr > o.x && pl < o.x + o.w && pb > top && pt < b.roofY) return (vx > 200 && !sw) ? 2500.0f : 500.0f;
        }
        if (y > 900) return 3000.0f;
    }
    return 0.0f;
}

struct WebQuery {
    float fromX, fromY, vx, vy;
    bool hasEx; float exX, exY;
};
static bool pickAnchor(const WebQuery& q, float& ox, float& oy) {
    struct Cand { float x, y, dx, dy, len, c; };
    static Cand cs[128];
    int n = 0;
    const float sy0 = q.fromY - 10;
    float cmin = 1e9f;
    const float x0 = q.fromX;
    bool relaxed = false;   // second pass: if nothing qualified, drop the soft filters so a swingable building is always found
    auto tryPoint = [&](float hx, float hy) {
        if (n >= 128) return;
        const float dx = hx - q.fromX, dy = q.fromY - hy;
        if (dy < 25 || dy > PICK_MAX_UP || dx > PICK_REACH || dx < (relaxed ? -120.0f : PICK_BEHIND_MIN)) return;
        const float len = hypotf(dx, dy);
        if (len > PICK_MAX_LEN || len < 90) return;
        if (!relaxed && q.hasEx && hypotf(hx - q.exX, hy - q.exY) < 150.0f) return;
        if (!relaxed && isBad(hx, hy)) return;
        if (webBlocked(x0, sy0, hx, hy)) return;
        Cand& c = cs[n];
        c.x = hx; c.y = hy; c.dx = dx; c.dy = dy; c.len = len;
        const float lead = clampValue(260.0f + 0.5f * std::max(q.vx, 0.0f), 300.0f, 760.0f);
        float sc = fabsf(dx - lead) + 0.6f * fabsf(dy - 330.0f);
        if (dx < 120) sc += (120.0f - dx) * 5.0f;
        if (len > 1400) sc += (len - 1400.0f) * 0.6f;
        if (hy + len > 700) sc += (hy + len - 700.0f) * 3.0f;
        if (hypotf(hx - gLastPickX, hy - gLastPickY) < BAD_R) sc -= 140.0f;
        c.c = sc;
        n++;
    };
    auto tryRay = [&](float ang) {
        float hx, hy;
        if (!rayTarget(x0, sy0, cosf(ang), -sinf(ang), PICK_MAX_LEN, hx, hy)) return;
        tryPoint(hx, hy);
    };
    auto gather = [&]() {   // swing to anything: fan rays upward/forward; each ray's first hit on any surface is a candidate
        const int N = relaxed ? 30 : 27;
        for (int r = 0; r < N; r++) tryRay((relaxed ? 4.0f + 3.0f * r : 8.0f + 3.0f * r) * pi / 180.0f);
        if (relaxed) for (int r = 0; r < 6; r++) tryRay((92.0f + 6.0f * r) * pi / 180.0f);   // last resort: straight up and slightly back
        for (auto& b : bldNear(q.fromX - 120.0f, q.fromX + PICK_REACH)) {   // shallow, far shots the fan can miss: aim at the nearest roof corners of every building in reach
            if (b.x > q.fromX + PICK_REACH || b.x + b.w < q.fromX - (relaxed ? 120.0f : 0.0f)) continue;
            const float cxs[2] = {b.x + 2.0f, b.x + std::min(b.w, 80.0f)};
            for (float cxp : cxs) tryRay(atan2f(sy0 - b.roofY, cxp - x0));
        }
    };
    gather();
    if (n == 0) { relaxed = true; gather(); }
    if (n == 0) return false;
    {
        const float sm = swingMult();
        bool done[128] = {false};
        for (int k = 0; k < std::min(n, 6); k++) {
            int bi = -1;
            for (int i = 0; i < n; i++) if (!done[i] && (bi < 0 || cs[i].c < cs[bi].c)) bi = i;
            done[bi] = true;
            cs[bi].c += simSwing(q.fromX, q.fromY, q.vx, q.vy, cs[bi].x, cs[bi].y, sm);
        }
        for (int i = 0; i < n; i++) if (!done[i]) cs[i].c += 2500.0f;
    }
    for (int i = 0; i < n; i++) cmin = std::min(cmin, cs[i].c);
    int best = -1; float bestCost = 1e9f;
    for (int i = 0; i < n; i++) {
        const float cost = (cs[i].c - cmin) / 700.0f;
        if (cost < bestCost) { bestCost = cost; best = i; }
    }
    if (best < 0) return false;
    ox = cs[best].x; oy = cs[best].y;
    gLastPickX = ox; gLastPickY = oy;
    return true;
}
static WebQuery makeQuery() {
    WebQuery q;
    q.fromX = P.x; q.fromY = P.y; q.vx = P.vx; q.vy = P.vy;
    q.hasEx = false; q.exX = q.exY = 0;
    return q;
}
static bool findAnchor(float& ox, float& oy) {
    return pickAnchor(makeQuery(), ox, oy);
}
static const u32 COMBO_COL[combo::TIERS + 1] = {0xFFFFFF, 0x7FE0FF, 0x9BFF8A, 0xFFC857, 0xFF5C8A};
static void saveComboBest() { if (gCombo.bestDirty) { gCombo.bestDirty = false; combo::saveFile(comboPath, gCombo.best); } }
static void comboHit(combo::Kind k, float base = -1.0f) {
    if (!P.alive) return;
    const int pts = combo::event(gCombo, k, base);
    if (pts <= 0) return;
    bonus += (float)pts;
    gFlow = std::min(1.0f, gFlow + 0.05f);
    const int t = gCombo.tier;
    const u32 c = COMBO_COL[t];
    burst(P.x, P.y - 10, 3 + 2 * t, c, 90.0f + 25.0f * t);
    if (gCombo.tierUp) {
        gCombo.tierUp = false;
        burst(P.x, P.y - 10, 8 + 4 * t, c, 150.0f + 30.0f * t);
        burst(P.x, P.y - 10, 5, 0xFFFFFF, 100);
        doShake(0.06f + 0.03f * t);
        if (cfg.shake) camPunch = std::max(camPunch, 0.3f + 0.15f * t);
        sfx(t >= 2 ? 8 : 3);
    }
}

// ---- Web Catch (rescue) ----
static const float FALLER_G = 520.0f, FALLER_TERM = 620.0f, CATCH_R = 38.0f;
static float fallerRand(u32 k) { return (float)(hashCoordinates(gFallerSerial, 0x52455343u, k) & 0xFFFFu) / 65535.0f; }   // own hash: never touches the world RNG
static void rescueTick(float dt) {
    if (!P.alive || gMenuIdle) return;
    if (gNextFallerX <= 0) gNextFallerX = P.x + 2000.0f;
    if (gFallers.capacity() < FALLER_SLOTS) gFallers.reserve(FALLER_SLOTS);
    if (P.x > gNextFallerX - 1100.0f && gFallers.size() < FALLER_SLOTS) {
        Faller f; f.x = P.x + 750.0f + 250.0f * fallerRand(1);
        f.y = clampValue(P.y - 320.0f - 160.0f * fallerRand(2), -2600.0f, -260.0f);
        f.vx = 0; f.vy = 0; f.t = 0; f.alive = true; f.shirt = (int)(fallerRand(3) * 4.0f) & 3;
        gFallers.push_back(f);
        gNextFallerX += 1800.0f + 1400.0f * fallerRand(4);
        gFallerSerial++;
    }
    for (Faller& f : gFallers) {
        if (!f.alive) continue;
        f.t += dt;
        f.vy = std::min(FALLER_TERM, f.vy + FALLER_G * dt);
        f.vx += (sinf(f.t * 3.0f + f.shirt) * 40.0f - f.vx) * std::min(1.0f, 2.0f * dt);
        f.x += f.vx * dt; f.y += f.vy * dt;
        if (!P.onGround && hypotf(f.x - P.x, f.y - P.y) < CATCH_R) {
            f.alive = false;
            gRescues++; gRescueStreak++;
            comboHit(combo::RESCUE, 60.0f + 20.0f * (float)std::min(gRescueStreak - 1, 5));
            gFlow = std::min(1.0f, gFlow + 0.12f);
            burst(f.x, f.y, 10, 0xFFE9A0, 140.0f);
            snprintf(gStuntName, sizeof gStuntName, "RESCUE");
            if (gRescueStreak > 1) snprintf(gTrickMsg, sizeof gTrickMsg, "RESCUE X%d", gRescueStreak);
            else snprintf(gTrickMsg, sizeof gTrickMsg, "RESCUE");
            gTrickBad = false; gTrickMsgT = 1.0f; sfx(3);
        } else if (f.y >= STREET_GROUND_Y - 4.0f) {
            f.alive = false; gRescueStreak = 0;
            burst(f.x, STREET_GROUND_Y - 2.0f, 4, 0xC9BFA8, 60.0f);
        }
    }
    gFallers.erase(std::remove_if(gFallers.begin(), gFallers.end(), [](const Faller& f) {   // one stable pass, no reallocation
        return (!f.alive && f.x < camX + uvzWorldWidth) || f.x < camX - 400.0f;
    }), gFallers.end());
}
static float fastSwingSpeed() {
    const float m = swingMult();
    const float peak = m <= 3.0f ? 381.0f + (m - 1.0f) * 121.0f : 623.0f + (m - 3.0f) * 105.0f;
    return std::max(450.0f, 0.9f * peak);
}
static const float TRICK_DUR[5]  = {0.0f, 0.55f, 0.55f, 0.50f, 0.45f};
static const float TRICK_BASE[5] = {0.0f, 30.0f, 36.0f, 36.0f, 28.0f};
static const char* const TRICK_NAME[5] = {"", "FRONT FLIP", "BACK FLIP", "TWIST", "CARTWHEEL"};
static bool trickFits(float dur) {
    const float feet = P.y + 26.0f;
    for (int k = 1; k <= 4; k++) {
        const float t = dur * 0.25f * k, fx = P.x + P.vx * t, fy = feet + P.vy * t + 0.5f * GRAV * t * t;
        float top = STREET_GROUND_Y;
        for (auto& b : bldNearExact(fx - 10.0f, fx + 10.0f)) {
            if (fx < b.x - 10 || fx > b.x + b.w + 10) continue;
            for (auto& o : b.obs) if (o.type <= 2 && fx + 10 > o.x && fx - 10 < o.x + o.w) top = std::min(top, b.roofY - o.h);
        }
        for (const StreetCrate& c : crateNearExact(fx - 10.0f, fx + 10.0f)) if (fx + 10 > c.x && fx - 10 < c.x + c.w) top = std::min(top, STREET_GROUND_Y - c.h);
        if (fy > top - 10.0f) return false;
    }
    return true;
}
static bool tryTrick() {
    Player& p = P;
    if (!p.alive || p.onGround || p.swinging || p.webFlying || p.wallCling || p.trickType || !p.trickReady || p.trickCool > 0 || p.vaultOneT > 0) return false;
    if (p.flipT > 0 || (p.releaseFlip && p.releaseT > 0)) return false;
    int ty; float apexQ = 0;
    if (p.vy < -130.0f) ty = steer < -0.3f ? T_BACK : T_FRONT;
    else if (p.vy <= 130.0f) { ty = T_TWIST; apexQ = 1.0f - fabsf(p.vy) / 130.0f; }
    else ty = T_CART;
    if (!trickFits(TRICK_DUR[ty])) return false;
    p.trickType = ty; p.trickT = 0; p.trickDur = TRICK_DUR[ty]; p.trickApexQ = apexQ; p.trickNear = false;
    p.trickReady = false; p.trickDoneT = 0;
    sfx(7); burst(p.x, p.y, 3, 0xBFD8FF, 60);
    return true;
}
static void trickDone() {
    Player& p = P;
    const int ty = p.trickType;
    const float sp = hypotf(p.vx, p.vy), speedK = clampValue((sp - 400.0f) / 700.0f, 0.0f, 1.0f);
    float f = 1.0f + 0.6f * speedK;
    if (ty == T_TWIST) f *= 1.0f + 0.4f * p.trickApexQ;
    if (p.trickNear) f *= 1.5f;
    f /= 1.0f + 0.35f * gTrickHeat;
    if (ty == p.trickLast && gTrickHeat > 0.3f) f *= 0.8f;
    const int before = gCombo.count;
    comboHit(combo::STUNT, TRICK_BASE[ty] * f);
    if (gCombo.count > before) {
        gFlow = std::min(1.0f, gFlow + 0.05f + 0.10f * speedK + (p.trickNear ? 0.10f : 0.0f));
        const char* pre = p.trickNear ? "CLOSE " : (ty == T_TWIST && p.trickApexQ > 0.7f ? "PERFECT " : (speedK > 0.6f ? "FAST " : ""));
        snprintf(gStuntName, sizeof gStuntName, "%s%s", pre, TRICK_NAME[ty]);
        snprintf(gTrickMsg, sizeof gTrickMsg, "%s", gStuntName); gTrickBad = false; gTrickMsgT = 0.9f;
    }
    gTrickHeat += 1.0f;
    p.trickLast = ty; p.trickType = 0; p.trickCool = 0.25f; p.trickDoneT = 0.7f;
}
static void trickStep(float dt) {
    Player& p = P;
    if (p.onGround || p.swinging || p.webFlying || p.wallCling || !p.alive) { p.trickType = 0; return; }
    p.trickT += dt;
    if (p.trickT >= p.trickDur) trickDone();
}
static void trickOnNearMiss() {
    if (P.trickType) { P.trickNear = true; return; }
    if (P.trickDoneT > 0 && P.trickLast) {
        P.trickDoneT = 0;
        gCombo.cd[combo::STUNT] = 0;
        const int before = gCombo.count;
        comboHit(combo::STUNT, 22.0f);
        if (gCombo.count > before) { gFlow = std::min(1.0f, gFlow + 0.10f); snprintf(gStuntName, sizeof gStuntName, "CLOSE CALL TRICK"); snprintf(gTrickMsg, sizeof gTrickMsg, "%s", gStuntName); gTrickBad = false; gTrickMsgT = 0.9f; }
    }
}
static void nearMissTick() {
    if (!P.alive || P.onGround || P.wallCling) { gComboNm = -1; gComboNmPrev = -2; return; }
    const Building* cur = nullptr;
    for (auto& b : bldNearExact(P.x, P.x)) if (P.x >= b.x && P.x < b.x + b.w) { cur = &b; break; }
    const int id = cur ? (int)cur->x : -1;
    if (id != gComboNmPrev) {
        if (gComboNm != -1 && gComboNmGap >= -2.0f && gComboNmGap <= 26.0f && P.x - gComboNmX >= 110.0f && hypotf(P.vx, P.vy) > 400.0f)
            { comboHit(combo::NEAR_MISS); trickOnNearMiss(); }
        gComboNm = -1; gComboNmPrev = id;
        if (cur) { gComboNm = id; gComboNmX = P.x; gComboNmGap = 1e9f; }
    }
    if (!cur || gComboNm == -1) return;
    float top = STREET_GROUND_Y;
    for (auto& o : cur->obs) if (o.type <= 2 && P.x + 8 > o.x && P.x - 8 < o.x + o.w) top = std::min(top, cur->roofY - o.h);
    const float gap = top - (P.y + 26.0f);
    if (gap > -2.0f) gComboNmGap = std::min(gComboNmGap, gap);
}

// Dive-to-swing: the rope would simply cancel the speed you were falling at (the part pointing away from the anchor). After a dive
// that part is converted into speed along the swing instead, so a web caught low in a dive launches a much bigger arc.
static const float DIVE_CONVERT = 0.45f, DIVE_MIN_VR = 350.0f;   // share of the cancelled speed handed to the swing; below this much it is a normal attach
static float diveConvertBonus(float vx, float vy, float dx, float dy) {   // dx, dy: player minus anchor; returns the extra speed along the swing
    const float d = hypotf(dx, dy);
    if (d < 1.0f || dy <= 0.0f) return 0.0f;                                  // only when hanging below the anchor
    const float vr = vx * (dx / d) + vy * (dy / d);
    return vr > DIVE_MIN_VR ? DIVE_CONVERT * (vr - DIVE_MIN_VR * 0.5f) : 0.0f;
}
static bool gDiveSwing = false; static float gDiveSwingGain = 0;   // set by diveToSwing(); read by tests and the HUD message
static void diveToSwing(float ax, float ay) {
    gDiveSwing = false; gDiveSwingGain = 0;
    if (!(P.diving || P.diveMemT > 0.0f)) return;
    const float dx = P.x - ax, dy = P.y - ay, d = std::max(hypotf(dx, dy), 1.0f);
    const float bonus = diveConvertBonus(P.vx, P.vy, dx, dy);
    if (bonus <= 0.0f) return;
    const float nx = dx / d, ny = dy / d, tx = ny, ty = -nx;   // tx, ty: the swing's forward tangent (towards +x at the bottom)
    const float cap = swingSpeedCap(swingMult());
    const float vr = P.vx * nx + P.vy * ny;
    float vtx = P.vx - nx * vr, vty = P.vy - ny * vr;         // what the rope would keep
    const float keep = hypotf(vtx, vty);
    const float want = std::min(keep + bonus, cap);
    vtx += tx * (want - keep); vty += ty * (want - keep);      // push the extra along the tangent, forward
    P.vx = vtx; P.vy = vty;                                    // the radial part is gone (the rope takes it), the tangent carries the speed
    P.diving = false; P.diveMemT = 0; P.diveCool = 0.2f;
    gDiveSwing = true; gDiveSwingGain = want - keep;
    gFlow = std::min(1.0f, gFlow + 0.08f);
    burst(ax, ay, 6, 0xBFE4FF, 120);
    snprintf(gTrickMsg, sizeof gTrickMsg, "DIVE SWING"); gTrickBad = false; gTrickMsgT = 0.8f;
}
static void attachWeb(float ax, float ay) {
    P.swinging = true;
    P.ax = ax; P.ay = ay;
    P.rope = std::max(90.0f, hypotf(P.x - ax, P.y - ay)); P.ropeEff = P.rope;
    diveToSwing(ax, ay);
    P.chain++;
    if (P.chain >= 2) {   // chain-speed bonus: every web in an unbroken chain keeps a little more of the momentum
        const float sp = hypotf(P.vx, P.vy), cap = swingSpeedCap(swingMult());
        const float k = 0.03f * std::min(P.chain - 1, 5);
        if (sp > 250.0f) { const float ns = std::min(sp * (1.0f + k), cap), f = ns / sp; P.vx *= f; P.vy *= f; }
    }
    P.swingStyle = wrng.range(0, 3); P.jit = wrng.f() * 2 - 1;
    P.attachT = 0.18f;
    P.swingT = 0; P.launchT = 0; P.wrapN = 0; P.wrapCool = 0;
    P.usedAir = false;
    if (P.chain >= 2) { bonus += 10.0f * P.chain; chainShowT = 1.6f; }
    burst(ax, ay, 8, 0xFFFFFF, 90);
    sfx(1);
}
static void releaseWeb(bool boosted, bool failed = false, bool forced = false) {
    if (!P.swinging) return;
    P.swinging = false;
    bool perfect = false;
    if (!failed) {
        const ReleaseFx fx = releaseEval(P.vx, P.vy);
        perfect = fx.perfect && P.swingT > 0.35f;
        P.launchK = fx.base + (perfect ? fx.extra : 0.0f);
        if (forced) P.launchK = std::max(P.launchK, forcedReleaseK(P.vx, P.vy));
        P.launchDur = perfect ? 0.32f : 0.25f; P.launchT = P.launchDur;
        {   // the "pop": an immediate kick along the velocity, then the rest eases in; plus a short low-gravity hang
            const float f = 1.0f + POP_NOW * P.launchK, sp = hypotf(P.vx, P.vy), cap = swingSpeedCap(swingMult());
            P.vx *= f; P.vy *= f;
            if (sp * f > cap) { const float g = cap / (sp * f); P.vx *= g; P.vy *= g; }
            P.hangT = HANG_TIME;
            const ReleaseShape sh = releaseShape(P.vx, P.vy);   // steer the launch by where on the arc it happened
            if (sh.hi > 0.0f || sh.lo > 0.0f) {
                const float v = hypotf(P.vx, P.vy) * (1.0f + sh.speedK), a = atan2f(-P.vy, P.vx) + sh.rot;
                const float nv = std::min(v, std::max(cap, hypotf(P.vx, P.vy)));   // never push past the speed cap (or past what we already had)
                P.vx = cosf(a) * nv; P.vy = -sinf(a) * nv;
                P.hangT = HANG_TIME * sh.hangK;
                if (sh.hi > 0.5f) burst(P.x, P.y - 12, 4, 0xBFE4FF, 90); else if (sh.lo > 0.5f) burst(P.x, P.y - 6, 4, 0xFFFFFF, 60);
            }
        }
        if (perfect) {
            P.perfectT = 0.7f; gPerfectStreak++; gPerfectShowT = 1.1f;
            gFlow = std::min(1.0f, gFlow + 0.25f);
            comboHit(combo::PERFECT, 10.0f + 5.0f * std::min(gPerfectStreak, 5));
            if (cfg.shake) camPunch = 1.0f;
            doShake(0.05f);
            burst(P.x, P.y - 10, 10, 0xFFE9A0, 140);
            burst(P.x, P.y - 10, 5, 0xFFFFFF, 90);
            sfx(8);
        } else {
            if (P.swingT > 0.3f) gPerfectStreak = 0;
            if (hypotf(P.vx, P.vy) > 400.0f) gFlow = std::min(1.0f, gFlow + 0.06f);
            if (P.swingT > 0.35f && hypotf(P.vx, P.vy) > fastSwingSpeed()) comboHit(combo::FAST);
        }
    } else { gPerfectStreak = 0; gFlow *= 0.5f; }
    markBad(P.ax, P.ay, failed && P.swingT < 0.45f ? 6.0f : 1.2f);
    if (!failed) P.trickReady = true;
    P.releaseFlip = P.vx > 250 && wrng.f() < 0.4f;
    P.flipDir = wrng.f() < 0.75f ? 1.0f : -1.0f;
    P.fallStyle = wrng.range(0, 1);
    P.releaseT = P.releaseFlip ? 0.5f : 0.25f;
    burst(P.x, P.y - 20, 4, 0xBFD8FF, 60);
    if (perfect) {} else if (boosted) sfx(7); else sfx(6);
}
// ---- Ragdoll: when the runner dies the rig goes limp. A verlet body with the rig's own bone lengths, seeded from the last live pose,
// carrying the runner's momentum; it falls, tumbles and settles on the street or on a vehicle roof. ----
struct RagLink { int a, b; float len; };
static const RagLink RAG_LINKS[] = {
    {J_HIP, J_NECK, STK_TORSO}, {J_NECK, J_HEAD, STK_HEADD},
    {J_HIP, J_KNF, STK_THIGH}, {J_KNF, J_FTF, STK_SHIN}, {J_HIP, J_KNB, STK_THIGH}, {J_KNB, J_FTB, STK_SHIN},
    {J_NECK, J_ELF, STK_UARM}, {J_ELF, J_HNF, STK_FARM}, {J_NECK, J_ELB, STK_UARM}, {J_ELB, J_HNB, STK_FARM}};
static const float RAG_H = 1.0f / 120.0f;
static float ragFloor(float x, float yPrev, float& carVx) {   // what a point at x (that was at yPrev) lands on: a vehicle roof under it, else the street
    float f = STREET_GROUND_Y; carVx = 0.0f;
    for (const TrafficCar& c : trafficCars) {
        if (fabsf(x - c.x) > c.width * 0.5f) continue;
        const float top = carTopY(c);
        if (yPrev <= top + 8.0f && top < f) { f = top; carVx = (float)c.dir * c.speed; }
    }
    return f;
}
static void ragStart(float vx, float vy, float spin) {
    float X[J_N], Y[J_N];
    gStkMirror = gLastMirror; stkPlace(gLastPose, P.x, P.y + 26.0f, gLastAng, X, Y); gStkMirror = false;
    const float hx = X[J_HIP], hy = Y[J_HIP];
    for (int i = 0; i < J_N; i++) {
        const float ivx = vx - spin * (Y[i] - hy), ivy = vy + spin * (X[i] - hx);   // body velocity + rotation about the hips
        gRag.x[i] = X[i]; gRag.y[i] = Y[i]; gRag.px[i] = X[i] - ivx * RAG_H; gRag.py[i] = Y[i] - ivy * RAG_H;
    }
    gRag.on = true;
}
static void ragStep(float dt) {
    if (!gRag.on) return;
    Ragdoll& r = gRag;
    const int n = std::min(8, std::max(1, (int)lroundf(dt / RAG_H)));
    for (int s = 0; s < n; s++) {
        float vy0[J_N];
        for (int i = 0; i < J_N; i++) {
            const float vx = (r.x[i] - r.px[i]) * 0.998f, vy = (r.y[i] - r.py[i]) * 0.998f;
            r.px[i] = r.x[i]; r.py[i] = r.y[i];
            r.x[i] += vx; r.y[i] += vy + GRAV * RAG_H * RAG_H;
            vy0[i] = r.y[i] - r.py[i];
        }
        for (int it = 0; it < 6; it++) {
            for (const RagLink& l : RAG_LINKS) {
                const float dx = r.x[l.b] - r.x[l.a], dy = r.y[l.b] - r.y[l.a], d = sqrtf(dx * dx + dy * dy);
                if (d < 1e-4f) continue;
                const float k = (d - l.len) / d * 0.5f;
                r.x[l.a] += dx * k; r.y[l.a] += dy * k; r.x[l.b] -= dx * k; r.y[l.b] -= dy * k;
            }
            {   // the head can't fold into the hips
                const float dx = r.x[J_HEAD] - r.x[J_HIP], dy = r.y[J_HEAD] - r.y[J_HIP], d = sqrtf(dx * dx + dy * dy);
                if (d > 1e-4f && d < 13.0f) { const float k = (d - 13.0f) / d * 0.5f; r.x[J_HEAD] -= dx * k; r.y[J_HEAD] -= dy * k; r.x[J_HIP] += dx * k; r.y[J_HIP] += dy * k; }
            }
            for (int i = 0; i < J_N; i++) {   // floor
                float cv; const float f = ragFloor(r.x[i], r.py[i], cv), rad = i == J_HEAD ? 5.0f : 2.0f;
                if (r.y[i] + rad > f) {
                    r.y[i] = f - rad;
                    if (it == 5) {   // once per step: a little bounce and ground friction (relative to a moving roof)
                        if (vy0[i] > 2.5f) r.py[i] = r.y[i] + vy0[i] * 0.28f;
                        const float rel = (r.x[i] - r.px[i]) - cv * RAG_H;
                        r.px[i] = r.x[i] - rel * 0.62f - cv * RAG_H;
                    }
                }
            }
        }
    }
    const float hx = r.x[J_HIP], hy = r.y[J_HIP];
    P.vx = (hx - r.px[J_HIP]) / RAG_H; P.vy = (hy - r.py[J_HIP]) / RAG_H;
    P.x = hx; P.y = std::min(hy, STREET_GROUND_Y - 26.0f);   // the camera follows the hips
}
static float gImpactT = 0, gImpactX = 0;   // pixel "splat" shockwave where the player hit the street
static void killPlayer(bool ground = false, float floorY = STREET_GROUND_Y) {   // floorY: the street, or the vehicle roof the runner crashed onto
    if (!P.alive) return;
    const float vx0 = P.vx, dir0 = vx0 >= 0.0f ? 1.0f : -1.0f;
    P.alive = false; P.swinging = false; P.deadT = 0; P.trickType = 0; P.rideId = -1;
    P.webFlying = false; P.wallCling = false; P.zipping = false; P.diving = false;
    combo::crash(gCombo); saveComboBest(); gComboNm = -1;
    if (ground) {
        // Hit the deadly street: no bounce, the body skids and stays down; pixel splat + dust + shake.
        P.deadGround = true;
        P.y = floorY - 26.0f; P.vy = 0; P.vx = clampValue(P.vx, -260.0f, 260.0f) * 0.55f;
        if (floorY >= STREET_GROUND_Y) { gImpactT = 0.55f; gImpactX = P.x; }
        doShake(0.55f);
        for (int i = 0; i < 22; i++) {                       // red splat fanned upward
            const float a = pi * (0.08f + 0.84f * wrng.f()), sp = 90.0f + 190.0f * wrng.f();
            spawnPart(P.x, floorY - 2, -cosf(a) * sp, -sinf(a) * sp, 0.45f + wrng.f() * 0.35f, (i & 3) ? 0xD62839 : 0xFF8A5C, 2);
        }
        for (int i = 0; i < 12; i++) {                       // dust pushed along the asphalt
            const float d = (i & 1) ? 1.0f : -1.0f;
            spawnPart(P.x, floorY - 1, d * (40.0f + 140.0f * wrng.f()), -10.0f - 50.0f * wrng.f(), 0.5f + wrng.f() * 0.3f, 0xC9BFA8, 2);
        }
        ragStart(clampValue(vx0, -300.0f, 300.0f) * 0.6f, -170.0f, dir0 * (3.0f + 3.0f * wrng.f()));   // the body bounces, topples forward and goes limp
        sfx(5); aMode = 1;
        return;
    }
    P.vy = -320; P.vx = std::min(P.vx, 80.0f) * 0.4f;
    ragStart(clampValue(vx0, -420.0f, 420.0f) * 0.5f, -320.0f, dir0 * (6.0f + 8.0f * wrng.f()));   // flung back and tumbling
    doShake(0.4f);
    burst(P.x, P.y, 14, 0xD62839, 160);
    sfx(5); aMode = 1;
}

static bool swingMeetsWall(float L, float T, float R, bool leftSide) {
    const float rise = (P.y + 26.0f) - T;
    if (leftSide && rise < 170.0f && P.vy < -150.0f && P.vx > 0) {
        P.x = L - 9;
        const float sp = hypotf(P.vx, P.vy);
        releaseWeb(true);
        P.vy = std::min(P.vy, -sqrtf(2.0f * GRAV * std::max(rise + 24.0f, 40.0f)));
        P.vx = std::max(P.vx * 0.6f, 200.0f);
        P.launchT = 0; P.hangT = 0;   // a wall vault is its own launch: no pop or hang on top of it
        P.vaultT = 0.8f;
        { const float v = hypotf(P.vx, P.vy), cap = swingSpeedCap(swingMult()); if (v > cap) { P.vx *= cap / v; P.vy *= cap / v; } }
        burst(P.x + 6, T, 6, 0xFFFFFF, 80);
        (void)sp;
        return true;
    }
    if (T < P.y - 20.0f && P.wrapN < 2 && P.wrapCool <= 0) {
        const float cx = leftSide ? L - 3 : R + 3, cy = T - 2;
        const float d = hypotf(P.x - cx, P.y - cy);
        if (d < 50.0f) return false;
        P.ax = cx; P.ay = cy; P.rope = d; P.ropeEff = d;
        P.wrapN++; P.wrapCool = 0.25f;
        P.x = leftSide ? L - 9 : R + 9;
        burst(cx, cy, 5, 0xFFFFFF, 70);
        sfx(1);
        return true;
    }
    return false;
}
static void solidHit(float L, float T, float R, float Bt, bool lethalSide, bool allowTop = true) {
    float pl = P.x - 8, pr = P.x + 8, pt = P.y - 24, pb = P.y + 26, prevB = P.py + 26;
    if (!(pr > L && pl < R && pb > T && pt < Bt)) return;
    if (allowTop && prevB <= T + 14 && P.vy >= 0) { P.y = T - 26; P.vy = 0; P.onGround = true; return; }
    if (allowTop && pb - T < 26 && P.vy >= -50) { P.y = T - 26; P.vy = std::min(P.vy, 0.0f); P.onGround = true; return; }
    if (!lethalSide && P.vaultT > 0 && P.vy < 0) { if (P.x < (L + R) * 0.5f) P.x = L - 9; return; }
    const bool webSlap = P.swinging && !lethalSide;
    const bool held = !lethalSide && (swingHeld || P.zipping);
    if (lethalSide || (P.vx > 200 && !webSlap && !held && !P.groundedPrev && !P.onGround)) { killPlayer(); return; }   // running into a taller neighbour's wall on a roof just stops you; hitting one in mid-air at speed is fatal
    const bool sideHit = (P.py + 26 > T + 10 && P.py - 24 < Bt - 10);
    if (sideHit && (!P.onGround || held) && P.alive) {
        const bool leftSide = P.x < (L + R) * 0.5f;
        const float edge = leftSide ? L : R;
        P.x = leftSide ? L - 9 : R + 9;
        const bool recent = P.wallCool > 0 || (P.wallLastCool > 0 && fabsf(edge - P.wallLastEdge) < 1.0f);
        if (!recent && (webSlap || held)) {
            if (webSlap && swingMeetsWall(L, T, R, leftSide)) return;
            P.wallX = P.x; P.wallDir = leftSide ? 1.0f : -1.0f; P.wallEdge = edge;
            if (P.swinging) markBad(P.ax, P.ay, 3.0f);
            P.wallImpact = hypotf(P.vx, P.vy);
            if (P.wallImpact > 220.0f) { sfx(2); burst(P.x + P.wallDir * 8, P.y, 4, 0x9AA0C0, 50); }
            P.wallCling = true; P.swinging = false; P.webFlying = false; P.onGround = false;
            P.vx = 0; P.vy = P.vy < 0 ? clampValue(P.vy * 0.75f, -320.0f, 0.0f) : clampValue(P.vy * 0.6f, 0.0f, 280.0f);
            P.landT = 0; P.releaseT = 0; P.flipT = 0; P.slideT = 0; P.jumpBuf = 0; P.mantleT = 0; P.climbPhase = 0;
            return;
        }
    }
    if (P.x < (L + R) * 0.5f) P.x = L - 8; else P.x = R + 8;
    P.vx = std::min(P.vx, 0.0f) * 0.2f;
    if (P.swinging) releaseWeb(false, true);
}
// Building bodies are untouchable: the player passes through their walls (no hit, cling or death) and only the ROOFS act as landing spots.
// Rooftop objects (vents, AC units...) stay solid. Set to true to bring back the old solid walls (wall cling / climb / wrap).
static void collide() {
    for (auto& b : bldNearExact(P.x - 20.0f - COLLIDE_PUSH_PAD, P.x + 20.0f + COLLIDE_PUSH_PAD)) {
        if (b.x + b.w < P.x - 20 || b.x > P.x + 20) continue;
        if (b.startRoof && P.vy >= 0.0f && P.x + 8.0f > b.x && P.x - 8.0f < b.x + b.w) {   // the opening rooftop is solid ground
            const float rf = b.roofY - START_ROOF_LIFT;
            if (P.y + 26.0f >= rf && P.py + 26.0f <= rf + 14.0f) { P.y = rf - 26.0f; P.vy = 0.0f; P.onGround = true; }
        }
        if (!b.startRoof && P.vy >= 0.0f && P.x + 8.0f > b.x && P.x - 8.0f < b.x + b.w) {   // every roof is a landing spot
            const float rf = b.roofY - START_ROOF_LIFT;
            if (P.y + 26.0f >= rf && P.py + 26.0f <= rf + 14.0f) { P.y = rf - 26.0f; P.vy = 0.0f; P.onGround = true; }
        }
        const float wallBottom = STREET_GROUND_Y - 56.0f;
        const bool aboveStreet = P.y + 26.0f < STREET_GROUND_Y - 40.0f;
        if (aboveStreet && gWallsSolid) {
            const bool crossedLeftFace = P.px + 8.0f <= b.x && P.x + 8.0f > b.x;
            const bool crossedRightFace = P.px - 8.0f >= b.x + b.w && P.x - 8.0f < b.x + b.w;
            if (crossedLeftFace) solidHit(b.x - 1.0f, b.roofY, b.x + 1.0f, wallBottom, false, false);
            else if (crossedRightFace) solidHit(b.x + b.w - 1.0f, b.roofY, b.x + b.w + 1.0f, wallBottom, false, false);
            if (!P.alive) return;
        }
        for (auto& o : b.obs) if (o.solid) { solidHit(o.x, b.roofY - o.h, o.x + o.w, b.roofY, true); if (!P.alive) return; }
    }
    // ---- Vehicles. The roof is a platform (you can land on it and ride it); touching a vehicle any other way
    // (running into its side, being hit from below) still ends the run. ----
    // ---- Street crates: land on top, vault the side while running (auto, one-handed), or get bumped. Never lethal. ----
    for (const StreetCrate& c : crateNearExact(P.x - 12.0f - COLLIDE_PUSH_PAD, P.x + 12.0f + COLLIDE_PUSH_PAD)) {
        const float L = c.x, R = c.x + c.w, T = STREET_GROUND_Y - c.h, Bt = STREET_GROUND_Y;
        const float pl = P.x - 8.0f, pr = P.x + 8.0f, pt = P.y - 24.0f, pb = P.y + 26.0f, prevB = P.py + 26.0f;
        if (!(pr > L && pl < R && pb > T && pt < Bt)) continue;
        if ((prevB <= T + 10.0f && P.vy >= 0.0f) || (pb - T <= 14.0f && P.vy >= -50.0f)) {
            P.y = T - 26.0f; P.vy = std::min(P.vy, 0.0f); P.onGround = true; P.vaultOneT = 0; continue;
        }
        if (P.vaultOneT > 0.0f) continue;                       // already sailing over it
        if (P.groundedPrev && !P.swinging && !P.wallCling && P.x < (L + R) * 0.5f) {
            const float air = 0.5f * (c.w + 34.0f) / std::max(P.vx, 120.0f);                    // time needed to clear the width at this speed
            P.vy = -std::min(720.0f, std::max(sqrtf(2.0f * GRAV * (c.h + 24.0f)), GRAV * air));
            P.onGround = false; P.slideT = 0; P.coyote = 0; P.vaultOneT = P.vaultOneDur = std::max(0.42f, 2.0f * (-P.vy) / GRAV * 0.95f);
            sfx(6); burst(P.x, P.y + 24, 4, 0xB89A74, 60);
            continue;
        }
        if (P.x < (L + R) * 0.5f) { P.x = L - 9.0f; P.vx = std::min(P.vx, 0.0f) * 0.2f; }      // clipped it in mid-air: bump off
        else { P.x = R + 9.0f; P.vx = std::max(P.vx, 0.0f) * 0.2f; }
        if (P.swinging) releaseWeb(false, true);
    }
    const int prevRide = P.rideId; P.rideId = -1;
    bool onVehicle = false;
    for (TrafficCar& car : trafficCars) {
        const float carL = car.x - car.width * 0.5f, carR = car.x + car.width * 0.5f;
        if (P.x + 8.0f <= carL || P.x - 8.0f >= carR) continue;   // not under or beside the runner: skip before any vertical math (same test as below, done first)
        const float carBottom = carBottomY(car), carTop = carTopY(car);
        const float pl = P.x - 8.0f, pr = P.x + 8.0f, pt = P.y - 24.0f, pb = P.y + 26.0f, prevB = P.py + 26.0f;
        const float stick = (prevRide == car.id && P.groundedPrev && P.vy >= 0.0f) ? 5.0f : 0.0f;   // a rider whose roof dips away this step stays on it instead of hovering for a few frames
        if (!(pr > carL && pl < carR && pb > carTop - stick && pt < carBottom)) continue;
        const bool fromAbove = prevB <= carTop + 6.0f;      // feet were at/above the roof last step
        const bool stepUp = pb - carTop <= 14.0f;          // clipped the roof edge (or the roof just dipped away): be forgiving, hop onto it
        if (P.vy >= -50.0f && (fromAbove || stepUp)) {
            const float impact = P.vy;
            const bool touchdown = !(prevRide == car.id && P.groundedPrev) && impact > 120.0f;   // one kick per touchdown, never while already riding
            if (touchdown) car.dipV = std::max(car.dipV, suspensionKick(car.type, impact));
            P.y = carTop - 26.0f; P.vy = std::min(P.vy, 0.0f);
            P.onGround = true; P.rideId = car.id; onVehicle = true;
            if (touchdown && gTime >= gSafeLandUntil) {
                // Same fall damage as the street (the springs take the edge off: ROOF_CUSHION). A roll still absorbs part of it.
                const bool roll = fall::canRoll(impact, P.slideBuf > 0.0f, P.trickDoneT > 0.0f);
                const float eff = impact / ROOF_CUSHION;
                if (fall::classify(eff, roll, jumpMult()) == fall::FATAL) { killPlayer(true, carTop); return; }
                P.streetImpact = eff; P.streetRoll = roll;   // read by the landing code: HARD LANDING stumble, roll bonus
            }
            continue;
        }
        killPlayer();
        return;
    }
    // ---- The street. Standing on it at the start of a run is fine, but *falling* onto it is deadly. ----
    if (!onVehicle && P.y + 26.0f >= STREET_GROUND_Y && P.vy >= 0.0f) {
        const bool alreadyOnStreet = P.groundedPrev && P.py + 26.0f >= STREET_GROUND_Y - 1.0f;   // still running where the run began
        const float impact = P.vy;
        P.y = STREET_GROUND_Y - 26.0f;
        P.vy = 0.0f;
        P.onGround = true;
        if (!alreadyOnStreet && gTime >= gSafeLandUntil) {
            // Fall damage: short drops are free, big drops hurt (stumble), huge drops end the run. A roll absorbs part of the impact.
            const bool roll = fall::canRoll(impact, P.slideBuf > 0.0f, P.trickDoneT > 0.0f);
            if (fall::classify(impact, roll, jumpMult()) == fall::FATAL) { killPlayer(true); return; }
            P.streetImpact = impact; P.streetRoll = roll;
        }
        if (!alreadyOnStreet) gSafeLandUntil = 0;   // forgiven once
    }
}
// Swept collision: at high speed one frame can move the runner 25+ px, enough to skip clean through a thin rooftop prop, a vehicle or a roof edge.
// The move is replayed in <= 8 px sub-steps and collide() runs at each; the first sub-step that resolves a contact (a landing, a bump) ends the sweep there.
static void collideSwept() {
    const float fx = P.x, fy = P.y, ox = P.px, oy = P.py;
    const float dx = fx - ox, dy = fy - oy;
    const int steps = std::min(24, std::max(1, (int)ceilf(std::max(fabsf(dx), fabsf(dy)) / 8.0f)));
    if (steps == 1) { collide(); return; }
    float prevX = ox, prevY = oy;
    for (int i = 1; i <= steps; i++) {
        const float u = (float)i / (float)steps;
        const float sx = ox + dx * u, sy = oy + dy * u;
        P.px = prevX; P.py = prevY; P.x = sx; P.y = sy;
        collide();
        if (!P.alive) return;
        if (P.x != sx || P.y != sy || P.wallCling) { P.px = ox; P.py = oy; return; }   // contact resolved here: keep the corrected position
        prevX = sx; prevY = sy;
    }
    P.px = ox; P.py = oy; P.x = fx; P.y = fy;
}

static const float WALL_GAP = 9.0f;
static const float CLIMB_UP = 215.0f, SLIDE_DOWN = 150.0f, CLIMB_ACC = 1700.0f, SLIDE_ACC = 900.0f;
static const float MANTLE_DUR = 0.2f;
static Building* wallBuilding() {
    for (auto& b : bldNearExact(P.wallEdge - 2.0f, P.wallEdge + 2.0f)) { const float e = P.wallDir > 0 ? b.x : b.x + b.w; if (fabsf(e - P.wallEdge) < 1.5f) return &b; }   // collide() uses 2 px wide face boxes (b.x +/- 1), so the recorded edge is up to 1 px off
    return nullptr;
}
static void leaveWall(float vx, float vy, float cool) {
    P.wallCling = false; P.mantleT = 0;
    P.wallLastEdge = P.wallEdge; P.wallLastCool = 0.9f; P.wallCool = cool;
    P.vx = vx; P.vy = vy;
}
static void wallJump() {
    const float away = -P.wallDir;
    const float climb = clampValue(-P.vy, -150.0f, CLIMB_UP);
    const float vx = away * (340.0f + 0.15f * std::min(P.wallImpact, 600.0f));
    leaveWall(vx, -540.0f - 0.6f * climb, 0.3f);
    P.x = P.wallX + away * 2.0f;
    P.jumpBuf = 0; P.usedAir = true; P.trickReady = true; P.flipT = 0; P.wallJumpT = 0.28f; P.releaseT = 0;
    P.jumpStyle = wrng.range(0, 2); P.fallStyle = wrng.range(0, 1); P.jit = wrng.f() * 2 - 1;
    sfx(7); comboHit(combo::TRICK);
    burst(P.wallX, P.y, 4, 0xBFD8FF, 70);
    if (swingHeld) swingWas = false;
}
static void wallStep(float dt) {
    Player& p = P;
    Building* b = wallBuilding();
    if (!b) { leaveWall(0, 80, 0.15f); return; }
    const float roof = b->roofY;
    p.x = p.wallX;
    if (p.mantleT > 0) {
        p.mantleT -= dt;
        const float u = 1.0f - clampValue(p.mantleT / MANTLE_DUR, 0.0f, 1.0f), uy = 1.0f - (1.0f - u) * (1.0f - u), ux = u * u;
        p.x = lerpValue(p.mantleX0, p.mantleX1, ux); p.y = lerpValue(p.mantleY0, p.mantleY1, uy);
        p.vx = 0; p.vy = (p.mantleY1 - p.mantleY0) * 2.0f * (1.0f - u) / MANTLE_DUR;
        p.climbPhase += (-p.vy / 110.0f) * dt;
        if (p.mantleT <= 0) {
            p.wallCling = false; p.onGround = true; p.vx = p.wallDir * 180.0f; p.vy = 0; p.coyote = 0.1f; p.usedAir = false;
            p.px = p.x; p.py = p.y; p.wallCool = 0.2f; sfx(2);
        }
        return;
    }
    const bool climbing = swingHeld;
    const float tv = climbing ? -CLIMB_UP : SLIDE_DOWN, acc = (climbing ? CLIMB_ACC : SLIDE_ACC) * dt;
    p.vy += clampValue(tv - p.vy, -acc, acc);
    p.y += p.vy * dt;
    p.climbPhase += (-p.vy / 110.0f) * dt;
    if (p.vy < -20.0f && p.y <= roof + 22.0f) {
        const float x1 = p.wallDir > 0 ? b->x + 14.0f : b->x + b->w - 14.0f;
        bool blocked = false;
        for (auto& o : b->obs) if (o.solid && x1 + 9 > o.x - 2 && x1 - 9 < o.x + o.w + 2) { blocked = true; break; }
        if (blocked) { p.y = std::max(p.y, roof + 22.0f); p.vy = 0; }
        else {
            p.mantleT = MANTLE_DUR; p.mantleX0 = p.x; p.mantleY0 = p.y; p.mantleX1 = x1; p.mantleY1 = roof - 26.0f;
            return;
        }
    }
    if (p.y < roof + 8.0f) p.y = roof + 8.0f;
    if (p.y + 26.0f > 760.0f) { leaveWall(-p.wallDir * 220.0f, -300.0f, 0.4f); p.wallJumpT = 0.2f; return; }
}

static const float ZIP_MIN = 140.0f, ZIP_MAX = 560.0f, ZIP_COOL = 1.1f, ZIP_TOP = 1500.0f, ZIP_ACC = 3400.0f, ZIP_EXIT = 1250.0f;
static const float DIVE_ACC = 1500.0f, DIVE_VY = 1150.0f, DIVE_MAX = 1.3f, DIVE_COOL = 0.8f;
static bool zipCanStart() { return P.alive && !P.onGround && !P.wallCling && !P.zipping && P.zipCool <= 0 && P.mantleT <= 0; }
static bool zipRange(float tx, float ty) {
    const float dx = tx - P.x, dy = ty - (P.y - 10), d = hypotf(dx, dy);
    return d >= ZIP_MIN && d <= ZIP_MAX && dx > 40.0f && dy < 30.0f && !webBlocked(P.x, P.y - 10, tx, ty);
}
static bool beginZip(float tx, float ty) {
    if (!zipCanStart() || !zipRange(tx, ty)) return false;
    if (P.swinging) { P.swinging = false; markBad(P.ax, P.ay, 1.2f); }
    P.zipping = true; P.zipX = tx; P.zipY = ty; P.zipT = 0;
    P.diving = false; P.webFlying = false; P.trickType = 0; P.launchT = 0; P.shootT = 0.12f; P.releaseT = 0;
    sfx(0); burst(P.x, P.y - 10, 4, 0xDCEBFF, 80);
    return true;
}
static bool findZipTarget(float& ox, float& oy) {
    WebQuery q = makeQuery();
    if (P.swinging) { q.hasEx = true; q.exX = P.ax; q.exY = P.ay; }
    return pickAnchor(q, ox, oy) && zipRange(ox, oy);
}
static void zipEnd(bool arrived) {
    P.zipping = false; P.zipCool = arrived ? ZIP_COOL : 0.5f;
    if (!arrived) return;
    const float sp = hypotf(P.vx, P.vy);
    if (sp > ZIP_EXIT) { P.vx *= ZIP_EXIT / sp; P.vy *= ZIP_EXIT / sp; }
    P.vy -= 140.0f;
    P.trickReady = true; P.releaseT = 0.25f; P.releaseFlip = false; P.usedAir = false;
    gFlow = std::min(1.0f, gFlow + 0.08f);
    comboHit(combo::STUNT);
    markBad(P.zipX, P.zipY, 1.5f);
    burst(P.x, P.y - 10, 6, 0xFFFFFF, 110); sfx(8);
}
static void zipSteer(float dt) {
    P.zipT += dt;
    float dx = P.zipX - P.x, dy = P.zipY - (P.y - 10);
    const float d = std::max(hypotf(dx, dy), 1.0f);
    dx /= d; dy /= d;
    const float sp = clampValue(260.0f + ZIP_ACC * P.zipT, 260.0f, ZIP_TOP), k = std::min(1.0f, 16.0f * dt);
    P.vx += (dx * sp - P.vx) * k; P.vy += (dy * sp - P.vy) * k;
}
static void zipCheck() {
    if (P.wallCling || P.onGround) { zipEnd(false); return; }
    if (hypotf(P.zipX - P.x, P.zipY - (P.y - 10)) < 56.0f || P.zipT > 1.0f) { zipEnd(true); return; }
    if (webBlocked(P.x, P.y - 10, P.zipX, P.zipY)) zipEnd(false);
}

static float senseScan(float& hitAng) {
    const Player& p = P;
    if (!p.alive || p.wallCling || p.zipping) return 0.0f;
    const float horizon = p.swinging ? 0.35f : 0.8f, g = p.swinging ? 0.0f : GRAV;
    float prevB = p.y + 26.0f;
    for (float t = 0.05f; t <= horizon + 1e-4f; t += 0.05f) {
        const float x = p.x + p.vx * t, y = p.y + p.vy * t + 0.5f * g * t * t, vy = p.vy + g * t;
        const float pl = x - 8, pr = x + 8, pt = y - 24, pb = y + 26;
        bool hit = false;
        for (auto& b : bldNearExact(pl - 4.0f, pr + 4.0f)) {
            if (b.x > pr + 4 || b.x + b.w < pl - 4) continue;
            for (auto& o : b.obs) {
                if (!o.solid) continue;
                const float T = b.roofY - o.h;
                if (!(pr > o.x && pl < o.x + o.w && pb > T && pt < b.roofY)) continue;
                if ((prevB <= T + 14 && vy >= 0) || (pb - T < 26 && vy >= -50)) return 0.0f;
                hit = true;
            }
            if (hit) break;
        }
        if (!hit) for (const TrafficCar& car : trafficCars) {
            const float cx = car.x + car.dir * car.speed * t;
            const float bottom = carBottomY(car), top = carTopY(car);
            if (!(fabsf(x - cx) < car.width * 0.5f + 8.0f && pb > top && pt < bottom)) continue;
            if (vy >= -50.0f && (prevB <= top + 6.0f || pb - top <= 14.0f)) return 0.0f;   // would land on the roof: safe
            hit = true; break;
        }
        if (!hit && !(p.onGround && p.rideId < 0) && pb >= STREET_GROUND_Y && vy >= 0) hit = true;   // would hit the street
        if (hit) { hitAng = atan2f(y - p.y, x - p.x); return clampValue(1.0f - (t - 0.05f) / horizon, 0.15f, 1.0f); }
        prevB = pb;
    }
    return 0.0f;
}
static void senseTick(float dt) {
    gSenseT -= dt;
    if (gSenseT <= 0) { gSenseTgt = senseScan(gSenseAng); gSenseT = 0.05f; }
    gSense += (gSenseTgt - gSense) * (1.0f - expf(-(gSenseTgt > gSense ? 18.0f : 5.0f) * dt));
    if (!P.alive) gSense = gSenseTgt = 0;
}
static void stepPhysics(float dt) {
    Player& p = P;
    if (!p.alive) {
        if (gRag.on) { ragStep(dt); return; }
        if (p.deadGround) { p.vx *= expf(-6.0f * dt); p.x += p.vx * dt; p.y = STREET_GROUND_Y - 26.0f; p.vy = 0; return; }
        p.vy += GRAV * dt; p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.y + 26.0f >= STREET_GROUND_Y && p.vy > 0) { p.y = STREET_GROUND_Y - 26.0f; p.vy = 0; p.vx *= 0.4f; }
        return;
    }
    if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.vx) || !std::isfinite(p.vy)) {

        p.x = std::isfinite(p.px) ? p.px : 0.0f; p.y = std::isfinite(p.py) ? p.py : 0.0f; p.vx = p.vy = 0;
        if (p.swinging) releaseWeb(false, true);
    }
    p.vx = clampValue(p.vx, -4000.0f, 4000.0f); p.vy = clampValue(p.vy, -4000.0f, 4000.0f);
    const float rm = runMult(), sm = swingMult();
    float runSp = diff::runSpeedBase(distM) * rm;
    p.px = p.x; p.py = p.y;
    p.coyote -= dt; p.jumpBuf -= dt; p.wrapCool -= dt; p.vaultT -= dt; p.vaultOneT -= dt; p.rollT -= dt;
    p.trickCool -= dt; p.trickDoneT -= dt;
    if (p.trickType) trickStep(dt);
    if (jumpEdge) { p.jumpBuf = 0.12f; jumpEdge = false; }
    p.slideBuf -= dt;
    if (slideEdge) { slideEdge = false; if (!tryTrick()) p.slideBuf = 0.15f; }
    p.boostT -= dt;
    float target = runSp + p.boostExtra * clampValue(p.boostT / p.boostDur, 0.0f, 1.0f);
    // Riding a vehicle: its roof grips you, so you move with it. Run speed is relative to the vehicle
    // (steer back to stand still on the roof), instead of the street's fixed auto-run speed.
    const TrafficCar* ride = (p.onGround && p.rideId >= 0) ? findCar(p.rideId) : nullptr;
    const float rideV = ride ? ride->dir * ride->speed : 0.0f;
    const float runRel = target * clampValue(0.18f + 0.72f * steer, 0.0f, 1.0f);
    const float groundTarget = ride ? rideV + runRel : target;
    p.wallCool -= dt; p.wallLastCool -= dt; p.wallJumpT -= dt; p.zipCool -= dt; p.diveCool -= dt;
    if (p.zipping && p.jumpBuf > 0) zipEnd(false);
    if (p.diving && (p.onGround || p.swinging || p.wallCling || p.zipping)) p.diving = false;
    if (p.wallCling && p.jumpBuf > 0 && p.mantleT <= 0) wallJump();
    if (p.wallCling) {
        wallStep(dt);
        if (p.y > 900) killPlayer();
        return;
    }
    if (p.jumpBuf > 0 && !p.zipping) {
        if (p.swinging) { releaseWeb(true); p.vy -= 200; p.jumpBuf = 0; }
        else if (p.onGround || p.coyote > 0) {
            p.vy = -560 * jumpMult(); p.onGround = false; p.trickReady = true; p.coyote = 0; p.jumpBuf = 0; p.slideT = 0; p.jumpStyle = wrng.range(0, 2); p.fallStyle = wrng.range(0, 1); p.jit = wrng.f() * 2 - 1; sfx(7);
            for (int i = 0; i < 4; i++) spawnPart(p.x, p.y + 26, (i - 1.5f) * 25, -20, 0.3f, 0x8A90B0);
        } else if (!p.usedAir) { p.vy = -440 * (1.0f + 0.6f * (jumpMult() - 1.0f)); p.usedAir = true; p.trickReady = true; p.jumpBuf = 0; p.flipT = 0.55f; p.flipDir = wrng.f() < 0.8f ? 1.0f : -1.0f; sfx(7); comboHit(combo::TRICK); }
    }
    if (jumpRel) { if (p.vy < -250 && !p.swinging) p.vy *= 0.6f; jumpRel = false; }
    if (p.slideBuf > 0 && p.onGround && p.slideT <= 0) {
        p.slideBuf = 0; p.slideT = 0.7f; p.slideStyle = wrng.range(0, 2); p.jit = wrng.f() * 2 - 1;
        if (ride) p.vx = rideV + std::min(std::max(p.vx - rideV, runRel) * (1.0f + SLIDE_BOOST), 760.0f * rm);
        else p.vx = std::min(std::max(p.vx, target) * (1.0f + SLIDE_BOOST), 760.0f * rm);
        sfx(6); burst(p.x, p.y + 24, 5, 0x9AA0C0, 70);
    }
    if (p.onGround) {
        if (ride) {
            if (p.slideT > 0) { /* the slide keeps its boosted speed on a vehicle roof too */ }
            else p.vx += (groundTarget - p.vx) * std::min(1.0f, 12 * dt);
        }
        else if (p.slideT > 0) { /* hold the boosted speed for the whole slide; the run then eases back to normal */ }
        else p.vx += (target - p.vx) * std::min(1.0f, 4 * dt);
    }
    p.slideT = p.onGround ? p.slideT - dt : 0;
    bool wasGround = p.onGround;
    p.onGround = false;
    if (p.zipping) zipSteer(dt);
    else {
        float gs = p.swinging ? sm : 1.0f;
        if (!p.swinging && p.hangT > 0) gs *= HANG_GRAV;                 // hang time after a release
        if (p.webFlying) {                                              // the web snaps toward its anchor instead of leaving you in free fall
            gs *= WEB_FLIGHT_GRAV;
            const float wx = tgtX - p.x, wy = tgtY - (p.y - 10), wd = std::max(hypotf(wx, wy), 1.0f);
            p.vx += wx / wd * WEB_PULL * dt; p.vy += wy / wd * WEB_PULL * dt;
        }
        p.vy += GRAV * gs * dt;
    }
    p.hangT = std::max(0.0f, p.hangT - dt);
    p.diveMemT = p.diving ? 0.35f : std::max(0.0f, p.diveMemT - dt);
    if (p.diving) {

        if (p.vy < DIVE_VY) p.vy = std::min(DIVE_VY, p.vy + DIVE_ACC * dt);
        p.diveT += dt;
        if (p.diveT > DIVE_MAX) { p.diving = false; p.diveCool = DIVE_COOL; }
    }
    const float preVy = p.vy;
    if (!wasGround && !p.swinging && fabsf(steer) > 0.01f && fabsf(p.vx) < 700 * rm) p.vx += steer * 240 * airMult() * cfg.sens * dt;
    p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.swinging) {
        reelStep(p.x, p.y, p.ax, p.ay, p.vx, p.vy, p.rope, p.ropeEff, dt);
        swingStep(p.x, p.y, p.vx, p.vy, p.ax, p.ay, p.ropeEff, sm, steer * cfg.sens * webMult(), dt);
        if (p.x - p.ax > swingMaxFwd(p.rope)) releaseWeb(false, false, true);
    } else {
        float dr = expf(-0.05f * dt); p.vx *= dr;
        if (p.launchT > 0) {
            const float g = 1.0f + (1.0f - POP_NOW) * p.launchK * dt / p.launchDur;   // the remaining share after the instant pop
            p.vx *= g; p.vy *= g; p.launchT -= dt;
            const float sp = hypotf(p.vx, p.vy), cap = swingSpeedCap(sm);
            if (sp > cap) { p.vx *= cap / sp; p.vy *= cap / sp; }
        }
    }
    p.groundedPrev = wasGround;
    collideSwept();
    if (!p.alive) return;
    if (p.zipping) zipCheck();
    if (wasGround && !p.onGround) p.trickReady = true;
    if (p.onGround) {
        p.wallCling = false;
        if (p.swinging) releaseWeb(false, true);
        p.coyote = 0.1f; p.usedAir = false; p.launchT = 0; p.hangT = 0;
        if (!wasGround) {
            if (p.trickType) {
                p.trickType = 0; p.trickCool = 0.3f; p.trickDoneT = 0;
                p.vx *= 0.9f;
                snprintf(gTrickMsg, sizeof gTrickMsg, "SLOPPY"); gTrickBad = true; gTrickMsgT = 0.7f;
            }
            const bool streetLand = p.streetImpact > 0.0f;
            const bool rolled = streetLand ? p.streetRoll : fall::canRoll(preVy, p.slideBuf > 0.0f, p.trickDoneT > 0.0f);
            const fall::Result hurt = streetLand ? fall::classify(p.streetImpact, p.streetRoll, jumpMult()) : fall::NONE;
            p.streetImpact = 0.0f; p.streetRoll = false;
            p.vaultOneT = 0;
            p.landDepth = clampValue((preVy - 250.0f) / 700.0f, 0.0f, 1.0f);
            p.hero = preVy > 640.0f && !rolled; p.landT = p.hero ? 0.42f : 0.14f + 0.10f * clampValue((preVy - 250.0f) / 390.0f, 0.0f, 1.0f); p.flipT = 0;
            if (rolled) { p.rollT = p.rollDur = 0.45f; p.landT = 0; p.hero = false; if (!(gTrickBad && gTrickMsgT > 0)) { snprintf(gTrickMsg, sizeof gTrickMsg, "ROLL"); gTrickBad = false; gTrickMsgT = 0.7f; } bonus += 10; }
            if (hurt == fall::HARD) {
                p.vx *= 0.45f; p.boostT = 0; p.landT = 0.55f; p.hero = true; p.rollT = 0;
                combo::crash(gCombo); saveComboBest(); gComboNm = -1;
                snprintf(gTrickMsg, sizeof gTrickMsg, "HARD LANDING"); gTrickBad = true; gTrickMsgT = 0.9f;
                doShake(0.35f); burst(p.x, p.y + 24, 10, 0xC9BFA8, 120);
            }
            if (gTrickBad && gTrickMsgT > 0.5f) p.landT = std::max(p.landT, 0.3f);
            const TrafficCar* landCar = p.rideId >= 0 ? findCar(p.rideId) : nullptr;
            float over = p.vx - (landCar ? landCar->dir * landCar->speed : 0.0f) - runSp;
            if (p.chain >= 1 && over > 40) {
                p.boostExtra = clampValue(over * 0.6f, 60, 250);
                p.boostDur = p.boostT = 2.0f + 3.0f * clampValue(over / 400.0f, 0, 1);
                if (p.slideBuf > 0) { p.boostT += 1; p.boostDur += 1; }
            }
            p.landStyle = wrng.range(0, 2); p.runStyle = wrng.range(0, 2); p.jit = wrng.f() * 2 - 1;
            bonus += 25 + (p.chain >= 2 ? 10.0f * p.chain : 0);
            if (p.slideBuf > 0 && !p.hero && hurt != fall::HARD) comboHit(combo::LAND);
            if (p.chain >= 5) comboHit(combo::LONGCHAIN, 20.0f * p.chain);
            if (p.chain >= 2) chainShowT = 1.6f;
            p.chain = 0;
            sfx(2); doShake(0.12f);
            for (int i = 0; i < 6; i++) spawnPart(p.x, p.y + 26, (i - 2.5f) * 35, -30 - wrng.f() * 30, 0.35f, 0x9AA0C0);
        }
    }
    if (p.y > 900) killPlayer();
}

enum { R_NONE, R_SWING, R_JUMP, R_PAUSE, R_UI, R_STEER, R_SLIDER, R_SLIDE, R_DRAG, R_IRON };
struct Touch { bool on = false; SDL_FingerID id = 0; float x = 0, y = 0, sx = 0, ox = 0, oy = 0; int role = 0; int btn = 0; };
static Touch tch[10];
enum { B_PLAY = 1, B_CONTROLS, B_SETTINGS, B_HOW, B_CREDITS, B_BACK, B_RESUME, B_RESTART, B_MENU, B_TRY,
       B_SHAKE, B_REDUCED, B_FULL, B_TARGET_HINTS, B_FPS_CAP, B_SHOW_FPS, B_TAB_KEYS, B_TAB_TOUCH, B_EDIT_LAYOUT, B_RESET_TAB, B_LEFTY, B_DONE, B_RESET_LAYOUT, B_KEY,
       B_GRAPHICS, B_GFX_RT, B_GFX_API, B_GFX_QUALITY, B_GFX_SHADOWS, B_GFX_AO, B_GFX_REFL, B_GFX_PERF, B_GFX_RESET,
       B_SKILLS, B_UP_RUN, B_UP_SWING, B_RB_RUN, B_RB_SWING, B_UP_JUMP, B_UP_AIR, B_UP_WEB, B_UP_IRON,
       S_MUSIC, S_SFX, S_SENS, S_SIZE, S_ALPHA };
struct Btn { int id, kind, x, y, w, h; const char* label; float* val; bool* flag; float vmin, vmax; int style = 0, act = 0; };
static std::vector<Btn> btns;
static Btn pauseBtn;
static int gFocus = -1;
static int gRebind = -1;
static int ctlTab = 0;
static float flashT = 0, uiAge = 0, noteT = 0;
static SDL_Texture* gCreditsTex = nullptr; static int gCreditsW = 0, gCreditsH = 0;
// The credits picture is decoded + uploaded only while the credits screen is open (up to 2048x2048 ARGB = 16 MB of VRAM, plus the transient decode
// buffers) and freed again when the player leaves it. gCreditsTried stops a missing file from being searched for every frame.
static bool gCreditsTried = false;
static void loadCreditsImage();
static void unloadCreditsImage();
static char gNote[48] = "";

static void setNote(const char*) { gNote[0] = 0; noteT = 0; }   // explanatory notes removed
static bool hasGlyph(unsigned char ch) { if (ch >= 128) return false; for (int i = 0; i < 7; i++) if (gGl[ch][i]) return true; return false; }
static void keyLabel(SDL_Scancode sc, char* out, size_t n) {
    switch (sc) {
        case SDL_SCANCODE_LSHIFT: snprintf(out, n, "L SHIFT"); return;
        case SDL_SCANCODE_RSHIFT: snprintf(out, n, "R SHIFT"); return;
        case SDL_SCANCODE_LCTRL: snprintf(out, n, "L CTRL"); return;
        case SDL_SCANCODE_RCTRL: snprintf(out, n, "R CTRL"); return;
        case SDL_SCANCODE_LALT: snprintf(out, n, "L ALT"); return;
        case SDL_SCANCODE_RALT: snprintf(out, n, "R ALT"); return;
        case SDL_SCANCODE_RETURN: snprintf(out, n, "ENTER"); return;
        case SDL_SCANCODE_SPACE: snprintf(out, n, "SPACE"); return;
        case SDL_SCANCODE_UP: snprintf(out, n, "UP ARROW"); return;
        case SDL_SCANCODE_DOWN: snprintf(out, n, "DOWN ARROW"); return;
        case SDL_SCANCODE_LEFT: snprintf(out, n, "LEFT ARROW"); return;
        case SDL_SCANCODE_RIGHT: snprintf(out, n, "RIGHT ARROW"); return;
        default: break;
    }
    const char* nm = SDL_GetScancodeName(sc);
    bool ok = nm && *nm;
    for (const char* c = nm; ok && *c; ++c) { unsigned char u = (unsigned char)toupper((unsigned char)*c); if (u != ' ' && !hasGlyph(u)) ok = false; }
    if (ok) snprintf(out, n, "%.12s", nm); else snprintf(out, n, "KEY %d", (int)sc);
    for (char* c = out; *c; ++c) *c = (char)toupper((unsigned char)*c);
}

static void ctlPos(int i, float& x, float& y, float& r) {
    static const float R[3] = {42, 33, 33};
    float s = ctl.scale;
    r = R[i] * s;
    if (ctl.px[i] >= 0) { x = ctl.px[i] * uvzWorldWidth; y = ctl.py[i] * uvzWorldHeight; }
    else {
        // SWING sits in the corner; JUMP and SLIDE form a tidy arc around it, evenly spaced, all inside thumb reach.
        float sr = R[0] * s, sx = uvzWorldWidth - uvzSafeRight - sr - 10, sy = uvzWorldHeight - uvzSafeBottom - sr - 8;
        if (i == 0) { x = sx; y = sy; }
        else if (i == 1) { x = sx - 88 * s; y = sy + 12 * s; }
        else { x = sx - 56 * s; y = sy - 72 * s; }
        if (ctl.lefty) x = uvzWorldWidth - x;
    }
    float m = r + 2;
    x = clampValue(x, m, uvzWorldWidth - m); y = clampValue(y, m, uvzWorldHeight - m);
}
// Iron Arms button: bottom-left corner (mirrored for left-handed layouts, where the other controls move to the left).
static void ironBtnPos(float& x, float& y, float& r) {
    r = 34.0f * ctl.scale;
    x = uvzSafeLeft + r + 16.0f; y = uvzWorldHeight - uvzSafeBottom - r - 14.0f;
    if (ctl.lefty) x = uvzWorldWidth - x;
    const float m = r + 2; x = clampValue(x, m, uvzWorldWidth - m); y = clampValue(y, m, uvzWorldHeight - m);
}
static bool inSteerZone(float x) { return ctl.lefty ? x > uvzWorldWidth * 0.45f : x < uvzWorldWidth * 0.55f; }

static const int SKILL_ROWS = 6;
static const int SKILL_ROW[SKILL_ROWS] = {prog::JUMP, prog::RUN, prog::SWING, prog::AIR, prog::WEB, prog::IRON};
static const char* const SKILL_ROW_LETTER[SKILL_ROWS] = {"J", "R", "S", "A", "W", "I"};
struct SkillLay { int rx, rw, rowY[SKILL_ROWS], rowH, bx[2], bw, bh, infoW, wcx, wcy, wr; bool compact; };
static SkillLay skillLay(int px, int pw) {
    SkillLay L;
    int top = 62, bottom = uvzWorldHeight - 14 - 38 - 8, gap = 3;   // six rows now: a slightly tighter pitch keeps the last one clear of BACK
    L.rowH = (int)clampValue((float)((bottom - top - (SKILL_ROWS - 1) * gap) / SKILL_ROWS), 25.0f, 64.0f);
    L.compact = L.rowH < 50;   // short screens: drop the second info line
    int total = SKILL_ROWS * L.rowH + (SKILL_ROWS - 1) * gap, y0 = top + std::max(0, (bottom - top - total) / 2);
    for (int i = 0; i < SKILL_ROWS; i++) L.rowY[i] = y0 + i * (L.rowH + gap);
    int leftW = std::min(170, (pw - 40) * 30 / 100);
    L.rx = px + 20 + leftW + 10; L.rw = px + pw - 20 - L.rx;
    L.bw = 88; L.bh = std::min(L.rowH - 8, 30);
    L.bx[1] = L.rx + L.rw - L.bw; L.bx[0] = L.bx[1] - L.bw - 6;
    L.infoW = L.bx[0] - L.rx - 8;
    L.wcx = px + 20 + leftW / 2; L.wcy = (top + bottom) / 2; L.wr = std::min(leftW / 2, (bottom - top) / 2) - 2;
    return L;
}

static bool gfxRtAvailable() { return gfxcfg::rtSupported(gCaps); }
static void buildUI() {
    btns.clear();
    float bh = std::max(uvzMinimumTouchSize * 0.8f, 30.0f);
    pauseBtn = {0, 0, (int)(uvzWorldWidth / 2 - 22), (int)uvzSafeTop, 44, 44, "", nullptr, nullptr, 0, 1};
    int pw = std::min(uvzWorldWidth - (int)(uvzSafeLeft + uvzSafeRight), 560), px = (uvzWorldWidth - pw) / 2;
    int footY = uvzWorldHeight - 14 - 38;
    auto add = [&](int id, int kind, int x, int y, int w, int h, const char* label, float* v, bool* f, float lo, float hi, int style, int act) {
        Btn b = {id, kind, x, y, w, h, label, v, f, lo, hi, style, act};
        btns.push_back(b);
    };
    switch (gState) {
        case MAIN_MENU: {
            if (trans >= 0) break;
            int x = (int)uvzSafeLeft + 8, w = (int)std::min(230.0f, uvzWorldWidth * 0.42f);
            int top = 82, n = 5, gap = 5;
            int ih = (int)clampValue((float)((uvzWorldHeight - top - 34 - gap * (n - 1)) / n), 26.0f, bh + 4);
            int y = top;
            add(B_PLAY, 0, x, y, w, ih + 6, "PLAY", nullptr, nullptr, 0, 1, 2, 0); y += ih + 6 + gap;
            add(B_CONTROLS, 0, x, y, w, ih, "CONTROLS", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_SETTINGS, 0, x, y, w, ih, "SETTINGS", nullptr, nullptr, 0, 1, 0, 0); y += ih + gap;
            add(B_CREDITS, 0, x, y, w, ih, "STRYER", nullptr, nullptr, 0, 1, 0, 0);
            add(B_SKILLS, 4, uvzWorldWidth - (int)uvzSafeRight - 54, (int)uvzSafeTop + 10, 46, 46, "UPGRADES", nullptr, nullptr, 0, 1, 0, 0);
        } break;
        case SETTINGS: {
            int cw = (pw - 56) / 2, y = 70, c1 = px + 20, c2 = px + 36 + cw;
            const int pitch = clampInt((footY - 6 - y) / 6, 30, 46), th = pitch - 6;   // six rows always clear the BACK button
            static char fpsLabel[24];
            if (fpsCap() > 0) snprintf(fpsLabel, sizeof fpsLabel, "FPS LIMIT %d", fpsCap()); else snprintf(fpsLabel, sizeof fpsLabel, "FPS UNCAPPED");
            add(S_MUSIC, 1, c1, y, cw, th, "MUSIC", &cfg.music, nullptr, 0, 1, 0, 0);
            add(S_SFX, 1, c1, y + pitch, cw, th, "EFFECTS", &cfg.sfx, nullptr, 0, 1, 0, 0);
            add(S_SENS, 1, c1, y + 2 * pitch, cw, th, "STEERING", &cfg.sens, nullptr, 0.5f, 1.5f, 0, 0);
            add(B_SHAKE, 2, c2, y, cw, th, "CAMERA SHAKE", nullptr, &cfg.shake, 0, 1, 0, 0);
            add(B_REDUCED, 2, c2, y + pitch, cw, th, "FEWER PARTICLES", nullptr, &cfg.reduced, 0, 1, 0, 0);
#ifndef __ANDROID__
            add(B_FULL, 2, c2, y + 2 * pitch, cw, th, "FULLSCREEN", nullptr, &cfg.full, 0, 1, 0, 0);   // phones are always fullscreen, so no toggle there
            add(B_SHOW_FPS, 2, c2, y + 3 * pitch, cw, th, "SHOW FPS", nullptr, &cfg.showFps, 0, 1, 0, 0);
#else
            add(B_SHOW_FPS, 2, c2, y + 2 * pitch, cw, th, "SHOW FPS", nullptr, &cfg.showFps, 0, 1, 0, 0);
#endif
            add(B_TARGET_HINTS, 2, c1, y + 3 * pitch, cw, th, "WEB TARGET HINTS", nullptr, &cfg.targetHints, 0, 1, 0, 0);
            add(B_FPS_CAP, 0, c1, y + 4 * pitch, 2 * cw + 16, th, fpsLabel, nullptr, nullptr, 0, 1, 1 | 4, 0);   // tap to cycle 30 / 60 / 120 / uncapped
            add(B_GRAPHICS, 0, c1, y + 5 * pitch, 2 * cw + 16, th, "GRAPHICS SETTINGS", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(B_BACK, 0, uvzWorldWidth / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case GRAPHICS: {
            int cw = (pw - 56) / 2, y = 62, c1 = px + 20, c2 = px + 36 + cw;
            const int warnH = 5 * 10 + 4, warnTop = footY - 4 - warnH;
            const int pitch = clampInt((warnTop - y) / 4, 28, 46), th = pitch - 6;
            static char apiL[40], qL[40], pL[48];
            snprintf(apiL, sizeof apiL, "GRAPHICS API: %s", gfxcfg::API_NAME[gGfx.api]);
            snprintf(qL, sizeof qL, "LIGHTING QUALITY: %s", gfxcfg::QUALITY_NAME[gGfx.quality]);
            snprintf(pL, sizeof pL, "MODE: %s", gfxcfg::PERF_NAME[gGfx.perf]);
            const int dimRt = gfxRtAvailable() ? 0 : 16;   // greyed out when the device cannot run ray-marched lighting (the choice is still remembered)
            const int dimRefl = gFx.rt ? 0 : 16;
            add(B_GFX_RT, 2, c1, y, cw, th, "DYNAMIC LIGHTING", nullptr, &gGfx.rt, 0, 1, dimRt, 0);
            add(B_GFX_API, 0, c1, y + pitch, cw, th, apiL, nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(B_GFX_QUALITY, 0, c1, y + 2 * pitch, cw, th, qL, nullptr, nullptr, 0, 1, 1 | 4 | dimRefl, 0);
            add(B_GFX_PERF, 0, c1, y + 3 * pitch, cw, th, pL, nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(B_GFX_SHADOWS, 2, c2, y, cw, th, "DYNAMIC SHADOWS", nullptr, &gGfx.shadows, 0, 1, 0, 0);
            add(B_GFX_AO, 2, c2, y + pitch, cw, th, "AMBIENT OCCLUSION", nullptr, &gGfx.ao, 0, 1, 0, 0);
            add(B_GFX_REFL, 2, c2, y + 2 * pitch, cw, th, "REFLECTIONS", nullptr, &gGfx.reflections, 0, 1, dimRefl, 0);
            add(B_BACK, 0, uvzWorldWidth / 2 - 170, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(B_GFX_RESET, 0, uvzWorldWidth / 2 + 10, footY, 160, 30, "RESTORE DEFAULTS", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case CONTROLS: {
            int cw = (pw - 56) / 2, c1 = px + 20, c2 = px + 36 + cw, gy = 96, th = 38, pitch = 42;
            add(B_TAB_KEYS, 0, c1, 60, 130, 26, "KEYBOARD", nullptr, nullptr, 0, 1, 1 | 8, 0);
            add(B_TAB_TOUCH, 0, c1 + 138, 60, 130, 26, "TOUCH", nullptr, nullptr, 0, 1, 1 | 8, 0);
            if (ctlTab == 0) {
                static const int L[3] = {A_LEFT, A_RIGHT, A_PAUSE}, R[3] = {A_JUMP, A_SLIDE, A_SWING};
                for (int i = 0; i < 3; i++) add(B_KEY, 3, c1, gy + i * pitch, cw, th, ACT_LABEL[L[i]], nullptr, nullptr, 0, 1, 0, L[i]);
                for (int i = 0; i < 3; i++) add(B_KEY, 3, c2, gy + i * pitch, cw, th, ACT_LABEL[R[i]], nullptr, nullptr, 0, 1, 0, R[i]);
            } else {
                add(S_SIZE, 1, c1, gy, cw, th, "BUTTON SIZE", &ctl.scale, nullptr, 0.7f, 1.4f, 0, 0);
                add(S_ALPHA, 1, c1, gy + pitch, cw, th, "BUTTON OPACITY", &ctl.alpha, nullptr, 0.2f, 1.0f, 0, 0);
                add(S_SENS, 1, c1, gy + 2 * pitch, cw, th, "STEERING", &cfg.sens, nullptr, 0.5f, 1.5f, 0, 0);
                add(B_LEFTY, 2, c2, gy, cw, th, "LEFT HANDED", nullptr, &ctl.lefty, 0, 1, 0, 0);
                add(B_EDIT_LAYOUT, 0, c2, gy + pitch + 4, cw, 32, "EDIT LAYOUT", nullptr, nullptr, 0, 1, 1 | 4, 0);
                add(B_RESET_LAYOUT, 0, c2, gy + 2 * pitch + 4, cw, 32, "RESET LAYOUT", nullptr, nullptr, 0, 1, 1 | 4, 0);
            }
            add(B_BACK, 0, uvzWorldWidth / 2 - 170, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(B_RESET_TAB, 0, uvzWorldWidth / 2 + 10, footY, 160, 30, "RESET TAB", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case LAYOUT_EDIT: {
            int bw = 104, gap = 12, left = (int)uvzSafeLeft + 8, right = uvzWorldWidth - (int)uvzSafeRight - 8;
            int sw = (int)clampValue((float)((right - left - 2 * bw - 4 * gap) / 2), 90.0f, 180.0f);
            int y = 10;
            add(B_DONE, 0, left, y, bw, 30, "DONE", nullptr, nullptr, 0, 1, 1 | 4, 0);
            add(S_SIZE, 1, left + bw + gap * 2, y - 2, sw, 40, "SIZE", &ctl.scale, nullptr, 0.7f, 1.4f, 0, 0);
            add(S_ALPHA, 1, left + bw + gap * 3 + sw, y - 2, sw, 40, "OPACITY", &ctl.alpha, nullptr, 0.2f, 1.0f, 0, 0);
            add(B_RESET_LAYOUT, 0, right - bw, y, bw, 30, "RESET", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        case CREDITS:   // full-screen image view: large BACK button in the top-left safe corner
            add(B_BACK, 0, (int)uvzSafeLeft, (int)uvzSafeTop + 2, 130, std::max(52, (int)uvzMinimumTouchSize + 8), "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            break;
        case HOW_TO_PLAY:
            add(B_BACK, 0, uvzWorldWidth / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
            break;
        case PAUSED: {
            int w = 250, n = 5, gap = 5, top = (int)(uvzWorldHeight * 0.28f);
            int ih = (int)clampValue((float)((uvzWorldHeight - top - 16 - gap * (n - 1)) / n), 24.0f, bh);
            int x = uvzWorldWidth / 2 - w / 2, y = top;
            add(B_RESUME, 0, x, y, w, ih + 4, "RESUME", nullptr, nullptr, 0, 1, 1 | 2, 0); y += ih + 4 + gap;
            add(B_RESTART, 0, x, y, w, ih, "RESTART", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_CONTROLS, 0, x, y, w, ih, "CONTROLS", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_SETTINGS, 0, x, y, w, ih, "SETTINGS", nullptr, nullptr, 0, 1, 1, 0); y += ih + gap;
            add(B_MENU, 0, x, y, w, ih, "MAIN MENU", nullptr, nullptr, 0, 1, 1, 0);
        } break;
        case GAME_OVER: {
            int y = uvzWorldHeight - (int)uvzSafeBottom - 46;
            add(B_TRY, 0, uvzWorldWidth / 2 - 205, y, 200, 38, "RESTART", nullptr, nullptr, 0, 1, 1 | 2, 0);
            add(B_MENU, 0, uvzWorldWidth / 2 + 5, y, 200, 38, "MAIN MENU", nullptr, nullptr, 0, 1, 1, 0);
            add(B_SKILLS, 4, uvzWorldWidth - (int)uvzSafeRight - 54, (int)uvzSafeTop + 10, 46, 46, "UPGRADES", nullptr, nullptr, 0, 1, 0, 0);
        } break;
        case SKILLS: {
            SkillLay L = skillLay(px, pw);
            static char lb[SKILL_ROWS * 2][28];
            static const int ids[prog::SKILL_COUNT][2] = {{B_UP_RUN, B_RB_RUN}, {B_UP_SWING, B_RB_SWING}, {B_UP_JUMP, 0}, {B_UP_AIR, 0}, {B_UP_WEB, 0}, {B_UP_IRON, 0}};
            for (int k = 0; k < SKILL_ROWS; k++) {
                const int sk = SKILL_ROW[k];
                char c[20];
                if (sk == prog::IRON) {   // a one-time unlock, not a level ladder
                    if (prog::atMaxLevel(gProg, sk)) snprintf(lb[k * 2], sizeof lb[0], "UNLOCKED");
                    else { fmtNum(prog::upgradeCostAt(gProg, sk), c, sizeof c); snprintf(lb[k * 2], sizeof lb[0], "UNLOCK %s", c); }
                }
                else if (prog::atMaxLevel(gProg, sk)) snprintf(lb[k * 2], sizeof lb[0], "MAX LEVEL");
                else { fmtNum(prog::upgradeCostAt(gProg, sk), c, sizeof c); snprintf(lb[k * 2], sizeof lb[0], "UPGRADE %s", c); }
                if (prog::maxRebirth(sk) == 0) snprintf(lb[k * 2 + 1], sizeof lb[0], "NO REBIRTH");
                else if (prog::atMaxRebirth(gProg, sk)) snprintf(lb[k * 2 + 1], sizeof lb[0], "MAX REBIRTH");
                else { fmtNum(prog::DEF[sk].rebirthCost, c, sizeof c); snprintf(lb[k * 2 + 1], sizeof lb[0], "REBIRTH %s", c); }
                int by = L.rowY[k] + (L.rowH - L.bh) / 2;
                add(ids[sk][0], 0, L.bx[0], by, L.bw, L.bh, lb[k * 2], nullptr, nullptr, 0, 1, 1 | 4 | (prog::canUpgrade(gProg, sk) ? 0 : 16), 0);
                if (ids[sk][1]) add(ids[sk][1], 0, L.bx[1], by, L.bw, L.bh, lb[k * 2 + 1], nullptr, nullptr, 0, 1, 1 | 4 | (prog::canRebirth(gProg, sk) ? 0 : 16), 0);
                else add(-1, 0, L.bx[1], by, L.bw, L.bh, lb[k * 2 + 1], nullptr, nullptr, 0, 1, 1 | 4 | 16, 0);   // disabled placeholder
            }
            add(B_BACK, 0, uvzWorldWidth / 2 - 80, footY, 160, 30, "BACK", nullptr, nullptr, 0, 1, 1 | 4, 0);
        } break;
        default: break;
    }
}
static bool inRect(float x, float y, int rx, int ry, int rw, int rh, int pad = 0) {
    return x >= rx - pad && x <= rx + rw + pad && y >= ry - pad && y <= ry + rh + pad;
}
static void setSlider(const Btn& b, float x) {
    float t = clampValue((x - b.x) / (float)b.w, 0, 1);
    *b.val = b.vmin + (b.vmax - b.vmin) * t;
    aMusic = cfg.music; aSfx = cfg.sfx;
}
static void startAudio() {
    if (!audioStarted && gAud) { SDL_PauseAudioDevice(gAud, 0); audioStarted = true; aMode = 1; }
}
static void enterMenu() {
    startAudio();
    gState = MAIN_MENU; flashT = 0.5f; menuT = 0; sfx(7);
}
static void activate(int id) {
    sfx(4);
    switch (id) {
        case B_PLAY: if (trans < 0) trans = 0; break;   // ignore repeat presses mid-sequence
        case B_CONTROLS: openSub(CONTROLS); break;
        case B_SETTINGS: openSub(SETTINGS); break;
        case B_HOW: openSub(HOW_TO_PLAY); break;
        case B_CREDITS: openSub(CREDITS); break;
        case B_EDIT_LAYOUT: openSub(LAYOUT_EDIT); break;
        case B_SKILLS: openSub(SKILLS); break;
        case B_UP_RUN: case B_UP_SWING: case B_UP_JUMP: case B_UP_AIR: case B_UP_WEB: case B_UP_IRON: {
            const int sk = id == B_UP_RUN ? prog::RUN : (id == B_UP_SWING ? prog::SWING : (id == B_UP_JUMP ? prog::JUMP : (id == B_UP_AIR ? prog::AIR : (id == B_UP_WEB ? prog::WEB : prog::IRON))));
            if (prog::upgrade(gProg, sk)) { saveProg(); sfx(3); gNote[0] = 0; if (sk == prog::IRON) setNote("IRON ARMS UNLOCKED"); }
            else setNote(prog::atMaxLevel(gProg, sk) ? (sk == prog::IRON ? "ALREADY UNLOCKED" : "ALREADY MAX LEVEL") : "NOT ENOUGH COINS");
        } break;
        case B_RB_RUN: case B_RB_SWING: {
            const int sk = id == B_RB_RUN ? prog::RUN : prog::SWING;
            if (prog::doRebirth(gProg, sk)) { saveProg(); sfx(7); setNote("REBIRTH COMPLETE"); }
            else if (prog::atMaxRebirth(gProg, sk)) setNote("MAX REBIRTH");
            else if (!prog::atMaxLevel(gProg, sk)) setNote("REACH MAX LEVEL FIRST");
            else setNote("NOT ENOUGH COINS");
        } break;
        case B_GRAPHICS: openSub(GRAPHICS); break;
        case B_GFX_RT: gGfx.rt = !gGfx.rt; gfxChanged(); break;
        case B_GFX_API: gGfx.api = (gGfx.api + 1) % gfxcfg::API_N; gfxChanged(); break;
        case B_GFX_QUALITY: gGfx.quality = (gGfx.quality + 1) % gfxcfg::Q_N; gfxChanged(); break;
        case B_GFX_SHADOWS: gGfx.shadows = !gGfx.shadows; gfxChanged(); break;
        case B_GFX_AO: gGfx.ao = !gGfx.ao; gfxChanged(); break;
        case B_GFX_REFL: gGfx.reflections = !gGfx.reflections; gfxChanged(); break;
        case B_GFX_PERF: gGfx.perf = (gGfx.perf + 1) % gfxcfg::PERF_N; gfxChanged(); break;
        case B_GFX_RESET: gGfx = gfxcfg::defaults(); gfxChanged(); break;
        case B_BACK: case B_DONE: goBack(); break;
        case B_RESUME: gState = PLAYING; break;
        case B_RESTART: case B_TRY: startRun(); fadeIn = 0.25f; break;
        case B_MENU: startRun(true); gState = MAIN_MENU; navStack.clear(); trans = -1; menuT = 0; aMode = 1; break;
        case B_SHAKE: cfg.shake = !cfg.shake; saveCfg(); break;
        case B_REDUCED: cfg.reduced = !cfg.reduced; saveCfg(); break;
        case B_TARGET_HINTS: cfg.targetHints = !cfg.targetHints; saveCfg(); break;
        case B_SHOW_FPS: cfg.showFps = !cfg.showFps; saveCfg(); break;
        case B_FPS_CAP: cfg.fpsIdx = (clampInt(cfg.fpsIdx, 0, FPS_CAP_N - 1) + 1) % FPS_CAP_N; saveCfg(); applyFramePacing(); break;
        case B_FULL: setFullscreen(!cfg.full); break;
        case B_TAB_KEYS: ctlTab = 0; gFocus = -1; gRebind = -1; break;
        case B_TAB_TOUCH: ctlTab = 1; gFocus = -1; gRebind = -1; break;
        case B_LEFTY:
            ctl.lefty = !ctl.lefty;
            for (int i = 0; i < 3; i++) if (ctl.px[i] >= 0) ctl.px[i] = 1.0f - ctl.px[i];
            saveControls();
            break;
        case B_RESET_LAYOUT:
            for (int i = 0; i < 3; i++) ctl.px[i] = ctl.py[i] = -1.0f;
            ctl.scale = 1.0f; ctl.alpha = 0.7f;
            saveControls(); setNote("LAYOUT RESET");
            break;
        case B_RESET_TAB:
            if (ctlTab == 0) ctl.resetKeys();
            else { ctl.resetTouch(); cfg.sens = 1.0f; saveCfg(); }
            saveControls(); setNote("RESET TO DEFAULTS");
            break;
        default: break;
    }
}
static void pressBtn(const Btn& b) {
    if (b.kind == 3) { gRebind = b.act; gNote[0] = 0; sfx(4); return; }
    if (b.kind == 1) return;
    activate(b.id);
}
static void assignKey(int a, SDL_Scancode sc) {
    gNote[0] = 0;
    for (int j = 0; j < A_N; j++) if (j != a && ctl.key[j] == sc) {
        ctl.key[j] = ctl.key[a];
        char b[48]; snprintf(b, sizeof b, "SWAPPED WITH %s", ACT_LABEL[j]); setNote(b);
    }
    ctl.key[a] = sc;
    saveControls(); sfx(3);
}
static void saveAll() { saveCfg(); saveControls(); }
static void releaseAll() {
    for (auto& t : tch) t = Touch();
    swingHeld = false; slideEdge = false; slideHeld = false; diveHeld = false; zipEdge = false; steer = 0;
    gIronUpEdge = gIronFwdEdge = gIronHeld = gIronKeyDown = gIronKeyUsed = false;
}
// True while a finger (or the Iron Arms key) is holding the button. Only a visible, ready button can be held.
static bool ironHeldNow() {
    if (!ironButtonShown()) return false;
    for (auto& t : tch) if (t.on && t.role == R_IRON) return true;
    return gIronKeyDown;
}
static void toInternal(float nx, float ny, float& x, float& y) {
    x = (nx * uvzOutputWidth - uvzOffsetX) / uvzScaleX; y = (ny * uvzOutputHeight - uvzOffsetY) / uvzScaleY;
}
static void fingerDown(const SDL_TouchFingerEvent& e) {
    startAudio();
    if (portrait) return;
    if (gState == TITLE) { enterMenu(); return; }
    if (gRebind >= 0) gRebind = -1;
    Touch* t = nullptr;
    for (auto& q : tch) if (!q.on) { t = &q; break; }
    if (!t) return;
    t->on = true; t->id = e.fingerId; toInternal(e.x, e.y, t->x, t->y); t->sx = t->x; t->role = R_NONE;
    if (gState == PLAYING) {
        float x[3], y[3], r[3], ix = 0, iy = 0, ir = 0;
        for (int i = 0; i < 3; i++) ctlPos(i, x[i], y[i], r[i]);
        ironBtnPos(ix, iy, ir);
        if (inRect(t->x, t->y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 6)) t->role = R_PAUSE;
        else if (hypotf(t->x - x[0], t->y - y[0]) <= r[0] * 1.2f) t->role = R_SWING;
        else if (hypotf(t->x - x[1], t->y - y[1]) <= r[1] * 1.25f) { t->role = R_JUMP; jumpEdge = true; }
        else if (hypotf(t->x - x[2], t->y - y[2]) <= r[2] * 1.25f) {
            // Iron Arms held + SLIDE = forward launch. The slide itself is skipped (and this touch is not a held slide, so it cannot start a dive).
            if (ironHeldNow()) gIronFwdEdge = true;
            else { t->role = R_SLIDE; slideEdge = true; }
        }
        else if (ironButtonShown() && hypotf(t->x - ix, t->y - iy) <= ir * 1.3f) t->role = R_IRON;   // checked before the steer zone it sits in
        else if (inSteerZone(t->x)) t->role = R_STEER;
    } else {
        if (gState == LAYOUT_EDIT) {
            for (int i = 0; i < 3; i++) {
                float x, y, r; ctlPos(i, x, y, r);
                if (hypotf(t->x - x, t->y - y) <= r * 1.15f) { t->role = R_DRAG; t->btn = i; t->ox = x - t->x; t->oy = y - t->y; return; }
            }
        }
        for (size_t i = 0; i < btns.size(); i++) {
            const Btn& b = btns[i];
            if (inRect(t->x, t->y, b.x, b.y, b.w, b.h, gState == CREDITS ? 18 : 4)) {   // credits BACK gets a generous extra margin
                t->btn = (int)i; t->role = b.kind == 1 ? R_SLIDER : R_UI; gFocus = (int)i;
                if (b.kind == 1) setSlider(b, t->x);
                break;
            }
        }
    }
}
static void fingerMove(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_SLIDER && t.btn >= 0 && t.btn < (int)btns.size()) setSlider(btns[t.btn], t.x);
        if (t.role == R_DRAG) { ctl.px[t.btn] = clampValue((t.x + t.ox) / uvzWorldWidth, 0, 1); ctl.py[t.btn] = clampValue((t.y + t.oy) / uvzWorldHeight, 0, 1); }
    }
}
static void fingerUp(const SDL_TouchFingerEvent& e) {
    for (auto& t : tch) if (t.on && t.id == e.fingerId) {
        toInternal(e.x, e.y, t.x, t.y);
        if (t.role == R_JUMP) jumpRel = true;
        else if (t.role == R_PAUSE) { if (inRect(t.x, t.y, pauseBtn.x, pauseBtn.y, pauseBtn.w, pauseBtn.h, 10) && gState == PLAYING) { gState = PAUSED; sfx(4); } }
        else if (t.role == R_IRON) {   // a tap (release on the button, no SLIDE pressed while held) = upward launch
            float ix, iy, ir; ironBtnPos(ix, iy, ir);
            if (ironButtonShown() && hypotf(t.x - ix, t.y - iy) <= ir * 2.0f) gIronUpEdge = true;
        }
        else if (t.role == R_UI) {
            if (t.btn >= 0 && t.btn < (int)btns.size()) {
                Btn b = btns[t.btn];
                if (inRect(t.x, t.y, b.x, b.y, b.w, b.h, 6)) { t = Touch(); pressBtn(b); continue; }
            }
        }
        else if (t.role == R_SLIDER || t.role == R_DRAG) saveAll();
        t = Touch();
    }
}
static void pollHeld() {
    swingHeld = false; steer = 0; slideHeld = false; diveHeld = false;
    for (auto& t : tch) if (t.on) {
        if (t.role == R_SWING) swingHeld = true;
        if (t.role == R_SLIDE) slideHeld = true;
        if (t.role == R_STEER) steer = clampValue((t.x - t.sx) / 50.0f, -1, 1);
    }
    gIronHeld = ironHeldNow();
    const Uint8* ks = SDL_GetKeyboardState(nullptr);
    if (ks[ctl.key[A_SWING]]) swingHeld = true;
    if (ks[ctl.key[A_SLIDE]]) slideHeld = true;
    if (ks[SDL_SCANCODE_X]) diveHeld = true;
    float kst = (ks[ctl.key[A_RIGHT]] ? 1.0f : 0.0f) - (ks[ctl.key[A_LEFT]] ? 1.0f : 0.0f);
    if (kst != 0) steer = kst;
}

static void mouseHover(int mx, int my) {
    if (gState == PLAYING || gState == TITLE || portrait) return;
    int ww = 1, wh = 1; SDL_GetWindowSize(uvzWindow, &ww, &wh);
    float x, y; toInternal((float)mx / std::max(1, ww), (float)my / std::max(1, wh), x, y);
    int f = -1;
    for (size_t i = 0; i < btns.size(); i++) if (inRect(x, y, btns[i].x, btns[i].y, btns[i].w, btns[i].h)) { f = (int)i; break; }
    gFocus = f;
}
static void menuKey(SDL_Scancode sc) {
    int n = (int)btns.size();
    if (n == 0) return;
    if (gState == GAME_OVER && (sc == SDL_SCANCODE_R || ((sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_KP_ENTER) && gFocus < 0))) { activate(B_TRY); return; }
    if (sc == SDL_SCANCODE_UP || sc == SDL_SCANCODE_DOWN) {
        int d = sc == SDL_SCANCODE_DOWN ? 1 : -1;
        gFocus = gFocus < 0 ? (d > 0 ? 0 : n - 1) : (gFocus + d + n) % n;
        sfx(6);
    } else if ((sc == SDL_SCANCODE_LEFT || sc == SDL_SCANCODE_RIGHT) && gFocus >= 0 && btns[gFocus].kind == 1) {
        const Btn& b = btns[gFocus];
        *b.val = clampValue(*b.val + (sc == SDL_SCANCODE_RIGHT ? 1 : -1) * (b.vmax - b.vmin) * 0.05f, b.vmin, b.vmax);
        aMusic = cfg.music; aSfx = cfg.sfx; saveAll();
    } else if (sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_KP_ENTER || sc == SDL_SCANCODE_SPACE) {
        if (gFocus < 0) gFocus = 0;
        else pressBtn(Btn(btns[gFocus]));
    }
}

static void drawHalo(int cx, int cy) {
    for (int i = 0; i < 3; i++) drawDisc(cx, cy, 34 - i * 8, 0x6A78FF, 9);
}
// Linear RGB blend. Channels are widened to *signed* ints before subtracting: the original
// subtracted two unsigned values, so every channel that got darker (b < a) wrapped to ~4e9 and the
// float->int cast overflowed (undefined behaviour). That corrupted the sky, skyline and street
// colours for most of the day cycle (garish bands, black areas, flicker that differed per CPU).
static u32 blendRgb(u32 a, u32 b, float t) {
    t = clampValue(t, 0.0f, 1.0f);
    const int ar = (int)((a >> 16) & 255), ag = (int)((a >> 8) & 255), ab = (int)(a & 255);
    const int br = (int)((b >> 16) & 255), bg = (int)((b >> 8) & 255), bb = (int)(b & 255);
    const int r = clampInt(ar + (int)lroundf((float)(br - ar) * t), 0, 255);
    const int g = clampInt(ag + (int)lroundf((float)(bg - ag) * t), 0, 255);
    const int bl = clampInt(ab + (int)lroundf((float)(bb - ab) * t), 0, 255);
    return (u32)((r << 16) | (g << 8) | bl);
}
static float dayPhase(double time) {
    float p = fmodf((float)time / 180.0f, 1.0f);
    return p < 0.0f ? p + 1.0f : p;
}
static float daylightAmount(double time) {
    return clampValue(0.5f + 0.5f * cosf((dayPhase(time) - 0.35f) * 2.0f * pi), 0.0f, 1.0f);
}
// ======================================================================================
//  Sky & skyline: original procedural pixel art.
//   * gSkyTime is the clock used for ALL lighting. The menu pins it to clear midday so the
//     background is stable; a run starts at midday and drifts through sunset to night.
//   * The sky is one dithered gradient texture that is rebuilt whenever the world size or
//     the (quantised) time changes, so it always covers the whole viewport with no seams.
//   * The skyline is three pre-rendered layers (far haze / mid / near). Each strip is built so
//     its left and right edges meet (buildings wrap), so parallax scrolling loops without gaps.
// ======================================================================================
static const double MENU_SKY_TIME = 0.32 * 180.0;    // fixed clear midday for the menu
static const double RUN_SKY_START = 0.32 * 180.0;    // runs begin in clear midday daylight
static float sunsetAmount(double t) { const float d = (dayPhase(t) - 0.60f) / 0.11f; return expf(-d * d); }

struct DayPalette { u32 top, mid, horizon; };
static DayPalette dayPalette(double time) {
    static const float stops[] = {0.0f, 0.12f, 0.26f, 0.44f, 0.58f, 0.68f, 0.80f, 1.0f};
    static const DayPalette colors[] = {
        {0x0B1226, 0x1B2542, 0x3A3F63},   // night
        {0x3B4A7A, 0xC27A86, 0xF4B27A},   // dawn
        {0x4A98C8, 0x89CDE8, 0xDDF1EB},   // day
        {0x4F93C9, 0x8ECDE9, 0xDCEFEA},   // afternoon (still a normal blue day sky)
        {0x5B5A9A, 0xEE9A66, 0xFFCF7A},   // golden hour
        {0x2D2F66, 0xA9567A, 0xF2865E},   // dusk
        {0x0D1428, 0x1D2941, 0x41485C},   // night falls
        {0x0B1226, 0x1B2542, 0x3A3F63}
    };
    const float p = dayPhase(time);
    int i = 0;
    while (i < 6 && p > stops[i + 1]) ++i;
    float u = (p - stops[i]) / (stops[i + 1] - stops[i]);
    u = u * u * (3.0f - 2.0f * u);
    return {blendRgb(colors[i].top, colors[i + 1].top, u),
            blendRgb(colors[i].mid, colors[i + 1].mid, u),
            blendRgb(colors[i].horizon, colors[i + 1].horizon, u)};
}

// ---- sky gradient texture --------------------------------------------------------------
static SDL_Texture* gSkyTex = nullptr;
static int gSkyW = 0, gSkyH = 0; static long gSkyKey = -1;
static void rebuildSky(const DayPalette& pal) {
    static const int bayer[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
    static std::vector<u32> px;                      // reused between rebuilds (this runs several times a second)
    px.resize((size_t)gSkyW * gSkyH);
    const float horizon = std::max(1.0f, gSkyH * 0.66f);
    for (int y = 0; y < gSkyH; y++) {
        const float t = clampValue((y + 0.5f) / horizon, 0.0f, 1.0f);
        const u32 c = t < 0.6f ? blendRgb(pal.top, pal.mid, t / 0.6f) : blendRgb(pal.mid, pal.horizon, (t - 0.6f) / 0.4f);
        // exact colour of this row, quantised to 32 levels per channel with an ordered dither (pixel-art banding)
        const float fr = (float)((c >> 16) & 255), fg = (float)((c >> 8) & 255), fb = (float)(c & 255);
        // the dither pattern repeats every 4 columns, so a row only has 4 distinct pixels: compute them once, then tile
        u32 pat[4];
        for (int k = 0; k < 4; k++) {
            const float o = (bayer[(y & 3) * 4 + k] - 7.5f) * 0.55f;
            const int r = clampInt(((int)(fr + o + 4.0f) / 8) * 8, 0, 255), g = clampInt(((int)(fg + o + 4.0f) / 8) * 8, 0, 255), b = clampInt(((int)(fb + o + 4.0f) / 8) * 8, 0, 255);
            pat[k] = 0xFF000000u | ((u32)r << 16) | ((u32)g << 8) | (u32)b;
        }
        u32* row = &px[(size_t)y * gSkyW];
        for (int x = 0; x < gSkyW; x++) row[x] = pat[x & 3];
    }
    SDL_UpdateTexture(gSkyTex, nullptr, px.data(), gSkyW * 4);
}
static void ensureSkyTexture(double t) {
    if (!gSkyTex || gSkyW != uvzBaseW || gSkyH != uvzBaseH) {       // first use, or the window was resized (NOT per zoom frame)
        if (gSkyTex) SDL_DestroyTexture(gSkyTex);
        gSkyW = std::max(1, uvzBaseW); gSkyH = std::max(1, uvzBaseH);
        gSkyTex = SDL_CreateTexture(uvzRenderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, gSkyW, gSkyH);
        gSkyKey = -1;
    }
    const long key = (long)floor(t * 4.0);            // palette changes slowly: refresh 4x per second at most
    if (key != gSkyKey && gSkyTex) { gSkyKey = key; rebuildSky(dayPalette(t)); }
}

// ---- skyline + cloud art ---------------------------------------------------------------
static const int SKY_PW = 1024, SKY_IH = 300;        // strip period (loops) and strip height
struct SkyLayer { SDL_Texture* body = nullptr; SDL_Texture* lights = nullptr; };
static SkyLayer gSkyLayer[3];
static SDL_Texture* gCloudTex;   // ONE atlas holding the 4 cloud variants side by side (120x30 cells): all clouds share a texture, so they leave as one batch
static const int CLOUD_W = 120, CLOUD_H = 30;
static bool gSkyBuilt = false;

struct WrapImg {   // draws wrap around the strip's edges so the strip tiles seamlessly
    Img& im;
    void set(int x, int y, u32 c) { im.set(positiveModulo(x, im.w), y, c); }
    void fill(int x, int y, int w, int h, u32 c) { for (int yy = y; yy < y + h; yy++) for (int xx = x; xx < x + w; xx++) set(xx, yy, c); }
};
static void skyTower(WrapImg& B, WrapImg& L, Rng& r, int layer, int x, int w, int h, int kind) {
    const int by = SKY_IH, top = by - h;
    const bool detail = layer > 0;
    const u32 face = layer == 0 ? 0xFFFFFFFFu : (layer == 1 ? 0xFFCBCFDFu : 0xFFD6D8E6u);
    const u32 shade = layer == 0 ? face : 0xFF9EA3BCu, line = layer == 0 ? face : 0xFF3C405Au, hi = 0xFFF2F2FAu, win = 0xFF566080u;
    auto block = [&](int bx, int bt, int bw) {
        B.fill(bx, bt, bw, by - bt, face);
        if (!detail) return;
        B.fill(bx + bw - 3, bt, 3, by - bt, shade);
        B.fill(bx, bt, 1, by - bt, line); B.fill(bx + bw - 1, bt, 1, by - bt, line);
        B.fill(bx, bt, bw, 1, line); B.fill(bx + 1, bt + 1, bw - 4, 1, hi);
    };
    auto windows = [&](int wx, int wy, int ww, int lim) {
        if (!detail) return;
        const int cw = layer == 1 ? 2 : 3, ch = layer == 1 ? 3 : 4, sx = cw + 2, sy = ch + 3;
        for (int yy = wy; yy + ch < lim && yy + ch < by - 8; yy += sy)
            for (int xx = wx; xx + cw <= wx + ww; xx += sx) {
                B.fill(xx, yy, cw, ch, win);
                if (r.f() < 0.36f) L.fill(xx, yy, cw, ch, r.f() < 0.82f ? 0xFFFFD27Au : 0xFFBFE8FFu);
            }
    };
    auto pole = [&](int px, int ptop, int len) { B.fill(px, ptop, 1, len, line); if (layer == 2 && (r.f() < 0.6f)) L.fill(px - 1, ptop - 1, 3, 2, 0xFFFF4040u); };
    const int cx = x + w / 2;
    switch (kind) {
        case 0: {   // slab tower with roof machinery and mast
            block(x, top, w); windows(x + 3, top + 5, w - 8, by);
            block(x + w / 4, top - 6, std::max(6, w / 3)); pole(cx, top - 6 - 12 - r.range(0, 10), 12 + 10);
        } break;
        case 1: {   // stepped setback tower with crown and spire
            block(x, top + h * 45 / 100, w); windows(x + 3, top + h * 45 / 100 + 5, w - 8, by);
            block(x + w * 15 / 100, top + h * 20 / 100, w * 70 / 100); windows(x + w * 15 / 100 + 3, top + h * 20 / 100 + 5, w * 70 / 100 - 8, top + h * 45 / 100);
            block(x + w * 30 / 100, top, w * 40 / 100); windows(x + w * 30 / 100 + 3, top + 5, w * 40 / 100 - 8, top + h * 20 / 100);
            block(x + w * 42 / 100, top - 10, std::max(5, w * 16 / 100)); pole(cx, top - 38, 28);
        } break;
        case 2: {   // slim needle with tapered crown
            const int wn = std::max(10, std::min(w, 20)), nx = x + (w - wn) / 2;
            block(x, top + h * 62 / 100, w); windows(x + 3, top + h * 62 / 100 + 5, w - 8, by);
            block(nx, top + 12, wn); windows(nx + 3, top + 16, wn - 7, top + h * 62 / 100);
            for (int i = 0; i < 12; i++) { const int tw = std::max(2, wn * (12 - i) / 12); B.fill(cx - tw / 2, top + i, tw, 1, i == 0 ? line : face); if (detail) { B.fill(cx - tw / 2, top + i, 1, 1, line); B.fill(cx + tw / 2 - 1, top + i, 1, 1, line); } }
            pole(cx, top - 26, 26);
        } break;
        case 3: {   // glass office with a slanted roof
            block(x, top, w); windows(x + 3, top + 12, w - 8, by);
            for (int xx = 0; xx < w; xx++) { const int cut = (w - xx) * 38 / 100 + 1; for (int yy = top - 8; yy < top + cut; yy++) B.set(x + xx, yy, 0); }
            if (detail) for (int xx = 0; xx < w; xx++) B.set(x + xx, top + (w - xx) * 38 / 100 + 1, line);
            pole(x + 4, top + (w - 4) * 38 / 100 - 16, 16);
        } break;
        case 4: {   // apartment block with cornice and a wooden water tank
            block(x, top, w); windows(x + 3, top + 6, w - 8, by);
            if (detail) { B.fill(x - 1, top, w + 2, 3, line); B.fill(x - 1, top + 1, w + 2, 1, hi); }
            const int tx = x + 4 + r.range(0, std::max(1, w - 18)), tc = layer == 0 ? face : 0xFFB89A80u;
            B.fill(tx + 1, top - 5, 2, 5, line); B.fill(tx + 8, top - 5, 2, 5, line);
            B.fill(tx, top - 14, 11, 9, tc); if (detail) { B.fill(tx, top - 14, 11, 1, line); B.fill(tx + 9, top - 14, 2, 9, shade); }
            for (int i = 0; i < 4; i++) B.fill(tx + 4 - i, top - 18 + i, 3 + 2 * i, 1, tc);   // conical roof, widest at the bottom
            if (detail) B.fill(tx + 5, top - 19, 1, 1, line);
        } break;
        case 6: {   // Chrysler-style: setback body, arched steel crown and needle
            block(x, top + h * 40 / 100, w); windows(x + 3, top + h * 40 / 100 + 5, w - 8, by);
            block(x + w / 5, top + h * 22 / 100, w * 3 / 5); windows(x + w / 5 + 3, top + h * 22 / 100 + 5, w * 3 / 5 - 8, top + h * 40 / 100);
            for (int i = 0; i < h * 22 / 100; i++) { const float t = (float)i / std::max(1, h * 22 / 100); const int tw = std::max(2, (int)(w * 0.5f * sqrtf(std::max(0.0f, 1.0f - t * t)))); B.fill(cx - tw / 2, top + h * 22 / 100 - i, tw, 1, face); if (detail && i % 5 == 0) B.fill(cx - tw / 2, top + h * 22 / 100 - i, tw, 1, line); }
            pole(cx, top - 4, 22);
        } break;
        case 7: {   // One-WTC-style: tapering prism with a long antenna
            block(x, top + h * 30 / 100, w);
            for (int i = 0; i < h * 30 / 100; i++) { const int tw = std::max(4, w - (w * 55 / 100) * i / std::max(1, h * 30 / 100)); B.fill(cx - tw / 2, top + h * 30 / 100 - i, tw, 1, face); }
            windows(x + 3, top + h * 30 / 100 + 5, w - 8, by);
            pole(cx, top - 14, 30);
        } break;
        default: {  // twin crown with a sky bridge
            const int tw = std::max(8, w * 38 / 100);
            block(x, top + h * 35 / 100, w);
            block(x, top, tw); block(x + w - tw, top + 7, tw);
            B.fill(x + tw, top + h * 28 / 100, w - 2 * tw, 4, face); if (detail) B.fill(x + tw, top + h * 28 / 100, w - 2 * tw, 1, line);
            windows(x + 3, top + 5, tw - 7, by); windows(x + w - tw + 3, top + 12, tw - 7, by); windows(x + 3, top + h * 35 / 100 + 5, w - 8, by);
            pole(x + tw / 2, top - 16, 16);
        } break;
    }
}
static void makeSkyline(int layer, Img& body, Img& lights) {
    WrapImg B{body}, L{lights};
    Rng r(4242u + layer * 977u);
    static const int wMin[3] = {20, 26, 32}, wMax[3] = {42, 50, 66}, hMin[3] = {80, 90, 120}, hMax[3] = {200, 235, 285};   // denser, taller skyline
    int x = 0;
    for (int i = 0; x < SKY_PW; i++) {
        int w = r.range(wMin[layer], wMax[layer]);
        if (x + w > SKY_PW - wMin[layer]) w = SKY_PW - x;                // last building closes the loop exactly
        const bool low = (i % 4) == 3;                                   // every third building is a low filler block
        const int h = low ? r.range(38, 78) : r.range(hMin[layer], hMax[layer]);
        const int kind = low ? (r.f() < 0.5f ? 0 : 4) : r.range(0, 7);
        skyTower(B, L, r, layer, x, w, h, kind);
        x += w;
    }
}
static void buildSky() {
    if (gSkyBuilt) return;
    gSkyBuilt = true;
    for (int l = 0; l < 3; l++) {
        Img body(SKY_PW, SKY_IH), lights(SKY_PW, SKY_IH);
        makeSkyline(l, body, lights);
        gSkyLayer[l].body = createTexture(body);
        gSkyLayer[l].lights = l == 0 ? nullptr : createTexture(lights);
    }
    Img cloudAtlas(CLOUD_W * 4, CLOUD_H);
    for (int v = 0; v < 4; v++) {   // flat-bottomed pixel clouds, 3 tones (lit top / body / shaded belly), tinted per frame
        Img im(CLOUD_W, CLOUD_H); Rng r(88u + v * 13u);
        const int n = 4 + v % 2;
        for (int k = 0; k < n; k++) {
            const int ccx = 18 + k * (84 / n) + r.range(-4, 4), rx = r.range(12, 24), ry = r.range(7, 13), cyy = 22 - ry + r.range(0, 2);
            for (int y = 0; y < 25; y++) for (int x = 0; x < 120; x++) {
                const float dx = (float)(x - ccx) / rx, dy = (float)(y - cyy) / ry;
                if (dx * dx + dy * dy <= 1.0f) im.set(x, y, 0xFFFFFFFFu);
            }
        }
        for (int y = 0; y < 30; y++) for (int x = 0; x < 120; x++) {
            if (!im.get(x, y)) continue;
            int under = 0; while (under < 8 && im.get(x, y - 1 - under)) under++;     // depth below the cloud's upper edge
            const bool bottom = !im.get(x, y + 3);
            im.set(x, y, bottom ? 0xFFA9A5C4u : (under >= 5 ? 0xFFDAD6E6u : 0xFFFFFFFFu));
        }
        for (int y = 0; y < CLOUD_H; y++) for (int x = 0; x < CLOUD_W; x++) cloudAtlas.set(v * CLOUD_W + x, y, im.get(x, y));
    }
    if (gCloudTex) { SDL_DestroyTexture(gCloudTex); gCloudTex = nullptr; }
    gCloudTex = createTexture(cloudAtlas);
}
// ---- Living city (decorative only: no collision, no RNG state, no per-object storage) ----
static float lifeFrac(float v) { return v - floorf(v); }
static void drawSkyLife(float cx, double t) {
    const int W = uvzWorldWidth, H = uvzWorldHeight;
    const float night = 1.0f - daylightAmount(t), tm = (float)gTime;
    // news helicopter crossing the skyline about every 70 s (spotlight at night)
    {
        const float u = lifeFrac(tm / 70.0f + 0.15f);
        const float sx = -50.0f + u * (W + 100.0f) - cx * 0.02f, sy = H * 0.15f + sinf(tm * 0.8f) * 3.0f;
        if (sx > -40 && sx < W + 40) {
            const int x = (int)sx, y = (int)sy;
            if (night > 0.3f) for (int i = 1; i <= 14; i++) drawFilledRect(x + 2 - i / 2, y + 6 + i * 4, 4 + i, 4, 0xFFF4C8, (int)(night * 34));   // search-light cone
            const int m = 255 - (int)(night * 110.0f);
            sprDraw(gHeliSpr[((int)(tm * 30.0f)) & 1], x - 19, y - 3, 255, m, m, m);   // body + rotor blur (two frames)
            if (((int)(tm * 1.25f)) % 2 == 0) drawFilledRect(x - 19, y - 3, 2, 2, 0xFF4A3C);     // blinking tail light
        }
    }
    // pigeon flock in daylight about every 26 s
    if (night < 0.7f) {
        const int n = cfg.reduced ? 4 : 7;
        const float u = lifeFrac(tm / 26.0f);
        for (int i = 0; i < n; i++) {
            const float row = (float)((i + 1) / 2) * (i & 1 ? 1.0f : -1.0f);
            const float sx = W + 20.0f - u * (W + 140.0f) + fabsf(row) * 12.0f - cx * 0.03f;
            const float sy = H * 0.30f + row * 7.0f + sinf(tm * 1.7f + i) * 3.0f;
            if (sx < -10 || sx > W + 10) continue;
            sprDraw(gBirdSpr[sinf(tm * 11.0f + i * 1.3f) > 0 ? 1 : 0], (int)sx - 3, (int)sy - 2);
        }
    }
}
// ---- Sidewalk walkers: live stickmen built from the player's own skeleton (stkSolve) and drawn with plain lines, so a
// crowd stays cheap. Each walker's stroll is a pure function of time; npc::State layers reactions on top. ----
struct Walker { float x, dir, sp, scale, ph; u32 q; bool idle, female; };
static Walker walkerAt(int c, int k, float tm) {
    const int S = 300;
    const u32 q = hashCoordinates((u32)c, 0x57414C4Bu, (u32)k + 3u);
    Walker w; w.q = q; w.dir = (q & 1) ? 1.0f : -1.0f;
    w.female = (hashCoordinates(q, 0x47454E44u, 5u) & 1u) != 0u;            // about half and half, stable per walker
    w.idle = ((q >> 4) % 5u) == 0u;                                          // one in five just stands there
    w.sp = w.idle ? 0.0f : 30.0f + (float)((q >> 1) & 15) * 1.4f;            // ~1-1.6 m/s at 30 px/m
    w.scale = 1.0f;   // same size as the runner (the player rig is drawn at 1.0)
    const float ph = (float)((q >> 8) & 0xFFFF) / 65535.0f;
    const float u = lifeFrac(ph + w.dir * w.sp * tm / (float)S);
    w.x = (float)(c * S) + u * (float)S;
    w.ph = w.sp * tm * 2.0f * pi / (40.0f * w.scale) + (float)((q >> 20) & 63);   // stride locked to ground speed
    return w;
}
static std::unordered_map<u32, npc::State> gWalkerState;
static u32 walkerKey(int c, int k) { return (u32)(c * 8 + k) * 2654435761u; }
static float gWalkerPrevVy = 0; static bool gWalkerPrevGround = false;
static void updateWalkers(float dt) {
    const int S = 300;
    const int c0 = (int)floorf((P.x - 360.0f) / (float)S), c1 = (int)floorf((P.x + 360.0f) / (float)S);
    npc::Hero h; h.x = P.x; h.y = P.y; h.vx = P.vx; h.vy = P.vy; h.swinging = P.swinging; h.onGround = P.onGround;
    h.feetY = P.y + 26.0f; h.groundY = STREET_GROUND_Y;
    h.landedNow = P.onGround && !gWalkerPrevGround && gWalkerPrevVy > 260.0f;   // touched down hard, not just stepped onto a roof
    gWalkerPrevGround = P.onGround; gWalkerPrevVy = P.vy;
    for (int c = c0; c <= c1; c++) {
        const u32 hh = hashCoordinates((u32)c, 0x50454453u, 11u);
        const int count = 1 + (int)((hh >> 4) & 1) + (int)(((hh >> 7) & 7) < 2 ? 1 : 0);
        for (int k = 0; k < count; k++) {
            const Walker w = walkerAt(c, k, (float)gTime);
            npc::update(gWalkerState[walkerKey(c, k)], w.x, h, dt);
        }
    }
    if (gWalkerState.size() > 160) {                                      // forget walkers the player has left far behind
        for (auto it = gWalkerState.begin(); it != gWalkerState.end();) it = (it->second.startle <= 0 && fabsf(it->second.off) < 0.01f) ? gWalkerState.erase(it) : std::next(it);
    }
}
static StkPose walkerPose(const Walker& w, const npc::State& st, int k) {
    StkPose p;
    if (w.idle) {
        const float b = sinf((float)gTime * 1.6f + (float)k * 2.3f + (float)(w.q & 15));
        p = stkMakePose(F_IDLE, (float)gTime * 0.25f + (float)(w.q & 15) * 0.1f, 0, 0, 0);
        if ((w.q >> 9) & 1) { p.upF = 12 + 2 * b; p.foF = -40; p.upB = -12; p.foB = -48; }          // hands in pockets
        else if ((w.q >> 10) & 1) { p.thF = 12; p.shF = 0; p.thB = -10; p.shB = -10; p.lean = 4; }   // upright, feet together
    } else {
        const float ph = w.ph, amp = 24.0f + 3.0f * w.scale;
        p.snap = 1; p.lean = 5; p.tilt = -3 + (w.dir * 0);
        if (w.female) { p.lean = 3; }
        p.thF = amp * sinf(ph);       p.shF = p.thF - 8.0f - 34.0f * std::max(0.0f, cosf(ph));
        p.thB = amp * sinf(ph + pi);  p.shB = p.thB - 8.0f - 34.0f * std::max(0.0f, cosf(ph + pi));
        p.upF = 26.0f * sinf(ph + pi); p.foF = p.upF + 20.0f;
        p.upB = 26.0f * sinf(ph);      p.foB = p.upB + 20.0f;
        p.hipY += 0.8f * fabsf(cosf(ph));                                  // slight bob
    }
    p.tilt += -14.0f * st.look; p.lean -= 6.0f * st.look;                  // tip the head back to watch a swinger overhead
    if (st.react > 0.001f) { p = stkBlend(p, stkMakePose(F_HIT, 0, 0, 0, 0), clampValue(st.react, 0.0f, 1.0f)); p.snap = 1.0f; }   // feet stay planted; the hop offset lifts the whole body
    return p;
}
static void drawWalker(const Walker& w, const npc::State& st, int k, float cx, int ground, int a, int dim) {
    static const u32 COAT[6] = {0xB04848, 0x4C80B0, 0x5E9E58, 0xB09848, 0x8060B0, 0x9A9AA2};
    static const u32 PANTS[4] = {0x3A4458, 0x5A4C38, 0x34487A, 0x505058};
    const StkPose pose = walkerPose(w, st, k);
    float jx[J_N], jy[J_N];
    stkSolve(pose, jx, jy);
    const float wx = w.x + st.off, sx = wx - cx, fy = (float)(ground + 5) + st.hop;
    float X[J_N], Y[J_N];
    for (int i = 0; i < J_N; i++) {
        float lx = jx[i] * w.scale; if (w.dir < 0) lx = -lx;
        X[i] = sx + lx; Y[i] = fy - ((float)STK_FEET_Y - jy[i]) * w.scale;
    }
    auto tone = [&](u32 c, float m) { const int r = (int)(((c >> 16) & 255) * m * dim / 255.0f), g = (int)(((c >> 8) & 255) * m * dim / 255.0f), b = (int)((c & 255) * m * dim / 255.0f); return (u32)((r << 16) | (g << 8) | b); };
    static const u32 SKIRT[5] = {0x8E3A5E, 0x3E6E8E, 0x7A5CA8, 0xA8584A, 0x2F5E54};
    static const u32 HAIR_M[4] = {0x2A2118, 0x4A3322, 0x1C1C20, 0x6B5636};
    static const u32 HAIR_F[5] = {0x2A2118, 0x6A3E22, 0xB89848, 0x1C1C20, 0x8A3A2A};
    static const u32 SKIN[4] = {0xD8B090, 0xC49A74, 0x9A6E4C, 0xEBC9A8};
    const u32 coat = COAT[(w.q >> 24) % 6], pants = PANTS[(w.q >> 16) & 3];
    const u32 skin = tone(SKIN[(w.q >> 18) & 3], 1.0f);
    const bool fem = w.female;
    const u32 legCol = fem ? tone(SKIN[(w.q >> 18) & 3], 0.92f) : tone(pants, 1.0f);       // women: bare / tights below a skirt; men: trousers
    const u32 legBack = fem ? tone(SKIN[(w.q >> 18) & 3], 0.70f) : tone(pants, 0.75f);
    struct B { int a, b; u32 c; };
    const B bones[9] = {
        {J_HIP, J_KNB, legBack}, {J_KNB, J_FTB, legBack}, {J_NECK, J_ELB, tone(coat, 0.75f)}, {J_ELB, J_HNB, tone(coat, 0.75f)},
        {J_HIP, J_NECK, tone(coat, 1.0f)},
        {J_HIP, J_KNF, legCol}, {J_KNF, J_FTF, legCol}, {J_NECK, J_ELF, tone(coat, 1.0f)}, {J_ELF, J_HNF, tone(coat, 1.0f)}};
    const u32 rim = tone(0xE8ECFF, 1.0f);                                 // the same light outline the player has, so they read against dark storefronts
    const int ra = a * 3 / 4;
    for (const B& bn : bones) {
        drawLine(X[bn.a] - 2, Y[bn.a], X[bn.b] - 2, Y[bn.b], rim, ra); drawLine(X[bn.a] + 2, Y[bn.a], X[bn.b] + 2, Y[bn.b], rim, ra);
        drawLine(X[bn.a], Y[bn.a] - 1, X[bn.b], Y[bn.b] - 1, rim, ra); drawLine(X[bn.a], Y[bn.a] + 1, X[bn.b], Y[bn.b] + 1, rim, ra);
    }
    const int hr = std::max(2, (int)lroundf(4.95f * w.scale));   // the runner's head radius
    drawDisc((int)X[J_HEAD], (int)Y[J_HEAD], hr + 1, rim, ra);
    for (const B& bn : bones) { drawLine(X[bn.a] - 1, Y[bn.a], X[bn.b] - 1, Y[bn.b], bn.c, a); drawLine(X[bn.a], Y[bn.a], X[bn.b], Y[bn.b], bn.c, a); drawLine(X[bn.a] + 1, Y[bn.a], X[bn.b] + 1, Y[bn.b], bn.c, a); }   // 3 px limbs like the runner
    if (fem) {   // skirt: a flared trapezoid from the waist down to mid-thigh, drawn over the legs
        const u32 sk = tone(SKIRT[(w.q >> 21) % 5], 1.0f);
        const float hx = X[J_HIP], hy = Y[J_HIP];
        const float kx = (X[J_KNF] + X[J_KNB]) * 0.5f, ky = (Y[J_KNF] + Y[J_KNB]) * 0.5f;
        const float len = std::max(5.0f, (ky - hy) * 0.8f), half = 5.0f * w.scale + 1.0f;
        const int rows = (int)len;
        for (int r = 0; r <= rows; r++) {
            const float u = (float)r / (float)std::max(rows, 1), cxr = hx + (kx - hx) * u * 0.35f, hw = 1.5f + (half - 1.5f) * u;
            drawFilledRect((int)lroundf(cxr - hw), (int)lroundf(hy + r), std::max(1, (int)lroundf(hw * 2.0f)), 1, sk, a);
        }
    }
    drawDisc((int)X[J_HEAD], (int)Y[J_HEAD], hr, skin, a);
    {   // hair: men short and cropped; women longer, falling behind the shoulders (the back is away from the walk direction)
        const int hxp = (int)X[J_HEAD], hyp = (int)Y[J_HEAD];
        const float back = w.dir > 0 ? -1.0f : 1.0f;
        if (fem) {
            const u32 hc = tone(HAIR_F[(w.q >> 11) % 5], 1.0f);
            drawDisc(hxp, hyp - 1, hr, hc, a);                              // crown and fringe
            drawDisc(hxp, hyp + 1, hr - 1 > 0 ? hr - 1 : 1, skin, a);      // face on top of it
            const int tail = (int)lroundf(11.0f * w.scale);
            for (int i = 0; i < tail; i++) {
                const float sway = sinf((float)gTime * 3.0f + (float)i * 0.35f + (float)(w.q & 7)) * 0.6f * ((float)i / (float)tail);
                drawFilledRect(hxp + (int)lroundf(back * (hr * 0.9f + (float)i * 0.15f + sway)) - 1, hyp - 1 + i, 2, 1, hc, a);
            }
        } else {
            const u32 hc = tone(HAIR_M[(w.q >> 11) & 3], 1.0f);
            drawDisc(hxp, hyp - 1, hr, hc, a);                              // short cropped hair
            drawDisc(hxp, hyp + 1, hr - 1 > 0 ? hr - 1 : 1, skin, a);
        }
    }
}
static void drawCityLife(float cx, int ground) {
    const int W = uvzWorldWidth;
    const float night = 1.0f - daylightAmount(gSkyTime), tm = (float)gTime;
    const int S = 300;                                                   // each sidewalk "cell" hosts a few walkers that stroll along it
    const int c0 = (int)floorf(cx / (float)S) - 1, c1 = (int)floorf((cx + W) / (float)S) + 1;
    const int dim = 255 - (int)(night * 110.0f);                         // walkers darken at night
    for (int c = c0; c <= c1; c++) {
        const u32 h = hashCoordinates((u32)c, 0x50454453u, 11u);
        const int count = 1 + (int)((h >> 4) & 1) + (int)(((h >> 7) & 7) < 2 ? 1 : 0);
        for (int k = 0; k < count; k++) {
            const Walker w = walkerAt(c, k, tm);
            npc::State st; const auto it = gWalkerState.find(walkerKey(c, k)); if (it != gWalkerState.end()) st = it->second;
            const int sx = (int)floorf(w.x + st.off - cx);
            if (sx < -24 || sx > W + 24) continue;
            const float u = (w.x - (float)(c * S)) / (float)S;
            const float edge = std::min(u, 1.0f - u) * (float)S;                // fade near the cell ends: they step out of / into doorways
            const int a = (int)(255.0f * clampValue(edge / 24.0f, 0.0f, 1.0f));
            if (a < 8) continue;
            drawWalker(w, st, k, cx, ground, a, dim);
        }
        if (!cfg.reduced && (h % 5u) == 0u) {                                   // manhole steam plume, as in every NYC street
            const int mx = (int)floorf((float)(c * S) + 150.0f - cx);
            if (mx > -20 && mx < W + 20) {
                drawFilledRect(mx - 4, ground + 8, 8, 2, 0x2A2C32);
                for (int i = 0; i < 4; i++) {
                    const float u = lifeFrac(tm * 0.6f + (float)i * 0.25f + (float)(h & 7) * 0.1f);
                    const int sz = 3 + (int)(u * 7.0f);
                    drawFilledRect(mx - sz / 2 + (int)(sinf(tm * 1.5f + (float)i * 2.0f) * 4.0f * u), ground + 6 - (int)(u * 46.0f), sz, sz, 0xE6E8EE, (int)(95.0f * (1.0f - u)));
                }
            }
        }
    }
}
static void drawBackdrop(float cx, float cy, double t, bool streetLevel = false) {
    buildSky();
    ensureSkyTexture(t);
    const DayPalette pal = dayPalette(t);
    const float day = daylightAmount(t), night = 1.0f - day, sun = sunsetAmount(t), phase = dayPhase(t);
    const int W = uvzWorldWidth, H = uvzWorldHeight;
    SDL_Rect whole = {0, 0, W, H};
    if (gSkyTex) SDL_RenderCopy(uvzRenderer, gSkyTex, nullptr, &whole);
    else drawFilledRect(0, 0, W, H, pal.mid);
    // stars
    if (night > 0.05f) for (int i = 0; i < 80; i++) {
        const u32 h = hashCoordinates(i, 77, 3);
        const int sx = positiveModulo((int)(h % (u32)(W * 2)) - (int)(cx * 0.02f), W), sy = (int)((h >> 10) % (u32)(H * 0.55f));
        drawFilledRect(sx, sy, 1, 1, 0xFFFFFF, (int)(night * night * (((int)(t * 2 + i)) % 7 == 0 ? 90 : 220)));
    }
    const float horizonY = H * 0.62f;
    // sun with banded glow (sets around phase 0.66)
    { const float f = (phase - 0.10f) / 0.56f;
      if (f > -0.05f && f < 1.05f) {
        const float e = sinf(clampValue(f, 0.0f, 1.0f) * pi);
        const int sxp = (int)(W * (0.85f - 0.55f * clampValue(f, 0.0f, 1.0f))), syp = (int)(horizonY - e * horizonY * 0.62f - 6);
        const int a = (int)(255 * clampValue(0.25f + e * 6.0f, 0.0f, 1.0f));
        const float g = 0.35f + 0.65f * sun;
        for (int k = 4; k >= 1; k--) drawDisc(sxp, syp, 14 + k * 14, blendRgb(0xFFE7A8, 0xFF9A55, sun), (int)((10 + 14 * g) * a / 255));
        drawDisc(sxp, syp, 15, blendRgb(0xFFF3C4, 0xFFC45E, sun), a);
        drawDisc(sxp, syp, 11, 0xFFFBE6, a);
      } }
    // moon
    { const float f = (fmodf(phase + 0.5f, 1.0f) - 0.10f) / 0.56f;
      if (f > 0.0f && f < 1.0f && night > 0.2f) {
        const float e = sinf(f * pi);
        const int mx = (int)(W * (0.85f - 0.55f * f)), my = (int)(horizonY - e * horizonY * 0.70f - 6), a = (int)(235 * clampValue((night - 0.2f) * 2.0f, 0, 1));
        drawDisc(mx, my, 20, 0xAFC0FF, a / 12); drawDisc(mx, my, 10, 0xE8ECFF, a);
        drawDisc(mx - 3, my - 2, 2, 0xB9C2E6, a); drawDisc(mx + 3, my + 3, 1, 0xB9C2E6, a);
      } }
    // clouds: two depth rows, drifting; warm underlit at sunset
    { const u32 cc = blendRgb(blendRgb(0x4A5488, 0xFFFFFF, day), 0xFFB07A, sun * 0.9f);
      for (int row = 0; row < 2; row++) for (int i = 0; i < 6; i++) {
        const u32 h = hashCoordinates(i, 31 + row, 9);
        const float par = row ? 0.03f : 0.06f, speed = row ? 3.0f : 6.0f;
        const int x = positiveModulo((int)(i * (W + 240) / 6 + (h % 70) + t * speed - cx * par), W + 240) - 120;
        const int y = (int)(H * (row ? 0.10f : 0.27f)) + (int)(h >> 8) % (int)(H * 0.12f);
        if (!gCloudTex) continue;
        SDL_SetTextureColorMod(gCloudTex, (Uint8)((cc >> 16) & 255), (Uint8)((cc >> 8) & 255), (Uint8)(cc & 255));
        SDL_SetTextureAlphaMod(gCloudTex, (Uint8)(row ? 150 : 215));
        SDL_Rect sr = {(int)(h % 4) * CLOUD_W, 0, CLOUD_W, CLOUD_H}, d = {x, y, CLOUD_W, CLOUD_H};   // one atlas texture: consecutive clouds batch into one draw
        SDL_RenderCopy(uvzRenderer, gCloudTex, &sr, &d);
      } }
    // skyline layers
    const u32 lightCol = blendRgb(blendRgb(0x46508A, 0xFFFFFF, day), 0xFFC8A0, sun * 0.85f);
    const u32 haze = blendRgb(pal.horizon, pal.mid, 0.3f);
    const u32 tint[3] = { blendRgb(haze, 0x202040, 0.10f), blendRgb(blendRgb(lightCol, 0x000000, 0.28f), haze, 0.30f), blendRgb(blendRgb(lightCol, 0x000000, 0.42f), haze, 0.10f) };
    static const float hPar[3] = {0.06f, 0.15f, 0.32f}, vPar[3] = {0.02f, 0.05f, 0.10f}, base[3] = {0.80f, 0.92f, 1.04f};
    static const int groundOff[3] = {-30, -14, 2};
    static const u32 faceAlbedo[3] = {0xFFFFFF, 0xCBCFDF, 0xD6D8E6};
    const float vy = clampValue(cy + 210.0f, -400.0f, 200.0f);
    for (int l = 0; l < 3; l++) {
        int baseY = (int)floorf(H * base[l] - vy * vPar[l]);
        // In the street canyon the skyline stands on the horizon (far layers a little higher), so the gaps between the
        // facades show whole towers instead of just their tops; swinging up lets it slide away as before.
        if (streetLevel) baseY = std::min(baseY, (int)floorf(STREET_GROUND_Y - cy) + groundOff[l]);
        const int ox = positiveModulo((int)floorf(cx * hPar[l]), SKY_PW);
        const Uint8 r = (Uint8)((tint[l] >> 16) & 255), g = (Uint8)((tint[l] >> 8) & 255), b = (Uint8)(tint[l] & 255);
        SDL_SetTextureColorMod(gSkyLayer[l].body, r, g, b);
        // Two passes instead of body,lights,body,lights...: the tiles abut and never overlap, so the result is identical,
        // but each texture is now drawn in one run (2 texture switches per layer instead of 2 per tile).
        for (int x = -ox; x < W; x += SKY_PW) {
            SDL_Rect d = {x, baseY - SKY_IH, SKY_PW, SKY_IH};
            SDL_RenderCopy(uvzRenderer, gSkyLayer[l].body, nullptr, &d);
        }
        if (gSkyLayer[l].lights) {
            const int la = (int)clampValue(night * 235.0f + sun * 90.0f + day * 8.0f, 0.0f, 255.0f);
            if (la > 3) {
                SDL_SetTextureAlphaMod(gSkyLayer[l].lights, (Uint8)la);
                for (int x = -ox; x < W; x += SKY_PW) { SDL_Rect d = {x, baseY - SKY_IH, SKY_PW, SKY_IH}; SDL_RenderCopy(uvzRenderer, gSkyLayer[l].lights, nullptr, &d); }
            }
        }
        if (baseY - 2 < H) {   // solid body below the strip so nothing ever shows through at the bottom
            const u32 f = faceAlbedo[l];
            drawFilledRect(0, baseY - 2, W, H - baseY + 2, (u32)((((f >> 16) & 255) * r / 255) << 16 | (((f >> 8) & 255) * g / 255) << 8 | ((f & 255) * b / 255)));
        }
    }
    drawSkyLife(cx, t);
}

static void drawObs(const Obs& o, int sx, int sy, double t);
static void drawObsSheet(const Obs& o, int sx, int sy, double t) {   // fixed-size obstacles come from the sprite sheet; the ones that scale or scroll stay code-drawn
    int id = -1;
    switch (o.type) { case 0: id = ((int)(t * 12) & 1) ? PROP_OBS0_1 : PROP_OBS0_0; break; case 1: id = PROP_OBS1; break; case 2: id = PROP_OBS2; break; case 3: case 4: case 5: break; default: id = PROP_OBS6; break; }
    if (id < 0 || !sprDrawProp(id, sx, sy)) drawObs(o, sx, sy, t);
}
static void drawObs(const Obs& o, int sx, int sy, double t) {
    int x = sx, y = sy;
    switch (o.type) {
        case 0:
            drawFilledRect(x, y - 20, 28, 20, 0x59606E); drawFilledRect(x, y - 20, 28, 2, 0x8A93A6);
            drawDisc(x + 8, y - 11, 5, 0x1B1F28);
            { int ph = (int)(t * 12) & 1; if (ph) { drawFilledRect(x + 3, y - 12, 10, 2, 0x4A5060); drawFilledRect(x + 7, y - 16, 2, 10, 0x4A5060); } else { drawLine(x + 4, y - 15, x + 12, y - 7, 0x4A5060); drawLine(x + 12, y - 15, x + 4, y - 7, 0x4A5060); } }
            for (int i = 0; i < 3; i++) drawFilledRect(x + 17, y - 16 + i * 4, 9, 2, 0x2B303B);
            break;
        case 1:
            drawFilledRect(x + 3, y - 18, 3, 18, 0x3B2A1E); drawFilledRect(x + 24, y - 18, 3, 18, 0x3B2A1E);
            drawLine(x + 4, y - 18, x + 25, y - 2, 0x3B2A1E);
            drawFilledRect(x, y - 42, 30, 24, 0x7A5236); drawFilledRect(x, y - 36, 30, 2, 0x4A301F); drawFilledRect(x, y - 26, 30, 2, 0x4A301F);
            drawFilledRect(x + 3, y - 40, 4, 20, 0x9A6B46); drawFilledRect(x + 4, y - 46, 22, 4, 0x4A301F); drawFilledRect(x + 9, y - 50, 12, 4, 0x4A301F);
            break;
        case 2:
            drawFilledRect(x, y - 14, 24, 14, 0xC9C3B5);
            for (int i = 0; i < 3; i++) drawFilledRect(x + 2 + i * 8, y - 12, 4, 10, 0xE0A81E);
            drawFilledRect(x, y - 14, 24, 2, 0xE8E3D5);
            break;
        case 3: {
            int h = (int)o.h;
            drawFilledRect(x, y - h, 2, h, 0x2A2F3F); drawFilledRect(x - 5, y - h + 20, 12, 1, 0x2A2F3F); drawFilledRect(x - 3, y - h + 30, 8, 1, 0x2A2F3F);
            if (((int)(t * 1.5) + (int)o.x) & 1) { drawDisc(x, y - h - 2, 4, 0xFF2A2A, 60); drawFilledRect(x - 1, y - h - 3, 4, 4, 0xFF4040); }
        } break;
        case 4: {
            int h = (int)o.h, jw = (int)o.w;
            drawFilledRect(x, y - h, 6, h, 0xC9A227);
            for (int i = 0; i < h; i += 10) { drawFilledRect(x, y - h + i, 6, 1, 0x6B5611); drawLine(x, y - h + i, x + 5, y - h + i + 9, 0x6B5611); }
            drawFilledRect(x - 30, y - h, 30 + jw, 4, 0xC9A227); drawFilledRect(x - 30, y - h + 4, 14, 10, 0x555B68);
            drawFilledRect(x - 6, y - h - 8, 12, 8, 0x3A4150);
            drawFilledRect(x + jw - 1, y - h + 4, 1, 26, 0x888888); drawFilledRect(x + jw - 3, y - h + 30, 5, 4, 0xD9481F);
            if (((int)(t * 2)) & 1) { drawDisc(x + 3, y - h - 10, 3, 0xFF4040, 70); drawFilledRect(x + 2, y - h - 11, 3, 3, 0xFF5050); }
            drawFilledRect(x + jw - 2, y - h + 1, 3, 3, 0xFFE9A0);
        } break;
        case 5: {
            static const char* ads[4] = {"NEON NOODLES", "CITY BANK", "SKY TV", "PIZZA 24/7"};
            static const u32 bg[4] = {0x3A1030, 0x103A50, 0x2A1050, 0x503A10};
            int w = (int)o.w;
            drawFilledRect(x + 8, y - 70, 4, 70, 0x2A2F3F); drawFilledRect(x + w - 12, y - 70, 4, 70, 0x2A2F3F);
            drawFilledRect(x, y - 114, w, 46, 0x1A1D28);
            drawFilledRect(x + 3, y - 111, w - 6, 40, bg[o.param & 3]);
            SDL_Rect clip = {x + 3, y - 111, w - 6, 40};
            SDL_RenderSetClipRect(uvzRenderer, &clip);
            { const char* s = ads[o.param & 3]; int tw = fontWidth(FS_LED, s, 3) + 40; int tx = x + 3 + w - 6 - (int)fmod(t * 30.0, (double)(tw + w));
              textF(FS_LED, s, tx, y - 103, 3, 0xFFE9A0);
              drawFilledRect(x + 3, y - 80, w - 6, 3, 0xFF3A6A, 160 + (int)(60 * sinf((float)t * 4))); }
            SDL_RenderSetClipRect(uvzRenderer, nullptr);
            drawFilledRect(x, y - 114, w, 2, 0x6A7090);
        } break;
        default:
            drawFilledRect(x, y - 6, 2, 6, 0x4A5060); drawFilledRect(x - 6, y - 14, 12, 3, 0xB8BED0); drawFilledRect(x - 4, y - 11, 8, 2, 0x8A90A8); drawFilledRect(x - 1, y - 16, 2, 4, 0x6A7090);
            break;
    }
}
static void drawFacade(const Building& b, int sx, int sy, int ground) {
    const int st = b.style % 6;
    const WinGeo& g = WIN_GEO[st];
    const u32 tm = (u32)(gTime * 0.4);
    const float night = 1.0f - daylightAmount(gSkyTime);
    const int W = (int)b.w, capH = 14, y0 = sy + capH;
    const int r0 = std::max(0, (int)floorf((0.0f - y0) / (float)TILE));
    const int cols = (W + TILE - 1) / TILE;
    // Night lighting is batched: the per-tile darkening rects (identical colour/alpha, abutting, never overlapping) become one rect over the
    // visible tile area, and the lit windows (never overlapping each other or another tile) are drawn as one fill call per colour.
    static std::vector<SDL_Rect> winRects[2]; winRects[0].clear(); winRects[1].clear();
    int vx0 = 1 << 30, vx1 = -(1 << 30), vy0 = 1 << 30, vy1 = -(1 << 30);
    // Tiles that start at or below hideY are fully covered later in the frame (plinth / sidewalk / road): never drawn.
    const int hideY = facade::hiddenFrom(y0, ground);
    const int maxRun = facade::STRIP_TILES;
    for (int r = r0; y0 + r * TILE < std::min(uvzWorldHeight, hideY); r++) {
        const int ty = y0 + r * TILE;
        facade::Run run;   // horizontally adjacent tiles of one variant leave as a single copy from the strip texture
        auto flush = [&]() {
            if (!run.n) return;
            const SDL_Rect cell = facadeCell(st, run.v);
            SDL_Rect sr = {cell.x, cell.y, run.w, TILE}, d = {run.tx, ty, run.w, TILE};
            SDL_RenderCopy(uvzRenderer, gFacadeAtlas, &sr, &d);
            run.n = 0;
        };
        for (int c = 0; c < cols; c++) {
            const int tx = sx + c * TILE;
            if (tx + TILE < 0 || tx > uvzWorldWidth) continue;
            int v = (int)(hashCoordinates(b.seed + c, r, 7) % 3);
            if (hashCoordinates(c + (u32)b.seed, r, tm) % 41 == 0) v = (v + 1) % 3;
            const int sw = std::min(TILE, W - c * TILE);
            if (facade::canExtend(run, c, v, maxRun)) { run.n++; run.w += sw; }
            else { flush(); run.c0 = c; run.n = 1; run.v = v; run.tx = tx; run.w = sw; }
            if (night > 0.03f) {
                // darkening overlay is merged into one rect after the loop (below); lit windows are queued per colour
                vx0 = std::min(vx0, tx); vx1 = std::max(vx1, tx + sw); vy0 = std::min(vy0, ty); vy1 = std::max(vy1, ty + TILE);
                for (int wr = 0; wr < g.rows; wr++) for (int wc = 0; wc < g.cols; wc++) {   // lit windows, aligned to the real ones
                    const int wx = tx + wc * g.colPitch + g.x0, wy = ty + wr * g.rowPitch + g.y0;
                    if (wx + g.w > tx + sw) continue;
                    const u32 h = hashCoordinates(b.seed + (u32)(c * 7 + wc), (u32)(r * 3 + wr), 0x57494Eu);
                    if (h % 100u < 36u) winRects[(h & 0x100u) ? 0 : 1].push_back({wx, wy, g.w, g.h});
                }
            }
        }
        flush();
    }
    if (vx1 > vx0 && vy1 > vy0) {
        drawFilledRect(vx0, vy0, vx1 - vx0, vy1 - vy0, 0x10182D, (int)(night * 80));
        static const u32 winCol[2] = {0x9ADFFF, 0xFFD884};
        for (int k = 0; k < 2; k++) if (!winRects[k].empty()) {
            setDrawColor(winCol[k], (int)(night * 205));
            SDL_RenderFillRects(uvzRenderer, winRects[k].data(), (int)winRects[k].size());
        }
    }
    const u32 stone = FACADE_STONE[st];
    const int top = std::max(sy, 0);
    // ground floor: a stone plinth with a belt course, so the shops belong to the building
    const int baseTop = ground - 132;
    if (baseTop > y0 + 20) {
        const u32 bc = blendRgb(FACADE_BASE[st], 0x10131C, night * 0.45f);
        drawFilledRect(sx, baseTop, W, ground + 4 - baseTop, bc);
        for (int yy = baseTop + 10; yy < ground; yy += 12) drawFilledRect(sx, yy, W, 1, 0x05060F, 70);
        drawFilledRect(sx - 3, baseTop - 7, W + 6, 7, stone);
        drawFilledRect(sx - 3, baseTop - 7, W + 6, 1, 0xFFFFFF, 70);
        drawFilledRect(sx, baseTop, W, 4, 0x05060F, 110);
    }
    // street-level shade so the facade sits down into the canyon
    for (int yy = std::max(top, ground - 280); yy < ground; yy += 4) {
        const float u = 1.0f - (float)(ground - yy) / 280.0f;
        drawFilledRect(sx, yy, W, 4, 0x0A0C18, (int)(78.0f * u * u));
    }
    // corner quoins on the masonry styles, plus the party-wall edges
    if (st == 2 || st == 3 || st == 4) {
        const int qb = baseTop > y0 + 20 ? baseTop - 8 : ground;
        for (int yy = std::max(y0, top); yy < qb; yy += 20) {
            const int w = ((yy - y0) / 20) % 2 ? 9 : 6;
            drawFilledRect(sx, yy, w, 10, stone, 215); drawFilledRect(sx + W - w, yy + 10, w, 10, stone, 215);
        }
    }
    drawFilledRect(sx, top, 3, uvzWorldHeight - top, 0x05060F, 130);
    drawFilledRect(sx + W - 3, top, 3, uvzWorldHeight - top, 0xFFE2B0, 40);
    // cornice: parapet cap, dentils, deep shadow
    const u32 frieze = blendRgb(stone, 0x000000, 0.18f);
    drawFilledRect(sx - 1, sy - 9, W + 2, 3, stone);
    drawFilledRect(sx - 1, sy - 9, W + 2, 1, 0xFFFFFF, 80);
    drawFilledRect(sx, sy - 6, W, 6, blendRgb(stone, 0x000000, 0.28f));
    drawFilledRect(sx, sy, W, capH, frieze);
    for (int x = 0; x + 5 <= W; x += 8) drawFilledRect(sx + x + 1, sy + 7, 5, 4, stone);
    drawFilledRect(sx - 4, sy, W + 8, 5, stone);
    drawFilledRect(sx - 4, sy, W + 8, 1, 0xFFFFFF, 90);
    drawFilledRect(sx - 4, sy + 5, W + 8, 2, 0x05060F, 150);
    drawFilledRect(sx, sy + capH - 2, W, 2, 0x05060F, 120);
}
// ---- extra city detail: purely decorative (no collision), derived from the building seed so it is stable between frames ----
// ---- rooftop props: one function per prop, so tools/gen_spritesheet.cpp can bake exactly what the game draws (sy = the roof line) ----
static void drawRoofAC(int x, int sy, int w, int hh) {   // AC unit / vent box
    drawFilledRect(x, sy - hh, w, hh, 0x6A7280); drawFilledRect(x, sy - hh, w, 2, 0x9AA3B4); drawFilledRect(x + w - 3, sy - hh, 3, hh, 0x464C58);
    for (int k = 3; k < w - 5; k += 5) drawFilledRect(x + k, sy - hh + 4, 2, hh - 6, 0x2B303B);
    drawFilledRect(x + 2, sy - hh - 3, 8, 3, 0x464C58);
}
static void drawRoofChimney(int x, int sy) {   // brick stack (the steam puffs are drawn separately, they animate)
    drawFilledRect(x, sy - 26, 10, 26, 0x7A4A3C); drawFilledRect(x - 1, sy - 28, 12, 3, 0x3D2A22); drawFilledRect(x + 2, sy - 24, 2, 22, 0x9A6454);
}
static void drawRoofDish(int x, int sy) {   // satellite dish
    drawFilledRect(x + 8, sy - 12, 2, 12, 0x4A5060);
    drawLine((float)x, (float)(sy - 22), (float)(x + 18), (float)(sy - 22), 0xC9CFDA);
    drawLine((float)x, (float)(sy - 22), (float)(x + 9), (float)(sy - 12), 0xA3ABBA);
    drawLine((float)(x + 18), (float)(sy - 22), (float)(x + 9), (float)(sy - 12), 0xA3ABBA);
    drawFilledRect(x + 8, sy - 30, 2, 8, 0x4A5060);
}
static void drawRoofWaterTower(int x, int sy) {   // wooden water tower
    drawFilledRect(x + 3, sy - 22, 3, 22, 0x2A2D34); drawFilledRect(x + 14, sy - 22, 3, 22, 0x2A2D34); drawFilledRect(x + 25, sy - 22, 3, 22, 0x2A2D34);
    drawFilledRect(x, sy - 52, 31, 30, 0x8A5A38); drawFilledRect(x, sy - 52, 31, 2, 0xB07A50); drawFilledRect(x + 25, sy - 52, 6, 30, 0x5E3B24, 160);
    for (int k = 0; k < 4; k++) drawFilledRect(x, sy - 46 + k * 7, 31, 1, 0x2A2D34);
    for (int k = 0; k < 8; k++) drawFilledRect(x + 15 - 2 * k - 1, sy - 53 - k, 4 * k + 3, 1, 0x5E3B24);
}
static void drawRoofAntenna(int x, int sy, bool lightOn) {   // lattice tower with an aircraft light
    drawLine((float)x, (float)sy, (float)(x + 6), (float)(sy - 64), 0x3A404E);
    drawLine((float)(x + 12), (float)sy, (float)(x + 6), (float)(sy - 64), 0x3A404E);
    for (int k = 1; k < 5; k++) drawFilledRect(x + k, sy - 14 * k, 12 - 2 * k, 1, 0x3A404E);
    if (lightOn) { drawDisc(x + 6, sy - 66, 5, 0xFF3030, 60); drawFilledRect(x + 5, sy - 67, 3, 3, 0xFF5050); }
}
static const char* const ROOF_NEON_NAME[4] = {"HOTEL", "BAR", "CAFE", "INN"};
static const u32 ROOF_NEON_COL[4] = {0xFF4F9A, 0x4FE0FF, 0xFFD34F, 0x7CFF8A};
static void drawRoofNeon(int x, int sy, int k, int blink) {   // vertical neon sign (the night glow is drawn separately)
    drawFilledRect(x + 9, sy - 50, 3, 50, 0x2A2D34);
    drawFilledRect(x, sy - 94, 22, 46, 0x15171E);
    for (int c = 0; ROOF_NEON_NAME[k][c]; c++) { char ch[2] = {ROOF_NEON_NAME[k][c], 0}; textF(FS_NEON, ch, x + 8, sy - 90 + c * 8, 1, ROOF_NEON_COL[k], blink); }
}
static void drawRoofHelipad(int x, int sy, bool lightsOn) {
    drawFilledRect(x, sy - 3, 72, 3, 0x353841); drawFilledRect(x + 2, sy - 3, 68, 1, 0xE8E4D0, 160);
    drawFilledRect(x + 26, sy - 3, 3, 3, 0xF4F0DC); drawFilledRect(x + 43, sy - 3, 3, 3, 0xF4F0DC); drawFilledRect(x + 29, sy - 2, 14, 1, 0xF4F0DC);
    if (lightsOn) { drawFilledRect(x, sy - 5, 2, 2, 0xFFE070); drawFilledRect(x + 70, sy - 5, 2, 2, 0xFFE070); }
}
static void drawRoofDetail(const Building& b, int sx, int sy) {
    const float night = 1.0f - daylightAmount(gSkyTime);
    const int W = (int)b.w;
    if (W < 120) return;
    const u32 h0 = hashCoordinates(b.seed, 301u, 9u);
    // rooftop AC units / vents, 1-3 per roof
    const int nAc = 1 + (int)(h0 % 3u);
    for (int i = 0; i < nAc; i++) {
        const u32 h = hashCoordinates(b.seed, 310u + (u32)i, 4u);
        const int w = 22 + (int)(h % 14u), x = sx + 14 + (int)((h >> 8) % (u32)std::max(1, W - w - 28)), hh = 10 + (int)((h >> 4) % 8u);
        drawRoofAC(x, sy, w, hh);
    }
    // chimney / vent stack with a drifting puff of steam
    if ((h0 >> 5) % 3u == 0u) {
        const int x = sx + 20 + (int)((h0 >> 9) % (u32)std::max(1, W - 60));
        if (!sprDrawProp(PROP_CHIMNEY, x, sy)) drawRoofChimney(x, sy);
        if (!cfg.reduced) for (int k = 0; k < 3; k++) {
            const float u = fmodf((float)gTime * 0.5f + k * 0.33f, 1.0f);
            drawDisc(x + 5 + (int)(u * 14), sy - 32 - (int)(u * 34), 3 + (int)(u * 5), 0xDDE2EA, (int)(110 * (1.0f - u)));
        }
    }
    // satellite dish
    if ((h0 >> 11) % 4u == 0u) { const int x = sx + 30 + (int)((h0 >> 13) % (u32)std::max(1, W - 80)); if (!sprDrawProp(PROP_DISH, x, sy)) drawRoofDish(x, sy); }
    // wooden water tower on wider roofs
    if (W >= 420 && (h0 >> 16) % 3u == 1u) { const int x = sx + 60 + (int)((h0 >> 18) % (u32)std::max(1, W - 160)); if (!sprDrawProp(PROP_WATERTOWER, x, sy)) drawRoofWaterTower(x, sy); }
    // blinking antenna tower
    if ((h0 >> 20) % 3u == 2u) { const int x = sx + 40 + (int)((h0 >> 22) % (u32)std::max(1, W - 90)); const bool on = (((int)(gTime * 1.3) + (int)b.seed) & 1) != 0; if (!sprDrawProp(on ? PROP_ANTENNA_ON : PROP_ANTENNA_OFF, x, sy)) drawRoofAntenna(x, sy, on); }
    // vertical rooftop neon sign on the wider buildings
    if (W >= 480 && (h0 >> 24) % 4u == 0u) {
        const int k = (int)((h0 >> 26) & 3u), x = sx + W - 52;
        const int blink = (((int)(gTime * 2.0) + (int)b.seed) % 11 == 0) ? 90 : 255;
        drawRoofNeon(x, sy, k, blink);
        if (night > 0.05f) drawDisc(x + 11, sy - 70, 24, ROOF_NEON_COL[k], (int)(night * 30));
    }
    // helipad on the widest roofs
    if (W >= 560 && (h0 >> 28) % 2u == 0u) { const int x = sx + W / 2 - 36; const bool on = (((int)(gTime * 2.0)) & 1) != 0; if (!sprDrawProp(on ? PROP_HELIPAD_ON : PROP_HELIPAD_OFF, x, sy)) drawRoofHelipad(x, sy, on); }
    // string lights along the parapet at night
    if (night > 0.2f && (h0 & 3u) == 1u)
        for (int x = 6; x < W - 6; x += 14) {
            const int dy = (int)(3.0f * sinf((float)x * 0.18f) + 5.0f);
            drawFilledRect(sx + x, sy - 12 + dy, 2, 2, ((x / 14) & 1) ? 0xFFD884 : 0xFF9ACD, (int)(night * 230));
        }
}
static void drawFacadeDetail(const Building& b, int sx, int sy, int ground) {
    const int st = b.style % 6;
    const WinGeo& g = WIN_GEO[st];
    const float night = 1.0f - daylightAmount(gSkyTime);
    const int W = (int)b.w, y0 = sy + 14, baseTop = ground - 132;
    const int cols = (W + TILE - 1) / TILE;
    // window details: AC boxes, flower boxes, striped awnings on a sprinkling of windows
    for (int r = std::max(0, (int)floorf((0.0f - y0) / (float)TILE)); y0 + r * TILE < std::min(uvzWorldHeight, baseTop - 20); r++) {
        for (int c = 0; c < cols; c++) {
            const int tx = sx + c * TILE, ty = y0 + r * TILE;
            if (tx + TILE < 0 || tx > uvzWorldWidth) continue;
            for (int wr = 0; wr < g.rows; wr++) for (int wc = 0; wc < g.cols; wc++) {
                const int wx = tx + wc * g.colPitch + g.x0, wy = ty + wr * g.rowPitch + g.y0;
                if (wx + g.w > sx + W - 2 || wy + g.h > baseTop - 8) continue;
                const u32 h = hashCoordinates(b.seed + (u32)(c * 11 + wc), (u32)(r * 5 + wr), 0xDE7A11u);
                const u32 k = h % 17u;
                if (k == 0u) {
                    drawFilledRect(wx + 3, wy + g.h - 12, g.w - 6, 11, 0xB9BFC9); drawFilledRect(wx + 3, wy + g.h - 12, g.w - 6, 2, 0xE4E8EE);
                    for (int s2 = 0; s2 < 3; s2++) drawFilledRect(wx + 6, wy + g.h - 8 + s2 * 2, g.w - 12, 1, 0x707784);
                    drawFilledRect(wx + 2, wy + g.h - 1, g.w - 4, 2, 0x05060F, 110);
                } else if (k == 1u) {
                    drawFilledRect(wx - 1, wy + g.h, g.w + 2, 4, 0x5B3B28);
                    for (int s2 = 0; s2 < g.w; s2 += 4) drawFilledRect(wx + s2, wy + g.h - 3, 3, 3, ((s2 / 4 + (int)h) & 1) ? 0xE0526E : 0x56B46B);
                } else if (k == 2u && st != 0) {
                    const u32 ac = (h & 0x100u) ? 0xC4372F : 0x2E6F9E;
                    for (int s2 = 0; s2 < g.w + 6; s2 += 6) { drawFilledRect(wx - 3 + s2, wy - 7, 3, 7, ac); drawFilledRect(wx + s2, wy - 7, 3, 7, 0xF0E2C4); }
                    drawFilledRect(wx - 3, wy - 1, g.w + 6, 2, 0x05060F, 100);
                }
            }
        }
    }
    // pilasters up the facade to break up the flat wall
    if (W >= 360) {
        const u32 stone = FACADE_STONE[st];
        const int step = W >= 520 ? 3 : 2, ya = std::max(y0, 0), hh = std::max(0, baseTop - ya);
        for (int i = 1; i < step; i++) {
            const int x = sx + W * i / step - 3;
            drawFilledRect(x, ya, 7, hh, stone, 120); drawFilledRect(x, ya, 1, hh, 0xFFFFFF, 60); drawFilledRect(x + 6, ya, 1, hh, 0x05060F, 110);
        }
    }
    // vertical blade sign with a glowing edge
    const u32 hs = hashCoordinates(b.seed, 733u, 5u);
    if (hs % 3u == 0u && baseTop - y0 > 260) {
        static const u32 sc[] = {0xFF4F9A, 0x4FE0FF, 0xFFD34F, 0x7CFF8A, 0xFF8A3D};
        const u32 c = sc[(hs >> 4) % 5u];
        const int x = sx + 8 + (((hs >> 8) % 3u == 0u) ? 0 : W - 38), top = baseTop - 170 - (int)((hs >> 12) % 60u);
        drawFilledRect(x, top, 20, 84, 0x15171E); drawFilledRect(x + 2, top + 2, 16, 80, blendRgb(c, 0x15171E, 0.55f));
        for (int s2 = 0; s2 < 6; s2++) drawFilledRect(x + 5, top + 8 + s2 * 12, 10, 6, c, 120 + (int)(night * 130));
        if (night > 0.05f) drawDisc(x + 10, top + 42, 34, c, (int)(night * 36));
    }
}
// ---- New York landmark crowns: Empire State, Chrysler, One World Trade, Flatiron-style cupola ----
// Purely visual; the crown's spire is a web pole (see addBuilding) so every landmark can be swung from.
static const char* LANDMARK_NAME[5] = {"", "EMPIRE", "CHRYSLER", "FREEDOM", "FLATIRON"};
static void drawLandmark(const Building& b, int sx, int sy) {
    if (!b.landmark) return;
    const float night = 1.0f - daylightAmount(gSkyTime);
    const int W = (int)b.w, cx = sx + W / 2, top0 = sy;
    if (cx + 400 < 0 || cx - 400 > uvzWorldWidth) return;
    const int K = 8;   // crowns are drawn life-size: ~30 px per metre, so 8x the old small-scale heights (a 56 m Empire State crown, a ~60 m spire)
    auto tier = [&](int& y, int w, int h, u32 c, u32 sh, u32 hi, u32 win) {
        const int x = cx - w / 2; y -= h;
        if (y > uvzWorldHeight || y + h < 0) return;
        drawFilledRect(x, y, w, h, c); drawFilledRect(x + w - 12, y, 12, h, sh); drawFilledRect(x, y, w, 6, hi); drawFilledRect(x, y, 3, h, 0x05060F, 90);
        for (int wy = y + 24; wy + 52 < y + h; wy += 96) {   // real floors: 3.2 m pitch, 0.8 x 1.7 m windows
            if (wy + 52 < 0 || wy > uvzWorldHeight) continue;
            for (int wx = x + 14; wx + 24 < x + w - 18; wx += 48) {
                if (wx + 24 < 0 || wx > uvzWorldWidth) continue;
                const u32 hh = hashCoordinates(b.seed + (u32)wx, (u32)wy, 0x4C4Du);
                drawFilledRect(wx, wy, 24, 52, win);
                if (night > 0.1f && hh % 100u < 38u) drawFilledRect(wx, wy, 24, 52, (hh & 0x100u) ? 0x9ADFFF : 0xFFD884, (int)(night * 220));
            }
        }
    };
    switch (b.landmark) {
        case 1: {   // Empire State: limestone setbacks, observatory, 60 m mast, colour-changing floodlights
            int y = top0;
            const int ws[4] = {W * 80 / 100, W * 62 / 100, W * 44 / 100, W * 26 / 100}, hs[4] = {44 * K, 52 * K, 60 * K, 56 * K};
            int ys[4];
            for (int i = 0; i < 4; i++) { tier(y, ws[i], hs[i], 0xCFC6AE, 0x9E957F, 0xEFE8D4, 0x3B4660); ys[i] = y; }
            drawFilledRect(cx - 7 * K / 2, y - 18 * K, 7 * K, 18 * K, 0xDAD2BC); drawFilledRect(cx - 4 * K / 2, y - 24 * K, 4 * K, 6 * K, 0xC9C0A8);   // art deco crown
            drawFilledRect(cx - 14, y - 24 * K - 48 * K, 28, 48 * K, 0xB8BEC8); drawFilledRect(cx - 5, y - 24 * K - 66 * K, 10, 18 * K, 0xB8BEC8);      // mast and antenna
            static const u32 fl[] = {0xFF4F5A, 0xFFFFFF, 0x4F8CFF, 0xFFD34F, 0x7CFF8A};
            const u32 fc = fl[(int)(gSkyTime / 12.0) % 5];
            if (night > 0.05f) for (int i = 2; i < 4; i++) drawFilledRect(cx - ws[i] / 2, ys[i], ws[i], hs[i], fc, (int)(night * 70));
            if (((int)(gTime * 1.2)) & 1) { const int ty = y - 24 * K - 66 * K; drawDisc(cx, ty - 4, 16, 0xFF3030, 70); drawFilledRect(cx - 4, ty - 8, 8, 8, 0xFF5050); }
        } break;
        case 2: {   // Chrysler: brick tiers, stainless-steel sunburst crown, needle
            int y = top0;
            tier(y, W * 62 / 100, 70 * K / 2, 0xE2D8C6, 0xAFA590, 0xFFFFFF, 0x4A5468);
            tier(y, W * 46 / 100, 46 * K / 2, 0xE2D8C6, 0xAFA590, 0xFFFFFF, 0x4A5468);
            const int baseY = y, crownW = W * 40 / 100, rowH = 3 * K / 2 * 2 / 2 + 8;   // 20 px rows
            for (int i = 0; i < 40; i++) {   // arched silhouette
                const float t = (float)i / 40.0f, w = crownW * sqrtf(std::max(0.0f, 1.0f - t * t * 0.96f));
                const int yy = baseY - i * rowH - rowH;
                if (yy > uvzWorldHeight || yy + rowH < 0) continue;
                drawFilledRect(cx - (int)w, yy, (int)(2 * w), rowH, (i / 6) & 1 ? 0xD3DAE2 : 0xB9C2CD);
                drawFilledRect(cx + (int)w - 10, yy, 10, rowH, 0x8F99A6);
            }
            for (int a = 0; a < 7; a++) {    // concentric arches with triangular windows
                const int ay = baseY - 40 - a * 100, aw = (int)(crownW * (1.0f - a * 0.12f));
                if (aw < 40 || ay > uvzWorldHeight || ay < -60) continue;
                drawFilledRect(cx - aw, ay, 2 * aw, 4, 0x4A5260);
                for (int k = -aw + 40; k < aw - 40; k += 64) { drawFilledRect(k + cx, ay - 44, 22, 30, 0x2A3140); if (night > 0.1f) drawFilledRect(k + cx, ay - 44, 22, 30, 0xFFE2A0, (int)(night * 200)); }
            }
            const int topY = baseY - 40 * rowH;
            drawFilledRect(cx - 8, topY - 14 * K, 16, 14 * K, 0xD3DAE2); drawFilledRect(cx - 3, topY - 14 * K - 22 * K, 6, 22 * K, 0xD3DAE2);   // spire and needle
            if (night > 0.05f) drawDisc(cx, baseY - 400, crownW + 80, 0xCFE4FF, (int)(night * 26));
        } break;
        case 3: {   // One World Trade: tapered glass prism and a 120 m-class antenna
            const int rows = 80, rh = 3 * K;   // 24 px rows: 64 m of prism
            for (int i = 0; i < rows; i++) {
                const float t = (float)i / rows, w = W * (0.62f - 0.34f * t);
                const int yy = top0 - (i + 1) * rh;
                if (yy > uvzWorldHeight || yy + rh < 0) continue;
                const u32 c = blendRgb(0x7FA8C6, 0xD2E6F2, t * 0.8f);
                drawFilledRect(cx - (int)(w / 2), yy, (int)w, rh, c);
                drawFilledRect(cx - (int)(w / 2), yy, 5, rh, 0x3F5F78); drawFilledRect(cx + (int)(w / 2) - 12, yy, 12, rh, 0x4E7690);
                if (i % 4 == 0) drawFilledRect(cx - (int)(w / 2), yy, (int)w, 2, 0xFFFFFF, 90);
                if (night > 0.1f && i % 2 == 0) drawFilledRect(cx - (int)(w / 2) + 10, yy + 6, (int)w - 22, 8, 0xFFE6A8, (int)(night * 90));
            }
            const int pt = top0 - rows * rh;
            drawFilledRect(cx - 16, pt - 130 * K / 2, 32, 130 * K / 2, 0xD9DEE6); drawFilledRect(cx - 6, pt - 130 * K / 2 - 20 * K, 12, 20 * K, 0xD9DEE6);
            drawFilledRect(cx - 40, pt - 30, 80, 30, 0xD9DEE6);
            if (((int)(gTime * 1.5)) & 1) { const int ty = pt - 130 * K / 2 - 20 * K; drawDisc(cx, ty - 4, 16, 0xFF3030, 70); drawFilledRect(cx - 4, ty - 8, 8, 8, 0xFF5050); }
        } break;
        default: {  // Flatiron-style: ornate limestone cupola with a copper dome
            int y = top0;
            tier(y, W * 74 / 100, 38 * K / 2, 0xD4C8AE, 0xA39878, 0xF2EAD6, 0x4A3F36);
            drawFilledRect(cx - W * 40 / 100, y - 30, W * 80 / 100, 30, 0xC9BDA2); drawFilledRect(cx - W * 40 / 100, y - 30, W * 80 / 100, 4, 0xFFFFFF, 120);
            y -= 30;
            tier(y, W * 40 / 100, 40 * K / 2, 0xD4C8AE, 0xA39878, 0xF2EAD6, 0x4A3F36);
            for (int i = 0; i < 28; i++) { const float t = (float)i / 28.0f, w = W * 0.22f * sqrtf(1.0f - t * t); drawFilledRect(cx - (int)w, y - i * 10 - 10, (int)(2 * w), 10, (i & 4) ? 0x5BA08C : 0x4B8E7A); }
            drawFilledRect(cx - 5, y - 28 * 10 - 12 * K, 10, 12 * K, 0x3F7A68); drawDisc(cx, y - 28 * 10 - 12 * K, 12, 0xE8C860);
        } break;
    }
    // small name plate on the facade so the landmark reads at a glance
    const char* nm = LANDMARK_NAME[b.landmark];
    const int tw = measureTextWidth(nm, 1);
    drawFilledRect(cx - tw / 2 - 4, sy + 22, tw + 8, 12, 0x15171E, 200);
    text(nm, cx - tw / 2, sy + 25, 1, 0xFFE9A0);
}
static void drawSetbacks(const Building& b, int sx, int sy) {
    if (!b.setbacks) return;
    const int st = b.style % 6, W = (int)b.w, cx = sx + W / 2;
    const float night = 1.0f - daylightAmount(gSkyTime);
    const u32 stone = FACADE_STONE[st], body = blendRgb(FACADE_BASE[st], stone, 0.55f);
    int y = sy;
    for (int i = 0; i < b.setbacks; i++) {   // life-size wedding-cake tiers: ~20 m and ~16 m
        const int w = (int)(W * (i == 0 ? 0.52f : 0.30f)), h = i == 0 ? 640 : 520, x = cx - w / 2;
        y -= h;
        if (y > uvzWorldHeight || y + h < 0) continue;
        drawFilledRect(x, y, w, h, body); drawFilledRect(x + w - 12, y, 12, h, 0x05060F, 70); drawFilledRect(x - 6, y - 10, w + 12, 12, stone); drawFilledRect(x - 6, y - 10, w + 12, 3, 0xFFFFFF, 90);
        for (int wy = y + 24; wy + 52 < y + h; wy += 96) {
            if (wy + 52 < 0 || wy > uvzWorldHeight) continue;
            for (int wx = x + 14; wx + 24 < x + w - 18; wx += 48) {
                if (wx + 24 < 0 || wx > uvzWorldWidth) continue;
                const u32 hh = hashCoordinates(b.seed + (u32)wx, (u32)wy, 0x5342u);
                drawFilledRect(wx, wy, 24, 52, 0x3B4660);
                if (night > 0.1f && hh % 100u < 40u) drawFilledRect(wx, wy, 24, 52, (hh & 0x100u) ? 0x9ADFFF : 0xFFD884, (int)(night * 220));
            }
        }
    }
    drawFilledRect(cx - 4, y - 360, 8, 360, 0x3A404E);   // 12 m antenna
    if (((int)(gTime * 1.3) + (int)b.seed) & 1) { drawDisc(cx, y - 364, 12, 0xFF3030, 60); drawFilledRect(cx - 3, y - 368, 8, 8, 0xFF5050); }
}
static void drawCable(const Building& b, float cx, float cy) {
    if (!b.cable) return;
    float x0 = b.cx0 - cx, y0 = b.cy0 - cy, x1 = b.cx1 - cx, y1 = b.cy1 - cy;
    if (x1 < -20 || x0 > uvzWorldWidth + 20) return;
    float px = x0, py = y0;
    for (int i = 1; i <= 24; i++) {
        float u = i / 24.0f, qx = lerpValue(x0, x1, u), qy = lerpValue(y0, y1, u) + 22 * 4 * u * (1 - u);
        drawLine(px, py + 1, qx, qy + 1, 0x05060F, 200); drawLine(px, py, qx, qy, 0x9AA3C0);
        px = qx; py = qy;
    }
    float ax = (x0 + x1) / 2, ay = (y0 + y1) / 2 + 22;
    drawDisc((int)ax, (int)ay + 2, 8, 0xFFE8A0, 45);
    drawFilledRect((int)ax - 3, (int)ay - 2, 6, 6, 0xFFE8A0); drawFilledRect((int)ax - 1, (int)ay - 4, 2, 2, 0x4A5060);
}
static void drawMasts(const Building& b, int sx, int sy) {
    if (b.mastR) { int x = sx + (int)b.w - 12; drawFilledRect(x, sy - 280, 3, 280, 0x2A2F3F); drawFilledRect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) drawFilledRect(x, sy - 284, 3, 3, 0xFF4040); }
    if (b.mastL) { int x = sx + 9; drawFilledRect(x, sy - 280, 3, 280, 0x2A2F3F); drawFilledRect(x - 4, sy - 280, 11, 2, 0x4A5060);
        if (((int)(gTime * 1.2) + b.style) & 1) drawFilledRect(x, sy - 284, 3, 3, 0xFF4040); }
}
static void drawBillboardBoard(int x, int sy, int k) {   // the rooftop ad board without its night lighting; k = ad 0..5
    static const char* ads[] = {"PIZZA", "NYC", "TAXI", "JAZZ", "METRO", "DELI"};
    static const u32 bg[] = {0xC4372F, 0x2E6F9E, 0xE0A92A, 0x5B3E8A, 0x2F8A63, 0xC46A2F};
    const int bw = 64, bh = 26, top = sy - bh - 16;
    drawFilledRect(x + 10, top + bh, 3, 16, 0x2A2D34); drawFilledRect(x + bw - 13, top + bh, 3, 16, 0x2A2D34);
    drawFilledRect(x - 2, top - 2, bw + 4, bh + 4, 0x1E2026);
    drawFilledRect(x, top, bw, bh, bg[k]);
    drawFilledRect(x, top, bw, 2, blendRgb(bg[k], 0xFFFFFF, 0.35f));
    textF(FS_ITAL, ads[k], x + (bw - fontWidth(FS_ITAL, ads[k], 2)) / 2, top + 6, 2, 0xFFF4D6);
}
static void drawBillboard(const Building& b, int sx, int sy) {   // decorative rooftop ad board (no collision)
    const float night = 1.0f - daylightAmount(gSkyTime);
    const int bw = 64, bh = 26, x = sx + 20 + (int)(hashCoordinates(b.seed, 77u, 3u) % (u32)std::max(1, (int)b.w - bw - 40));
    const int k = (int)(hashCoordinates(b.seed, 78u, 4u) % 6u), top = sy - bh - 16;
    if (!sprDrawProp(PROP_BILLBOARD0 + k, x, sy)) drawBillboardBoard(x, sy, k);
    if (night > 0.05f) {
        drawFilledRect(x, top, bw, bh, 0xFFE8A0, (int)(night * 38));
        for (int i = 0; i < 3; i++) drawFilledRect(x + 8 + i * 24, top - 5, 3, 3, 0xFFF1B2, (int)(night * 220));
    }
}
static void drawRoofShed(int x, int sy) {   // wooden rooftop shed
    drawFilledRect(x - 3, sy - 5, 42, 6, 0x292A32);
    drawFilledRect(x, sy - 24, 34, 19, 0x7D573F);
    drawFilledRect(x + 2, sy - 22, 30, 14, 0xA3734A);
    drawFilledRect(x + 1, sy - 25, 32, 3, 0x46352F);
    drawFilledRect(x + 5, sy - 7, 3, 5, 0x49362D);
    drawFilledRect(x + 25, sy - 7, 3, 5, 0x49362D);
    drawFilledRect(x + 11, sy - 19, 2, 12, 0x5D4336);
    drawFilledRect(x + 21, sy - 19, 2, 12, 0x5D4336);
}
static void drawNYCRooftop(const Building& b, int sx, int sy) {
    const u32 pick = hashCoordinates(b.seed, 21u, 8u) % 3u;
    if (pick == 1u && b.w > 130.0f) { drawBillboard(b, sx, sy); return; }
    if (pick != 0u) return;
    { const int x = sx + 34 + (int)(b.seed % (u32)std::max(1, (int)b.w - 92)); if (!sprDrawProp(PROP_SHED, x, sy)) drawRoofShed(x, sy); }
}
static const u32 FE_DARK = 0x2B3037, FE_MID = 0x4A505C, FE_LITE = 0x69717D;
static void drawFireEscapeLanding(int x, int y, int pw) {   // one landing with its railing; y = the platform's top edge
    drawFilledRect(x, y, pw, 3, FE_MID); drawFilledRect(x, y, pw, 1, FE_LITE);
    drawFilledRect(x, y + 3, pw, 1, 0x05060F, 110);
    drawFilledRect(x, y - 22, 2, 22, FE_DARK); drawFilledRect(x + pw - 2, y - 22, 2, 22, FE_DARK);
    drawFilledRect(x, y - 22, pw, 2, FE_DARK);
    for (int bx = x + 8; bx < x + pw - 4; bx += 8) drawFilledRect(bx, y - 20, 1, 20, FE_DARK, 190);
}
static void drawFireEscapeStairs(int xa, int xb, int y, int yn) {   // one flight from the landing at y down to the next at yn
    drawLine((float)xa, (float)(y + 3), (float)xb, (float)(yn), FE_DARK);
    drawLine((float)xa + 1, (float)(y + 3), (float)xb + 1, (float)(yn), FE_MID);
}
static void drawFireEscape(const Building& b, int sx, int sy, int ground) {
    const int st = b.style % 6;
    if (st < 2 || st == 5) return;   // fire escapes belong on the old brick and brownstone fronts
    if (hashCoordinates(b.seed, 48u, 15u) % 3u == 0u) return;
    const WinGeo& g = WIN_GEO[st];
    const int cols = std::max(1, (int)b.w / g.colPitch - 2);
    const int col = 1 + (int)(hashCoordinates(b.seed, 51u, 2u) % (u32)cols);
    const int pw = 60, x = sx + col * g.colPitch + g.x0 + g.w / 2 - pw / 2;
    const int baseTop = ground - 132, first = sy + 14;
    for (int r = 0;; r++) {
        const int y = first + r * TILE + g.y0 + g.h;
        if (y > baseTop - 16 || y > uvzWorldHeight + 40) break;
        if (y < -40) continue;
        drawFireEscapeLanding(x, y, pw);
    }
    // zig-zag stairs between landings
    for (int r = 0;; r++) {
        const int y = first + r * TILE + g.y0 + g.h, yn = y + TILE;
        if (yn > baseTop - 16) break;
        if (yn < -40 || y > uvzWorldHeight + 40) continue;
        const bool left = (r & 1) != 0;
        const int xa = left ? x + 6 : x + pw - 8, xb = left ? x + pw - 8 : x + 6;
        drawFireEscapeStairs(xa, xb, y, yn);
    }
}

static int pickFrame() {
    Player& p = P;
    if (!p.alive) return p.deadT < 0.3f ? F_HIT : F_DEAD;
    if (p.wallCling) return (p.mantleT > 0 || fabsf(p.vy) > 35.0f) ? F_CLIMB : F_CLING;
    if (p.zipping) return F_ATTACH;
    if (p.swinging && !p.onGround) return p.attachT > 0 ? F_ATTACH : F_SWING;
    if (p.shootT > 0 && !p.onGround) return F_SHOOT;
    if (p.trickType && !p.onGround) {
        if (p.trickType == T_TWIST) return F_TWIST;
        if (p.trickType == T_CART) return F_STAR;
        if (p.trickT / std::max(0.01f, p.trickDur) > 0.78f) return F_FLIPOPEN;   // open up and reach for the landing
        return p.trickType == T_BACK ? F_BACKFLIP : F_FLIP;
    }
    if (p.diving && !p.onGround) return F_DIVE;
    if (p.vaultOneT > 0 && !p.onGround) return F_VAULT;
    if (p.rollT > 0 && p.onGround) return F_ROLL;
    if (p.releaseT > 0) return p.releaseFlip ? (p.flipDir < 0 ? F_BACKFLIP : F_FLIP) : F_RELEASE;
    if (p.slideT > 0 && p.onGround) return F_SLIDE;
    if (p.landT > 0) return p.hero ? F_HERO : F_LAND;
    if (p.onGround) return gMenuIdle ? F_IDLE : F_RUN;
    if (p.wallJumpT > 0 && !p.swinging) return F_WALLJUMP;
    if (p.flipT > 0) return p.flipT < 0.12f ? F_FLIPOPEN : (p.flipDir < 0 ? F_BACKFLIP : F_FLIP);
    return p.vy < 0 ? F_JUMP : F_FALL;
}

// ======================================================================================
// Ray-marched lighting (Graphics Settings). Rays are marched through a height-field of the skyline (one cell = 8 px) towards the sun or moon.
//   * Dynamic Shadows: soft building shadows on the street and on rooftops, plus a shadow under the runner and the cars.
//   * Ambient Occlusion: rays over a hemisphere darken roof corners next to taller neighbours; contact darkening under cars and the runner.
//   * Reflections: a planar street reflection of cars, signals, the runner and the sky.
// With dynamic lighting off (or unavailable) the same options fall back to cheap blob shadows and fixed AO strips, and reflections are disabled.
// ======================================================================================
struct GfxLight { float toward; float tanE; float strength; };   // toward: +1 = light comes from the right of the screen
static GfxLight gfxLight(double t) {
    const float phase = dayPhase(t), day = daylightAmount(t);
    GfxLight sunL = {1.0f, 1.0f, 0.0f}, moonL = {1.0f, 1.0f, 0.0f};
    { const float f = (phase - 0.10f) / 0.56f, fc = clampValue(f, 0.0f, 1.0f), e = sinf(fc * pi);
      sunL.toward = fc < 0.5f ? 1.0f : -1.0f; sunL.tanE = tanf(0.16f + e * 1.15f); sunL.strength = clampValue(day * (0.55f + 0.45f * e), 0.0f, 1.0f); }
    { const float f = clampValue((fmodf(phase + 0.5f, 1.0f) - 0.10f) / 0.56f, 0.0f, 1.0f), e = sinf(f * pi);
      moonL.toward = f < 0.5f ? 1.0f : -1.0f; moonL.tanE = tanf(0.2f + e * 1.0f); moonL.strength = (1.0f - day) * 0.38f; }
    return sunL.strength >= moonL.strength ? sunL : moonL;
}
static const int GFX_CELL = 8;
static std::vector<float> gHF; static std::vector<int> gHFid;   // skyline height above the street, and which building owns the cell
static float gHFx0 = 0, gHFmax = 0; static int gHFn = 0;
static unsigned gGfxFrame = 1, gHFFrame = 0; static float gHFcx = 0;
static void gfxField(float cx) {
    if (gHFFrame == gGfxFrame && gHFcx == cx) return;
    gHFFrame = gGfxFrame; gHFcx = cx;
    const int reach = std::max(gFx.p.steps, gFx.p.aoReach / GFX_CELL + 1) * GFX_CELL;
    gHFx0 = floorf((cx - reach) / GFX_CELL) * GFX_CELL;
    gHFn = (int)((uvzWorldWidth + 2 * reach) / GFX_CELL) + 3;
    gHF.assign((size_t)gHFn, 0.0f); gHFid.assign((size_t)gHFn, 0); gHFmax = 0;
    const float x1 = gHFx0 + gHFn * GFX_CELL;
    for (const Building& b : bldNear(gHFx0, x1)) {
        const int id = b.uid;
        if (b.x + b.w < gHFx0 || b.x > x1) continue;
        const float h = STREET_GROUND_Y - b.roofY;
        const int i0 = std::max(0, (int)floorf((b.x - gHFx0) / GFX_CELL)), i1 = std::min(gHFn - 1, (int)floorf((b.x + b.w - gHFx0) / GFX_CELL));
        for (int i = i0; i <= i1; i++) if (h > gHF[(size_t)i]) { gHF[(size_t)i] = h; gHFid[(size_t)i] = id; }
        gHFmax = std::max(gHFmax, h);
    }
}
static int gfxCell(float wx) { return (int)floorf((wx - gHFx0) / GFX_CELL); }
// Is the ray from (wx, h0) towards the light blocked by a building other than the one it starts on?
static bool gfxRayBlocked(float wx, float h0, int ownId, float dir, float tanE, int steps) {
    for (int k = 1; k <= steps; k++) {
        const int i = gfxCell(wx + dir * k * GFX_CELL);
        if (i < 0 || i >= gHFn) return false;
        const float rh = h0 + k * GFX_CELL * tanE;
        if (rh > gHFmax) return false;
        if (gHF[(size_t)i] > rh && gHFid[(size_t)i] != ownId) return true;
    }
    return false;
}
static float gfxShadowFrac(float wx, float h0, int ownId, const GfxLight& L) {
    const int n = gFx.p.penumbra; int hit = 0;
    for (int k = 0; k < n; k++) {
        const float spread = n > 1 ? ((float)k / (n - 1) - 0.5f) * 0.5f : 0.0f;   // +-25 % around the sun elevation = soft edge
        if (gfxRayBlocked(wx, h0, ownId, L.toward, L.tanE * (1.0f + spread), gFx.p.steps)) hit++;
    }
    return (float)hit / n;
}
static float gfxAoFrac(float wx, float h0, int ownId) {
    const int n = gFx.p.aoRays, reach = gFx.p.aoReach / GFX_CELL; int hit = 0;
    for (int r = 0; r < n; r++) {
        const float a = pi * (r + 0.5f) / n, dx = cosf(a), dy = sinf(a);   // hemisphere above the surface
        if (fabsf(dx) < 0.2f) continue;                                    // straight up never meets a wall
        for (int k = 1; k <= reach; k++) {
            const int i = gfxCell(wx + dx * k * GFX_CELL);
            if (i < 0 || i >= gHFn) break;
            if (gHF[(size_t)i] > h0 + dy * k * GFX_CELL && gHFid[(size_t)i] != ownId) { hit++; break; }
        }
    }
    return (float)hit / std::max(1, n);
}
static void gfxBlob(int cx, int y, int rx, int ry, int a, int bands = 3) {   // soft elliptical shadow: stacked ellipses, widest and faintest first
    for (int k = 0; k < bands; k++) {
        const float f = (float)(bands - k) / bands;
        const int rxk = std::max(1, (int)(rx * f)), ryk = std::max(1, (int)(ry * f));
        for (int yy = -ryk; yy <= ryk; yy++) {
            const int hw = (int)(rxk * sqrtf(std::max(0.0f, 1.0f - (float)(yy * yy) / (float)(ryk * ryk))));
            if (hw > 0) drawFilledRect(cx - hw, y + yy, hw * 2, 1, 0x05060F, a / bands);
        }
    }
}
// Buildings' shadows on the street, rooftop shadows and AO, base AO. Runs right after the facades are drawn.
static void gfxBuildingFx(float cx, float cy) {
    if (!gFx.shadows && !gFx.ao) return;
    const bool rtS = gFx.rtShadows, rtA = gFx.rtAo;
    if (rtS || rtA) gfxField(cx);
    const GfxLight L = gfxLight(gSkyTime);
    const int W = uvzWorldWidth, cs = gFx.p.colStep;
    if (rtS && L.strength > 0.03f) {   // shadow on the roofs
        for (const Building& b : bldNear(cx, cx + W)) {
            if (b.x + b.w < cx || b.x > cx + W) continue;
            const int id = b.uid, sy = (int)floorf(b.roofY - cy);
            const float h0 = STREET_GROUND_Y - b.roofY;
            const int xa = std::max(0, (int)floorf(b.x - cx)), xb = std::min(W, (int)floorf(b.x + b.w - cx));
            for (int x = xa; x < xb; x += cs) {
                const float f = gfxShadowFrac(cx + x + cs * 0.5f, h0, id, L);
                if (f > 0) drawFilledRect(x, sy, std::min(cs, xb - x), 6, 0x05060F, (int)(110 * L.strength * f));
            }
        }
    }
    if (gFx.ao) {   // base-of-wall AO everywhere, roof-corner AO when ray-marched
        const int ground = (int)floorf(STREET_GROUND_Y - cy), bands = rtA ? gFx.p.bands : 2;
        for (const Building& b : bldNear(cx, cx + W)) {
            if (b.x + b.w < cx || b.x > cx + W) continue;
            const int id = b.uid, xa = std::max(0, (int)floorf(b.x - cx)), xb = std::min(W, (int)floorf(b.x + b.w - cx));
            for (int k = 0; k < bands; k++) drawFilledRect(xa, ground - 7 - (k + 1) * 3, xb - xa, 3, 0x05060F, (int)(70.0f * (bands - k) / bands));
            if (!rtA) continue;
            const int sy = (int)floorf(b.roofY - cy); const float h0 = STREET_GROUND_Y - b.roofY;
            for (int x = xa; x < xb; x += std::max(cs, 4)) {
                const float o = gfxAoFrac(cx + x + 2, h0, id);
                if (o < 0.12f) continue;
                const int w = std::min(std::max(cs, 4), xb - x);
                for (int k = 0; k < bands; k++) drawFilledRect(x, sy - (k + 1) * 3, w, 3, 0x05060F, (int)(90.0f * o * (bands - k) / bands));
            }
        }
    }
}
// Street: building shadows across the road, reflections, shadows / AO under cars and crates. Runs after the road is painted, before the cars.
static void gfxStreetFx(float cx, float cy, int ground) {
    const int W = uvzWorldWidth, H = uvzWorldHeight, roadTop = ground + 10;
    const float night = 1.0f - daylightAmount(gSkyTime);
    const GfxLight L = gfxLight(gSkyTime);
    if (gFx.rtShadows && L.strength > 0.03f) {
        gfxField(cx);
        const int cs = gFx.p.colStep; int runX = 0, runA = -1;
        auto flush = [&](int x) { if (runA > 0) drawFilledRect(runX, ground - 7, x - runX, H - (ground - 7), 0x05060F, runA); };
        for (int x = 0; x < W; x += cs) {
            const float wx = cx + x + cs * 0.5f, i = (float)gfxCell(wx);
            const int id = (i >= 0 && i < gHFn) ? gHFid[(size_t)i] : 0;
            const int a = (int)(95 * L.strength * gfxShadowFrac(wx, 0.0f, id, L)) / 6 * 6;   // quantised so equal neighbours merge into one rect
            if (a != runA) { flush(x); runX = x; runA = a; }
        }
        flush(W);
    }
    if (gFx.reflections) {
        const int bands = gFx.p.bands;
        const DayPalette pal = dayPalette(gSkyTime);
        for (int k = 0; k < bands; k++) drawFilledRect(0, roadTop + k * 3, W, 3, pal.horizon, (int)((22 - 18 * k / std::max(1, bands)) * (0.6f + 0.4f * (1 - night))));   // sky sheen on the asphalt
        for (const TrafficCar& car : trafficCars) {
            const int sx = (int)floorf(car.x - cx);
            if (sx < -90 || sx > W + 90) continue;
            const int bottom = (int)floorf(carBottomY(car) - cy), rw = (int)car.width;
            const int rh = std::min((int)car.height * 3 / 5, bands * 4);
            for (int k = 0; k < bands; k++) {
                const int yy = bottom + 1 + k * rh / bands;
                drawFilledRect(sx - rw / 2 + k, yy, std::max(2, rw - 2 * k), std::max(1, rh / bands), car.color, (int)(80.0f * (bands - k) / bands));
            }
            if (night > 0.35f) drawFilledRect(sx + (car.dir > 0 ? rw / 2 - 6 : -rw / 2), bottom + 2, 6, bands * 3, 0xFFE9A0, (int)(70 * night));   // headlight streak
        }
        for (const TrafficSignal& sg : sigNear(cx - 120.0f, cx + W + 120.0f)) {
            const int px = (int)floorf(sg.x - cx) + 32;
            if (px < -20 || px > W + 20 || night < 0.3f) continue;
            const u32 c = trafficSignalGreen(sg, 1, gTime) ? 0x43D17A : 0xED4A46;
            for (int k = 0; k < bands; k++) drawFilledRect(px - 1, roadTop + 6 + k * 4, 4, 4, c, (int)(70 * night * (bands - k) / bands));
        }
        const float feet = P.y + 26.0f, dist = STREET_GROUND_Y - feet;
        if (P.alive && dist > 0 && dist < 240.0f) {   // the runner mirrored in the road, fading with height
            const int sx = (int)floorf(P.x - cx), top = roadTop + 10 + (int)(dist * 0.12f);
            const int a = (int)(70.0f * (1.0f - dist / 240.0f));
            drawFilledRect(sx - 3, top, 6, 10, 0xD62839, a); drawFilledRect(sx - 3, top + 10, 6, 8, 0x2E4A9A, a * 2 / 3);
        }
    }
    const int bandsAo = gFx.rtAo ? 4 : 2;
    for (const TrafficCar& car : trafficCars) {   // cars: a shadow pushed away from the light, and contact AO under the wheels
        const int sx = (int)floorf(car.x - cx);
        if (sx < -120 || sx > W + 120) continue;
        const int bottom = (int)floorf(carBottomY(car) - cy), rw = (int)car.width;
        const int off = gFx.rtShadows ? (int)(-L.toward * std::min(1.0f / L.tanE, 3.0f) * car.height * 0.35f) : 0;
        if (gFx.shadows) gfxBlob(sx + off, bottom, rw / 2 + std::abs(off) / 2, 3, (int)(120 * (gFx.rtShadows ? std::max(0.35f, L.strength) : 0.8f)));
        if (gFx.ao) gfxBlob(sx, bottom, rw / 2 - 2, 2, 90, bandsAo);
    }
    for (const StreetCrate& c : crateNear(cx - 40.0f - 64.0f, cx + W + 40.0f)) {
        const int x = (int)floorf(c.x - cx);
        if (x > W + 40 || x + (int)c.w < -40) continue;
        if (gFx.shadows) gfxBlob(x + (int)c.w / 2 + (gFx.rtShadows ? (int)(-L.toward * c.h * 0.4f) : 0), ground + 1, (int)c.w / 2 + 4, 2, (int)(100 * std::max(0.35f, L.strength)));
        if (gFx.ao) gfxBlob(x + (int)c.w / 2, ground + 1, (int)c.w / 2, 2, 70, bandsAo);
    }
}
// The runner's shadow on whatever is below: the nearest rooftop or the street.
static void gfxPlayerFx(float cx, float cy) {
    if (!(gFx.shadows || gFx.ao) || !P.alive) return;
    const float feet = P.y + 26.0f;
    float surf = STREET_GROUND_Y - 4.0f;
    for (const Building& b : bldNear(P.x, P.x)) if (P.x >= b.x && P.x <= b.x + b.w && b.roofY >= feet - 6.0f) surf = std::min(surf, b.roofY);
    const float d = std::max(0.0f, surf - feet);
    if (d > 280.0f) return;
    const int sx = (int)floorf(P.x - cx), sy = (int)floorf(surf - cy);
    const float k = 1.0f - d / 280.0f;
    if (gFx.shadows) {
        const GfxLight L = gfxLight(gSkyTime);
        const int off = gFx.rtShadows ? (int)clampValue(-L.toward * d / std::max(0.25f, L.tanE) * 0.3f, -46.0f, 46.0f) : 0;
        gfxBlob(sx + off, sy, 7 + (int)(d * 0.03f) + std::abs(off) / 2, 2, (int)(130 * k * (gFx.rtShadows ? std::max(0.35f, L.strength) : 0.8f)));
    }
    if (gFx.ao && d < 40.0f) gfxBlob(sx, sy, 6, 2, (int)(80 * (1.0f - d / 40.0f)), gFx.rtAo ? 4 : 2);   // contact darkening when nearly touching
}
static void drawWorldScene(float cx, float cy) {
    const int ground = (int)floorf(STREET_GROUND_Y - cy);
    const float swarm = sunsetAmount(gSkyTime);
    tileMod(255, 255 - (int)(48 * swarm), 255 - (int)(100 * swarm));   // golden-hour light on the facades
    for (auto& b : bldNear(cx - SCENE_MARGIN, cx + uvzWorldWidth + SCENE_MARGIN)) {
        if (b.x + b.w < cx - 160 || b.x > cx + uvzWorldWidth + 160) continue;
        int sx = (int)floorf(b.x - cx), sy = (int)floorf(b.roofY - cy);
        for (auto& o : b.obs) if (!o.solid) drawObsSheet(o, (int)floorf(o.x - cx), sy, gTime);
        drawFacade(b, sx, sy, ground);
        drawMasts(b, sx, sy);
        if (!b.landmark && !b.setbacks) drawNYCRooftop(b, sx, sy);
        drawFacadeDetail(b, sx, sy, ground);
        drawFireEscape(b, sx, sy, ground);
        if (b.landmark) drawLandmark(b, sx, sy); else if (b.setbacks) drawSetbacks(b, sx, sy); else drawRoofDetail(b, sx, sy);
        for (auto& o : b.obs) if (o.solid) drawObsSheet(o, (int)floorf(o.x - cx), sy, gTime);
    }
    tileMod(255, 255, 255);
    gfxBuildingFx(cx, cy);
    for (auto& b : bldNear(cx - CABLE_REACH, cx + uvzWorldWidth + SCENE_MARGIN)) drawCable(b, cx, cy);
}
static void drawTrafficCar(const TrafficCar& car, float cx, float cy) {
    // The vehicle art comes from the sprite sheet (baked by tools/gen_spritesheet.cpp, east- and west-facing, one per paint colour).
    // Only the dynamic parts are drawn here: brake lights, low-sun glints and night headlight beams. Hit boxes are unchanged.
    const float S = trafficScale(car.type);
    const int RW = (int)car.width, RH = (int)car.height;
    const int w = (int)lroundf(car.width / S), h = (int)lroundf(car.height / S);
    const int left = (int)floorf(car.x - cx) - RW / 2;
    const int dipPx = (int)lroundf(car.dip);
    const int bottom = (int)floorf(carBottomY(car) - cy), top = bottom - RH + dipPx;
    const bool east = car.dir > 0;
    { const int reach = (int)(48.0f * S) + 4;   // body plus the headlight beams; anything fully outside the view draws nothing
      if (left + RW + reach < 0 || left - reach > uvzWorldWidth) return; }
    auto R = [&](int lx, int ly, int lw, int lh, u32 c, int a = 255) {
        const int x0 = (int)lroundf(lx * S), x1 = (int)lroundf((lx + lw) * S), y0 = (int)lroundf(ly * S), y1 = (int)lroundf((ly + lh) * S);
        const int pw = std::max(lw > 0 ? 1 : 0, x1 - x0), ph = std::max(lh > 0 ? 1 : 0, y1 - y0);
        drawFilledRect(east ? left + x0 : left + RW - x0 - pw, top + y0, pw, ph, c, a);
    };
    const float night = 1.0f - daylightAmount(gSkyTime), sun = sunsetAmount(gSkyTime);
    static const u32 PAL[CAR_COLORS] = {0xE8B72D, 0xB7473F, 0x3F92B5, 0x747C86, 0x5D9B69, 0xC66F9A};
    int ci = -1; for (int i = 0; i < CAR_COLORS; i++) if (PAL[i] == car.color) ci = i;
    const int type = car.type % 5, lean = type == 4 ? clampValue((int)(car.speed / 120.0f), 0, 3) : 0;
    const SprRect* sp = &gCarSpr[type][std::max(ci, 0)][east ? 0 : 1][lean];
    if (!sp->ok) for (int i = 0; i < CAR_COLORS && !sp->ok; i++) sp = &gCarSpr[type][i][east ? 0 : 1][lean];   // unknown paint: any colour will do
    if (dipPx > 0 && sp->ok && gSheet) {            // suspension squash: body down, wheels stay on the road (upper 62% shifted, lower part fixed)
        const int split = sp->h * 62 / 100;
        SDL_Rect su = {sp->x, sp->y, sp->w, split}, du = {left, top, sp->w, split};
        SDL_Rect sl = {sp->x, sp->y + split, sp->w, sp->h - split}, dl = {left, top - dipPx + split, sp->w, sp->h - split};
        SDL_SetTextureAlphaMod(gSheet, 255); SDL_SetTextureColorMod(gSheet, 255, 255, 255);
        SDL_RenderCopy(uvzRenderer, gSheet, &su, &du); SDL_RenderCopy(uvzRenderer, gSheet, &sl, &dl);
    } else sprDraw(*sp, left, top);
    const bool braking = car.speed < 38.0f;
    if (type == 4) {
        if (braking) R(0, h - 12, 2, 2, 0xFF3B3B);
        if (night > 0.05f) {
            const int fx = east ? left + RW : left;
            drawLine((float)fx, top + (h - 11) * S, fx + car.dir * 38.0f * S, top + (h - 17) * S, 0xFFE8A0, (int)(night * 92.0f));
        }
        return;
    }
    if (braking) R(0, h - 13, 2, 3, 0xFF3B3B);
    if (sun > 0.1f) R(2, 11, w - 4, 1, 0xFFC87A, (int)(150 * sun));        // low sun glints along the bodywork
    if (night > 0.05f) {
        const int fx = east ? left + RW : left;
        const int beam = (int)(night * 92.0f);
        drawLine((float)fx, top + (h - 13) * S, fx + car.dir * 45.0f * S, top + (h - 21) * S, 0xFFE8A0, beam);
        drawLine((float)fx, top + (h - 9) * S, fx + car.dir * 45.0f * S, top + (h - 1) * S, 0xFFE8A0, beam / 2);
    }
}
static void drawStorefronts(float cx, int ground) {
    static const char* names[] = {"BODEGA", "PIZZA", "DELI", "LAUNDRY", "MARKET"};
    static const u32 signs[] = {0xD6483D, 0xD28C29, 0x2E718C, 0x4B8C73, 0x8A4773};
    const float night = 1.0f - daylightAmount(gSkyTime);
    for (const Building& b : bldNear(cx - 40.0f, cx + uvzWorldWidth + 40.0f)) {
        if (b.x + b.w < cx - 40 || b.x > cx + uvzWorldWidth + 40) continue;
        const int left = (int)floorf(b.x - cx), right = left + (int)b.w;
        int shop = 0;
        const int K = 2;   // life size: a shop door is ~1.8 m next to the 1.75 m stickman
        for (int x = left + 12; x + 76 * K < right - 6; x += 112 * K, ++shop) {
            const int y = ground - 52 * K;
            const u32 sign = signs[(b.seed + (u32)shop) % 5u];
            drawFilledRect(x, y + 17 * K, 76 * K, 35 * K, 0x282A30);
            drawFilledRect(x + 4 * K, y + 19 * K, 30 * K, 27 * K, 0x76A6B4);
            drawFilledRect(x + 39 * K, y + 19 * K, 31 * K, 27 * K, 0x3D424A);
            drawFilledRect(x + 4 * K, y + 17 * K, 66 * K, 2 * K, 0xD2C3A5);
            drawFilledRect(x, y + 5 * K, 76 * K, 11 * K, sign, (int)(190 + 55 * night));
            { const char* nm = names[(b.seed + (u32)shop) % 5u];
              textF(fitFont(FS_BOLD, nm, 2, 76 * K - 12), nm, x + 6 * K, y + 7 * K, 2, 0xFFF0C3, (int)(175 + 80 * night)); }
            for (int stripe = 0; stripe < 8; ++stripe)
                drawFilledRect(x + stripe * 10 * K, y + 16 * K, 5 * K, 3 * K, (stripe & 1) ? 0xF0D6A8 : sign);
            drawFilledRect(x + 34 * K, y + 20 * K, 3 * K, 32 * K, 0x574B42);
            if (night > 0.5f && ((shop + (int)b.seed) & 1))
                drawFilledRect(x + 5 * K, y + 20 * K, 28 * K, 25 * K, 0xFFE4A1, (int)(night * 44));
        }
    }
}
// One wooden street crate with its feet on the line y = ground (also used by tools/gen_spritesheet.cpp to bake the crate sprites).
static void drawCrate(const StreetCrate& c, int x, int ground) {
    const int y = ground, w = (int)c.w, h = (int)c.h;
    drawFilledRect(x - 1, y - 1, w + 2, 3, 0x000000, 60);                                   // contact shadow
    const int rows = c.variant == 2 ? 2 : 1;
    for (int r = 0; r < rows; r++) {
        const int bh = h / rows, by = y - bh * (r + 1);
        drawFilledRect(x, by, w, bh, 0x7A5236); drawFilledRect(x, by, w, 2, 0x9A6B46); drawFilledRect(x, by + bh - 2, w, 2, 0x4A301F);
        drawFilledRect(x, by, 2, bh, 0x4A301F); drawFilledRect(x + w - 2, by, 2, bh, 0x4A301F);
        for (int k = 1; k * 14 < w; k++) drawFilledRect(x + k * 14, by + 2, 1, bh - 4, 0x4A301F);
        drawLine((float)x + 2, (float)by + 2, (float)x + w - 3, (float)by + bh - 3, 0x5F3E28);
    }
}
static void drawStreetScene(float cx, float cy) {
    const int ground = (int)floorf(STREET_GROUND_Y - cy);
    const int roadTop = ground + 10;
    const float night = 1.0f - daylightAmount(gSkyTime);
    const u32 road = blendRgb(0x686A67, 0x242832, night);
    drawFilledRect(0, roadTop, uvzWorldWidth, uvzWorldHeight - roadTop, road);
    drawFilledRect(0, ground - 7, uvzWorldWidth, 18, blendRgb(0xB9AE94, 0x524D4A, night));
    drawFilledRect(0, ground + 8, uvzWorldWidth, 3, blendRgb(0xE0D2B6, 0x77716A, night));
    drawFilledRect(0, ground + 11, uvzWorldWidth, 2, 0x17191F);
    const int roadH = uvzWorldHeight - roadTop;
    (void)roadH;
    const int laneY = ground + (int)LANE_DIV_Y;                          // centre line between the two traffic lanes
    const int dashOffset = positiveModulo((int)floorf(cx), 64);
    for (int x = -dashOffset; x < uvzWorldWidth; x += 64)
        drawFilledRect(x, laneY, 28, 2, blendRgb(0xE8D9A6, 0x73717A, night), 210);
    gfxStreetFx(cx, cy, ground);
    drawStorefronts(cx, ground);
    drawCityLife(cx, ground);
    for (const TrafficSignal& signal : sigNear(cx - 120.0f, cx + uvzWorldWidth + 120.0f)) {
        const int sx = (int)floorf(signal.x - cx);
        if (sx < -120 || sx > uvzWorldWidth + 120) continue;
        for (int x = sx - 42; x <= sx + 42; x += 12)
            drawFilledRect(x, roadTop + 12, 6, std::min(25, std::max(0, uvzWorldHeight - roadTop - 12)), 0xE7E0C8, 190);
        const int subX = sx - 92;
        drawFilledRect(subX, ground - 18, 48, 14, 0x343B43);
        drawFilledRect(subX + 2, ground - 17, 44, 3, 0xD6C9AB);
        for (int step = 0; step < 4; ++step) drawFilledRect(subX + 6 + step * 8, ground - 12 + step * 2, 7, 2, 0xAAA08E);
        drawFilledRect(subX + 9, ground - 33, 30, 12, 0x183B35);
        textF(FS_TINY, "SUBWAY", subX + 12, ground - 30, 1, 0xC4E9A3);
        const bool eastGreen = trafficSignalGreen(signal, 1, gTime);
        const int poleX = sx + 30;
        drawFilledRect(poleX, ground - 86, 3, 82, 0x34383D);
        drawFilledRect(poleX - 6, ground - 90, 17, 28, 0x24262B);
        const u32 eastColor = eastGreen ? 0x43D17A : 0xED4A46;
        const u32 westColor = eastGreen ? 0xED4A46 : 0x43D17A;
        drawDisc(poleX + 2, ground - 84, 3, eastGreen ? 0x5A3E3C : 0xED4A46);
        drawDisc(poleX + 2, ground - 75, 3, 0xE6BA45);
        drawDisc(poleX + 2, ground - 66, 3, eastGreen ? 0x43D17A : 0x3D5543);
        drawFilledRect(poleX + 12, ground - 82, 7, 7, westColor);
        drawFilledRect(poleX + 13, ground - 81, 5, 5, 0xF7F1D8);
        if (night > 0.35f) {
            drawDisc(poleX + 2, ground - 84, 8, eastColor, (int)(night * 32));
            drawDisc(poleX + 13, ground - 78, 8, westColor, (int)(night * 28));
        }
        drawFilledRect(poleX - 2, ground - 4, 7, 4, 0x282B31);
    }
    for (const StreetCrate& c : crateNear(cx - 40.0f - 64.0f, cx + uvzWorldWidth + 40.0f)) {
        const int x = (int)floorf(c.x - cx);
        if (x > uvzWorldWidth + 40 || x + (int)c.w < -40) continue;
        static const float CW[4] = {28.0f, 46.0f, 28.0f, 60.0f}, CH[4] = {22.0f, 24.0f, 36.0f, 24.0f};   // the sizes baked on the sheet
        const bool stock = c.variant >= 0 && c.variant < 4 && c.w == CW[c.variant] && c.h == CH[c.variant];   // a crate capped lower by the difficulty tier is drawn from code
        if (!(stock && sprDrawProp(PROP_CRATE0 + c.variant, x, ground))) drawCrate(c, x, ground);
    }
    for (int lane = 0; lane < 2; ++lane)
        for (const TrafficCar& car : trafficCars) if (car.lane == lane)
            drawTrafficCar(car, cx, cy);
    gfxPlayerFx(cx, cy);
}
static void drawFallers(float cx, float cy) {
    for (const Faller& f : gFallers) {
        if (!f.alive) continue;
        const int x = (int)floorf(f.x - cx), y = (int)floorf(f.y - cy);
        if (x < -32 || x > uvzWorldWidth + 32 || y < -40 || y > uvzWorldHeight + 40) continue;   // sprite + halo ring fit inside this margin
        sprDraw(gFallerSpr[f.shirt & 3][((int)(f.t * 10.0f)) & 1], x - 6, y - 10);     // body + flailing arms from the sprite sheet
        if (f.t < 30.0f) { const int a = (int)(120 + 100 * sinf(f.t * 9.0f)); const int r = 16 + (int)(3 * sinf(f.t * 9.0f));
            for (int i = 0; i < 12; i++) { const float t = (float)i / 12.0f * 2.0f * pi; drawFilledRect(x + (int)(cosf(t) * r), y + (int)(sinf(t) * r), 2, 2, 0xFFE9A0, a); } }
    }
}
static void drawParticles(float cx, float cy) {
    drawFallers(cx, cy);
    for (auto& p : parts) if (p.alive) {
        const int px = (int)(p.x - cx), py = (int)(p.y - cy);
        if (px + p.sz < 0 || px > uvzWorldWidth || py + p.sz < 0 || py > uvzWorldHeight) continue;
        drawFilledRect(px, py, p.sz, p.sz, p.c, (int)(255 * clampValue(p.life / p.max, 0, 1)));
    }
    if (gImpactT > 0) {   // pixel shockwave + starburst where the player hit the street
        const float u = clampValue(1.0f - gImpactT / 0.55f, 0.0f, 1.0f);
        const int gx = (int)floorf(gImpactX - cx), gy = (int)floorf(STREET_GROUND_Y - cy), a = (int)(230 * (1.0f - u));
        const int r = 6 + (int)(52 * u);
        for (int i = 0; i < 44; i++) {
            const float t = (float)i / 44.0f * 2.0f * pi;
            drawFilledRect(gx + (int)(cosf(t) * r), gy + (int)(sinf(t) * r * 0.2f), 2, 2, 0xFFE9C8, a);
        }
        const int len = 8 + (int)(30 * u);
        for (int k = 0; k < 9; k++) {
            const float t = pi * (0.08f + 0.84f * k / 8.0f);
            drawLine((float)gx, (float)(gy - 3), gx - cosf(t) * len, gy - 3 - sinf(t) * len, (k & 1) ? 0xFFFFFF : 0xFF8A5C, a);
        }
    }
}

// Body tilt while swinging: the body hangs along the rope, and as speed builds it leans into the direction of travel (streamlined, head-first).
static float swingTiltDeg(const Player& p) {
    const float ropeAng = atan2f(p.ax - p.x, p.y - p.ay) * 180.0f / pi;
    const float sp = hypotf(p.vx, p.vy);
    const float velAng = clampValue(atan2f(p.vx, -p.vy) * 180.0f / pi, -70.0f, 70.0f);   // 0 = straight up, + = leaning right
    const float w = 0.35f * clampValue((sp - 500.0f) / 700.0f, 0.0f, 1.0f);
    const float lean = clampValue(sp * 0.012f, 0.0f, 16.0f) * (p.vx >= 0 ? 1.0f : -1.0f);
    return clampValue(lerpValue(ropeAng * 0.9f, velAng, w) + lean * (1.0f - w), -58.0f, 58.0f);
}
// Rope tension estimate 0..1 (centripetal + the weight along the rope): taut at the bottom of a fast swing, slack at the top or right after attaching.
static float webTension(const Player& p) {
    const float dx = p.x - p.ax, dy = p.y - p.ay, d = std::max(hypotf(dx, dy), 1.0f), nx = dx / d, ny = dy / d;
    const float vr = p.vx * nx + p.vy * ny, vt2 = std::max(0.0f, p.vx * p.vx + p.vy * p.vy - vr * vr);
    return clampValue((vt2 / std::max(p.ropeEff, 60.0f) + GRAV * std::max(ny, 0.0f)) / 2600.0f, 0.0f, 1.0f);
}
// Sag (px at the middle of the line) for a rope of the given length: a slack rope droops, a taut one is nearly straight.
static float webSagPx(float len, float tension, float settle) {
    const float slack = 1.0f - tension;
    return std::min(0.075f * len, 16.0f) * (0.12f + 0.88f * slack * slack) + 0.07f * len * settle * settle;
}
static void drawWebLine(float hx, float hy, float ax, float ay, float sag, int a = 255) {
    const float len = hypotf(ax - hx, ay - hy);
    const int n = (int)clampValue(len / 12.0f, 4.0f, 20.0f);
    const float cxp = (hx + ax) * 0.5f, cyp = (hy + ay) * 0.5f + 2.0f * sag;   // quadratic control point; the curve sags by `sag` at its middle
    float px = hx, py = hy;
    for (int i = 1; i <= n; i++) {
        const float t = (float)i / n, u = 1.0f - t;
        const float qx = u * u * hx + 2 * u * t * cxp + t * t * ax, qy = u * u * hy + 2 * u * t * cyp + t * t * ay;
        drawLine(px, py + 1, qx, qy + 1, 0x05060F, a * 220 / 255);
        drawLine(px, py, qx, qy, 0xFFFFFF, a);
        drawLine(px + 1, py, qx + 1, qy, 0xC8D8FF, a * 150 / 255);
        px = qx; py = qy;
    }
}
static float swingPoseT() {
    const Player& p = P;
    const float lean = clampValue(p.vx * 0.0001f, -0.1f, 0.15f);
    if (p.swinging && p.rope > 1.0f) return clampValue(0.5f + 0.5f * clampValue((p.x - p.ax) / (std::max(p.rope, 90.0f) * 0.8f), -1.0f, 1.0f) + lean, 0.0f, 1.0f);
    return clampValue(0.5f + (p.x - p.ax) / 80.0f + lean, 0.0f, 1.0f);
}
static void drawWindStreaks() {
    if (!P.alive || cfg.reduced) return;
    const float sp = hypotf(P.vx, P.vy);
    const float k = clampValue((sp - 650.0f) / 900.0f, 0.0f, 1.0f) * (P.onGround ? 0.0f : 1.0f);
    if (k <= 0.02f) return;
    const float zk = clampValue((1.0f - gZoom) / 0.1f, 0.0f, 1.0f);   // the more the camera has pulled back, the more lines
    const int n = 4 + (int)(8 * k) + (int)(8 * zk);
    const float dx = -P.vx / std::max(sp, 1.0f), dy = -P.vy / std::max(sp, 1.0f);
    for (int i = 0; i < n; i++) {
        const u32 h = hashCoordinates((u32)i, (u32)(gTime * 24.0), 7u);
        const float fx = (float)(h & 1023) / 1023.0f, fy = (float)((h >> 10) & 1023) / 1023.0f;

        const float x = (i & 1) ? fx * uvzWorldWidth * 0.22f : uvzWorldWidth * (1.0f - 0.22f * fx);
        const float y = fy * uvzWorldHeight;
        const float len = 10.0f + 26.0f * k + 18.0f * zk;
        drawLine(x, y, x + dx * len, y + dy * len, 0xFFFFFF, (int)(40 + 70 * k + 30 * zk));
    }
}
static void drawSense(float cx, float cy) {
    if (gSense < 0.08f || !P.alive) return;
    const int sx = (int)floorf(P.x - cx), sy = (int)floorf(P.y - cy) - 8;
    const float pulse = cfg.reduced ? 1.0f : 0.65f + 0.35f * sinf((float)gTime * (14.0f + 16.0f * gSense));
    const int a = (int)(255.0f * clampValue(gSense * 1.2f, 0.0f, 1.0f) * pulse);
    const u32 c = gSense > 0.6f ? 0xFF5A4A : 0xFFF2A0;
    for (int k = -1; k <= 1; k++) {
        const float an = gSenseAng + k * 0.34f, r0 = 22.0f, r1 = r0 + 6.0f + 10.0f * gSense;
        drawLine(sx + cosf(an) * r0, sy + sinf(an) * r0, sx + cosf(an) * r1, sy + sinf(an) * r1, c, a);
    }
    if (gSense > 0.6f) {
        const int ea = (int)(70.0f * gSense * pulse);
        drawFilledRect(0, 0, uvzWorldWidth, 2, 0xFF3030, ea); drawFilledRect(0, uvzWorldHeight - 2, uvzWorldWidth, 2, 0xFF3030, ea); drawFilledRect(0, 0, 2, uvzWorldHeight, 0xFF3030, ea); drawFilledRect(uvzWorldWidth - 2, 0, 2, uvzWorldHeight, 0xFF3030, ea);
        drawFilledRect(sx - 1, sy - 44, 3, 7, c, a); drawFilledRect(sx - 1, sy - 35, 3, 3, c, a);
    }
}
// ---- Swing dynamics layered on the smoothed swing pose: a fast swing stretches the body (straight legs trailing behind, braced
// free arm, a forward lean); a slow, rising swing near the top of the arc tucks the knees. Both ease in and out (no snapping). ----
struct SwingDyn { float stretch = 0, tuck = 0; };
static SwingDyn gSwingDyn;
static float swingStretchTarget(float speed) { return clampValue((speed - 380.0f) / 520.0f, 0.0f, 1.0f); }
static float swingTuckTarget(float speed, float vy) { return clampValue((420.0f - speed) / 260.0f, 0.0f, 1.0f) * (vy < 0.0f ? 1.0f : 0.35f); }
static void applySwingDynamics(StkPose& p, SwingDyn& d, bool swinging, float speed, float vy, float dt) {
    const float sT = swinging ? swingStretchTarget(speed) : 0.0f, tT = swinging ? swingTuckTarget(speed, vy) : 0.0f;
    const float k = 1.0f - expf(-7.0f * clampValue(dt, 0.0f, 0.05f));
    d.stretch += (sT - d.stretch) * k; d.tuck += (tT - d.tuck) * k;
    if (d.stretch < 0.001f && d.tuck < 0.001f) return;
    const float s = d.stretch, t = d.tuck * (1.0f - s);
    p.thF = lerpValue(p.thF, p.thF - 22.0f, s); p.thB = lerpValue(p.thB, p.thB - 26.0f, s);        // legs stream out behind
    p.shF = lerpValue(p.shF, p.thF + 2.0f, 0.8f * s); p.shB = lerpValue(p.shB, p.thB + 2.0f, 0.8f * s);   // ...and straighten
    p.foB = lerpValue(p.foB, p.upB, 0.7f * s);                                                      // free arm braced straight
    p.lean += 8.0f * s; p.tilt -= 4.0f * s;
    p.thF += 26.0f * t; p.shF -= 38.0f * t; p.thB += 18.0f * t; p.shB -= 44.0f * t; p.hipY -= 1.0f * t;   // knees drawn up
}
static void ironDrawArms(int sx, int sy, const StkPose& pose, double ang, bool harnessOnly);
static void ironDrawFx(float cx, float cy, int sx, int sy);
static void drawPlayerAndWeb(float cx, float cy) {
    Player& p = P;
    if (!p.alive && gRag.on) {   // ragdoll: joints are simulated in world space
        float X[J_N], Y[J_N];
        for (int i = 0; i < J_N; i++) { X[i] = gRag.x[i] - cx; Y[i] = gRag.y[i] - cy; }
        gStkMirror = false;
        drawStickmanJoints(X, Y, (int)floorf(X[J_HIP]), (int)floorf(Y[J_HIP]) + STK_FEET_Y);
        return;
    }
    int sx = (int)floorf(p.x - cx), sy = (int)floorf(p.y - cy);
    if (p.deadGround) sy += 21;   // lying down: the rotation pivot is the torso, so lower it onto the asphalt
    if (cfg.targetHints && haveTarget && !p.swinging && p.alive) {
        int ax = (int)(tgtX - cx), ay = (int)(tgtY - cy);
        int r = 5 + (int)(2 * sinf((float)gTime * 8));
        drawDisc(ax, ay, r + 2, 0x7FE0FF, 40); drawFilledRect(ax - 1, ay - 1, 3, 3, 0xFFFFFF);
    }
    double target = 0;
    bool spin = false;
    if (p.swinging) {
        const float sp = hypotf(p.vx, p.vy);
        (void)sp; target = swingTiltDeg(p);
    }
    else if (p.zipping) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.5f, -40, 30);
    else if (p.diving && p.alive && !p.onGround) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.75f, 12, 60);
    else if (!p.alive && p.deadGround) { target = 90.0; spin = false; }
    else if (!p.alive) { target = gTime * 500; spin = true; }
    else if (p.rollT > 0 && p.onGround) {
        const float u = clampValue(1.0f - p.rollT / p.rollDur, 0.0f, 1.0f);
        target = u * u * (3.0f - 2.0f * u) * 360.0; spin = true; sy += (int)(9.0f * sinf(u * pi));
    }
    else if (p.vaultOneT > 0 && !p.onGround) target = 8.0 + 14.0 * sinf(clampValue(1.0f - p.vaultOneT / p.vaultOneDur, 0.0f, 1.0f) * pi);
    else if (p.trickType && !p.onGround) {
        const float u = clampValue(p.trickT / p.trickDur, 0.0f, 1.0f), e = u * u * (3.0f - 2.0f * u);
        if (p.trickType == T_TWIST) target = 0;
        else { target = e * 360.0 * (p.trickType == T_BACK ? -1.0 : 1.0); spin = true; }
    }
    else if (!p.onGround && ((p.releaseFlip && p.releaseT > 0) || p.flipT > 0)) {
        float u = p.releaseFlip && p.releaseT > 0 ? 1.0f - p.releaseT / 0.5f : 1.0f - p.flipT / 0.55f;
        u = clampValue(u, 0, 1);
        target = (u * u * (3 - 2 * u)) * 360.0 * p.flipDir;
        spin = true;
    }
    else if (!p.onGround && p.releaseT > 0) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.6f, -30, 42);
    else if (!p.onGround) {
        const float sp = hypotf(p.vx, p.vy);
        if (sp > 650.0f) target = clampValue(atan2f(p.vy, std::max(p.vx, 60.0f)) * 180.0f / pi * 0.45f, -32, 32);
        else target = clampValue(p.vy * 0.01f, -8, 14);
    }
    const int fr = pickFrame();
    int style = 0;
    if (fr == F_RUN) style = p.runStyle;
    else if (fr == F_JUMP) style = p.jumpStyle;
    else if (fr == F_FALL) style = p.fallStyle;
    else if (fr == F_LAND) style = p.landStyle;
    else if (fr == F_SHOOT) style = p.shootStyle;
    else if (fr == F_SLIDE) style = p.slideStyle;
    else if (fr == F_SWING || fr == F_ATTACH) style = p.swingStyle;
    const float animPhase = fr == F_VAULT ? clampValue(1.0f - p.vaultOneT / std::max(0.01f, p.vaultOneDur), 0.0f, 1.0f) : (p.wallCling ? p.climbPhase : gRunPhase);
    const float animSwing = (fr == F_LAND || fr == F_HERO) ? p.landDepth : swingPoseT();
    StkPose pose = stkAdvance(gPlayerAnim, fr, animPhase, animSwing, style, p.jit);
    applySwingDynamics(pose, gSwingDyn, fr == F_SWING && p.swinging, hypotf(p.vx, p.vy), p.vy, gPlayerAnim.dt);
    double ang = stkAngle(gPlayerAnim, target, spin);
    float hfx, hfy;
    gStkMirror = p.wallCling && p.wallDir < 0;
    if (p.trickType == T_TWIST && !p.onGround) gStkMirror = ((int)(clampValue(p.trickT / p.trickDur, 0.0f, 0.99f) * 5.0f) & 1) != 0;
    if (p.alive) { gLastPose = pose; gLastAng = ang; gLastMirror = gStkMirror; }   // seeds the ragdoll if the next hit is fatal
    stickHand(pose, sx, sy + 26, ang, hfx, hfy);
    if (p.swinging) {
        const float hx = hfx, hy = hfy, ax = p.ax - cx, ay = p.ay - cy;
        const float settle = clampValue(p.attachT / 0.18f, 0.0f, 1.0f);   // just after attaching the line is still settling
        drawWebLine(hx, hy, ax, ay, webSagPx(hypotf(ax - hx, ay - hy), webTension(p), settle));
    } else if (p.zipping && p.alive) {
        int wx = (int)(p.zipX - cx), wy = (int)(p.zipY - cy);
        drawLine(hfx, hfy + 1, wx, wy + 1, 0x05060F, 220); drawLine(hfx, hfy, wx, wy, 0xFFFFFF);
        drawLine(hfx + 1, hfy, wx + 1, wy, 0xC8D8FF, 150);
        drawDisc(wx, wy, 3, 0xDCEBFF);
    } else if (p.webFlying && p.alive) {
        int wx = (int)(p.webX - cx), wy = (int)(p.webY - cy);
        drawWebLine(hfx, hfy, (float)wx, (float)wy, 0.05f * hypotf(wx - hfx, wy - hfy) * (1.0f - clampValue(p.webT / std::max(p.webDur, 0.01f), 0.0f, 1.0f)));
        drawDisc(wx, wy, 3, 0xDCEBFF); drawFilledRect(wx - 1, wy - 1, 3, 3, 0xFFFFFF);
    } else if (p.shootT > 0 && p.alive) {
        float u = 1 - p.shootT / 0.14f;
        drawLine(hfx, hfy, hfx + 70 * u, hfy - 70 * u, 0xFFFFFF, 200);
    }
    for (auto& t : gTrail) if (t.t > 0) {
        const float u = clampValue(t.t / t.max, 0, 1);
        const int sz = u > 0.6f ? 3 : (u > 0.3f ? 2 : 1);
        drawFilledRect((int)(t.x - cx) - sz / 2, (int)(t.y - cy) - sz / 2, sz, sz, t.c, (int)(190 * u));
    }
    ironDrawFx(cx, cy, sx, sy);                          // Iron Arms: speed lines and the launch ring, behind the body
    if (p.alive) ironDrawArms(sx, sy, pose, ang, false); // the four arms sit behind the runner
    drawHalo(sx, sy - 6);
    drawStickman(pose, sx, sy + 26, ang);
    if (p.alive) ironDrawArms(sx, sy, pose, ang, true);  // the harness plate on his back, in front of the arms
    gStkMirror = false;
    if (p.vx > 420 && p.alive)
        for (int i = 0; i < 4; i++) drawFilledRect(sx - 40 - (int)hashCoordinates(i, (u32)(gTime * 20), 1) % 50, sy - 30 + i * 14, 20 + (int)hashCoordinates(i, 4, 4) % 20, 1, 0xFFFFFF, 70);
}

static const u32 UI_INK = 0x070A14, UI_WHITE = 0xF4F7FF, UI_DIM = 0x8C96B8, UI_RED = 0xE8262F, UI_RED_D = 0x6A0E16;

static void hline(int x, int y, int w, u32 c, int a) { drawFilledRect(x, y, w, 1, c, a); }
static void slantBar(int x, int y, int w, int h, int shear, u32 c, int a) {
    for (int r = 0; r < h; r++) {
        int off = (h - 1 - r) * shear / std::max(1, h - 1);
        drawFilledRect(x + off, y + r, w - shear, 1, c, a);
    }
}
static void ringDraw(int cx, int cy, int r, int th, u32 c, int a) {
    int ri = r - th;
    static std::vector<SDL_Rect> rows; rows.clear();   // the row segments are disjoint: one batched fill, same pixels as one call per segment
    for (int dy = -r; dy <= r; dy++) {
        int xo = (int)sqrtf((float)(r * r - dy * dy));
        if (ri > 0 && std::abs(dy) < ri) {
            int xi = (int)sqrtf((float)(ri * ri - dy * dy));
            if (xo - xi > 0) { rows.push_back({cx - xo, cy + dy, xo - xi, 1}); rows.push_back({cx + xi + 1, cy + dy, xo - xi, 1}); }
        } else rows.push_back({cx - xo, cy + dy, xo * 2 + 1, 1});
    }
    if (rows.empty()) return;
    setDrawColor(c, a);
    SDL_RenderFillRects(uvzRenderer, rows.data(), (int)rows.size());
}
static void thickLine(float x0, float y0, float x1, float y1, int r, u32 c, int a = 255) {
    float dx = x1 - x0, dy = y1 - y0;
    int n = std::max(1, (int)hypotf(dx, dy));
    for (int i = 0; i <= n; i++) { float t = (float)i / n; drawDisc((int)lroundf(x0 + dx * t), (int)lroundf(y0 + dy * t), r, c, a); }
}
static void ellipseFill(int cx, int cy, int rx, int ry, u32 c) {
    ry = std::max(1, ry);
    for (int dy = -ry; dy <= ry; dy++) {
        int dx = (int)(rx * sqrtf(std::max(0.0f, 1.0f - (float)(dy * dy) / (float)(ry * ry))));
        drawFilledRect(cx - dx, cy + dy, dx * 2 + 1, 1, c);
    }
}

// ---- Iron Arms: pose targets, spring-driven joints, drawing ----
// Every arm angle is measured in the plane spanned by "back" (0) and "up" (+pi/2), so the same numbers work whatever the body angle or facing.
static void ironArmTarget(int k, float& a1, float& a2, float& ext) {
    // Marvel's Spider-Man (Iron Spider) rig: four legs from ONE mount between the shoulder blades, fanned behind the runner like spider legs.
    // The two upper legs rise up and arch over, the two lower legs sweep out and down; each has a high knee and a pointed tip.
    static const float fan[4] = {1.20f, 0.62f, 0.06f, -0.50f};      // first-segment angle per leg (0 = straight back, +up), top leg first
    static const float bend[4] = {0.55f, 0.35f, -0.35f, -0.55f};    // second segment bends further out (upper legs curl up, lower legs curl down)
    static const float off[4] = {-0.36f, -0.12f, 0.12f, 0.36f};
    const Player& p = P;
    const bool hold = gIronFxT > gIronFxDur * 0.38f;              // arms stay out for the first ~60 % of the effect, then fold back
    if (gIronKind == 1 && hold) { a1 = -1.58f + off[k] * 1.9f; a2 = a1 * 0.92f; ext = 1.0f; return; }   // planted below the feet, fanned out
    if (gIronKind == 2 && hold) { a1 = 0.10f + off[k] * 0.9f; a2 = a1 + 0.12f; ext = 1.0f; return; }    // stretched straight back
    const float t = (float)gTime;
    if (p.wallCling) { a1 = fan[k] * 0.5f + 0.3f; a2 = a1 - 2.0f; ext = 0.0f; return; }
    if (p.swinging) { a1 = fan[k] + 0.10f * sinf(t * 3.2f + k * 1.3f); a2 = a1 + bend[k]; ext = 0.7f; return; }   // fanned wide, swaying
    if (p.onGround) {                                              // tucked tight against the back, bobbing with the stride
        a1 = 0.25f + k * 0.18f + 0.08f * sinf(gRunPhase * 6.2832f + k * 0.9f); a2 = a1 - 2.0f; ext = 0.0f; return;
    }
    const float v = clampValue(p.vy / 1000.0f, -1.0f, 1.0f);       // airborne: drag lifts the fan while falling, trails it down while rising
    a1 = fan[k] + 0.45f * v + 0.06f * sinf(t * 7.0f + k * 1.7f); a2 = a1 + bend[k]; ext = 0.55f + 0.2f * fabsf(v);
}
[[maybe_unused]] static void ironArmsSnap() { for (int k = 0; k < 4; k++) ironArmTarget(k, gIronArm[k].a1, gIronArm[k].a2, gIronArm[k].ext); }
static void ironArmsUpdate(float dt) {
    {   // the arms and harness are tucked away completely unless a launch is in progress
        const float target = (gIronFxT > 0.0f && P.alive) ? 1.0f : 0.0f;
        const float rate = target > gIronVis ? 14.0f : 7.0f;
        gIronVis += (target - gIronVis) * (1.0f - expf(-rate * dt));
        if (target == 0.0f && gIronVis < 0.02f) gIronVis = 0.0f;
    }
    for (int k = 0; k < 4; k++) {
        float a1, a2, ex; ironArmTarget(k, a1, a2, ex);
        const float f = 1.0f - expf(-(20.0f - 2.5f * k) * dt);       // the lower arms lag a little: natural follow-through
        gIronArm[k].a1 += (a1 - gIronArm[k].a1) * f; gIronArm[k].a2 += (a2 - gIronArm[k].a2) * f; gIronArm[k].ext += (ex - gIronArm[k].ext) * f;
    }
}
static void ironDrawArms(int sx, int sy, const StkPose& pose, double ang, bool harnessOnly) {
    if (!ironUnlocked()) return;                                    // locked: the runner has no arms at all
    if (gState != PLAYING) { gIronVis = 0.0f; return; }             // menus and pause: hidden
    if (gIronVis < 0.02f) return;                                   // not in use: no arms, no harness
    float X[J_N], Y[J_N];
    stkPlace(pose, (float)sx, (float)(sy + 26), ang, X, Y);
    const float a = (float)(ang * pi / 180.0), c = cosf(a), sn = sinf(a);
    float bx = -c, by = -sn, ux = sn, uy = -c;                      // unit vectors "back" and "up" in screen space
    if (gStkMirror) { bx = -bx; ux = -ux; }
    const float hx = X[J_HIP], hy = Y[J_HIP], tx = X[J_NECK] - hx, ty = Y[J_NECK] - hy;
    static const float along[4] = {0.90f, 0.87f, 0.84f, 0.81f};   // one mount between the shoulder blades, sockets only a hair apart
    const float glow = gIronFxT > 0 ? clampValue(gIronFxT / gIronFxDur, 0.0f, 1.0f) : 0.0f;
    float rx[4], ry[4];
    for (int k = 0; k < 4; k++) { rx[k] = hx + tx * along[k] + bx * 3.5f; ry[k] = hy + ty * along[k] + by * 3.5f; }
    if (harnessOnly) {                                              // backpack plate + the four shoulder sockets
        thickLine(hx + tx * 0.74f + bx * 2.5f, hy + ty * 0.74f + by * 2.5f, hx + tx * 0.96f + bx * 2.5f, hy + ty * 0.96f + by * 2.5f, 2, 0x2B3347);   // compact back plate
        drawDisc((int)lroundf(hx + tx * 0.86f + bx * 3.5f), (int)lroundf(hy + ty * 0.86f + by * 3.5f), 2, 0x9FB2D0);
        return;
    }
    for (int k = 3; k >= 0; k--) {
        const IronArm& A = gIronArm[k];
        const float l1 = (10.0f + 12.0f * A.ext) * gIronVis, l2 = (10.0f + 14.0f * A.ext) * gIronVis;
        const float d1x = bx * cosf(A.a1) + ux * sinf(A.a1), d1y = by * cosf(A.a1) + uy * sinf(A.a1);
        const float d2x = bx * cosf(A.a2) + ux * sinf(A.a2), d2y = by * cosf(A.a2) + uy * sinf(A.a2);
        const float jx = rx[k] + d1x * l1, jy = ry[k] + d1y * l1, ex = jx + d2x * l2, ey = jy + d2y * l2;
        const u32 metal = (k & 1) ? 0x8C9AB4 : 0xB4C2DA;
        thickLine(rx[k], ry[k], jx, jy, 2, 0x131826); thickLine(jx, jy, ex, ey, 2, 0x131826);
        thickLine(rx[k], ry[k], jx, jy, 1, metal);   thickLine(jx, jy, ex, ey, 1, metal);
        drawDisc((int)lroundf(jx), (int)lroundf(jy), 2, 0x131826); drawDisc((int)lroundf(jx), (int)lroundf(jy), 1, 0xE8F0FF);   // elbow
        thickLine(ex, ey, ex + d2x * 6.0f, ey + d2y * 6.0f, 1, 0xE8F0FF);   // pointed spear tip
        if (glow > 0 && A.ext > 0.6f) drawDisc((int)lroundf(ex), (int)lroundf(ey), 3, 0x7FE0FF, (int)(150 * glow));   // thruster glow at the claw
    }
}
// Speed lines trail the launch direction; a ring expands from the point of the launch.
static void ironDrawFx(float cx, float cy, int sx, int sy) {
    if (gIronRingT > 0) {
        const float u = 1.0f - gIronRingT / 0.35f;
        ringDraw((int)(gIronRingX - cx), (int)(gIronRingY - cy), (int)(8 + 64 * u), 2, 0xBFE4FF, (int)(210 * (1.0f - u)));
        ringDraw((int)(gIronRingX - cx), (int)(gIronRingY - cy), (int)(4 + 40 * u), 1, 0xFFFFFF, (int)(160 * (1.0f - u)));
    }
    if (gIronFxT <= 0 || !P.alive) return;
    const float k = clampValue(gIronFxT / gIronFxDur, 0.0f, 1.0f);
    float vx = P.vx, vy = P.vy; const float sp = std::max(hypotf(vx, vy), 1.0f);
    vx /= sp; vy /= sp;
    const float px = -vy, py = vx;
    const u32 seed = (u32)(gTime * 45.0);
    const int n = cfg.reduced ? 6 : (gIronKind == 2 ? 16 : 11);
    for (int i = 0; i < n; i++) {
        const u32 h = hashCoordinates((u32)i, seed, 91u);
        const float off = ((h & 255) / 255.0f - 0.5f) * 110.0f, back = 12.0f + ((h >> 8) & 255) / 255.0f * 80.0f, len = 20.0f + ((h >> 16) & 255) / 255.0f * 70.0f * (0.5f + k);
        const float x0 = sx - vx * back + px * off, y0 = sy - vy * back + py * off;
        drawLine(x0, y0, x0 - vx * len, y0 - vy * len, (i & 1) ? 0xFFFFFF : 0xBFE4FF, (int)(190 * k));
    }
}
static void drawSpider(int cx, int cy, float s, u32 c) {
    static const float L[5][4][2] = {
        {{0.06f, -0.20f}, {0.26f, -0.60f}, {0.46f, -0.86f}, {0.80f, -1.00f}},
        {{0.09f, -0.10f}, {0.46f, -0.38f}, {0.82f, -0.44f}, {1.00f, -0.72f}},
        {{0.10f, 0.00f}, {0.56f, -0.04f}, {0.90f, 0.12f}, {1.04f, 0.42f}},
        {{0.11f, 0.14f}, {0.48f, 0.38f}, {0.74f, 0.68f}, {0.80f, 1.00f}},
        {{0.09f, 0.30f}, {0.26f, 0.68f}, {0.32f, 0.94f}, {0.26f, 1.14f}}};
    int r = std::max(0, (int)lroundf(s * 0.07f));
    for (int side = -1; side <= 1; side += 2)
        for (int i = 0; i < 5; i++)
            for (int k = 0; k < 3; k++)
                thickLine(cx + side * L[i][k][0] * s, cy + L[i][k][1] * s * 0.9f, cx + side * L[i][k + 1][0] * s, cy + L[i][k + 1][1] * s * 0.9f, r, c);
    ellipseFill(cx, cy + (int)(0.34f * s), std::max(1, (int)(0.17f * s)), (int)(0.38f * s), c);
    ellipseFill(cx, cy - (int)(0.10f * s), std::max(1, (int)(0.10f * s)), (int)(0.15f * s), c);
    ellipseFill(cx, cy - (int)(0.30f * s), std::max(1, (int)(0.06f * s)), (int)(0.07f * s), c);
}
static void drawWebIcon(int cx, int cy, float r, u32 c, int a = 255) {
    for (int i = 0; i < 8; i++) { float an = i * pi / 4; drawLine((float)cx, (float)cy, cx + cosf(an) * r, cy + sinf(an) * r, c, a); }
    for (int k = 1; k <= 3; k++) {
        float rr = r * k / 3.0f;
        for (int i = 0; i < 8; i++) {
            float a0 = i * pi / 4, a1 = (i + 1) * pi / 4;
            drawLine(cx + cosf(a0) * rr, cy + sinf(a0) * rr, cx + cosf(a1) * rr, cy + sinf(a1) * rr, c, a);
        }
    }
}
static int textWSp(const char* s, int sc, int gap) { int n = (int)strlen(s); return n <= 0 ? 0 : n * (6 * sc + gap) - gap - sc; }
static void textSp(const char* s, int x, int y, int sc, u32 c, int gap, int a = 255) {
    char b[2] = {0, 0};
    for (; *s; ++s) { b[0] = *s; text(b, x, y, sc, c, a); x += 6 * sc + gap; }
}
static void textSpC(const char* s, int cx, int y, int sc, u32 c, int gap, int a = 255) { textSp(s, cx - textWSp(s, sc, gap) / 2, y, sc, c, gap, a); }

static float easeOut(float t) { t = clampValue(t, 0, 1); return 1 - (1 - t) * (1 - t); }

static void drawButton(const Btn& b, int idx, bool foc, bool pr) {
    float e = easeOut((uiAge - idx * 0.05f) / 0.22f);
    if (e <= 0) return;
    int a = (int)(255 * e), ox = (int)((1 - e) * -22);
    bool hot = foc || pr;
    if (b.style & 16) { hot = false; a = a * 120 / 255; }
    int x = b.x + ox;
    if (b.kind == 5) {
        drawFilledRect(x, b.y, b.w, b.h, hot ? UI_RED : UI_WHITE, hot ? a : 70 * a / 255);
        drawFilledRect(x + 1, b.y + 1, b.w - 2, b.h - 2, UI_INK, a);
        int tw = measureTextWidth(b.label, 2);
        text(b.label, x + (b.w - tw) / 2, b.y + (b.h - 14) / 2, 2, UI_WHITE, a);
        return;
    }
    if (b.kind == 4) {
        int cx = x + b.w / 2, cy = b.y + b.h / 2, r = b.w / 2;
        drawDisc(cx, cy, r, hot ? UI_WHITE : UI_INK, hot ? 245 * a / 255 : 170 * a / 255);
        ringDraw(cx, cy, r, 2, hot ? UI_RED : UI_WHITE, a);
        drawWebIcon(cx, cy, (float)(r - 6), hot ? UI_INK : UI_WHITE, a);
        text(b.label, cx - measureTextWidth(b.label, 1) / 2, b.y + b.h + 4, 1, hot ? UI_WHITE : UI_DIM, a);
        return;
    }
    if (b.kind == 1) {
        char v[16];
        snprintf(v, sizeof v, "%d%%", (int)lroundf(*b.val * 100));
        text(b.label, x, b.y + 3, 1, hot ? UI_WHITE : UI_DIM, a);
        text(v, x + b.w - measureTextWidth(v, 1), b.y + 3, 1, UI_WHITE, a);
        int ty = b.y + 22, fw = (int)((*b.val - b.vmin) / (b.vmax - b.vmin) * b.w);
        drawFilledRect(x, ty + 1, b.w, 2, UI_WHITE, 55 * a / 255);
        drawFilledRect(x, ty, fw, 4, UI_WHITE, a);
        slantBar(x + fw - 4, ty - 5, 8, 14, 3, hot ? UI_WHITE : UI_RED, a);
        hline(x, b.y + b.h - 1, b.w, UI_WHITE, 26 * a / 255);
        if (hot) drawFilledRect(x - 7, b.y + 4, 2, b.h - 10, UI_RED, a);
        return;
    }
    if (b.kind == 2) {
        int sc = fitTextScale(b.label, b.w - 56, 2);
        text(b.label, x, b.y + (b.h - 7 * sc) / 2, sc, hot ? UI_WHITE : 0xC9D1EE, a);
        bool on = *b.flag;
        int tx = x + b.w - 34, ty = b.y + b.h / 2 - 7;
        drawFilledRect(tx, ty, 32, 14, on ? UI_RED : UI_WHITE, on ? a : 45 * a / 255);
        drawFilledRect(tx + (on ? 19 : 3), ty + 3, 10, 8, on ? UI_WHITE : UI_DIM, a);
        hline(x, b.y + b.h - 1, b.w, UI_WHITE, 26 * a / 255);
        if (hot) drawFilledRect(x - 7, b.y + 4, 2, b.h - 10, UI_RED, a);
        return;
    }
    if (b.kind == 3) {
        bool cap = gRebind == b.act && gRebind >= 0;
        text(b.label, x, b.y + 2, 1, hot || cap ? UI_WHITE : UI_DIM, a);
        int by = b.y + 14, bh2 = b.h - 16;
        if (cap) drawFilledRect(x, by, b.w, bh2, UI_RED, a);
        else drawFilledRect(x, by, b.w, bh2, UI_WHITE, (hot ? 38 : 14) * a / 255);
        int oa = (cap ? 255 : (hot ? 230 : 90)) * a / 255;
        hline(x, by, b.w, UI_WHITE, oa); hline(x, by + bh2 - 1, b.w, UI_WHITE, oa);
        drawFilledRect(x, by, 1, bh2, UI_WHITE, oa); drawFilledRect(x + b.w - 1, by, 1, bh2, UI_WHITE, oa);
        char k[24];
        if (cap) snprintf(k, sizeof k, "%s", (((int)(gTime * 3)) & 1) ? "PRESS A KEY" : "PRESS A KEY.");
        else keyLabel(ctl.key[b.act], k, sizeof k);
        int sc = fitTextScale(k, b.w - 12, 2);
        text(k, x + (b.w - measureTextWidth(k, sc)) / 2, by + (bh2 - 7 * sc) / 2, sc, UI_WHITE, a);
        return;
    }
    int w = b.w;
    if (b.style & 8) {
        bool act = b.id == (ctlTab == 0 ? B_TAB_KEYS : B_TAB_TOUCH);
        if (act) slantBar(x, b.y, w, b.h, b.h / 4, UI_WHITE, a);
        else if (hot) slantBar(x, b.y, w, b.h, b.h / 4, UI_WHITE, 60 * a / 255);
        int sc = fitTextScale(b.label, w - 24, 2);
        text(b.label, x + (w - measureTextWidth(b.label, sc)) / 2 + b.h / 8, b.y + (b.h - 7 * sc) / 2, sc, act ? UI_INK : UI_WHITE, a);
        return;
    }
    if (b.style & 4) {
        drawFilledRect(x, b.y, w, b.h, UI_WHITE, hot ? a : 0);
        int oa = (hot ? 255 : 100) * a / 255;
        hline(x, b.y, w, UI_WHITE, oa); hline(x, b.y + b.h - 1, w, UI_WHITE, oa);
        drawFilledRect(x, b.y, 1, b.h, UI_WHITE, oa); drawFilledRect(x + w - 1, b.y, 1, b.h, UI_WHITE, oa);
        int sc = fitTextScale(b.label, w - 16, 2);
        text(b.label, x + (w - measureTextWidth(b.label, sc)) / 2, b.y + (b.h - 7 * sc) / 2, sc, hot ? UI_INK : UI_WHITE, a);
        return;
    }
    int shear = b.h / 4;
    const bool cta = (b.style & 2) != 0;
    if (hot) slantBar(x, b.y, w, b.h, shear, UI_WHITE, 245 * a / 255);
    else if (cta) slantBar(x, b.y, w, b.h, shear, UI_RED, 235 * a / 255);
    else { drawFilledRect(x, b.y, w, b.h - 1, UI_WHITE, 10 * a / 255); hline(x, b.y + b.h - 1, w, UI_WHITE, 45 * a / 255); }
    const FontStyle bf = cta ? FS_COMIC : FS_ITAL;   // the slanted bars get slanted lettering; the call-to-action gets the comic outline
    int sc = fitFontScale(bf, b.label, w - 40, (b.style & 2) ? 3 : 2);
    int tw = fontWidth(bf, b.label, sc), ty = b.y + (b.h - 7 * sc) / 2;
    int tx = (b.style & 1) ? x + (w - tw) / 2 : x + 16 + (hot ? 4 : 0);
    textF(bf, b.label, tx, ty, sc, hot ? UI_INK : UI_WHITE, a);
    if (hot) {
        int o = (int)(1 + 1.5f * sinf((float)gTime * 7));
        text(">", x + w - shear - 18 + o, b.y + (b.h - 14) / 2, 2, UI_RED);
    }
}
static void drawButtons() {
    for (size_t i = 0; i < btns.size(); i++) {
        bool pr = false;
        for (auto& t : tch) if (t.on && t.btn == (int)i && (t.role == R_UI || t.role == R_SLIDER)) pr = true;
        drawButton(btns[i], (int)i, gFocus == (int)i, pr);
    }
}
// Hand-placed pixel icons: Bresenham lines of a square pen (odd width), mirrored about the centre so nothing is off by a pixel.
static void pixDot(int x, int y, int t, u32 c) { drawFilledRect(x - t / 2, y - t / 2, t, t, c); }
static void pixLine(int x0, int y0, int x1, int y1, int t, u32 c) {
    const int dx = std::abs(x1 - x0), dy = -std::abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
    int err = dx + dy;
    static std::vector<SDL_Rect> dots; dots.clear();   // opaque single-colour dots: order is irrelevant, so one batched fill per line
    for (;;) {
        if (t > 0) dots.push_back({x0 - t / 2, y0 - t / 2, t, t});
        if (x0 == x1 && y0 == y1) break;
        const int e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += sx; }
        if (e2 <= dx) { err += dx; y0 += sy; }
    }
    if (dots.empty()) return;
    setDrawColor(c);
    SDL_RenderFillRects(uvzRenderer, dots.data(), (int)dots.size());
}
static void pixSpider(int cx, int cy, int s, int t, u32 c) {   // s = half the icon height
    static const int L[4][3][2] = {   // legs in tenths of s: root, knee, foot (right side; the left is the mirror)
        {{1, -3}, {5, -8}, {9, -10}}, {{1, -1}, {7, -4}, {10, -3}}, {{1, 1}, {7, 2}, {10, 7}}, {{1, 3}, {5, 7}, {7, 10}}};
    for (int side = -1; side <= 1; side += 2)
        for (int i = 0; i < 4; i++) {
            int px = cx + side * L[i][0][0] * s / 10, py = cy + L[i][0][1] * s / 10;
            for (int k = 1; k < 3; k++) {
                const int qx = cx + side * L[i][k][0] * s / 10, qy = cy + L[i][k][1] * s / 10;
                pixLine(px, py, qx, qy, t, c); px = qx; py = qy;
            }
        }
    ellipseFill(cx, cy + s * 3 / 10, std::max(2, s * 2 / 10), std::max(3, s * 4 / 10), c);   // abdomen
    ellipseFill(cx, cy - s * 3 / 10, std::max(2, s * 15 / 100), std::max(2, s * 2 / 10), c); // head
}
static void drawCtlButton(int i, bool pressed, bool editing) {
    float fx, fy, fr; ctlPos(i, fx, fy, fr);
    int cx = (int)fx, cy = (int)fy, r = (int)fr;
    float al = ctl.alpha, k = ctl.scale;
    int fillA = (int)(110 * al) + 120, ringA = (int)(200 * clampValue(al + 0.1f, 0, 1));
    drawDisc(cx + 1, cy + 2, r, 0x000000, 60);                          // soft drop shadow
    drawDisc(cx, cy, r, pressed ? UI_WHITE : UI_INK, pressed ? 235 : fillA);
    ringDraw(cx, cy, r, 1, pressed ? UI_RED : UI_WHITE, pressed ? 255 : ringA);
    if (!pressed) ringDraw(cx, cy, r - 4, 1, UI_WHITE, 28);              // inner bezel
    if (editing) ringDraw(cx, cy, r + 5, 1, UI_WHITE, 140);
    u32 ic = pressed ? UI_INK : UI_WHITE;
    const int t = 1 + 2 * (int)(fr / 24.0f);   // odd stroke width, so every icon is symmetric about the button centre
    if (i == 0) pixSpider(cx, cy, (int)lroundf(fr * 0.50f), t, ic);
    else if (i == 1) {                         // JUMP: two stacked chevrons
        const int w = (int)lroundf(fr * 0.40f), h = (int)lroundf(w * 0.75f), sep = h + t, top = -(sep + h) / 2;
        for (int j = 0; j < 2; j++) {
            const int ay = cy + top + j * sep;
            pixLine(cx - w, ay + h, cx, ay, t, ic); pixLine(cx, ay, cx + w, ay + h, t, ic);
        }
    } else {                                   // SLIDE: arrow pointing right with wind lines trailing behind it
        const int W = (int)lroundf(fr * 0.62f);   // half width; coordinates below are in tenths of W
        auto X = [&](int v) { return cx + v * W / 10; };
        auto Y = [&](int v) { return cy + v * W / 10; };
        pixLine(X(-10), Y(-5), X(-4), Y(-5), t, ic); pixLine(X(-10), Y(5), X(-4), Y(5), t, ic);   // wind lines
        pixLine(X(-7), Y(0), X(10), Y(0), t, ic);                                                // shaft
        pixLine(X(10), Y(0), X(4), Y(-6), t, ic); pixLine(X(10), Y(0), X(4), Y(6), t, ic);       // head
    }
}
static void drawRotateScreen() {
    drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x070A1E);
    int cx = uvzWorldWidth / 2, cy = uvzWorldHeight / 2 - 30;
    float a = sinf((float)gTime * 2.0f);
    drawFilledRect(cx - 12, cy - 20, 24, 40, 0xE8ECFF); drawFilledRect(cx - 10, cy - 17, 20, 30, 0x0E1432); drawFilledRect(cx - 3, cy + 15, 6, 2, 0xE8ECFF);
    int ax = cx + 36 + (int)(a * 6);
    text(">", ax, cy - 8, 3, UI_RED);
    drawCenteredText("ROTATE YOUR", cx, cy + 50, fitTextScale("ROTATE YOUR", uvzWorldWidth - 20, 3), 0xFFFFFF);
    drawCenteredText("DEVICE", cx, cy + 50 + 26, fitTextScale("DEVICE", uvzWorldWidth - 20, 3), 0xFFFFFF);
    drawCenteredText("TO LANDSCAPE", cx, cy + 50 + 52, fitTextScale("TO LANDSCAPE", uvzWorldWidth - 20, 2), UI_RED);
}
static void drawLogoBig() {
    int sc = (int)clampValue(uvzWorldWidth / 120.0f, 3, 6);
    float s = clampValue(uvzWorldHeight * 0.15f, 26, 54);
    int cy = (int)(uvzWorldHeight * 0.30f);
    drawHalo(uvzWorldWidth / 2, cy);
    drawSpider(uvzWorldWidth / 2 + 2, cy + 3, s, UI_RED_D);
    drawSpider(uvzWorldWidth / 2, cy, s, UI_WHITE);
    int ty = cy + (int)s + 16;
    textSpCF(FS_BOLD, "STICKMAN", uvzWorldWidth / 2 + 2, ty + 2, sc, UI_RED_D, sc);
    textSpCF(FS_BOLD, "STICKMAN", uvzWorldWidth / 2, ty, sc, UI_WHITE, sc);
    int y2 = ty + 7 * sc + 10, w2 = fontWidthSp(FS_BOLD, "STICKMAN", sc, sc);
    slantBar(uvzWorldWidth / 2 - w2 / 2, y2, w2, 3, 3, UI_RED, 255);
}
static void drawLogoSmall(float e) {
    int x = (int)uvzSafeLeft + 8, y = 18;
    int a = (int)(255 * e);
    drawSpider(x + 17, y + 20, 16, UI_WHITE);
    int tx = x + 44;
    textSpF(FS_BOLD, "STICKMAN", tx + 1, y + 3, 3, UI_RED_D, 2, a);
    textSpF(FS_BOLD, "STICKMAN", tx, y + 2, 3, UI_WHITE, 2, a);
    slantBar(tx, y + 27, 54, 3, 3, UI_RED, a);
}
// Camera framing for the main menu: the player stands on the opening rooftop at the right of the screen, the menu panel sits on the left.
static void menuCamera(float& cx, float& cy) {
    const float mx = P.x - uvzWorldWidth * 0.68f, my = (P.y + 26.0f) - uvzWorldHeight * 0.76f;
    const float gx = P.x - uvzWorldWidth * 0.30f,  gy = P.y - uvzWorldHeight * 0.58f;   // normal gameplay framing
    float k = trans >= 0 ? clampValue(trans, 0.0f, 1.0f) : 0.0f;
    k = k * k * (3.0f - 2.0f * k);   // ease in and out
    cx = lerpValue(mx, gx, k); cy = lerpValue(my, gy, k);
}
static void drawMenuScene(double dt) {
    menuT += (float)dt;
    float cx, cy; menuCamera(cx, cy);
    cx = floorf(cx); cy = floorf(cy);
    drawBackdrop(cx, cy, gSkyTime, true);
    drawWorldScene(cx, cy);
    drawStreetScene(cx, cy);
    drawParticles(cx, cy);
    drawPlayerAndWeb(cx, cy);
}

static void drawComboHUD(int x, int cy) {
    if (!P.alive) return;
    char b[48];
    const int t = gCombo.tier;
    const u32 c = COMBO_COL[t];
    if (gCombo.count > 0) {
        const bool drain = gCombo.draining;
        const int sc = gCombo.hitT > 0.12f ? 4 : 3;
        const u32 mc = drain && ((int)(gTime * 8) & 1) ? 0xD62839 : c;
        snprintf(b, sizeof b, "x%.1f", gCombo.mult);
        textF(FS_COMIC, b, x, cy - (sc == 4 ? 4 : 0), sc, mc);
        if (gCombo.awardT > 0) {
            snprintf(b, sizeof b, "+%d", gCombo.lastAward);
            textF(FS_BOLD, b, x + fontWidth(FS_COMIC, "x0.0", 3) + 8, cy + 2, 2, 0xFFE9A0, (int)(255 * clampValue(gCombo.awardT / 0.4f, 0, 1)));
        }
        if (gCombo.awardT > 0 && gCombo.lastKindShown == combo::STUNT && gStuntName[0]) snprintf(b, sizeof b, "%s", gStuntName);
        else if (gCombo.awardT > 0 && gCombo.lastKindShown >= 0) snprintf(b, sizeof b, "%s", combo::kindName(gCombo.lastKindShown));
        else snprintf(b, sizeof b, drain ? "COMBO FADING" : "COMBO %d", gCombo.count);
        text(b, x, cy + 25, 1, gCombo.awardT > 0 ? 0xFFE9A0 : UI_DIM);
        const int bw = 56, by = cy + 36;
        drawFilledRect(x, by, bw, 3, UI_WHITE, 45);
        drawFilledRect(x, by, std::max(1, (int)(bw * combo::meter(gCombo))), 3, drain ? 0xD62839 : c);
        if (!cfg.reduced && t >= 3) {
            const int a = 28 + (int)(22 * (0.5f + 0.5f * sinf((float)gTime * (t >= 4 ? 9.0f : 6.0f))));
            drawFilledRect(0, 0, 2, uvzWorldHeight, c, a); drawFilledRect(uvzWorldWidth - 2, 0, 2, uvzWorldHeight, c, a);
        }
    }
    if (gTrickMsgT > 0 && gTrickMsg[0]) {
        const int a = (int)(255 * clampValue(gTrickMsgT / 0.35f, 0, 1));
        const int ty = (int)(uvzWorldHeight * 0.27f);
        textSpCF(FS_COMIC, gTrickMsg, uvzWorldWidth / 2, ty, 2, gTrickBad ? 0xFF6B6B : 0xFFE9A0, 1, a);
    }
    if (gCombo.tierPopT > 0) {
        const int tp = gCombo.tierPop;
        const char* nm = combo::tierName(tp);
        const float k = gCombo.tierPopT / 1.5f;
        int sc = (k > 0.9f ? 4 : 3) + (tp >= 4 ? 1 : 0);
        while (sc > 2 && fontWidthSp(FS_COMIC, nm, sc, 2) > uvzWorldWidth - 60) sc--;
        const int a = (int)(255 * clampValue(gCombo.tierPopT / 0.5f, 0, 1));
        const int by = (int)(uvzWorldHeight * 0.36f);
        const int w = fontWidthSp(FS_COMIC, nm, sc, 2);
        slantBar(uvzWorldWidth / 2 - w / 2 - 10, by - 4, w + 20, 7 * sc + 8, 4, COMBO_COL[tp], a / 6);
        textSpCF(FS_COMIC, nm, uvzWorldWidth / 2, by, sc, (tp >= 4 && ((int)(gTime * 10) & 1)) ? 0xFFFFFF : COMBO_COL[tp], 2, a);
    }
}

static void drawIronButton(bool pressed) {
    float fx, fy, fr; ironBtnPos(fx, fy, fr);
    float pop = gIronReadyPop > 0 ? easeOut(1.0f - gIronReadyPop / 0.25f) : 1.0f;   // pops in when the cooldown ends
    const int cx = (int)fx, cy = (int)fy, r = std::max(8, (int)(fr * (0.6f + 0.4f * pop)));
    const float al = ctl.alpha;
    const int fillA = (int)(110 * al) + 120, ringA = (int)(210 * clampValue(al + 0.1f, 0, 1));
    drawDisc(cx + 1, cy + 2, r, 0x000000, 60);
    drawDisc(cx, cy, r, pressed ? 0xBFE4FF : UI_INK, pressed ? 235 : fillA);
    ringDraw(cx, cy, r, 1, pressed ? UI_RED : 0x7FE0FF, pressed ? 255 : ringA);
    if (!pressed) ringDraw(cx, cy, r - 4, 1, 0x7FE0FF, 40);
    const u32 ic = pressed ? UI_INK : UI_WHITE;
    const int t = 1 + 2 * (int)(fr / 24.0f), W = std::max(4, (int)lroundf(r * 0.5f));
    auto X = [&](int v) { return cx + v * W / 10; };
    auto Y = [&](int v) { return cy + v * W / 10; };
    pixLine(X(0), Y(-10), X(0), Y(6), t, ic);                       // arrow: the launch
    pixLine(X(0), Y(-10), X(-5), Y(-5), t, ic); pixLine(X(0), Y(-10), X(5), Y(-5), t, ic);
    pixLine(X(-2), Y(1), X(-7), Y(6), t, ic);  pixLine(X(-7), Y(6), X(-9), Y(10), t, ic);   // four arms, two per side
    pixLine(X(2), Y(1), X(7), Y(6), t, ic);    pixLine(X(7), Y(6), X(9), Y(10), t, ic);
    pixLine(X(-1), Y(4), X(-4), Y(10), t, ic); pixLine(X(1), Y(4), X(4), Y(10), t, ic);
}
// Speed gauge: a C-shaped ring open at the lower right, four segments (bottom to top: blue, yellow, orange, red) that light up with speed.
// The gauge is redrawn every frame, but the pixels of a ring only depend on its two radii. Those pixels (and their angle, normalised
// exactly as the per-pixel test below expects) are computed once per (r0, r1) pair, in row-major order; arcBand then only compares
// angles and joins neighbours into runs. That drops the per-frame sqrtf + atan2f over the whole bounding box (~6000 pixels per arc,
// 9 arcs per frame) and emits exactly the rects the direct scan did, in the same order.
struct ArcPx { int dx, dy; float ang; };
struct ArcRing { float r0 = -1, r1 = -1; std::vector<ArcPx> px; };
static const std::vector<ArcPx>& arcRingPixels(float r0, float r1) {
    static std::vector<ArcRing> cache;   // a few entries: the gauge uses two radius pairs, and only changes them when the layout scale changes
    for (const ArcRing& e : cache) if (e.r0 == r0 && e.r1 == r1) return e.px;
    if (cache.size() >= 8) cache.erase(cache.begin());
    cache.emplace_back(); ArcRing& e = cache.back(); e.r0 = r0; e.r1 = r1;
    const int R = (int)r1 + 1;
    for (int dy = -R; dy <= R; dy++)
        for (int dx = -R; dx <= R; dx++) {
            const float d = sqrtf((float)(dx * dx + dy * dy));
            if (!(d >= r0 && d <= r1)) continue;
            float ang = atan2f((float)dy, (float)dx) * 180.0f / pi;
            if (ang < 0) ang += 360.0f;
            if (ang < 100.0f) ang += 360.0f;
            e.px.push_back({dx, dy, ang});
        }
    return e.px;
}
static void arcBandRects(int cx, int cy, float r0, float r1, float a0, float a1, std::vector<SDL_Rect>& rs) {
    rs.clear();
    const std::vector<ArcPx>& px = arcRingPixels(r0, r1);
    bool open = false; int runY = 0, runX0 = 0, runX1 = 0;   // current run: [runX0, runX1) on row runY (offsets from the centre)
    auto flush = [&]() { if (open) { rs.push_back({cx + runX0, cy + runY, runX1 - runX0, 1}); open = false; } };
    for (const ArcPx& q : px) {
        if (!(q.ang >= a0 && q.ang <= a1)) { flush(); continue; }
        if (open && q.dy == runY && q.dx == runX1) runX1++;
        else { flush(); open = true; runY = q.dy; runX0 = q.dx; runX1 = q.dx + 1; }
    }
    flush();
}
static void arcBand(int cx, int cy, float r0, float r1, float a0, float a1, u32 c, int a) {   // angles in degrees, clockwise on screen from 3 o'clock, a0..a1 within 100..400
    static std::vector<SDL_Rect> rs;
    arcBandRects(cx, cy, r0, r1, a0, a1, rs);
    if (rs.empty()) return;
    setDrawColor(c, a);
    SDL_RenderFillRects(uvzRenderer, rs.data(), (int)rs.size());
}
static void drawSpeedGauge(int cx, int cy, int r, float kmh) {
    static const u32 col[4] = {0x3DA5FF, 0xFFD93D, 0xFF8A2B, 0xFF3B30};   // bottom -> top
    const float A0 = 105.0f, A1 = 390.0f, seg = (A1 - A0) / 4.0f, gap = 4.0f, MAXKMH = 160.0f;
    const float frac = clampValue(kmh / MAXKMH, 0.0f, 1.0f);
    drawDisc(cx, cy, r + 3, UI_INK, 90);
    arcBand(cx, cy, r - 7.0f, r + 1.5f, A0 - 3.0f, A1 + 3.0f, UI_INK, 200);   // dark rim behind the segments
    for (int i = 0; i < 4; i++) {
        const float s0 = A0 + i * seg + gap / 2, s1 = A0 + (i + 1) * seg - gap / 2;
        arcBand(cx, cy, (float)(r - 6), (float)r, s0, s1, col[i], 70);   // unlit
        const float lit = A0 + frac * (A1 - A0);
        if (lit > s0) arcBand(cx, cy, (float)(r - 6), (float)r, s0, std::min(s1, lit), col[i], 255);
    }
}
static void drawHUD() {
    char b[64];
    int x = (int)uvzSafeLeft, y = (int)uvzSafeTop;
    const int gr = 22, sx = x + 2 * gr + 14;   // speed gauge sits in the top-left corner; score and distance sit to its right
    textF(FS_TINY, "SCORE", sx, y + 1, 1, UI_DIM);
    snprintf(b, sizeof b, "%d", scoreVal());
    textShadowF(FS_BOLD, b, sx, y + 10, 3, UI_WHITE);
    snprintf(b, sizeof b, "%dM", (int)distM);
    textShadowF(FS_ITAL, b, sx, y + 35, 2, 0xBFD8FF);
    int rx = uvzWorldWidth - (int)uvzSafeRight;
    { char cb[40]; fmtNum(gProg.coins, cb, sizeof cb); char t[48]; snprintf(t, sizeof t, "COINS %s", cb);
      drawTextWithShadow(t, rx - measureTextWidth(t, 1), y, 1, 0xFFE9A0); }
    if (cfg.showFps) {   // FPS (smoothed over ~0.5 s) under the coins, top-right
        static Uint64 last = 0; static float acc = 0, shown = 60.0f; static int frames = 0;
        const Uint64 now = SDL_GetPerformanceCounter();
        const double gap = last ? (double)(now - last) / (double)SDL_GetPerformanceFrequency() : 0.0;
        if (last && gap < 0.25) { acc += (float)gap; frames++; }   // a long gap (pause, menu) is not a frame time
        last = now;
        if (acc >= 0.5f) { shown = frames / acc; acc = 0; frames = 0; }
        char f[24]; snprintf(f, sizeof f, "%d FPS", (int)lroundf(shown));
        drawTextWithShadow(f, rx - measureTextWidth(f, 1), y + 12, 1, shown >= 55.0f ? 0x9CFFB0 : (shown >= 30.0f ? 0xFFE9A0 : 0xFF8A7A));
    }
    {   // speed meter, bottom-left: world units are ~28.9 px per metre (a 52 px stickman is 1.8 m)
        static float kmh = 0;
        const float target = P.alive ? hypotf(P.vx, P.vy) / 28.9f * 3.6f : 0.0f;
        kmh += (target - kmh) * 0.25f;
        drawSpeedGauge(x + gr + 3, y + gr + 3, gr, kmh);
        char v[24]; snprintf(v, sizeof v, "%3d", (int)lroundf(kmh));   // padded to 3 cells so the ghost segments (and the unit label) stay put
        const int vy0 = uvzWorldHeight - (int)uvzSafeBottom - 26, lw = fontWidth(FS_LCD, v, 2);
        drawFilledRect(x - 4, vy0 - 1, lw + 8, 24, UI_INK, 140);
        textF(FS_LCD, v, x, vy0 + 2, 2, kmh > 120.0f ? 0xFF8A7A : (kmh > 60.0f ? 0xFFE9A0 : UI_WHITE));
        textF(FS_TINY, "KM/H", x + lw + 8, vy0 + 16, 1, UI_DIM);
    }
    int pcx = pauseBtn.x + 22, pcy = pauseBtn.y + 20;
    drawDisc(pcx, pcy, 15, UI_INK, 110);
    ringDraw(pcx, pcy, 15, 1, UI_WHITE, 150);
    drawFilledRect(pcx - 5, pcy - 6, 3, 12, UI_WHITE); drawFilledRect(pcx + 2, pcy - 6, 3, 12, UI_WHITE);
    { const int t = diff::tierFor(distM);
      if (t != gTier) { gTier = t; gTierMsgT = 2.2f; }
      if (gTierMsgT > 0) gTierMsgT -= 1.0f / 60.0f; }
    drawComboHUD(x, y + 64);
    if (gPerfectShowT > 0 && P.alive) {
        snprintf(b, sizeof b, gPerfectStreak >= 2 ? "PERFECT x%d" : "PERFECT", gPerfectStreak);
        textSpCF(FS_COMIC, b, uvzWorldWidth / 2, (int)(uvzWorldHeight * 0.15f), 2, 0xFFE9A0, 1);
    }
    if (gFlow > 0.05f && P.alive) {
        int fw = 60, fy = (int)(uvzWorldHeight * 0.27f);
        drawFilledRect(uvzWorldWidth / 2 - fw / 2, fy, fw, 2, UI_WHITE, 40);
        drawFilledRect(uvzWorldWidth / 2 - fw / 2, fy, (int)(fw * gFlow), 2, 0x7FE0FF);
    }
    if (P.boostT > 0 && P.alive) {
        int bw = 90, by = (int)(uvzWorldHeight * 0.30f);
        drawFilledRect(uvzWorldWidth / 2 - bw / 2, by + 11, bw, 1, UI_WHITE, 50);
        drawFilledRect(uvzWorldWidth / 2 - bw / 2, by + 10, (int)(bw * clampValue(P.boostT / P.boostDur, 0, 1)), 3, 0xFFE9A0);
    }
    for (int i = 0; i < 3; i++) {
        bool pr = false;
        int role = i == 0 ? R_SWING : (i == 1 ? R_JUMP : R_SLIDE);
        for (auto& t : tch) if (t.on && t.role == role) pr = true;
        if (i == 0 && swingHeld) pr = true;
        drawCtlButton(i, pr, false);
    }
    if (ironButtonShown()) {   // hidden completely (no ghost, no timer) while the ability is locked or cooling down
        drawIronButton(gIronHeld);
    }
}
static void dim(int a) { drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x03040C, a); }
static void shadeLeft(int w, int aMax) {
    for (int x = 0; x < w; x += 2) drawFilledRect(x, 0, 2, uvzWorldHeight, UI_INK, (int)(aMax * (1.0f - (float)x / w)));
}
static void menuPanel(int pw, float fade) {   // solid ink panel with a thin edge line and a short soft falloff
    const int A = (int)(244 * fade);
    drawFilledRect(0, 0, pw, uvzWorldHeight, UI_INK, A);
    for (int i = 0; i < 12; i++) drawFilledRect(pw + i, 0, 1, uvzWorldHeight, UI_INK, A * (12 - i) / 12 / 3);
    drawFilledRect(pw - 1, 0, 1, uvzWorldHeight, UI_WHITE, (int)(40 * fade));
    drawFilledRect(0, 0, pw, 2, UI_RED, (int)(255 * fade));
}
static void shadeEdges(int h, int aMax) {
    for (int y = 0; y < h; y += 2) {
        int a = (int)(aMax * (1.0f - (float)y / h));
        drawFilledRect(0, y, uvzWorldWidth, 2, UI_INK, a); drawFilledRect(0, uvzWorldHeight - 2 - y, uvzWorldWidth, 2, UI_INK, a);
    }
}
static void sheet(int px, int pw, const char* title) {
    float e = easeOut(uiAge / 0.25f);
    drawFilledRect(px, 10, pw, uvzWorldHeight - 20, UI_INK, (int)(228 * e));
    hline(px, 10, pw, UI_WHITE, (int)(150 * e));
    slantBar(px + 20, 10, 46, 4, 4, UI_RED, 255);
    textSp(title, px + 20, 24, 3, UI_WHITE, 3, (int)(255 * e));
    hline(px + 20, 54, pw - 40, UI_WHITE, (int)(60 * e));
}
static void drawLines(const char* const* ls, int n, int cx, int y0, int maxW) {
    for (int i = 0; i < n; i++) {
        float e = easeOut((uiAge - 0.1f - i * 0.05f) / 0.22f);
        int sc = fitTextScale(ls[i], maxW, 2);
        int tw = measureTextWidth(ls[i], sc);
        text(ls[i], cx - tw / 2, y0 + i * 24 + (int)((1 - e) * 8), sc, 0xDDE6FF, (int)(255 * e));
    }
}

static void drawStatLine(const char* label, const char* val, int cx, int y, u32 vc) {
    textSpCF(FS_TINY, label, cx, y + 1, 1, UI_DIM, 3);
    int sc = 3; while (sc > 1 && fontWidthSp(FS_BOLD, val, sc, 2) > 140) sc--;
    textSpCF(FS_BOLD, val, cx, y + 11 + (3 - sc) * 3, sc, vc, 2);
}
// Pull-back geometry: the view size drawn for zoom z, and the camera that keeps the player at the same screen spot once it is shrunk into the frame.
static void zoomView(float z, float cx, float cy, int& W1, int& H1, float& zcx, float& zcy) {
    W1 = std::min((int)ceilf(uvzWorldWidth / z), (int)ceilf(uvzWorldWidth / ZOOM_MIN)); H1 = std::min((int)ceilf(uvzWorldHeight / z), (int)ceilf(uvzWorldHeight / ZOOM_MIN));
    zcx = floorf(P.x - (P.x - cx) * (float)W1 / uvzWorldWidth); zcy = floorf(P.y - (P.y - cy) * (float)H1 / uvzWorldHeight);
}
static void render(double dt) {
    ++gGfxFrame;
    gSkyTime = (gState == PLAYING || gState == PAUSED || gState == GAME_OVER || ((gState == SETTINGS || gState == GRAPHICS || gState == CONTROLS || gState == LAYOUT_EDIT || gState == HOW_TO_PLAY || gState == CREDITS || gState == SKILLS) && (navRoot == PAUSED || navRoot == GAME_OVER)))
        ? RUN_SKY_START + (gTime - gRunT0) : (gState == MAIN_MENU && trans >= 0 ? lerpValue((float)MENU_SKY_TIME, (float)RUN_SKY_START, clampValue(trans, 0.0f, 1.0f)) : MENU_SKY_TIME);
    SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
    SDL_SetRenderDrawBlendMode(uvzRenderer, SDL_BLENDMODE_BLEND);
    if (portrait) drawRotateScreen();
    else {
        static State prevS = (State)-1;
        if (gState != prevS) { uiAge = 0; gFocus = -1; gRebind = -1; prevS = gState; }
        uiAge += (float)dt; noteT -= (float)dt; if (flashT > 0) flashT -= (float)dt;
        bool world = gState == PLAYING || gState == PAUSED || gState == GAME_OVER || (isSub(gState) && (navRoot == PAUSED || navRoot == GAME_OVER));
        buildUI();
        if (gFocus >= (int)btns.size()) gFocus = -1;
        if (world) {
            float shx = 0, shy = 0;
            if (shakeT > 0 && cfg.shake) { shx = ((int)hashCoordinates((u32)(gTime * 90), 1, 2) % 5) - 2.0f; shy = ((int)hashCoordinates((u32)(gTime * 90), 3, 4) % 5) - 2.0f; }
            float cx = floorf(camX + shx), cy = floorf(camY + shy);
            const bool zoomed = gZoom < 0.995f && uvzZoomTex && gState != GAME_OVER;
            if (zoomed) {
                // Pull-back: draw a larger view of the world into the scratch texture, keep the player pinned to the same screen spot, then shrink it into the frame.
                const int W0 = uvzWorldWidth, H0 = uvzWorldHeight;
                int W1, H1; float zcx, zcy; zoomView(gZoom, cx, cy, W1, H1, zcx, zcy);
                uvzWorldWidth = W1; uvzWorldHeight = H1;
                SDL_SetRenderTarget(uvzRenderer, uvzZoomTex);
                SDL_SetRenderDrawBlendMode(uvzRenderer, SDL_BLENDMODE_BLEND);
                drawBackdrop(zcx, zcy, gSkyTime, true);
                drawWorldScene(zcx, zcy);
                drawStreetScene(zcx, zcy);
                drawParticles(zcx, zcy);
                drawPlayerAndWeb(zcx, zcy);
                uvzWorldWidth = W0; uvzWorldHeight = H0;
                SDL_SetRenderTarget(uvzRenderer, uvzRenderTarget);
                SDL_Rect src = {0, 0, W1, H1}, dst = {0, 0, W0, H0};
                SDL_RenderCopy(uvzRenderer, uvzZoomTex, &src, &dst);
            } else {
                drawBackdrop(cx, cy, gSkyTime, true);
                drawWorldScene(cx, cy);
                drawStreetScene(cx, cy);
                drawParticles(cx, cy);
                drawPlayerAndWeb(cx, cy);
            }
            drawSense(cx, cy);
            drawWindStreaks();
            drawFilledRect(0, (int)(uvzWorldHeight * 0.86f), uvzWorldWidth, uvzWorldHeight, 0x2A3060, 30);
            if (gState == PLAYING) drawHUD();
        } else drawMenuScene(dt);
        { const float sw = sunsetAmount(gSkyTime); if (sw > 0.02f) drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0xFF9A4A, (int)(26 * sw)); }

        int pw = std::min(uvzWorldWidth - (int)(uvzSafeLeft + uvzSafeRight), 560), px = (uvzWorldWidth - pw) / 2;
        switch (gState) {
            case TITLE: {
                shadeEdges(70, 200); dim(115);
                drawLogoBig();
                int by0 = (int)(uvzWorldHeight * 0.80f) - 12;
                for (int i = 0; i < 28; i++) { int a = (int)(150 * sinf(pi * (i + 0.5f) / 28.0f)); drawFilledRect(0, by0 + i, uvzWorldWidth, 1, UI_INK, a); }
                if (uiAge > 0.9f) {
                    float pulse = 0.5f + 0.5f * sinf((float)gTime * 3.2f);
                    int a = (int)(90 + 165 * pulse), y = (int)(uvzWorldHeight * 0.80f);
                    textSpC("PRESS TO START", uvzWorldWidth / 2, y, 2, UI_WHITE, 4, a);
                    int half = textWSp("PRESS TO START", 2, 4) / 2 + 14;
                    hline(uvzWorldWidth / 2 - half - 70, y + 6, 70, UI_WHITE, a / 2); hline(uvzWorldWidth / 2 + half, y + 6, 70, UI_WHITE, a / 2);
                }
                if (uiAge < 0.7f) drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x000000, (int)(255 * (1 - uiAge / 0.7f)));
            } break;
            case MAIN_MENU:
                { const float fade = trans >= 0 ? 1.0f - clampValue(trans * 2.5f, 0.0f, 1.0f) : 1.0f;   // menu panel fades out as the camera moves
                  if (fade > 0.0f) menuPanel((int)uvzSafeLeft + 8 + (int)std::min(230.0f, uvzWorldWidth * 0.42f) + 18, fade);
                  if (fade > 0.0f) drawLogoSmall(easeOut(uiAge / 0.3f) * fade); }
                drawButtons();
                if (trans < 0 && cfg.best > 0) { char b[40]; snprintf(b, sizeof b, "BEST %dM", (int)cfg.best); text(b, (int)uvzSafeLeft + 10, uvzWorldHeight - (int)uvzSafeBottom - 12, 1, UI_DIM); }
                if (trans < 0) { char cb[32], t[48]; fmtNum(gProg.coins, cb, sizeof cb); snprintf(t, sizeof t, "COINS %s", cb);
                  drawTextWithShadow(t, uvzWorldWidth - (int)uvzSafeRight - 8 - measureTextWidth(t, 1), (int)uvzSafeTop + 10 + 46 + 16, 1, 0xFFE9A0); }
                break;
            case SKILLS: {
                dim(150); sheet(px, pw, "SKILL UPGRADES");
                SkillLay L = skillLay(px, pw);
                float e = easeOut((uiAge - 0.05f) / 0.25f);
                int A = (int)(255 * e);
                { char cb[32], t[48]; fmtNum(gProg.coins, cb, sizeof cb); snprintf(t, sizeof t, "COINS %s", cb);
                  int sc = fitTextScale(t, pw - 40 - 300, 2), tw = measureTextWidth(t, sc), tx = px + pw - 20 - tw;
                  drawDisc(tx - 13, 34, 6, 0xFFE9A0, A); ringDraw(tx - 13, 34, 6, 1, 0xB8862B, A);
                  text(t, tx, 34 - 7 * sc / 2, sc, 0xFFE9A0, A); }
                {
                    int cx = L.wcx, cy = L.wcy, r = L.wr;
                    for (int k = 1; k <= 3; k++) {
                        float rr = r * k / 3.0f; int al = (k == 3 ? 170 : 90) * A / 255;
                        drawLine(cx, cy - rr, cx + rr, cy, UI_WHITE, al); drawLine(cx + rr, cy, cx, cy + rr, UI_WHITE, al);
                        drawLine(cx, cy + rr, cx - rr, cy, UI_WHITE, al); drawLine(cx - rr, cy, cx, cy - rr, UI_WHITE, al);
                    }
                    drawLine(cx, cy - r, cx, cy + r, UI_WHITE, 120 * A / 255); drawLine(cx - r, cy, cx + r, cy, UI_WHITE, 120 * A / 255);
                    drawLine(cx - r / 2.0f, cy - r / 2.0f, cx + r / 2.0f, cy + r / 2.0f, UI_WHITE, 50 * A / 255);
                    drawLine(cx + r / 2.0f, cy - r / 2.0f, cx - r / 2.0f, cy + r / 2.0f, UI_WHITE, 50 * A / 255);
                    for (int i = 0; i < SKILL_ROWS; i++) {
                        const float an = -pi / 2 + i * 2.0f * pi / SKILL_ROWS;
                        int ncx = cx + (int)(cosf(an) * 0.62f * r), ncy = cy + (int)(sinf(an) * 0.62f * r);
                        int sk = SKILL_ROW[i];
                        float fill = gProg.level[sk] / (float)prog::maxLevel(sk);
                        drawDisc(ncx, ncy, 10, UI_INK, 235 * A / 255);
                        if (fill > 0) drawDisc(ncx, ncy, 2 + (int)(7 * fill), UI_RED, A);
                        ringDraw(ncx, ncy, 10, 1, UI_WHITE, 230 * A / 255);
                        text(SKILL_ROW_LETTER[i], ncx - 2, ncy - 3, 1, UI_WHITE, A);
                    }
                }
                for (int i = 0; i < SKILL_ROWS; i++) {
                    float re = easeOut((uiAge - 0.08f - i * 0.05f) / 0.22f);
                    int ra = (int)(255 * re), y = L.rowY[i];
                    int sk = SKILL_ROW[i];
                    hline(L.rx, y + L.rowH, L.rw, UI_WHITE, 28 * ra / 255);
                    int lsc = fitTextScale(prog::DEF[sk].name, L.infoW, L.compact ? 1 : 2);
                    text(prog::DEF[sk].name, L.rx, y + 2, lsc, UI_WHITE, ra);
                    int barY = y + L.rowH - (L.compact ? 5 : 8), barW = L.infoW;
                    char t[64];
                    if (sk == prog::IRON) snprintf(t, sizeof t, "%s", gProg.level[sk] >= 1 ? "UNLOCKED" : "LOCKED");
                    else if (prog::maxRebirth(sk) == 0) snprintf(t, sizeof t, "LV %d/%d  +%.0f%%", gProg.level[sk], prog::maxLevel(sk), 100.0f * (prog::totalMult(gProg, sk) - 1.0f));
                    else snprintf(t, sizeof t, "LV %d/%d  REBIRTH %d/%d", gProg.level[sk], prog::maxLevel(sk), gProg.rebirth[sk], prog::maxRebirth(sk));
                    text(t, L.rx, y + (L.compact ? 14 : 19), 1, UI_WHITE, ra);
                    if (!L.compact) {
                        if (prog::maxRebirth(sk) == 0) snprintf(t, sizeof t, "%s", sk == prog::JUMP ? "HIGHER JUMPS" : (sk == prog::AIR ? "STEER IN THE AIR" : (sk == prog::IRON ? "LAUNCH UP / FORWARD" : "STEER ON THE WEB")));
                        else snprintf(t, sizeof t, "BONUS +%.2fX  REB X%.1f", prog::totalBonus(gProg, sk), prog::rebirthMult(gProg, sk));
                        text(t, L.rx, y + 29, 1, 0xBFD8FF, ra);
                    }
                    drawFilledRect(L.rx, barY, barW, 4, UI_WHITE, 40 * ra / 255);
                    drawFilledRect(L.rx, barY, (int)(barW * gProg.level[sk] / (float)prog::maxLevel(sk)), 4, UI_RED, ra);
                }
                drawButtons();
                int fy = uvzWorldHeight - 14 - 38 + 12;
                if (noteT > 0 && gNote[0]) text(gNote, px + 20, fy, 1, UI_RED);
            } break;
            case SETTINGS: {
                dim(110); sheet(px, pw, "SETTINGS");
                drawButtons();
            } break;
            case GRAPHICS: {
                dim(110); sheet(px, pw, "GRAPHICS");
                drawButtons();
                const int footY2 = uvzWorldHeight - 14 - 38, warnH = 5 * 10 + 4, wy = footY2 - 4 - warnH;
                char st[96];
                snprintf(st, sizeof st, "RENDERER %s   DETAIL %s%s   SCORE %d", gCaps.renderer, gfxcfg::QUALITY_NAME[gFx.quality], gFx.rt ? " MARCHED" : "", gCaps.score);
                for (char* c = st; *c; ++c) *c = (char)toupper((unsigned char)*c);
                text(st, px + 20, wy, 1, 0xBFD8FF);
                for (int i = 0; i < gGfxWarn.n; i++) text(gGfxWarn.line[i], px + 20, wy + 11 + i * 9, 1, gGfxWarn.line[i][0] == 'A' && gGfxWarn.line[i][1] == 'U' ? 0xFFE9A0 : UI_RED);
            } break;
            case CONTROLS: {
                dim(110); sheet(px, pw, "CONTROLS");
                drawButtons();
            } break;
            case LAYOUT_EDIT: {
                dim(140);
                int zx = ctl.lefty ? (int)(uvzWorldWidth * 0.45f) : 0, zw = (int)(uvzWorldWidth * 0.55f);
                drawFilledRect(zx, 0, zw, uvzWorldHeight, UI_WHITE, 12);
                int ex = ctl.lefty ? zx : zw;
                for (int y = 0; y < uvzWorldHeight; y += 8) drawFilledRect(ex, y, 1, 4, UI_WHITE, 70);
                for (int i = 0; i < 3; i++) {
                    bool pr = false;
                    for (auto& t : tch) if (t.on && t.role == R_DRAG && t.btn == i) pr = true;
                    drawCtlButton(i, pr, true);
                }
                drawButtons();
            } break;
            case HOW_TO_PLAY: {
                dim(110); sheet(px, pw, "HOW TO PLAY");
                int c1 = px + 22, c2 = px + (int)(pw * 0.24f), c3 = px + (int)(pw * 0.60f), y0 = 66;
                textSp("ACTION", c1, y0, 1, UI_DIM, 3); textSp("TOUCH", c2, y0, 1, UI_DIM, 3); textSp("KEYBOARD", c3, y0, 1, UI_DIM, 3);
                hline(c1, y0 + 11, pw - 44, UI_WHITE, 45);
                char k[A_N][16];
                for (int i = 0; i < A_N; i++) keyLabel(ctl.key[i], k[i], sizeof k[i]);
                char steerK[40], pauseK[40];
                snprintf(steerK, sizeof steerK, "%s / %s", k[A_LEFT], k[A_RIGHT]);
                snprintf(pauseK, sizeof pauseK, "%s / ESC", k[A_PAUSE]);
                const char* rows[5][3] = {{"STEER", ctl.lefty ? "DRAG RIGHT SIDE" : "DRAG LEFT SIDE", steerK}, {"JUMP", "JUMP BUTTON", k[A_JUMP]},
                    {"SLIDE", "SLIDE BUTTON", k[A_SLIDE]}, {"SWING", "HOLD SWING", k[A_SWING]}, {"PAUSE", "PAUSE BUTTON", pauseK}};
                for (int i = 0; i < 5; i++) {
                    float e = easeOut((uiAge - 0.1f - i * 0.05f) / 0.22f);
                    int a = (int)(255 * e), y = y0 + 18 + i * 22 + (int)((1 - e) * 8);
                    int s1 = fitTextScale(rows[i][0], c2 - c1 - 8, 2), s2 = fitTextScale(rows[i][1], c3 - c2 - 8, 2), s3 = fitTextScale(rows[i][2], px + pw - 22 - c3, 2);
                    text(rows[i][0], c1, y, s1, UI_WHITE, a);
                    text(rows[i][1], c2, y, s2, 0xC9D1EE, a);
                    text(rows[i][2], c3, y, s3, UI_WHITE, a);
                    hline(c1, y + 17, pw - 44, UI_WHITE, 22 * a / 255);
                }
                drawButtons();
            } break;
            case CREDITS: {
                if (!gCreditsTex && !gCreditsTried) { gCreditsTried = true; loadCreditsImage(); }
                drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x000000, 255);
                if (gCreditsTex && gCreditsW > 0 && gCreditsH > 0) {
                    const float k = std::min((float)uvzWorldWidth / gCreditsW, (float)uvzWorldHeight / gCreditsH);   // contain: aspect ratio preserved
                    const int dw = (int)(gCreditsW * k), dh = (int)(gCreditsH * k);
                    SDL_Rect d = {(uvzWorldWidth - dw) / 2, (uvzWorldHeight - dh) / 2, dw, dh};
                    SDL_RenderCopy(uvzRenderer, gCreditsTex, nullptr, &d);
                } else textSpC("IMAGE NOT FOUND", uvzWorldWidth / 2, uvzWorldHeight / 2 - 4, 1, UI_DIM, 2);
                drawButtons();
            } break;
            case PAUSED: {
                dim(150); shadeEdges(60, 160);
                int ty = (int)(uvzWorldHeight * 0.10f);
                textSpCF(FS_BOLD, "PAUSED", uvzWorldWidth / 2 + 2, ty + 2, 5, UI_RED_D, 3);
                textSpCF(FS_BOLD, "PAUSED", uvzWorldWidth / 2, ty, 5, UI_WHITE, 3);
                slantBar(uvzWorldWidth / 2 - 30, ty + 7 * 5 + 8, 60, 3, 3, UI_RED, 255);
                drawButtons();
            } break;
            case GAME_OVER: {
                dim(165); shadeEdges(60, 160);
                int ty = (int)(uvzWorldHeight * 0.10f);
                textSpCF(FS_BOLD, "GAME OVER", uvzWorldWidth / 2 + 2, ty + 2, 5, UI_RED_D, 3);
                textSpCF(FS_BOLD, "GAME OVER", uvzWorldWidth / 2, ty, 5, UI_WHITE, 3);
                slantBar(uvzWorldWidth / 2 - 30, ty + 7 * 5 + 8, 60, 3, 3, UI_RED, 255);
                char b[64];
                int sy = ty + 7 * 5 + 28;
                snprintf(b, sizeof b, "%d", scoreVal()); drawStatLine("SCORE", b, uvzWorldWidth / 2 - 150, sy, UI_WHITE);
                snprintf(b, sizeof b, "%dM", (int)distM); drawStatLine("DISTANCE", b, uvzWorldWidth / 2, sy, 0xBFD8FF);
                { char cb[32]; fmtNum(runCoins, cb, sizeof cb); drawStatLine("COINS EARNED", cb, uvzWorldWidth / 2 + 168, sy, 0xFFE9A0); }
                snprintf(b, sizeof b, "BEST %dM", (int)cfg.best);
                int by = sy + 42;
                if (newBest) {
                    int bw = textWSp(b, 2, 3) + 90;
                    textSp(b, uvzWorldWidth / 2 - bw / 2, by, 2, 0xFFE9A0, 3);
                    int nx = uvzWorldWidth / 2 - bw / 2 + textWSp(b, 2, 3) + 14;
                    slantBar(nx, by - 3, 62, 19, 5, UI_RED, 255);
                    text("NEW!", nx + 9, by + 1, 2, UI_WHITE);
                } else textSpC(b, uvzWorldWidth / 2, by, 2, 0xBFD8FF, 3);
                if (gCombo.runBestCount > 0) {
                    snprintf(b, sizeof b, "BEST COMBO THIS RUN  %d HITS  x%.1f", gCombo.runBestCount, gCombo.runBestMult);
                    textSpC(b, uvzWorldWidth / 2, by + 26, 1, COMBO_COL[combo::tierFor(gCombo.runBestMult)], 1);
                }
                drawButtons();
            } break;
            default: break;
        }
        if (flashT > 0) { float f = clampValue(flashT / 0.5f, 0, 1); drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, UI_WHITE, (int)(230 * f * f)); }
        if (fadeIn > 0) drawFilledRect(0, 0, uvzWorldWidth, uvzWorldHeight, 0x000000, (int)(255 * clampValue(fadeIn / 0.5f, 0, 1)));
    }
    SDL_SetRenderTarget(uvzRenderer, nullptr);
    SDL_SetRenderDrawColor(uvzRenderer, 0, 0, 0, 255);
    SDL_RenderClear(uvzRenderer);
    SDL_Rect dst = {uvzOffsetX, uvzOffsetY, uvzDisplayWidth, uvzDisplayHeight};
    SDL_RenderCopy(uvzRenderer, uvzRenderTarget, nullptr, &dst);
    SDL_RenderPresent(uvzRenderer);
}


// ---- Iron Arms: launch + shared cooldown ----
static const float IRON_UP_VY = -1020.0f, IRON_FWD_ADD = 560.0f, IRON_FWD_VY = -690.0f, IRON_FWD_TOP = 1300.0f;
static bool ironFire(bool fwd) {
    Player& p = P;
    if (gIronCd > 0.0f || !ironUnlocked() || !p.alive || gState != PLAYING || p.mantleT > 0.0f) return false;
    // Drop only what would fight the launch; velocity (momentum) is kept and builds on it.
    if (p.swinging) { p.swinging = false; markBad(p.ax, p.ay, 1.2f); p.swingT = 0; p.wrapN = 0; p.wrapCool = 0; }
    if (p.wallCling) leaveWall(fwd ? 0.0f : -p.wallDir * 150.0f, 0.0f, 0.45f);
    if (p.zipping) { p.zipping = false; p.zipCool = 0.5f; }
    p.diving = false; p.webFlying = false; p.trickType = 0; p.shootT = 0; p.releaseT = 0; p.launchT = 0; p.flipT = 0; p.releaseFlip = false;
    const bool grounded = p.onGround;
    const float fx = p.x, fy = p.y + 26.0f;                        // feet
    p.onGround = false; p.groundedPrev = false; p.rideId = -1; p.coyote = 0; p.slideT = 0; p.slideBuf = 0; p.jumpBuf = 0;
    if (fwd) {
        const float base = std::max(p.vx, diff::runSpeedBase(distM) * runMult());   // never slower than a running start
        p.vx = std::min(base + IRON_FWD_ADD, IRON_FWD_TOP);
        p.vy = std::max(std::min(IRON_FWD_VY, p.vy - 220.0f), -1500.0f);
        p.hangT = 0.20f;
    } else {
        p.vy = std::max(std::min(IRON_UP_VY, p.vy - 350.0f), -1500.0f);              // vx is untouched
        p.hangT = 0.30f;                                                            // a soft apex, so the fall or a web shot flows on
    }
    p.trickReady = true; p.jumpStyle = wrng.range(0, 2); p.fallStyle = wrng.range(0, 1); p.jit = wrng.f() * 2 - 1;
    // ONE shared cooldown starts now: the button disappears this very frame and stays gone for IRON_COOLDOWN seconds.
    gIronCd = IRON_COOLDOWN; gIronKind = fwd ? 2 : 1; gIronFxDur = fwd ? 0.55f : 0.50f; gIronFxT = gIronFxDur;
    gIronUpEdge = gIronFwdEdge = gIronHeld = gIronKeyDown = gIronKeyUsed = false;
    for (auto& t : tch) if (t.on && t.role == R_IRON) t.role = R_NONE;      // a finger still down on the old button is inert
    gIronRingT = 0.35f; gIronRingX = fx; gIronRingY = fwd ? p.y : fy;
    if (fwd) {
        burst(p.x, p.y, 14, 0xFFFFFF, 260);
        for (int i = 0; i < 22; i++) spawnPart(p.x - 10 - wrng.f() * 16, p.y - 12 + wrng.f() * 28, -(220 + wrng.f() * 480), (wrng.f() - 0.5f) * 140, 0.3f + wrng.f() * 0.3f, (i & 1) ? 0xFFFFFF : 0xBFE4FF, 2 + (i & 1));
        if (cfg.shake) camPunch = 1.0f;
        doShake(0.14f); sfx(8); sfx(6);
    } else {
        for (int i = 0; i < 28; i++) {                              // exhaust blasting down from under the runner
            const float a = pi * 0.5f + (wrng.f() - 0.5f) * 1.9f, v = 120.0f + wrng.f() * 340.0f;
            spawnPart(fx + (wrng.f() - 0.5f) * 30.0f, fy, cosf(a) * v, sinf(a) * v, 0.3f + wrng.f() * 0.4f, (i % 3 == 0) ? 0xFFE9A0 : ((i & 1) ? 0xFFFFFF : 0xBFE4FF), 2 + (i & 1));
        }
        if (grounded) for (int i = 0; i < 12; i++) spawnPart(fx, fy - 2, (i & 1 ? 1 : -1) * (90 + wrng.f() * 200), -10 - wrng.f() * 50, 0.35f + wrng.f() * 0.25f, 0x9AA0C0, 3);   // dust
        doShake(0.16f); sfx(2); sfx(7);
    }
    return true;
}
static void ironTick(float dt) {
    Player& p = P;
    const bool wasCooling = gIronCd > 0.0f;
    if (gIronCd > 0.0f) gIronCd = std::max(0.0f, gIronCd - dt);
    // Input that arrived while the ability was locked or cooling down is dropped, never buffered: nothing can bypass the cooldown.
    const bool up = gIronUpEdge, fwd = gIronFwdEdge;
    gIronUpEdge = gIronFwdEdge = false;
    if (wasCooling && gIronCd <= 0.0f && p.alive) { gIronReadyPop = 0.25f; sfx(3); }   // back: automatic, whatever the runner is doing
    if (up || fwd) ironFire(fwd);                                                      // forward wins if both land in the same frame
    gIronReadyPop = std::max(0.0f, gIronReadyPop - dt); gIronRingT = std::max(0.0f, gIronRingT - dt);
    if (gIronFxT > 0 && p.alive) {                                                      // propulsion while the arms are out
        const bool hold = gIronFxT > gIronFxDur * 0.38f;
        if (hold) for (int k = 0; k < 3; k++) {
            if (gIronKind == 1) spawnPart(p.x + (wrng.f() - 0.5f) * 34.0f, p.y + 30.0f, (wrng.f() - 0.5f) * 90.0f, 80.0f + wrng.f() * 200.0f, 0.25f + wrng.f() * 0.2f, (k & 1) ? 0xFFFFFF : 0xBFE4FF, 2);
            else spawnPart(p.x - 22.0f - wrng.f() * 10.0f, p.y - 10.0f + (wrng.f() - 0.5f) * 36.0f, -(180.0f + wrng.f() * 340.0f), (wrng.f() - 0.5f) * 50.0f, 0.2f + wrng.f() * 0.25f, (k & 1) ? 0xFFFFFF : 0x7FE0FF, 2);
        }
        gTrail[gTrailHead] = {p.x, p.y + 2, 0.32f, 0.32f, gIronKind == 2 ? 0xBFE4FFu : 0xFFE9A0u};   // motion trail
        gTrailHead = (gTrailHead + 1) % 16;
    }
    gIronFxT = std::max(0.0f, gIronFxT - dt);
    ironArmsUpdate(dt);
}
static void updateGame(double dt) {
    pollHeld();
    Player& p = P;
    const float fdt = (float)dt;
    badTick(fdt); hintT -= fdt;
    gAirT = (p.onGround || !p.alive) ? 0.0f : gAirT + fdt;
    const bool canShoot = !p.wallCling && p.alive && !p.onGround && !p.swinging && !p.webFlying;
    const bool pressed = swingHeld && !swingWas;
    if (pressed && p.alive) { gWebBufT = WEB_BUF; gWebRetryT = 0.0f; }
    else if (!swingHeld || !p.alive) gWebBufT = 0.0f;
    else gWebBufT = std::max(0.0f, gWebBufT - fdt);
    if (canShoot && (pressed || gWebBufT > 0.0f)) {
        float fx = 0, fy = 0;
        bool found = false;
        if (pressed) {
            sfx(0);
            p.shootT = 0.14f; p.shootStyle = wrng.range(0, 1);
            found = findAnchor(fx, fy);
        } else if ((gWebRetryT -= fdt) <= 0.0f) {   // a buffered tap retries (every 0.05 s) as the runner moves into range
            gWebRetryT = 0.05f;
            if (findAnchor(fx, fy)) { found = true; sfx(0); p.shootT = 0.14f; p.shootStyle = wrng.range(0, 1); }
        }
        if (found) {
            gWebBufT = 0.0f;
            tgtX = fx; tgtY = fy;
            p.webFlying = true;
            p.webStartX = p.webX = p.x;
            p.webStartY = p.webY = p.y - 10;
            p.webT = 0;
            p.webDur = webTravelTime(hypotf(tgtX - p.webStartX, tgtY - p.webStartY), swingMult());
        } else if (pressed) {
            for (int i = 0; i < 3; i++) spawnPart(p.x + AIM_DEF_X * 80, p.y - 10 + AIM_DEF_Y * 80, AIM_DEF_X * 40 + (wrng.f() - 0.5f) * 60, AIM_DEF_Y * 40 + (wrng.f() - 0.5f) * 60, 0.3f, 0xBFD8FF, 1);
        }
    }
    swingWas = swingHeld;
    haveTarget = false;
    if (p.alive && !p.onGround && !p.swinging && !p.webFlying) {
        if (hintT <= 0) { hintFound = findAnchor(hintX, hintY); hintT = 0.05f; }
        haveTarget = hintFound;
        if (haveTarget) { tgtX = hintX; tgtY = hintY; }
    } else hintT = 0;

    if (p.webFlying) {
        p.webT += fdt;
        const float progress = clampValue(p.webT / p.webDur, 0, 1);

        p.webStartX = p.x; p.webStartY = p.y - 10;
        p.webX = lerpValue(p.webStartX, tgtX, progress);
        p.webY = lerpValue(p.webStartY, tgtY, progress);

        if (!swingHeld || p.onGround || !p.alive) {
            p.webFlying = false;
        } else if (progress >= 1.0f && p.y - 10 < tgtY + 20.0f) {
            markBad(tgtX, tgtY, 1.5f);
            p.webFlying = false;
        } else if (webBlocked(p.x, p.y - 10, tgtX, tgtY)) {
            markBad(tgtX, tgtY, 1.5f);
            p.webFlying = false;
        } else if (progress >= 1.0f) {
            p.webFlying = false;
            attachWeb(tgtX, tgtY);
        }
    }
    if (p.swinging) p.swingT += fdt;
    if (p.swinging && !swingHeld) releaseWeb(false);

    if (slideEdge && p.swinging && p.alive) { slideEdge = false; zipEdge = true; }
    if (zipEdge) {
        zipEdge = false;
        float zx, zy;
        if (zipCanStart() && findZipTarget(zx, zy)) beginZip(zx, zy);
    }
    ironTick(fdt);
    gSlideHoldT = slideHeld ? gSlideHoldT + fdt : 0.0f;
    const bool diveWant = (diveHeld || gSlideHoldT > 0.22f) && p.alive && !p.onGround && !p.swinging && !p.wallCling &&
                          !p.zipping && !p.trickType && p.diveCool <= 0 && gAirT > 0.12f;
    if (diveWant && !p.diving) { p.diving = true; p.diveT = 0; }
    else if (!diveWant && p.diving) p.diving = false;
    static double acc = 0;
    acc += dt;
    int guard = 0;
    const int sub = (int)clampValue(ceilf(std::max(fabsf(p.vx), fabsf(p.vy)) / 1100.0f), 1.0f, 4.0f);
    const double h = 1.0 / (120.0 * sub);
    while (acc >= h && guard++ < 12 * sub) { updateTraffic((float)h); stepPhysics((float)h); acc -= h; }
    if (guard >= 12 * sub) acc = 0;
    p.landT -= (float)dt; p.shootT -= (float)dt; p.attachT -= (float)dt; p.releaseT -= (float)dt; p.flipT -= (float)dt;
    if (p.alive && p.onGround) gRunPhase += (float)dt * 1.44f * clampValue(p.vx / 230.0f, 0.6f, 2.2f);
    chainShowT -= (float)dt; shakeT -= (float)dt; gImpactT -= (float)dt;
    gPerfectShowT -= (float)dt; p.perfectT -= (float)dt;
    gTrickHeat = std::max(0.0f, gTrickHeat - (float)dt * 0.35f); gTrickMsgT -= (float)dt;
    camPunch *= expf(-5.0f * (float)dt);
    gFlow = std::max(0.0f, gFlow - (float)dt * (p.onGround ? 0.25f : 0.04f) * (gCombo.count > 0 && !gCombo.draining ? 0.5f : 1.0f));
    senseTick(fdt);
    rescueTick(fdt);
    if (p.alive) { combo::update(gCombo, (float)dt, p.onGround); nearMissTick(); }
    else combo::update(gCombo, (float)dt, true);
    saveComboBest();
    for (auto& t : gTrail) if (t.t > 0) t.t -= (float)dt;
    if (p.alive) {
        const float spd = hypotf(p.vx, p.vy);
        gTrailTick -= (float)dt;
        if (!p.onGround && spd > 650.0f && gTrailTick <= 0) {
            gTrailTick = cfg.reduced ? 0.05f : 0.025f;
            const u32 c = p.perfectT > 0 ? 0xFFE9A0 : (gCombo.tier >= 2 ? COMBO_COL[gCombo.tier] : (spd > 1000.0f ? 0xFFFFFF : 0x7FE0FF));
            gTrail[gTrailHead] = {p.x, p.y + 2, 0.32f, 0.32f, c};
            gTrailHead = (gTrailHead + 1) % 16;
        }
        distM = std::max(distM, (p.x - startX) / 16.0f);
        int earned = prog::coinsForDistance(distM, coinMilestones);
        if (earned > 0) { gProg.coins += earned; runCoins += earned; sfx(3); saveProg(); }
        if (p.vx > 420) speedBonus += (float)dt * 20.0f;
        if (p.slideT > 0 && p.onGround && ((int)(gTime * 40)) % 2 == 0)
            spawnPart(p.x - 10, p.y + 26, -60 - wrng.f() * 60, -20 - wrng.f() * 40, 0.3f, 0xB0B6D0);
        if (p.swinging || p.vx > 350) {
            if (((int)(gTime * 30)) % 3 == 0) spawnPart(p.x - 6, p.y - 8, -30, 10, 0.25f, 0x7FA8FF, 1);
        }
    } else {
        p.deadT += (float)dt;
        if (p.deadT > (gRag.on ? 1.8f : (p.deadGround ? 1.0f : 1.1f)) && gState == PLAYING) {   // the ragdoll gets time to tumble and settle
            if (distM > cfg.best) { cfg.best = distM; newBest = true; }
            saveCfg();
            gState = GAME_OVER;
        }
    }
    for (auto& q : parts) if (q.alive) {
        q.life -= (float)dt; if (q.life <= 0) { q.alive = false; continue; }
        q.x += q.vx * (float)dt; q.y += q.vy * (float)dt; q.vy += 300 * (float)dt;
    }
    const float fast = p.wallCling ? 0.0f : clampValue((hypotf(p.vx, p.vy) - 600.0f) / 900.0f, 0.0f, 1.0f);
    float tx = p.x - uvzWorldWidth * 0.30f + clampValue(p.vx * 0.12f, -20, 100) + 14.0f * fast + 25.0f * camPunch;
    float ty = p.y - uvzWorldHeight * 0.58f + clampValue(p.vy * 0.05f, -30, 40) * fast;

    static float camSwing = 0, camWall = 0;
    camSwing += ((p.swinging ? 1.0f : 0.0f) - camSwing) * (1 - expf(-6.0f * (float)dt));
    camWall += ((p.wallCling ? 1.0f : 0.0f) - camWall) * (1 - expf(-6.0f * (float)dt));
    ty = lerpValue(ty, lerpValue(p.y, p.ay, 0.3f) - uvzWorldHeight * 0.55f, camSwing);
    ty = lerpValue(ty, p.y - uvzWorldHeight * 0.52f, camWall);
    if (p.diving) ty += clampValue(p.vy * 0.06f, 0.0f, 60.0f);
    if (!p.onGround && !p.swinging && !p.wallCling && p.vy > 350.0f) ty += clampValue((p.vy - 350.0f) * 0.07f, 0.0f, 45.0f);
    tx += clampValue((hypotf(p.vx, p.vy) - 700.0f) * 0.05f, 0.0f, 40.0f);
    if (p.zipping) tx += 30.0f;
    if (p.alive || p.deadT < (gRag.on ? 1.6f : 0.6f)) {
        // Follow rate rises with the distance to the target so a fast swing or a long fall can never outrun the camera.
        const float errX = fabsf(tx - camX), errY = fabsf(ty - camY);
        const float rx = 6.0f + 2.0f * fast + 10.0f * clampValue((errX - 50.0f) / 200.0f, 0.0f, 1.0f);
        const float ry = 4.0f + 12.0f * clampValue((errY - 40.0f) / 160.0f, 0.0f, 1.0f);
        camX += (tx - camX) * (1 - expf(-rx * (float)dt));
        camY += (ty - camY) * (1 - expf(-ry * (float)dt));
        // Hard guarantee: the player always stays inside a safe box on screen (the zoom pivots on the player, so the fractions hold).
        camX = clampValue(camX, p.x - uvzWorldWidth * 0.48f, p.x - uvzWorldWidth * 0.14f);
        camY = clampValue(camY, p.y - uvzWorldHeight * 0.78f, p.y - uvzWorldHeight * 0.24f);
    }
    {   // speed pull-back: 1.0 -> ~0.9 as speed builds, eased so it never snaps
        const float sp = hypotf(p.vx, p.vy);
        float zt = lerpValue(1.0f, ZOOM_FAR, clampValue((sp - ZOOM_SPEED_START) / (ZOOM_SPEED_FULL - ZOOM_SPEED_START), 0.0f, 1.0f));
        if (p.onGround || p.wallCling || !p.alive || cfg.reduced) zt = 1.0f;
        gZoom += (zt - gZoom) * (1 - expf(-(zt < gZoom ? ZOOM_OUT_RATE : ZOOM_IN_RATE) * (float)dt));
        if (fabsf(gZoom - 1.0f) < 0.002f && zt == 1.0f) gZoom = 1.0f;
        gZoom = clampValue(gZoom, ZOOM_MIN, 1.0f);
    }
    ensureWorld();
    aWind = clampValue((hypotf(p.vx, p.vy) - 250.0f) / 900.0f, 0, 1) * (p.onGround ? 0.4f : 1.0f) * (p.alive ? 1.0f : 0.0f);
}

// ---- Frame pacing -------------------------------------------------------------------------------------
// The limiter sleeps (coarse SDL_Delay, then a short spin) so each frame lasts 1/cap seconds. Vsync is only left on when the cap is at or above the
// display refresh rate (vsync then does the pacing); for a lower cap or UNCAPPED it is switched off, otherwise a 30 FPS sleep + a 60 Hz vsync wait
// would stack up to 20 FPS.
static Uint64 gPaceNext = 0;
static void applyFramePacing() {
    int hz = 60; SDL_DisplayMode dm;
    if (uvzWindow && SDL_GetCurrentDisplayMode(0, &dm) == 0 && dm.refresh_rate > 0) hz = dm.refresh_rate;
    gDisplayHz = hz;
    const int cap = fpsCap();
#if SDL_VERSION_ATLEAST(2, 0, 18)
    if (uvzRenderer) SDL_RenderSetVSync(uvzRenderer, (cap > 0 && cap >= hz - 1) ? 1 : 0);
#endif
    gPaceNext = 0;
}
static void paceFrame() {
    const int cap = fpsCap();
    if (cap <= 0) { gPaceNext = 0; return; }
    const Uint64 freq = SDL_GetPerformanceFrequency(), target = std::max<Uint64>(1, freq / (Uint64)cap);
    Uint64 now = SDL_GetPerformanceCounter();
    if (gPaceNext == 0) gPaceNext = now;
    gPaceNext += target;
    if (now >= gPaceNext) { if (now - gPaceNext > target * 4) gPaceNext = now; return; }   // running late: no sleep; forget a big hitch instead of catching up
    while ((now = SDL_GetPerformanceCounter()) < gPaceNext) {
        const Uint64 ms = (gPaceNext - now) * 1000 / freq;
        if (ms > 1) SDL_Delay((Uint32)(ms - 1));
    }
}
// F11 / Alt+Enter toggle anywhere; Esc leaves fullscreen only on the main menu (everywhere else Esc keeps its pause / back meaning).
static bool fullscreenKey(SDL_Scancode sc, Uint16 mod, bool repeat) {
#ifdef __ANDROID__
    (void)sc; (void)mod; (void)repeat; return false;   // the activity is always immersive
#else
    if (gRebind >= 0) return false;
    const bool altEnter = (sc == SDL_SCANCODE_RETURN || sc == SDL_SCANCODE_KP_ENTER) && (mod & KMOD_ALT);
    if (sc == SDL_SCANCODE_F11 || altEnter) { if (!repeat) setFullscreen(!cfg.full); return true; }
    if (sc == SDL_SCANCODE_ESCAPE && gState == MAIN_MENU && windowIsFullscreen()) { if (!repeat) setFullscreen(false); return true; }
    return false;
#endif
}
// Reads what the running renderer and the machine offer, then derives the capability score the optimiser works from.
static void detectGraphicsCaps() {
    gfxcfg::Caps c;
    SDL_RendererInfo ri; SDL_zero(ri);
    if (uvzRenderer && SDL_GetRendererInfo(uvzRenderer, &ri) == 0) {
        snprintf(c.renderer, sizeof c.renderer, "%s", ri.name ? ri.name : "unknown");
        c.accelerated = (ri.flags & SDL_RENDERER_ACCELERATED) != 0;
        c.targetTextures = (ri.flags & SDL_RENDERER_TARGETTEXTURE) != 0;
        c.maxTexture = std::min(ri.max_texture_width, ri.max_texture_height);
        c.active = gfxcfg::classifyDriver(ri.name);
    }
    c.hasOpenGL = false; c.hasVulkan = false;
    for (int i = 0, n = SDL_GetNumRenderDrivers(); i < n; i++) {
        SDL_RendererInfo di; SDL_zero(di);
        if (SDL_GetRenderDriverInfo(i, &di) != 0 || !di.name) continue;
        const int k = gfxcfg::classifyDriver(di.name);
        if (k == gfxcfg::ACTIVE_OPENGL) c.hasOpenGL = true;
        if (k == gfxcfg::ACTIVE_VULKAN) c.hasVulkan = true;
    }
    c.cpus = std::max(1, SDL_GetCPUCount());
    c.ramMB = SDL_GetSystemRAM();
#ifdef __ANDROID__
    c.mobile = true;
#endif
    gfxcfg::scoreCaps(c);
    gCaps = c;
    gGov.reset();
    gfxRefresh();
}
// Credits picture: assets/70554.png (decoded in-engine by png.h), or assets/credits.tga as a fallback. Photos are box-reduced to <= 2048 px
// on the long side so every GPU accepts them, and smooth-scaled when drawn. A missing file just leaves the credits screen black with BACK.
static void loadCreditsImage() {
    static const char* const DIRS[] = {"assets/", "../assets/", "../../assets/"};
    static const char* const FILES[] = {"70554.png", "credits.tga"};
    for (const char* dir : DIRS) for (const char* fn : FILES) {
        std::vector<unsigned char> raw; Img im(1, 1);
        if (!sprReadFile((std::string(dir) + fn).c_str(), raw)) continue;
        const bool png = strstr(fn, ".png") != nullptr;
        const bool decoded = png ? sprDecodePng(raw, im) : sprDecodeTga(raw, im);
        std::vector<unsigned char>().swap(raw);   // compressed / raw file bytes are dead weight once the pixels exist
        if (!decoded) continue;
        const int longSide = std::max(im.w, im.h);
        if (longSide > 2048) {
            const int n = (longSide + 2047) / 2048, nw = std::max(1, im.w / n), nh = std::max(1, im.h / n);
            Img sm(nw, nh);
            for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) {
                unsigned a = 0, r = 0, g = 0, b = 0, c = 0;
                for (int j = 0; j < n; j++) for (int i = 0; i < n; i++) { const u32 q = im.get(x * n + i, y * n + j); a += q >> 24; r += (q >> 16) & 255; g += (q >> 8) & 255; b += q & 255; c++; }
                sm.p[(size_t)y * nw + x] = ((a / c) << 24) | ((r / c) << 16) | ((g / c) << 8) | (b / c);
            }
            im = std::move(sm);   // was a full copy of the reduced image; the oversized original is released here
        }
        gCreditsTex = createTexture(im); gCreditsW = im.w; gCreditsH = im.h;
        if (gCreditsTex) SDL_SetTextureScaleMode(gCreditsTex, SDL_ScaleModeLinear);
        return;
    }
}
static void unloadCreditsImage() {
    if (gCreditsTex) { SDL_DestroyTexture(gCreditsTex); gCreditsTex = nullptr; }
    gCreditsW = gCreditsH = 0; gCreditsTried = false;
}
// Orderly teardown: stop the audio thread before anything it touches goes away, then release every GPU resource, the renderer and the window.
static void shutdownResources() {
    if (gAud) { SDL_CloseAudioDevice(gAud); gAud = 0; }
    auto kill = [](SDL_Texture*& t) { if (t) { SDL_DestroyTexture(t); t = nullptr; } };
    unloadCreditsImage();
    kill(gFacadeAtlas);
    kill(gCloudTex);
    for (auto& l : gSkyLayer) { kill(l.body); kill(l.lights); }
    kill(gSkyTex); kill(gStkTex); kill(gSheet); kill(uvzZoomTex); kill(uvzRenderTarget);
    if (uvzRenderer) { SDL_DestroyRenderer(uvzRenderer); uvzRenderer = nullptr; }
    if (uvzWindow) { SDL_DestroyWindow(uvzWindow); uvzWindow = nullptr; }
}
int main(int argc, char** argv) {
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
    SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");
    SDL_SetHint(SDL_HINT_MOUSE_TOUCH_EVENTS, "1");
    SDL_SetHint(SDL_HINT_TOUCH_MOUSE_EVENTS, "0");
    SDL_SetHint(SDL_HINT_ANDROID_TRAP_BACK_BUTTON, "1");
    SDL_SetHint(SDL_HINT_ORIENTATIONS, "LandscapeLeft LandscapeRight");   // landscape only, both directions
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }
    loadCfg();
    loadControls();
    Uint32 flags = SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI;
#ifdef __ANDROID__
    flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;   // immersive sticky, real display size (the cutout mode is set by tools/android_fullscreen.sh)
#endif
    uvzWindow = SDL_CreateWindow("NYC Pixel Runner", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 600, flags);
    if (uvzWindow) {
        // Graphics API: the chosen backend is picked from the render drivers this SDL build offers. Vulkan falls back to OpenGL, then to SDL's own choice;
        // a driver that fails to start never blocks the game. (A change made in the menu is saved and used from the next launch.)
        std::vector<std::string> drivers;
        for (int i = 0, n = SDL_GetNumRenderDrivers(); i < n; i++) { SDL_RendererInfo di; SDL_zero(di); if (SDL_GetRenderDriverInfo(i, &di) == 0 && di.name) drivers.push_back(di.name); }
        const int want = gfxcfg::pickDriverIndex(gGfx.api, drivers);
        const Uint32 rf = SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC | SDL_RENDERER_TARGETTEXTURE;
        if (want >= 0) uvzRenderer = SDL_CreateRenderer(uvzWindow, want, rf);
        if (!uvzRenderer) uvzRenderer = SDL_CreateRenderer(uvzWindow, -1, rf);
        if (!uvzRenderer) uvzRenderer = SDL_CreateRenderer(uvzWindow, -1, SDL_RENDERER_PRESENTVSYNC);
        if (!uvzRenderer) uvzRenderer = SDL_CreateRenderer(uvzWindow, -1, SDL_RENDERER_SOFTWARE);   // last resort: the effects switch themselves off
    }
    if (!uvzRenderer) {
        fprintf(stderr, "Could not create window/renderer: %s\n", SDL_GetError());
        return 1;
    }
    SDL_SetRenderDrawBlendMode(uvzRenderer, SDL_BLENDMODE_BLEND);
#ifndef __ANDROID__
    if (cfg.full) { SDL_SetWindowFullscreen(uvzWindow, SDL_WINDOW_FULLSCREEN_DESKTOP); gFsReqTicks = SDL_GetTicks() | 1u; }
    // Debug: --ratio=W:H (e.g. 16:9, 18:9, 19.5:9, 20:9, 21:9) sizes a desktop window to that aspect ratio.
    for (int i = 1; i < argc; i++) {
        float rw = 0, rh = 0;
        if (sscanf(argv[i], "--ratio=%f:%f", &rw, &rh) == 2 && rw > 0 && rh > 0) {
            SDL_SetWindowFullscreen(uvzWindow, 0);
            SDL_SetWindowSize(uvzWindow, (int)lroundf(720.0f * rw / rh), 720);
        }
    }
#endif
    initFont();
    recalculateDisplayLayout();
    applyFramePacing();
    detectGraphicsCaps();
    buildArt();
    initAudio();
    startRun(true);
    gState = TITLE; aMode = 1; menuT = 0;

    bool running = true;
    Uint64 last = SDL_GetPerformanceCounter();
    while (running) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            switch (e.type) {
                case SDL_QUIT: running = false; break;
                case SDL_WINDOWEVENT: {
                    const Uint8 we = e.window.event;
                    const bool sizeEv = we == SDL_WINDOWEVENT_SIZE_CHANGED || we == SDL_WINDOWEVENT_RESIZED;
                    if (sizeEv || we == SDL_WINDOWEVENT_EXPOSED || we == SDL_WINDOWEVENT_FOCUS_GAINED) {   // also re-reads insets after rotation / immersive changes
                        int ow = 0, oh = 0; SDL_GetRendererOutputSize(uvzRenderer, &ow, &oh);
#ifdef __ANDROID__
                        const bool relayout = true;
#else
                        const bool relayout = sizeEv || ow != uvzOutputWidth || oh != uvzOutputHeight;   // skip the texture rebuild when nothing changed
                        if (sizeEv && !fsRecent()) cfg.full = windowIsFullscreen();   // the OS left (or entered) fullscreen on its own: keep the setting truthful
#endif
                        if (relayout) { recalculateDisplayLayout(); applyFramePacing(); }
                        releaseAll();
                    }
                    if (we == SDL_WINDOWEVENT_FOCUS_LOST) { releaseAll(); if (gState == PLAYING && !fsRecent()) gState = PAUSED; }   // a focus blip during a fullscreen switch must not pause the run
                } break;
                case SDL_APP_WILLENTERBACKGROUND:
                    releaseAll(); if (gState == PLAYING) gState = PAUSED; saveCfg();
                    if (gAud) SDL_PauseAudioDevice(gAud, 1);
                    break;
                case SDL_APP_DIDENTERFOREGROUND:
                    if (gAud && audioStarted) SDL_PauseAudioDevice(gAud, 0);
                    break;
                case SDL_FINGERDOWN: fingerDown(e.tfinger); break;
                case SDL_FINGERMOTION: fingerMove(e.tfinger); break;
                case SDL_FINGERUP: fingerUp(e.tfinger); break;
                case SDL_KEYDOWN: {
                    SDL_Scancode sc = e.key.keysym.scancode;
                    startAudio();
                    if (fullscreenKey(sc, e.key.keysym.mod, e.key.repeat != 0)) break;
                    if (gState == TITLE) { if (!e.key.repeat) enterMenu(); break; }
                    if (gRebind >= 0) {
                        if (e.key.repeat) break;
                        if (sc == SDL_SCANCODE_ESCAPE) { gRebind = -1; sfx(4); }
                        else { assignKey(gRebind, sc); gRebind = -1; }
                        break;
                    }
                    if (sc == SDL_SCANCODE_AC_BACK || sc == SDL_SCANCODE_ESCAPE) {
                        if (e.key.repeat) break;
                        if (gState == PLAYING) gState = PAUSED;
                        else if (gState == PAUSED) gState = PLAYING;
                        else if (isSub(gState)) activate(B_BACK);
                        break;
                    }
                    if (gState == PLAYING) {
                        if (e.key.repeat) break;
                        if (sc == ctl.key[A_JUMP]) jumpEdge = true;
                        if (sc == ctl.key[A_SLIDE]) {
                            if (ironHeldNow()) { gIronFwdEdge = true; gIronKeyUsed = true; }   // Iron Arms key held + SLIDE = forward launch
                            else slideEdge = true;
                        }
                        if (sc == SDL_SCANCODE_E && ironButtonShown()) {                      // fixed key (E), unless the player bound it to something else
                            bool taken = false;
                            for (int j = 0; j < A_N; j++) if (ctl.key[j] == SDL_SCANCODE_E) taken = true;
                            if (!taken) { gIronKeyDown = true; gIronKeyUsed = false; }
                        }
                        if (sc == SDL_SCANCODE_Z) zipEdge = true;
                        if (sc == ctl.key[A_PAUSE]) { gState = PAUSED; sfx(4); }
                    } else if (gState == PAUSED && sc == ctl.key[A_PAUSE]) gState = PLAYING;
                    else menuKey(sc);
                } break;
                case SDL_KEYUP:
                    if (gState == PLAYING && e.key.keysym.scancode == ctl.key[A_JUMP]) jumpRel = true;
                    if (e.key.keysym.scancode == SDL_SCANCODE_E && gIronKeyDown) {
                        gIronKeyDown = false;
                        if (!gIronKeyUsed && ironButtonShown()) gIronUpEdge = true;          // tapped: upward launch
                    }
                    break;
                case SDL_MOUSEMOTION: mouseHover(e.motion.x, e.motion.y); break;
                default: break;
            }
        }
        Uint64 now = SDL_GetPerformanceCounter();
        double dt = (double)(now - last) / (double)SDL_GetPerformanceFrequency();
        last = now;
        const double rawDt = dt;
        dt = std::min(dt, 0.05);
        // Automatic optimiser: while playing, watch real frame times and trade effect detail for a steady frame rate (and win it back when it holds).
        { static bool wasPlaying = false;
          if (gState == PLAYING && !wasPlaying) { gGov.ema = 0; gGov.slowT = 0; }
          wasPlaying = gState == PLAYING;
          if (gState == PLAYING && !portrait && (gFx.shadows || gFx.ao || gFx.reflections) &&
              gGov.update((float)rawDt, gfxcfg::targetFpsFor(fpsCap(), gDisplayHz), gGfx.perf, gfxcfg::maxGovernorLevel(gGfx.perf))) gfxRefresh(); }
        gTime += dt;
        if (fadeIn > 0) fadeIn -= (float)dt;
        if (!portrait) {
            if (gState == PLAYING) updateGame(dt);
            else if (gState == GAME_OVER) {
                gImpactT -= (float)dt;
                for (auto& q : parts) if (q.alive) { q.life -= (float)dt; if (q.life <= 0) q.alive = false; }
            }
            if (gMenuIdle && (gState == TITLE || gState == MAIN_MENU || isSub(gState))) {
                updateTraffic((float)dt);               // the city is alive behind the menu
                gRunPhase += (float)dt * 0.83f;         // idle breathing
                for (auto& q : parts) if (q.alive) { q.life -= (float)dt; if (q.life <= 0) q.alive = false; }
            }
            if (gState == MAIN_MENU && trans >= 0) {
                trans += (float)dt / MENU_SEQ_SECS;
                if (trans >= 1.0f) { trans = -1; beginRunFromMenu(); }
            }
        }
        render(dt);
        if (gState != CREDITS && (gCreditsTex || gCreditsTried)) unloadCreditsImage();
        paceFrame();
    }
    saveCfg();
    shutdownResources();
    SDL_Quit();
    return 0;
}
